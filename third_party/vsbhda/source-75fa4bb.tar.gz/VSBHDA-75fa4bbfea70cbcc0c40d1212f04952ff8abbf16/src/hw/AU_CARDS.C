//**************************************************************************
//*                     This file is part of the                           *
//*                      Mpxplay - audio player.                           *
//*                  The source code of Mpxplay is                         *
//*        (C) copyright 1998-2015 by PDSoft (Attila Padar)                *
//*                 http://mpxplay.sourceforge.net                         *
//*                  email: mpxplay@freemail.hu                            *
//**************************************************************************
//*  This program is distributed in the hope that it will be useful,       *
//*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *
//*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                  *
//*  Please contact with the author (with me) if you want to use           *
//*  or modify this source.                                                *
//**************************************************************************
//function: audio main functions

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include "CONFIG.H"
#include "AU_CARDS.H"
#include "DMABUFF.H"

//#define DMABUFFLOG /* activate in case of DMA buffer handling issues */

extern uint8_t bOMode;

#ifndef NOES1371
extern struct sndcard_info_s ES1371_sndcard_info;
#endif
#ifndef NOICH
extern struct sndcard_info_s ICH_sndcard_info;
#endif
#ifndef NOHDA
extern struct sndcard_info_s HDA_sndcard_info;
#endif
#ifndef NOVIA82
extern struct sndcard_info_s VIA82XX_sndcard_info;
#endif
#ifndef NOSBLIVE
extern struct sndcard_info_s SBALL_sndcard_info;
#endif

static const struct sndcard_info_s *sndcard_info_table[] = {
#ifndef NOES1371
	&ES1371_sndcard_info,
#endif
#ifndef NOICH
	&ICH_sndcard_info,
#endif
#ifndef NOHDA
	&HDA_sndcard_info,
#endif
#ifndef NOSBLIVE
	&SBALL_sndcard_info,
#endif
#ifndef NOVIA82
	&VIA82XX_sndcard_info,
#endif
};

#define NUMCARDS sizeof(sndcard_info_table)/sizeof(sndcard_info_table[0])

/* gap between buffer read/write pointer;
 * since v2.0, AU_writedata() won't skip samples that exceed free buffer space;
 * to avoid sound distorsion, the free space reported by AU_cardbuf_space()
 * has to be reduced.
 * the amount of the reduction depends on:
 * - the ratio SB frequency / hardware frequency
 * - usage of ADPCM
 * if ADPCM is 2-bit, SB freq is 4110 and hardware freq is 41100
 * there may be 3 * 10 exceeding samples = 120 bytes!
 */
#define BUFFER_PROTECTION_DEFAULT 64

#ifdef _DEBUG
int max_spaceexc; /* max no of bytes exceeding free dma buffer space */
#endif

/* scan for audio devices */

void * FAREXP AU_init( const struct globalvars *gvars )
///////////////////////////////////////////////////////
{
	struct audioout_info_s *aui;
	int i;

#ifdef NOTFLAT
# ifdef _DEBUG
	if ( gvars->logfile )
		bOMode = OM_BUFFERED;
# endif
#endif

	dbgprintf(("AU_init\n"));
	if ( !( aui = (struct audioout_info_s *)calloc( 1, sizeof( struct audioout_info_s ) ) ) ) {
		dbgprintf(("AU_init: out of memory\n"));
		return(NULL);
	}
	/* v1.7: global settings can be accessed directly - card_select_ variables removed */
	aui->gvars = gvars;

	for ( i = 0; i < NUMCARDS; i++ ) {
		aui->card_handler = sndcard_info_table[i];
		if( aui->card_handler->card_detect ) {
			if (!(aui->card_private_data = calloc( 1, aui->card_handler->private_data_size ))) {
				dbgprintf(("AU_init: calloc() failed for private data\n" ));
				break;
			}
			dbgprintf(("AU_init: checking card %s\n", aui->card_handler->shortname));
			aui->card_wave_id = WAVEID_PCM_SLE; // integer pcm
			aui->freq_card = gvars->freq;
			aui->chan_card = 2;
			aui->bits_card = 16;
			aui->card_irq = 0xff;
			/* v2.0: buffer protection bytes is configurable now */
			aui->buffer_protection = gvars->buffer_protection ? gvars->buffer_protection : BUFFER_PROTECTION_DEFAULT;
			if ( aui->card_handler->card_detect(aui) ) {
				if( !aui->card_handler->cardbuf_getpos ) {
					dbgprintf(("AU_init: ERROR, cardbuf_getpos()=NULL!\n"));
				} else {
					//aui->freq_card = aui->chan_card = aui->bits_card = 0;
					dbgprintf(("AU_init: found card %s\n", aui->card_handler->shortname));
					return(aui);
				}
			}
			free( aui->card_private_data );
			aui->card_private_data = NULL;
		}
	}

	dbgprintf(("AU_init: no card found\n"));
	free( aui );
	return(NULL);

}

int FAREXP AU_getirq( struct audioout_info_s *aui )
///////////////////////////////////////////////////
{
    return( aui->card_irq );
}

char * FAREXP AU_getshortname( struct audioout_info_s *aui )
////////////////////////////////////////////////////////////
{
    return( aui->card_handler->shortname );
}

int FAREXP AU_getfreq( struct audioout_info_s *aui )
////////////////////////////////////////////////////
{
    return( aui->freq_card );
}

int FAREXP AU_isirq( struct audioout_info_s *aui )
//////////////////////////////////////////////////
{
    /* check if the irq belongs to the sound card */
    return( aui->card_handler->irq_routine(aui) );
}

#if 0 /* v2.0: cardbuf_clear() removed */
static void AU_clearbuffs( struct audioout_info_s *aui )
////////////////////////////////////////////////////////
{
	if(aui->card_handler->cardbuf_clear)
		aui->card_handler->cardbuf_clear(aui);
	aui->card_ctrlbits &= ~AUI_CARDCTRLBIT_DMACLEAR;
	return;
}
#endif

#if 0
void AU_setsamplenum( struct audioout_info_s *aui, int samples )
////////////////////////////////////////////////////////////////
{
    aui->samplenum = samples ;
    return;
}
#endif

#if 0
void FAREXP AU_prestart( struct audioout_info_s *aui )
//////////////////////////////////////////////////////
{
	if( aui->card_ctrlbits & AUI_CARDCTRLBIT_DMACLEAR )
		AU_clearbuffs(aui);
	return;
}
#endif

void FAREXP AU_start( struct audioout_info_s *aui )
///////////////////////////////////////////////////
{
	if( !(aui->card_infobits & AUI_CARDINFOBIT_PLAYING ) ) {
		//if( aui->card_ctrlbits & AUI_CARDCTRLBIT_DMACLEAR )
		//	AU_clearbuffs(aui);
		if( aui->card_handler->card_start )
			aui->card_handler->card_start( aui );
		aui->card_infobits |= AUI_CARDINFOBIT_PLAYING;
	}
#ifdef NOTFLAT
	if ( bOMode == OM_DOS ) bOMode = OM_DIRECT;  /* no DOS output anymore */
#endif
	dbgprintf(("AU_start: card ctrlbits=%X infobits=%X\n", aui->card_ctrlbits, aui->card_infobits));
	dbgprintf(("AU_start: card dmasize=0x%X dmalastput=0x%X dmaspace=%u buffer_protection=%u\n", aui->card_dmasize, aui->card_dmalastput, aui->card_dmaspace, aui->buffer_protection));
	dbgprintf(("AU_start: card bytespersign=%u sampleshift=%u\n", aui->card_bytespersign, aui->sampleshift_card));
	dbgprintf(("AU_start: freq_card=%u, chan_card=%u, bits_card=%u\n", aui->freq_card, aui->chan_card, aui->bits_card));
	return;
}

void FAREXP AU_stop( struct audioout_info_s *aui )
//////////////////////////////////////////////////
{
	if( aui->card_infobits & AUI_CARDINFOBIT_PLAYING ) {
		aui->card_infobits &= ~AUI_CARDINFOBIT_PLAYING;
		if( aui->card_handler && aui->card_handler->card_stop )
			aui->card_handler->card_stop( aui );
		//aui->card_dmaspace = aui->card_dmasize - aui->card_dmalastput;
	}
	return;
}

void FAREXP AU_close( struct audioout_info_s *aui )
///////////////////////////////////////////////////
{
	if(!aui)
		return;
	AU_stop(aui);
	if(aui->card_handler && aui->card_handler->card_close)
		aui->card_handler->card_close(aui);
#ifdef _DEBUG
	if ( max_spaceexc )
		dbgprintf(("AU_close: max_spaceexc=%u\n", max_spaceexc ));
#endif
	return;
}

/* AU_setrate() is called by main(), not during interrupt time! */

int FAREXP AU_setrate( struct audioout_info_s *aui, int freq, int outchannels, int bits )
/////////////////////////////////////////////////////////////////////////////////////////

{
	dbgprintf(("AU_setrate(freq=%u, chan=%u, bits=%u) enter, freq_card=%u\n", freq, outchannels, bits, aui->freq_card ));

	if ( aui->card_infobits & AUI_CARDINFOBIT_PLAYING )
		AU_stop(aui);

	aui->freq_card = freq; /* may be modified below by card_setrate() */
	aui->chan_card = outchannels;
	aui->bits_card = bits;
	aui->card_wave_id = WAVEID_PCM_SLE; // integer pcm

	if( aui->card_handler->card_setrate )
		aui->card_handler->card_setrate(aui);

	if(aui->card_wave_id == WAVEID_PCM_FLOAT)
		aui->sampleshift_card = 2;
	else
		aui->sampleshift_card = (aui->bits_card > 16) ? 2 : ( aui->bits_card >> 4 );

	//aui->card_ctrlbits |= AUI_CARDCTRLBIT_DMACLEAR;  /* triggers running AU_clearbuffs(); v2.0: obsolete */

	aui->card_bytespersign = aui->chan_card * ( 1 << aui->sampleshift_card );
	return( aui->freq_card );
}

void FAREXP AU_setmixer_init( struct audioout_info_s *aui )
///////////////////////////////////////////////////////////
{
	unsigned int i;

	aui->card_master_volume = -1;

	for( i = 0; i < AU_MIXCHANS_NUM; i++ )
		aui->card_mixer_values[i] = -1;
	return;
}

static const struct aucards_mixerchan_s *AU_search_mixerchan( const struct aucards_mixerchan_s *mixeri[], unsigned int mixchannum )
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
{
	while(*mixeri){
		if((*mixeri)->channel == mixchannum)
			return (*mixeri);
		mixeri++;
	}
	return NULL;
}

/* set mixer volume for "mixchannum" (0-10):
 * MASTER, PCM, HEADPHONE, SPDIF, SYNTH, MICIN, ...
 * defined by SC_xxx mixerset...
 */

void FAREXP AU_setmixer_one( struct audioout_info_s *aui, unsigned int channel, int function, unsigned int setmode, int newvalue )
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
{
	const struct sndcard_info_s *cardi;
	const struct aucards_mixerchan_s *onechi; // one mixer channel infos (master,pcm,etc.)
	unsigned int subchannelnum, sch;
	long newpercentval, maxpercentval;

	dbgprintf(("AU_setmixer_one( channel=%u, setmode=%u, newvalue=%u )\n", channel, setmode, newvalue ));
	//mixer structure/values verifying

	//function = AU_MIXCHANFUNCS_GETFUNC(mixchannum);
	if( function >= AU_MIXCHANFUNCS_NUM )
		return;
	//channel = AU_MIXCHANFUNCS_GETCHAN(mixchannum);
	if( channel >= AU_MIXCHANS_NUM )
		return;
	cardi = aui->card_handler;
	if(!cardi)
		return;
	if(!cardi->card_writemixer || !cardi->card_readmixer || !cardi->card_mixerchans)
		return;
	onechi = AU_search_mixerchan( cardi->card_mixerchans, channel );
	if(!onechi)
		return;
	subchannelnum = onechi->subchannelnum;
	dbgprintf(("AU_setmixer_one: function=%u, channel=%u, subchannelnum=%u\n", function, channel, subchannelnum ));
	if( !subchannelnum || (subchannelnum > AU_MIXERCHAN_MAX_SUBCHANNELS) )
		return;

	maxpercentval = AU_MIXCHAN_MAX_VALUE_VOLUME;

	//calculate new percent
	switch( setmode ) {
	case MIXER_SETMODE_ABSOLUTE:
		newpercentval = newvalue;
		dbgprintf(("AU_setmixer_one: set newpercentval to %u %% )\n", newvalue ));
		break;
	case MIXER_SETMODE_RELATIVE:
		if(function == AU_MIXCHANFUNC_VOLUME)
			newpercentval = aui->card_mixer_values[channel] + newvalue;
		else
			if(newvalue < 0)
				newpercentval = 0;
			else
				newpercentval = maxpercentval;
		break;
	default:
		return;
	}
	if( newpercentval < 0 )
		newpercentval = 0;

	if(newpercentval > maxpercentval)
		newpercentval = maxpercentval;

	//read current register value, mix it with the new one, write it back
	for( sch = 0; sch < subchannelnum; sch++ ){
		const struct aucards_submixerchan_s *subchi = &(onechi->submixerchans[sch]); // one subchannel infos (left,right,etc.)
		unsigned long currchval,newchval,maxchval;

		maxchval = (1 << subchi->submixch_bits) - 1;
		/* vsbhda: if card handles mixer setting on its own then don't check subchannel settings */
		if( !( subchi->submixch_infobits & SUBMIXCH_INFOBIT_CARD_SETVOL ) ) {
			/* invalid subchannel infos? */
			if((subchi->submixch_register > AU_MIXERCHAN_MAX_REGISTER) || !maxchval || (subchi->submixch_shift > AU_MIXERCHAN_MAX_BITS)) {
				dbgprintf(("AU_setmixer_one: setting mixer ignored due to invalid subchannel info (reg=%u, max=%u, shift=%u)\n",
						   subchi->submixch_register, maxchval, subchi->submixch_shift ));
				continue;
			}
		}

		/* vsbhda: if SUBMIXCH_INFOBIT_CARD_SETVOL==1, let the card handle the volume.
		 * Thus the values submixch_bits and submixch_shift aren't used.
		 */
		if ( subchi->submixch_infobits & SUBMIXCH_INFOBIT_CARD_SETVOL ) {
			dbgprintf(("AU_setmixer_one: calling card_writemixer(%u)\n", newpercentval ));
			cardi->card_writemixer( aui, subchi->submixch_register, newpercentval );
		} else {
			/* vsbhda: don't use floats here - function may be called during interrupt time */
			//newchval=(long)(((float)newpercentval * (float)subchi->submixch_max + ((float)((maxpercentval >> 1) - 1)))/(float)maxpercentval);   // percent to chval (rounding up)
			newchval = (((int64_t)newpercentval * maxchval + (((maxpercentval >> 1) - 1))) / maxpercentval);   // percent to chval (rounding up)
			dbgprintf(("AU_setmixer_one: newchval=%X max=%X\n", newchval, maxchval ));
			if( newchval > maxchval)
				newchval = maxchval;
			if( subchi->submixch_infobits & SUBMIXCH_INFOBIT_REVERSEDVALUE )   // reverse value if required
				newchval = maxchval - newchval;
			dbgprintf(("AU_setmixer_one: newchval=%X\n", newchval ));

			newchval <<= subchi->submixch_shift;                             // shift to position
			dbgprintf(("AU_setmixer_one: newchval=%X after shift\n", newchval ));

			currchval = cardi->card_readmixer( aui, subchi->submixch_register);// read current value
			dbgprintf(("AU_setmixer_one: called card_readmixer(%X)=%X (max=%X, shift=%u)\n", subchi->submixch_register, currchval, maxchval, subchi->submixch_shift ));
			currchval &= ~(maxchval << subchi->submixch_shift);  // unmask
			newchval = (currchval | newchval);                               // add new value

			dbgprintf(("AU_setmixer_one: calling card_writemixer(%X, %X) [currchval=%X]\n", subchi->submixch_register, newchval, currchval ));
			cardi->card_writemixer( aui, subchi->submixch_register, newchval);  // write it back
		}
	}

	if( function == AU_MIXCHANFUNC_VOLUME )
		aui->card_mixer_values[channel] = newpercentval;

	return;
}

#define AU_MIXCHANS_OUTS 4

/* for AC97, there's another out channel, AU_MIXCHAN_SYNTH (see AU_CARDS.H) */

static const unsigned int au_mixchan_outs[AU_MIXCHANS_OUTS] = {
	AU_MIXCHAN_MASTER, AU_MIXCHAN_PCM, AU_MIXCHAN_HEADPHONE, AU_MIXCHAN_SPDIFOUT };

/* set the volumes of "output channels:", defined in array above.
 * for VSBHDA, this is actually the mixer function that's used for volume setting;
 * setmode == SETMODE_ABSOLUTE.
 */

void FAREXP AU_setmixer_outs( struct audioout_info_s *aui, unsigned int setmode, int newvalue )
///////////////////////////////////////////////////////////////////////////////////////////////
{
	unsigned int i;

	for( i = 0; i < AU_MIXCHANS_OUTS; i++ )
		AU_setmixer_one( aui, au_mixchan_outs[i], AU_MIXCHANFUNC_VOLUME, setmode, newvalue );

	aui->card_master_volume = aui->card_mixer_values[AU_MIXCHAN_MASTER];

	return;
}

#if 0

/* called by AU_setmixer_all() */

static int AU_getmixer_one( struct audioout_info_s *aui, unsigned int mixchannum )
//////////////////////////////////////////////////////////////////////////////////
{
	const struct sndcard_info_s *cardi;
	const struct aucards_mixerchan_s *onechi;    // one mixer channel infos (master,pcm,etc.)
	const struct aucards_submixerchan_s *subchi; // one subchannel infos (left,right,etc.)
	unsigned long channel,function,subchannelnum;
	long value,maxpercentval,maxchval;

	//mixer structure/values verifying
	function = AU_MIXCHANFUNCS_GETFUNC(mixchannum);
	if(function >= AU_MIXCHANFUNCS_NUM)
		return -1;
	channel = AU_MIXCHANFUNCS_GETCHAN(mixchannum);
	if(channel > AU_MIXCHANS_NUM)
		return -1;
	cardi = aui->card_handler;
	if(!cardi)
		return -1;
	if(!cardi->card_readmixer || !cardi->card_mixerchans)
		return -1;
	onechi = AU_search_mixerchan(cardi->card_mixerchans,mixchannum);
	if(!onechi)
		return -1;
	subchannelnum = onechi->subchannelnum;
	if(!subchannelnum || (subchannelnum > AU_MIXERCHAN_MAX_SUBCHANNELS))
		return -1;

	maxpercentval = AU_MIXCHAN_MAX_VALUE_VOLUME;

	// we read one (the left at stereo) sub-channel only
	subchi = &(onechi->submixerchans[0]);
	if((subchi->submixch_register > AU_MIXERCHAN_MAX_REGISTER) || (subchi->submixch_shift > AU_MIXERCHAN_MAX_BITS)) { // invalid subchannel infos
		dbgprintf(("AU_getmixer_one(channel=%u, func=%u): don't like subchannel info (%u %u)!\n", channel, function, subchi->submixch_register, subchi->submixch_shift ));
		return -1;
	}

	value = cardi->card_readmixer( aui, subchi->submixch_register );

	/* vsbhda: if SUBMIXCH_INFOBIT_CARD_SETVOL==1, just return the plain value -
	 * it's a volume percentage already. Thus it's ensured that the values in submixch_shift/max
	 * are never used.
	 */
    if ( !( subchi->submixch_infobits & SUBMIXCH_INFOBIT_CARD_SETVOL ) ) {
        maxchval = (1 << subchi->submixch_bits) - 1;
		value >>= subchi->submixch_shift;                         // shift
		value &= maxchval;                                        // mask

		if(subchi->submixch_infobits & SUBMIXCH_INFOBIT_REVERSEDVALUE)// reverse value if required
			value = maxchval - value;

		/* vsbhda: no float usage here! */
		//value=(long)((float)value * (float)maxpercentval / (float)subchi->submixch_max); // chval to percent
		value = value * maxpercentval / maxchval; // chval to percent
		if( value > maxpercentval )
			value = maxpercentval;
	}
	dbgprintf(("AU_getmixer_one(channel=%u, func=%u)=%d)\n", channel, function, value ));
	return value;
}

/* set the volumes of all (output) "channels" that aren't set yet */

void FAREXP AU_setmixer_all( struct audioout_info_s *aui )
//////////////////////////////////////////////////////////
{
	unsigned int i;
	int vol = aui->card_master_volume;

	dbgprintf(("AU_setmixer_all: vol=%d)\n", vol ));
	/* reinit all output channels that haven't been set yet to the master volume */
	if( vol >= 0 )
		for( i = 0; i < AU_MIXCHANS_OUTS; i++)
			if( aui->card_mixer_values[au_mixchan_outs[i]] < 0 )
				aui->card_mixer_values[au_mixchan_outs[i]] = vol;

	/* either
	 * - set volume of out channels that haven't been set yet to the master volume OR
	 * - get volume of the other channels
	 */
	for( i = 0; i < AU_MIXCHANS_NUM; i++ ){
		vol = aui->card_mixer_values[i];
		if( vol >= 0 ){
			AU_setmixer_one(aui,AU_MIXCHANFUNCS_PACK( i, AU_MIXCHANFUNC_VOLUME ), MIXER_SETMODE_ABSOLUTE, vol );
		} else {
			vol = AU_getmixer_one(aui,AU_MIXCHANFUNCS_PACK( i, AU_MIXCHANFUNC_VOLUME ));
			if( vol >= 0 )
				aui->card_mixer_values[i] = vol;
		}
	}
	return;
}
#endif

/* functions AU_cardbuf_space() and AU_writedata() handle the hardware ring buffer:
 * - AU_cardbuf_space calculates the "free" space in the ring buffer (= aui->card_dmaspace, in byte units)
 * - AU_writedata writes into free space and updates the write pointer (= aui->card_dmalastput)
 */

unsigned int FAREXP AU_cardbuf_space( struct audioout_info_s *aui )
///////////////////////////////////////////////////////////////////
{
	unsigned int bufpos;
#ifdef DMABUFFLOG
	unsigned int old_card_dmaspace = aui->card_dmaspace;
#endif

	/* v2.0: the only function that should update card_dmalastput is AU_writedata()! */
	//if( aui->card_dmalastput >= aui->card_dmasize ) /* ensure write pointer is valid */
	//	aui->card_dmalastput = 0;

	bufpos = aui->card_handler->cardbuf_getpos(aui);
	bufpos %= aui->card_dmasize;
	bufpos -= (bufpos % aui->card_bytespersign);

	/* cardbuf_getpos() may either return a position or a space */
	if( aui->card_handler->infobits & SNDCARD_CARDBUF_SPACE ) {
		aui->card_dmaspace = bufpos;
	} else {
#if 0 /* currently DMA underrun bit is nowhere set */
		if( aui->card_infobits & AUI_CARDINFOBIT_DMAUNDERRUN ) {
			dbgprintf(("AU_cardbuf_space: DMA underrun occurred\n"));
			aui->card_dmalastput = bufpos; /* sets a new put-pointer in this case */
			aui->card_infobits &= ~AUI_CARDINFOBIT_DMAUNDERRUN;
		}
#endif
		if( bufpos > aui->card_dmalastput )
			aui->card_dmaspace = bufpos - aui->card_dmalastput;
		else
			aui->card_dmaspace = bufpos + aui->card_dmasize - aui->card_dmalastput;
	}

	//if( aui->card_dmaspace > aui->card_dmasize ) // checking
	//	aui->card_dmaspace = aui->card_dmasize;
#ifdef DMABUFFLOG
	dbgprintf(("AU_cardbuf_space: bufpos=%X, card_dmaspace new/old=%X/%X card_dmalastput=%X\n", bufpos, aui->card_dmaspace, old_card_dmaspace, aui->card_dmalastput ));
#endif

    return (aui->card_dmaspace > aui->buffer_protection) ? aui->card_dmaspace - aui->buffer_protection: 0;

}

/* AU_writedata(): calls card's writedata() and updates ring buffer's write pointer (=card_dmalastput).
 * v2.0: all checks and limitations removed. If more samples are provided than card_dmaspace can hold,
 * they are accepted - should be no problem at all.
 */

int FAREXP AU_writedata( struct audioout_info_s *aui, char *pData, unsigned int samples )
/////////////////////////////////////////////////////////////////////////////////////////
{
#ifdef DMABUFFLOG
	unsigned int old_card_dmalastput = aui->card_dmalastput;
#endif
#ifdef _DEBUG
	{
		int tmp = ( samples << aui->sampleshift_card ) - aui->card_dmaspace;
		if ( tmp > max_spaceexc )
			max_spaceexc = tmp;
	}
#endif

	aui->card_handler->cardbuf_writedata( aui, pData, samples << aui->sampleshift_card );
	aui->card_dmalastput += samples << aui->sampleshift_card;
	aui->card_dmalastput %= aui->card_dmasize;

#ifdef DMABUFFLOG
    dbgprintf(("AU_writedata(samples=%u [bytes=%u]): exit, card_dmalastput new/old=%X/%X\n", samples, samples << aui->sampleshift_card, aui->card_dmalastput, old_card_dmalastput ));
#endif
	return 1;
}
