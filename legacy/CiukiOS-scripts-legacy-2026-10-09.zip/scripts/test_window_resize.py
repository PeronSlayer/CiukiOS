#!/usr/bin/env python3
"""Execute the real 16-bit resize, hit-test and cursor routines on a CPU fixture.

Run: uv run --with unicorn python scripts/test_window_resize.py
Framebuffer transfers model the documented row ABI, not a graphics device.
"""
import json
import contextlib
import io
import struct
import subprocess
import tempfile
from pathlib import Path

from unicorn import (Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR,
                     UC_HOOK_INSN, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE)
from unicorn import x86_const as x

import build_cursors
from test_vmfork_launch_diagnostics import symbols

ROOT = Path(__file__).resolve().parents[1]


def between(path, start, end):
    return (ROOT / path).read_text().split(start, 1)[1].split(end, 1)[0]


def assemble(directory):
    source = 'bits 16\norg 100h\nUI_WINDOW_COUNT equ 32\n'
    source += 'ui_hits equ 0\nui_pointer_under equ 2000h\n'
    source += 'ui_cursor_table equ 4000h\nvc_pointer_row equ 4500h\n'
    source += '%define VC_POINTER_WORKSPACE_EXTERNAL 1\n'
    source += 'ui_cursor_enter_fixture:' + between('src/com/shell_gui.inc', 'ui_enter:', '    call ui_assets_begin') + '\nret\n'
    source += 'ui_cursor_video_fixture:' + between('src/com/shell_gui.inc', 'ui_video_begin:', '    ; Save client mouse state') + '\nret\n'
    source += 'ui_hit_find:' + between('src/com/shell_gui.inc', 'ui_hit_find:', '; Item records:')
    source += 'ui_windows_hit:' + between('src/com/shell_gui_windows.inc', 'ui_windows_hit:', 'ui_windows_cycle:')
    source += '%include "src/com/shell_gui_resize.inc"\n'
    source += 'ui_pointer_hide:' + (ROOT / 'src/com/shell_gui_input.inc').read_text().split('ui_pointer_hide:', 1)[1]
    source += 'app_s_cursor:' + between('src/com/shell_apps.inc', 'app_s_cursor:', '; Display module only.')
    source += 'vc_store_pixel:' + between('src/com/vbe_fb.inc', 'vc_store_pixel:', '; Linear framebuffer bursts')
    source += 'ui_production_styles ' + between('src/com/shell_apps.inc', '\napp_win_style ', '\napp_ev_window ')
    source += '''
ui_assets_seg dw 5000h
ui_vbe db 1
ui_front_base dd 0
ui_width dw 800
ui_height dw 600
ui_window_visible db 0
ui_maximized db 0
ui_wx dw 100
ui_wy dw 100
ui_ww dw 510
ui_wh dw 370
ui_window_drag db 3
ui_hit_target db 0
ui_hit_count dw 0
ui_last_hit_ptr dw 0
ui_button_down db 0
app_overlay db 0
app_win_slot times 32 db 0FFh
app_win_style times 32 db 0
app_saved_w times 32 dw 0
ui_window_order times 32 db 0
ui_window_flags times 32 db 0
ui_window_x times 32 dw 0
ui_window_y times 32 dw 0
ui_window_width times 32 dw 0
ui_window_height times 32 dw 0
vc_bytes db 4
vc_pitch dw 3200
vc_frame_bytes dd 1920000
vc_info times 256 db 0
vc_colors times 16 dd 0
vc_fb_read db 0
damage_count dw 0
ui_previous_width dw 0
ui_previous_height dw 0
app_capture db 0
ui_full_redraw db 0
ui_motion_phase db 0
ui_video_wait_release:
ui_sound_preference:
ui_icons_begin:
    ret
ui_comp_damage_drag:
    inc word [damage_count]
    ret
ui_library_focus_clamp:
    ret
vc_fb_put_rows:
    mov byte [cs:vc_fb_read],0
vc_fb_rows:
    int 0F3h
    ret
ui_rect:
    int 0F4h
    ret
'''
    asm, binary, listing = (directory / n for n in ('resize.asm', 'resize.bin', 'resize.lst'))
    asm.write_text(source)
    subprocess.run(['nasm', '-f', 'bin', str(asm), '-o', str(binary), '-l', str(listing)],
                   cwd=ROOT, check=True)
    return binary.read_bytes(), symbols(listing.read_text())


class Machine:
    def __init__(self, program):
        image, self.labels = program
        self.u = Uc(UC_ARCH_X86, UC_MODE_16)
        self.u.mem_map(0, 0x100000)
        self.base, self.assets = 0x30000, 0x50000
        self.u.mem_write(self.base + 0x100, image)
        for reg in (x.UC_X86_REG_CS, x.UC_X86_REG_DS, x.UC_X86_REG_ES, x.UC_X86_REG_SS):
            self.u.reg_write(reg, 0x3000)
        self.u.reg_write(x.UC_X86_REG_FS, 0x5000)
        self.u.reg_write(x.UC_X86_REG_SP, 0xf000)
        self.u.hook_add(UC_HOOK_CODE, self.stop)
        self.u.hook_add(UC_HOOK_INTR, self.interrupt)
        self.u.hook_add(UC_HOOK_INSN, self.port_out, None, 1, 0, x.UC_X86_INS_OUT)
        self.u.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self.vga_memory,
                        None, 0xa0000, 0xaffff)
        self.file, self.file_pos, self.calls = b'', 0, []
        self.frame = bytearray()
        self.planes = [bytearray((i + k * 37) & 255 for i in range(38400)) for k in range(4)]
        self.plane, self.plane_mask = 0, 15
        self.transfers = []
        self.put('ui_mouse_ready', 1, 1)
        self.put('ui_window_order', 2, 1, 30)
        self.put('ui_window_order', 3, 1, 31)
        for slot, geometry in ((2, (100, 100, 500, 400)), (3, (200, 150, 400, 300))):
            self.put('ui_window_flags', 1, 1, slot)
            self.put('app_win_slot', slot, 1, slot)
            self.geometry(slot, geometry)

    def put(self, name, value, size=2, index=0):
        self.u.mem_write(self.base + self.labels[name] + index * size,
                         value.to_bytes(size, 'little', signed=value < 0))

    def get(self, name, size=2, index=0):
        return int.from_bytes(self.u.mem_read(self.base + self.labels[name] + index * size, size), 'little')

    def reg(self, name, value=None):
        register = getattr(x, 'UC_X86_REG_' + name.upper())
        if value is not None:
            self.u.reg_write(register, value)
        return self.u.reg_read(register)

    def stop(self, uc, address, size, data):
        if address == self.base + 0x80:
            uc.emu_stop()

    def run(self, label):
        self.reg('sp', self.reg('sp') - 2)
        self.u.mem_write(self.base + self.reg('sp'), b'\x80\0')
        self.u.emu_start(self.base + self.labels[label], 0x100000, count=100000)
        assert self.reg('ip') == 0x80, ('instruction bound', label)

    def geometry(self, slot, values=None):
        names = ('ui_window_x', 'ui_window_y', 'ui_window_width', 'ui_window_height')
        if values:
            for name, value in zip(names, values):
                self.put(name, value, index=slot)
        return tuple(self.get(name, index=slot) for name in names)

    def pointer(self, px, py):
        self.put('ui_mouse_x', px)
        self.put('ui_mouse_y', py)

    def hit(self, px, py):
        self.pointer(px, py)
        self.run('ui_hit_find')
        return self.reg('ax'), self.get('ui_resize_edge', 1), self.get('ui_hit_target', 1)

    def port_out(self, uc, port, size, value, data):
        assert size == 2 and port in (0x3ce, 0x3c4), (port, size)
        register, operand = value & 255, value >> 8
        if port == 0x3ce and register == 4:
            self.plane = operand
        if port == 0x3c4 and register == 2:
            self.plane_mask = operand

    def vga_memory(self, uc, access, address, size, value, data):
        from unicorn import UC_MEM_READ
        offset = address - 0xa0000
        assert 0 <= offset and offset + size <= 38400, ('VGA outside visible plane', offset, size)
        if access == UC_MEM_READ:
            uc.mem_write(address, bytes(self.planes[self.plane][offset:offset + size]))
        else:
            for plane in range(4):
                if self.plane_mask & (1 << plane):
                    self.planes[plane][offset:offset + size] = value.to_bytes(size, 'little')

    def interrupt(self, uc, number, data):
        if number == 0xf4:
            px, py = self.reg('bx'), self.reg('dx')
            if px < 640 and py < 480:
                pos, mask, color = py * 80 + px // 8, 0x80 >> (px % 8), self.reg('al')
                for i, plane in enumerate(self.planes):
                    plane[pos] = ((plane[pos] | mask) if color & (1 << i)
                                  else (plane[pos] & ~mask))
            return
        if number == 0xf3:
            offset, cols, rows = self.reg('edi'), self.reg('cx'), self.reg('dx')
            pitch, stride = self.get('vc_pitch'), self.reg('bx')
            src = self.reg('fs') * 16 + self.reg('si')
            assert cols > 0 and rows > 0
            for row in range(rows):
                begin = offset + row * pitch
                assert begin // pitch == (begin + cols - 1) // pitch, ('row wrap', begin, cols)
                assert 0 <= begin <= begin + cols <= len(self.frame), ('frame overflow', begin, cols)
                if self.get('vc_fb_read', 1):
                    uc.mem_write(src + row * stride, bytes(self.frame[begin:begin + cols]))
                else:
                    self.frame[begin:begin + cols] = uc.mem_read(src + row * stride, cols)
            self.transfers.append((offset, cols, rows, pitch, stride))
            return
        assert number == 0x21, number
        self.calls.append(self.reg('ax'))
        ah, result = self.reg('ah'), 0
        if ah == 0x3d:
            self.file_pos, result = 0, 7
        elif ah == 0x42:
            self.file_pos = (self.reg('cx') << 16) | self.reg('dx')
            result = self.file_pos
        elif ah == 0x3f:
            data = self.file[self.file_pos:self.file_pos + self.reg('cx')]
            uc.mem_write(self.reg('ds') * 16 + self.reg('dx'), data)
            self.file_pos += len(data)
            result = len(data)
        else:
            assert ah == 0x3e, hex(ah)
        self.reg('ax', result)
        self.reg('eflags', self.reg('eflags') & ~1)


def cursor_file():
    previous = build_cursors.ROOT
    try:
        with tempfile.TemporaryDirectory(prefix='ciuki-cursors-') as temporary:
            build_cursors.ROOT = Path(temporary)
            with contextlib.redirect_stdout(io.StringIO()):
                build_cursors.build()
            content = (build_cursors.ROOT / 'assets/cursors/CURSORS.DAT').read_bytes()
    finally:
        build_cursors.ROOT = previous
    assert len(content) == 1446 and struct.unpack_from('<8sHH', content) == (b'CIUKCUR2', 3, 478)
    return content


def test_resize(program):
    edges = [(200, 300, 1, 3), (599, 300, 2, 3), (400, 150, 4, 4),
             (400, 449, 8, 4), (200, 150, 5, 5), (599, 150, 6, 6),
             (200, 449, 9, 6), (599, 449, 10, 5)]
    for px, py, edge, cursor in edges:
        m = Machine(program)
        assert m.hit(px, py) == (65, edge, 4)
        m.run('ui_resize_hover')
        assert m.get('ui_cursor_type', 1) == cursor
        m.put('ui_dragging', 4, 1)
        m.run('ui_resize_begin')
        m.pointer(px + 30, py + 20)
        m.run('ui_hit_find')             # pointer now away from captured edge
        m.run('ui_resize_hover')
        assert m.get('ui_cursor_type', 1) == cursor
        m.run('ui_resize_apply')
        x0, y0 = 230 if edge & 1 else 200, 170 if edge & 4 else 150
        width = 370 if edge & 1 else 430 if edge & 2 else 400
        height = 280 if edge & 4 else 320 if edge & 8 else 300
        assert m.geometry(3) == (x0, y0, width, height), (edge, m.geometry(3))
        m.run('ui_resize_cancel')
        assert m.geometry(3) == (200, 150, 400, 300)
        assert m.get('ui_dragging', 1) == m.get('ui_button_down', 1) == 0
        assert m.get('damage_count') == 2
    for attr in ('app_win_style', 'app_saved_w', 'app_win_slot'):
        m = Machine(program)
        m.put(attr, 255 if attr == 'app_win_slot' else 1,
              2 if attr == 'app_saved_w' else 1, 3)
        assert m.hit(599, 449)[1] == 0, attr
    m = Machine(program)
    assert m.hit(400, 300) == (70, 0, 4)        # covered background right edge
    assert m.hit(100, 300) == (65, 1, 3)        # exposed background left edge
    m.put('app_overlay', 1, 1)
    assert m.hit(200, 150)[1] == 0
    m.put('ui_cursor_type', 5, 1)
    m.run('ui_resize_hover')
    assert m.get('ui_cursor_type', 1) == 0
    m = Machine(program)
    m.put('ui_hit_count', 1)
    m.u.mem_write(m.assets, struct.pack('<5H', 0, 0, 799, 599, (4 << 8) | 65))
    assert m.hit(40, 40) == (0, 0, 0), 'stale background control'
    for delta, near, size, low, high, minimum, edge, expected in [
        (-999, 200, 400, 4, 792, 320, 1, (4, 596)),
        (999, 200, 400, 4, 792, 320, 1, (280, 320)),
        (-999, 200, 400, 4, 792, 320, 2, (200, 320)),
        (999, 200, 400, 4, 792, 320, 2, (200, 592)),
        (999, 20, 80, 4, 196, 320, 2, (20, 176)),
        (999, 20, 80, 4, 196, 320, 1, (4, 96)),
        (999, 150, 300, 32, 563, 200, 0, (150, 300)),
    ]:
        m = Machine(program)
        for reg, value in zip(('ax', 'bx', 'cx', 'si', 'dx', 'di', 'bp'),
                              (delta & 65535, near, size, low, high, minimum, edge)):
            m.reg(reg, value)
        m.run('ui_resize_axis')
        assert (m.reg('bx'), m.reg('cx')) == expected
    m = Machine(program)
    m.put('ui_window_flags', 0, 1, 2)
    m.put('ui_window_flags', 0, 1, 3)
    m.put('ui_window_visible', 1, 1)
    assert m.hit(100, 100) == (61, 5, 1)
    m.put('ui_dragging', 2, 1)
    m.run('ui_resize_begin')
    m.pointer(200, 200)
    m.run('ui_resize_apply')
    assert (m.get('ui_ww'), m.get('ui_wh')) == (510, 370)
    m.put('ui_maximized', 1, 1)
    assert m.hit(100, 100)[1] == 0
    return {'eight_edges': 8, 'captured_cursor_and_escape': 8, 'axis_constraints': 7,
            'fixed_maximized_overlay_z_order_stale_hits': True, 'programs': True}


def test_resources(program):
    resource = cursor_file()
    m = Machine(program)
    for theme in range(3):
        m.file = resource
        m.reg('al', theme)
        m.run('ui_set_cursor_scheme')
        assert m.get('ui_cursor_loaded', 1) == 1
        table = resource[28 + theme * 478:28 + theme * 478 + 462]
        assert bytes(m.u.mem_read(m.assets + 0x4000, 462)) == table
        for shape in range(7):
            m.reg('ax', shape)
            m.run('app_s_cursor')
            actual = bytes(m.u.mem_read(m.base + m.labels['ui_pointer_black'], 64))
            assert actual == table[shape * 66:shape * 66 + 64]
    retained = bytes(m.u.mem_read(m.assets + 0x4000, 462))
    malformed = [resource[:6], b'CIUKCUR1' + resource[8:], resource[:-1],
                 resource[:10] + b'\xd6\0' + resource[12:]]
    bad_hotspot = bytearray(resource)
    bad_hotspot[28 + 2 * 478 + 64] = 16
    malformed.append(bytes(bad_hotspot))
    for content in malformed:
        m.file = content
        m.reg('al', 2)
        m.run('ui_set_cursor_scheme')
        assert bytes(m.u.mem_read(m.assets + 0x4000, 462)) == retained
    m = Machine(program)
    arrow = bytes(m.u.mem_read(m.base + m.labels['ui_pointer_black'], 64))
    m.file = resource[:6]
    m.run('ui_set_cursor_scheme')
    assert bytes(m.u.mem_read(m.base + m.labels['ui_pointer_black'], 64)) == arrow
    # Execute the production entry/video reset blocks: settings load the table
    # before video initialization, which must preserve it on boot/mode change.
    m.put('ui_cursor_loaded', 1, 1)
    m.run('ui_cursor_enter_fixture')
    assert m.get('ui_cursor_loaded', 1) == 0
    m.file = resource
    m.reg('al', 0)
    m.run('ui_set_cursor_scheme')
    for _ in range(2):
        m.run('ui_cursor_video_fixture')
        assert m.get('ui_cursor_loaded', 1) == 1
        m.reg('ax', 3)
        m.run('app_s_cursor')
        actual = bytes(m.u.mem_read(m.base + m.labels['ui_pointer_black'], 64))
        assert actual == resource[28 + 3 * 66:28 + 3 * 66 + 64]
    return {'themes': 3, 'shapes_per_theme': 7, 'malformed_atomic_rejection': 5,
            'new_assets_reset_and_video_init_preservation': True}


def test_window_policies(program):
    profiles = {12: (600, 400), 14: (442, 390), 20: (500, 270)}
    cases = 0
    for screen_w, screen_h in ((640, 480), (800, 600)):
        for slot, minimum in profiles.items():
            for edge in (1, 2, 4, 8, 5, 6, 9, 10):
                m = Machine(program)
                m.put('ui_width', screen_w)
                m.put('ui_height', screen_h)
                original = (4, 32, 620, min(460, screen_h - 69))
                m.geometry(slot, original)
                m.put('ui_window_drag', slot, 1)
                m.put('ui_dragging', 4, 1)
                m.put('ui_resize_edge', edge, 1)
                px = 4 if edge & 1 else 623
                py = 32 if edge & 4 else 31 + original[3]
                m.pointer(px, py)
                m.run('ui_resize_begin')
                m.pointer(screen_w - 1 if edge & 1 else 0,
                          screen_h - 1 if edge & 4 else 0)
                m.run('ui_resize_apply')
                got = m.geometry(slot)
                assert got[2] == (minimum[0] if edge & 3 else original[2])
                assert got[3] == (minimum[1] if edge & 12 else original[3])
                assert got[0] >= 4 and got[0] + got[2] <= screen_w - 8
                assert got[1] >= 32 and got[1] + got[3] <= screen_h - 37
                m.run('ui_resize_cancel')
                assert m.geometry(slot) == original
                cases += 1
    # A restored/legacy window may be below today's minimum. Escape must put
    # back its exact geometry instead of running it through the new clamp.
    m = Machine(program)
    original = (20, 80, 580, 360)
    m.geometry(12, original)
    m.put('ui_width', 640)
    m.put('ui_height', 480)
    m.put('ui_window_drag', 12, 1)
    m.put('ui_dragging', 4, 1)
    m.put('ui_resize_edge', 10, 1)
    m.pointer(599, 439)
    m.run('ui_resize_begin')
    m.pointer(40, 100)
    m.run('ui_resize_apply')
    assert m.geometry(12) == (20, 80, 600, 363)
    m.run('ui_resize_cancel')
    assert m.geometry(12) == original
    for slot in (1, 2, 18):
        m = Machine(program)
        style = m.get('ui_production_styles', 1, slot)
        assert style & 1, ('production fixed style', slot)
        m.put('app_win_style', style, 1, slot)
        m.put('app_win_slot', slot, 1, slot)
        m.put('ui_window_flags', 1, 1, slot)
        m.put('ui_window_order', slot, 1, 31)
        m.geometry(slot, (200, 150, 400, 300))
        assert m.hit(599, 300)[1] == 0
    return {'per_app_edge_and_resolution_cases': cases, 'fixed_production_styles': [1, 2, 18],
            'available_area_clamp_and_exact_escape_below_minimum': True}


def test_framebuffer(program):
    count = 0
    for bpp in (1, 2, 3, 4):
        for px, py in ((0, 0), (799, 0), (0, 599), (799, 599), (794, 593), (310, 200)):
            m = Machine(program)
            pitch, frame_bytes = 800 * bpp + 16, (800 * bpp + 16) * 600
            m.put('vc_bytes', bpp, 1)
            m.put('vc_pitch', pitch)
            m.put('vc_frame_bytes', frame_bytes, 4)
            m.put('vc_info', 800, index=9)
            m.put('vc_info', 600, index=10)
            m.frame = bytearray((i * 7 + 13) & 255 for i in range(frame_bytes * 2))
            original = bytes(m.frame)
            m.pointer(px, py)
            m.run('ui_pointer_show')
            assert m.transfers[-1][1:3] == (min(24, 800 - px) * bpp, min(16, 600 - py))
            # Every write must be within the actual pixel span (no row padding).
            changed = [i for i, (a, b) in enumerate(zip(original, m.frame)) if a != b]
            assert changed and all((i % pitch) < 800 * bpp for i in changed)
            m.pointer(400, 300)                 # restore uses captured geometry
            m.put('vc_info', 1024, index=9)
            m.put('vc_info', 768, index=10)
            m.run('ui_pointer_hide')
            assert m.frame == original
            count += 1
    # Different save rectangles on each physical page; catch-up restores a
    # source page's background onto the opposite page using the source area.
    m = Machine(program)
    m.put('vc_info', 800, index=9)
    m.put('vc_info', 600, index=10)
    m.frame = bytearray((i * 17 + 19) & 255 for i in range(1920000 * 2))
    first = bytes(m.frame)
    m.pointer(799, 599)
    m.run('ui_pointer_show')
    m.run('ui_pointer_hide')
    m.put('ui_front_base', 1920000, 4)
    m.pointer(300, 290)
    m.run('ui_pointer_show')
    m.run('ui_pointer_hide')
    assert m.frame == first
    m.reg('edi', 1920000 + 599 * 3200 + 799 * 4)
    m.reg('si', 0x2000)
    m.run('vc_pointer_restore')
    assert m.transfers[-1][1:3] == (4, 1)
    for px, py in ((0, 0), (639, 0), (0, 479), (639, 479), (635, 474), (310, 200)):
        m = Machine(program)
        m.put('ui_vbe', 0, 1)
        m.put('ui_width', 640)
        m.put('ui_height', 480)
        original = [bytes(plane) for plane in m.planes]
        m.pointer(px, py)
        m.run('ui_pointer_show')
        m.pointer(320, 240)
        m.run('ui_pointer_hide')
        assert m.planes == original, ('VGA restore', px, py)
    # Centered sizing cursors retain their exact hotspot even when their
    # left/top pixels lie off screen; check the full silhouette, not merely
    # transfer lengths or restoration.
    for shape in range(3, 7):
        for px, py in ((0, 0), (63, 0), (0, 47), (63, 47)):
            m = Machine(program)
            m.file = cursor_file()
            m.reg('al', 0)
            m.run('ui_set_cursor_scheme')
            m.reg('ax', shape)
            m.run('app_s_cursor')
            m.put('ui_width', 64)
            m.put('ui_height', 48)
            m.put('vc_info', 64, index=9)
            m.put('vc_info', 48, index=10)
            m.put('vc_pitch', 272)
            m.put('vc_frame_bytes', 272 * 48, 4)
            m.put('vc_colors', 0xffffff, 4, 15)
            m.frame = bytearray(b'\x80' * (272 * 48))
            original = bytes(m.frame)
            expected = bytearray(original)
            art = build_cursors.RESIZE_CURSORS[shape - 3][0]
            for dy, row in enumerate(art):
                for dx, char in enumerate(row):
                    xx, yy = px - 7 + dx, py - 7 + dy
                    if char != ' ' and 0 <= xx < 64 and 0 <= yy < 48:
                        start = yy * 272 + xx * 4
                        expected[start:start + 4] = ((0xffffff if char == '.' else 0)
                                                     .to_bytes(4, 'little'))
            m.pointer(px, py)
            m.run('ui_pointer_show')
            assert m.frame == expected, ('clipped hotspot silhouette', shape, px, py)
            m.run('ui_pointer_hide')
            assert m.frame == original
    return {'packed_depth_position_cases': count, 'saved_page_geometry': True,
            'centered_hotspot_clipped_silhouettes': 16,
            'planar_vga_positions': 6, 'out_of_frame_or_row_accesses': 0}


def main():
    with tempfile.TemporaryDirectory(prefix='ciuki-resize-') as temporary:
        program = assemble(Path(temporary))
        report = {'resize': test_resize(program), 'cursor_resource': test_resources(program),
                  'window_policies': test_window_policies(program),
                  'cursor_framebuffer': test_framebuffer(program),
                  'scope': 'CPU execution and transfer/planar fixtures; no physical GPU claim'}
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
