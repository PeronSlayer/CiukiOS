#!/usr/bin/env python3
"""Execute VMFORK's pin/cleanup paths with the assembled full-profile DOS kernel.

Run: uv run --with unicorn python scripts/test_vmfork_pinned_ancestors.py
The real INT 21h dispatcher, F149, MCB allocator and AH=52h are executed. Only
BIOS memory reporting and diagnostic file I/O are modeled; no disk image or
QEMU is used. The test stops before target EXEC or unsafe-path error reporting.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from unicorn import x86_const as x

from test_kernel_f149_arena import (
    BASE, CHILD, LIVE, ROOT, SEG, SHELL, TOP, TSR, Machine, assemble,
)

ROOT_SIZE = 0x800
PINNED = 0x3000
UNPINNED = 0x4000
PARENT_EXTRA = 0x4500
FOREIGN = 0x7000
REGISTERS = (x.UC_X86_REG_EAX, x.UC_X86_REG_EBX, x.UC_X86_REG_ECX,
             x.UC_X86_REG_EDX, x.UC_X86_REG_ESI, x.UC_X86_REG_EDI,
             x.UC_X86_REG_EBP, x.UC_X86_REG_ESP, x.UC_X86_REG_CS,
             x.UC_X86_REG_SS, x.UC_X86_REG_DS, x.UC_X86_REG_ES,
             x.UC_X86_REG_FS, x.UC_X86_REG_GS)


def vm_symbols(listing, length):
    """Read NASM addresses, including names scoped by non-local labels."""
    labels, pending, scope = {}, [], ''
    for line in listing.splitlines():
        line = re.sub(r'^\s*\d+\s*', '', line)
        address = re.match(r'^([0-9A-F]{8})\s+.*?\s{2,}', line)
        if address:
            line = line[address.end():]
        source = re.sub(r'^<\d+>\s*', '', line).split(';', 1)[0].strip()
        match = re.match(r'([.]?[A-Za-z_]\w*)(?::|\s+(?:dw|db|dd|times)\b)', source)
        if match:
            name = match[1]
            if name.startswith('.'):
                name = scope + name
            else:
                scope = name
            pending.append(name)
        if address:
            for name in pending:
                labels[name] = int(address[1], 16) + 0x100
            pending.clear()
    for name in pending:
        labels[name] = length + 0x100
    return labels


def assemble_vmfork(directory, kernel_labels):
    (directory / 'kernel_layout.inc').write_text(
        f'KL_EXEC_PSP equ {kernel_labels["dos_exec_identity_psp"]}\n'
        f'KL_CURRENT_PSP equ {kernel_labels["current_psp_seg"]}\n')
    binary, listing = directory / 'VMFORK.COM', directory / 'vmfork.lst'
    subprocess.run(['nasm', '-f', 'bin', '-I', str(directory) + '/',
                    'src/com/vmfork.asm', '-o', str(binary), '-l', str(listing)],
                   cwd=ROOT, check=True)
    image = binary.read_bytes()
    return image, vm_symbols(listing.read_text(), len(image))


class ForkMachine(Machine):
    def __init__(self, kernel, kernel_labels, vmfork, vm_labels, embedded=False):
        self.vm_stops, self.vm_forbidden, self.stopped = {}, set(), None
        self.dos_calls, self.files, self.dispatches = [], [], 0
        self.kernel_entries = {BASE + kernel_labels[name]: name for name in
                               ('int21_handler', 'int21_free_impl', 'int21_mem_rebuild_chain')}
        self.kernel_hits = dict.fromkeys(self.kernel_entries.values(), 0)
        super().__init__(kernel, kernel_labels, SHELL)
        self.segment = 0x1600 if embedded else CHILD
        self.parent = 0x1500 if embedded else 0x4800
        self.base, self.vm_labels = self.segment * 16, vm_labels
        assert vm_labels['image_end'] < 0x3000
        assert not embedded or self.segment + (vm_labels['image_end'] + 15) // 16 < SHELL + ROOT_SIZE
        self.psp(SHELL, ROOT_SIZE, SHELL)
        self.u.mem_write(SHELL * 16 + 0x100, bytes.fromhex('fa8cc88ed0bc'))
        for segment, size, parent in ((self.parent, 0x80, SHELL),
                                     (self.segment, 0x800, self.parent)):
            # Embedded PSPs need no separate MCB inside their enclosing root.
            self.u.mem_write(segment * 16, struct.pack('<HH', 0x20CD, segment + size))
            self.u.mem_write(segment * 16 + 0x16, struct.pack('<H', parent))
            if not embedded:
                self.mcb(segment, size, segment)
        self.put('dos_exec_identity_psp', self.segment)
        self.put('current_psp_seg', self.segment)
        self.put('dos_mem_psp_mcb_end', self.segment + 0x800)
        entries = [(TSR, 0x50, TSR, 7), (PINNED, 0x80, SHELL, 1),
                   (UNPINNED, 0x90, SHELL, 1),
                   (PARENT_EXTRA, 0x70, self.parent, 1),
                   (LIVE, 0x80, self.segment, 1), (FOREIGN, 0x60, FOREIGN, 1)]
        if not embedded:
            entries.append((self.parent, 0x80, self.parent, 1))
        self.put('dos_mem_block_count', len(entries), 1)
        self.u.mem_write(BASE + self.labels['dos_mem_block_table'],
                         b''.join(struct.pack('<4H', *entry) for entry in entries))
        for segment, size, owner, _ in entries:
            self.mcb(segment, size, owner)
        self.call('int21_mem_rebuild_chain')
        self.u.mem_write(self.base + 0x100, vmfork)
        self.word('kernel_seg', SEG)
        self.word('first_mcb', SHELL - 1)
        self.word('root_psp', SHELL)
        self.word('root_end', SHELL + ROOT_SIZE)
        self.word('ancestors', self.parent)
        self.u.mem_write(self.base + vm_labels['ancestors'] + 2,
                         struct.pack('<HH', SHELL, 0))
        self.word('trace_vm', 2)
        self.u.mem_write(self.base + vm_labels['program'], b'\\VM\\DPMIRUN.COM\0')
        for vector in range(256):
            self.vector(vector, 0xF000, 0xFFF0)
        self.vector(0x21, SEG, kernel_labels['int21_handler'])
        # Publish SYSVARS before taking preservation snapshots; this is the
        # actual AH=52h dispatcher, including its normal one-time setup.
        self.run('trace_initial_memory')
        assert self.vm_value('trace_memory_valid') == 1
        assert self.chain()[SHELL] == dict(owner=SHELL, size=ROOT_SIZE)

    def word(self, name, value):
        self.u.mem_write(self.base + self.vm_labels[name], struct.pack('<H', value))

    def vm_value(self, name, size=2):
        return int.from_bytes(self.u.mem_read(self.base + self.vm_labels[name], size), 'little')

    def vector(self, number, segment, offset):
        self.u.mem_write(number * 4, struct.pack('<HH', offset, segment))

    def stop(self, uc, address, size, data):
        if address in self.kernel_entries:
            self.kernel_hits[self.kernel_entries[address]] += 1
        if address in self.vm_forbidden:
            raise AssertionError(f'pin path reached forbidden relocation at {address:05X}')
        if address in self.vm_stops:
            self.stopped = self.vm_stops[address]
            uc.emu_stop()
        elif address == self.stop_at:
            uc.emu_stop()

    def interrupt(self, uc, number, data):
        if number == 0x12:
            uc.reg_write(x.UC_X86_REG_AX, TOP // 64)
            return
        assert number == 0x21, f'unexpected interrupt {number:02X}'
        ax = uc.reg_read(x.UC_X86_REG_AX)
        self.dos_calls.append((ax, uc.reg_read(x.UC_X86_REG_BX), uc.reg_read(x.UC_X86_REG_ES)))
        if ax >> 8 in (0x3C, 0x40, 0x3E):
            # Diagnostic writes never touch a real disk. All allocation,
            # current PSP and list-of-lists operations use the real kernel.
            result = 8 if ax >> 8 == 0x3C else 0
            if ax >> 8 == 0x40:
                result = uc.reg_read(x.UC_X86_REG_CX)
                address = uc.reg_read(x.UC_X86_REG_DS) * 16 + uc.reg_read(x.UC_X86_REG_DX)
                self.files.append(bytes(uc.mem_read(address, result)))
            uc.reg_write(x.UC_X86_REG_AX, result)
            uc.reg_write(x.UC_X86_REG_EFLAGS, uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1)
            return
        assert ax >> 8 in (0x52, 0x62) or ax == 0xF149, f'unexpected DOS call {ax:04X}'
        # UC_HOOK_INTR supplies the IP after INT, but not its stack frame.
        # Reproduce the CPU's FLAGS/CS/IP pushes, then execute the dispatcher
        # in this emulation run. Its IRET resumes the original VMFORK caller.
        flags = uc.reg_read(x.UC_X86_REG_EFLAGS)
        cs, ip = uc.reg_read(x.UC_X86_REG_CS), uc.reg_read(x.UC_X86_REG_IP)
        ss, sp = uc.reg_read(x.UC_X86_REG_SS), uc.reg_read(x.UC_X86_REG_SP)
        sp = (sp - 6) & 0xFFFF
        uc.mem_write(ss * 16 + sp, struct.pack('<HHH', ip, cs, flags & 0xFFFF))
        uc.reg_write(x.UC_X86_REG_SP, sp)
        uc.reg_write(x.UC_X86_REG_EFLAGS, flags & ~0x300)
        uc.reg_write(x.UC_X86_REG_CS, SEG)
        uc.reg_write(x.UC_X86_REG_IP, self.labels['int21_handler'])
        self.dispatches += 1

    def run(self, name, stops=(), forbid=(), ax=0, dx=0, es=None):
        self.vm_stops = {self.base + 0x80: 'return'}
        self.vm_stops.update({self.base + self.vm_labels[n]: n for n in stops})
        self.vm_forbidden = {self.base + self.vm_labels[n] for n in forbid}
        self.stopped, self.stop_at = None, 0
        for reg, value in ((x.UC_X86_REG_CS, self.segment),
                           (x.UC_X86_REG_SS, self.segment),
                           (x.UC_X86_REG_DS, self.segment),
                           (x.UC_X86_REG_ES, self.segment if es is None else es),
                           (x.UC_X86_REG_EAX, ax), (x.UC_X86_REG_EDX, dx),
                           (x.UC_X86_REG_EBX, 0xA5011234),
                           (x.UC_X86_REG_ECX, 0xA5022345),
                           (x.UC_X86_REG_ESI, 0xA5033456),
                           (x.UC_X86_REG_EDI, 0xA5044567),
                           (x.UC_X86_REG_EBP, 0xA5055678),
                           (x.UC_X86_REG_EFLAGS, 0xA03)):
            self.u.reg_write(reg, value)
        self.u.reg_write(x.UC_X86_REG_ESP, self.vm_labels['stack_top'] - 2)
        self.u.mem_write(self.base + self.vm_labels['stack_top'] - 2, struct.pack('<H', 0x80))
        before = [self.u.reg_read(reg) for reg in REGISTERS]
        before[7] += 2  # the caller's SP after the routine returns
        self.u.emu_start(self.base + self.vm_labels[name], 0xFFFFF, count=2_000_000)
        assert self.stopped, f'{name} exceeded instruction bound'
        after = [self.u.reg_read(reg) for reg in REGISTERS]
        return dict(stop=self.stopped, carry=bool(self.u.reg_read(x.UC_X86_REG_EFLAGS) & 1),
                    before=before, after=after,
                    flags=self.u.reg_read(x.UC_X86_REG_EFLAGS))

    def context(self):
        return {name: self.value(name) for name in
                ('current_psp_seg', 'dos_exec_identity_psp', 'dos_mem_psp_mcb_end',
                 'dos_mem_top_seg', 'dos_mem_chain_limit_seg', 'windows_active')}

    def psp_bytes(self):
        return {p: bytes(self.u.mem_read(p * 16, 0x80))
                for p in (SHELL, self.parent, self.segment)}

    def free_calls(self):
        return [(owner, segment) for ax, owner, segment in self.dos_calls if ax == 0xF149]


def free_memory(chain):
    blocks = [entry['size'] for entry in chain.values() if entry['owner'] == 0]
    return dict(total=sum(blocks), largest=max(blocks, default=0))


def test_intervals(make):
    cases = []
    first, end = SHELL + 0x10, SHELL + ROOT_SIZE
    targets = [('first-byte', first, 0, True),
               ('last-byte', end - 1, 0xF, True),
               ('offset-alias', first - 0x100, 0x1007, True),
               ('last-alias', end - 0x100, 0xFFF, True),
               ('before-start', first - 1, 0xF, False),
               ('exclusive-end', end, 0, False),
               ('bios', 0xF000, 0xFFF0, False),
               ('umb', 0xC800, 0x20, False),
               ('above-one-megabyte', 0xFFFF, 0xFFFF, False),
               ('root-psp-only', SHELL, 0xFF, False)]
    for name, segment, offset, expected in targets:
        m = make()
        m.vector(0xDA, segment, offset)
        before_ivt = bytes(m.u.mem_read(0, 1024))
        result = m.run('interval_has_ivt_reference', ax=first, dx=end)
        assert result['carry'] == expected, (name, result)
        assert result['before'] == result['after'], name
        assert result['flags'] & ~1 == 0xA02, (name, result['flags'])
        assert bytes(m.u.mem_read(0, 1024)) == before_ivt
        if expected:
            assert m.vm_value('trace_vector_ref') == 0xDA * 4
            assert m.vm_value('trace_vector_target', 4) == segment << 16 | offset
        cases.append(dict(name='interval-' + name, pinned=expected, passed=True))
    return cases


def test_root(make):
    cases = []
    for embedded in (False, True):
        for alias in (False, True):
            m = make(embedded)
            segment, offset = ((SHELL - 0x20, 0x307) if alias else (SHELL + 0x10, 7))
            m.vector(0xDA, segment, offset)
            before_chain, before_context, before_psps = m.chain(), m.context(), m.psp_bytes()
            before_ivt = bytes(m.u.mem_read(0, 1024))
            sentinel_address = (SHELL + ROOT_SIZE - 0x10) * 16
            m.u.mem_write(sentinel_address, b'root tail remains owned' * 3)
            sentinel = bytes(m.u.mem_read(sentinel_address, 64))
            result = m.run('prepare_compaction',
                           forbid=('stage_vmfork', 'move_vector_resident', 'reparent_retained_ancestors'))
            assert result['stop'] == 'return' and not result['carry']
            assert m.vm_value('compact_ready', 1) == 0
            assert m.vm_value('stage_psp') == 0 and m.vm_value('source_psp') == 0
            assert m.vm_value('trace_progress') & 0x1800 == 0x1800
            assert m.vm_value('trace_pin_mcb') == SHELL - 1
            assert m.vm_value('trace_pin_owner') == SHELL
            assert m.vm_value('trace_pin_paras') == ROOT_SIZE
            assert m.vm_value('trace_pin_vector') == 0xDA * 4
            assert m.vm_value('trace_pin_target', 4) == segment << 16 | offset
            assert m.chain() == before_chain and m.context() == before_context
            assert m.psp_bytes() == before_psps
            assert bytes(m.u.mem_read(0, 1024)) == before_ivt
            assert bytes(m.u.mem_read(sentinel_address, 64)) == sentinel
            assert all(m.u.reg_read(reg) == m.segment for reg in
                       (x.UC_X86_REG_CS, x.UC_X86_REG_SS, x.UC_X86_REG_DS, x.UC_X86_REG_ES))
            assert not m.free_calls()
            cases.append(dict(name=f'root-pin-{"embedded" if embedded else "separate"}-'
                                   f'{"alias" if alias else "direct"}',
                              execution_psp=m.segment, pinned_owner=SHELL, passed=True))
    # Pointers into the kept PSP, BIOS and UMB do not pin the reclaimable tail.
    for name, segment, offset in (('psp', SHELL, 0xFF), ('bios', 0xF000, 0x20),
                                  ('umb', 0xC800, 0x200), ('end', SHELL + ROOT_SIZE, 0),
                                  ('root-owned-extra', PINNED - 0x40, 0x527)):
        m = make()
        m.vector(0xDA, segment, offset)
        result = m.run('prepare_compaction', stops=('prepare_compaction.stage',))
        assert result['stop'] == 'prepare_compaction.stage' and m.vm_value('trace_pin_events') == 0
        cases.append(dict(name='unreferenced-root-enters-staging-' + name, passed=True))
    return cases


def test_cleanup(make):
    cases = []
    for embedded in (False, True):
        for header in (False, True):
            m = make(embedded)
            # Root pin avoids staging; a second independent vector pins an
            # extra allocation, using an alias into either header or payload.
            m.vector(0xDA, SHELL - 0x20, 0x307)
            pinned_mcb = PINNED - 1
            target = pinned_mcb * 16 + (7 if header else 0x127)
            segment, offset = pinned_mcb - 0x100, target - (pinned_mcb - 0x100) * 16
            m.vector(0xDB, segment, offset)
            m.u.mem_write(PINNED * 16, bytes(range(256)) * 8)
            pinned_before = bytes(m.u.mem_read(pinned_mcb * 16, (0x80 + 1) * 16))
            before_chain, before_psps, before_context = m.chain(), m.psp_bytes(), m.context()
            before_ivt = bytes(m.u.mem_read(0, 1024))
            initial = free_memory(before_chain)
            assert m.vm_value('trace_total_free') == initial['total']
            assert m.vm_value('trace_largest_free') == initial['largest']
            result = m.run('prepare_compaction', forbid=('stage_vmfork',))
            assert not result['carry']
            result = m.run('child.cleanup_walk', stops=('child.launch', 'child.cleanup_failed'),
                           forbid=('stage_vmfork',))
            assert result['stop'] == 'child.launch', result
            after_chain = m.chain()
            assert set(m.free_calls()) == {(SHELL, UNPINNED), (m.parent, PARENT_EXTRA)}, m.free_calls()
            assert len(m.free_calls()) == 2
            assert m.kernel_hits['int21_free_impl'] == 2
            assert bytes(m.u.mem_read(pinned_mcb * 16, len(pinned_before))) == pinned_before
            assert m.psp_bytes() == before_psps and m.context() == before_context
            assert bytes(m.u.mem_read(0, 1024)) == before_ivt
            for p in (SHELL, PINNED, TSR, LIVE, FOREIGN):
                assert after_chain[p] == before_chain[p], (p, after_chain[p], before_chain[p])
            if not embedded:
                for p in (m.segment, m.parent):
                    assert after_chain[p] == before_chain[p]
            for p in (UNPINNED, PARENT_EXTRA):
                assert p not in after_chain or after_chain[p]['owner'] == 0
            remaining = free_memory(after_chain)
            assert remaining['total'] > initial['total']
            assert m.vm_value('trace_total_free') == initial['total']
            assert m.vm_value('trace_largest_free') == initial['largest']
            assert m.vm_value('trace_remaining_free') == remaining['total']
            assert m.vm_value('trace_remaining_largest') == remaining['largest']
            assert m.vm_value('trace_remaining_valid') == 1
            if 'dos_mem_free_owner' in m.labels:
                assert m.value('dos_mem_free_owner') == 0
            cases.append(dict(name=f'mixed-cleanup-{"embedded" if embedded else "separate"}-'
                                   f'{"header" if header else "payload"}-alias',
                              free_calls=m.free_calls(), initial=initial, remaining=remaining,
                              kernel_execution=m.kernel_hits, dispatches=m.dispatches, passed=True))
    return cases


def test_indirect_owner(make):
    cases = []
    for header in (False, True):
        m = make(True)
        # Only the extra block is referenced. Its owner PSP lives inside the
        # root tail, which must survive even without a direct IVT hit.
        segment = PARENT_EXTRA - 0x40
        offset = 0x3F7 if header else 0x527
        m.vector(0xDA, segment, offset)
        before_chain, context, psps = m.chain(), m.context(), m.psp_bytes()
        initial = free_memory(before_chain)
        ivt = bytes(m.u.mem_read(0, 1024))
        pinned = bytes(m.u.mem_read((PARENT_EXTRA - 1) * 16, 0x71 * 16))
        result = m.run('prepare_compaction', forbid=('stage_vmfork',))
        assert not result['carry'] and result['stop'] == 'return'
        assert m.vm_value('compact_ready', 1) == 0
        assert m.vm_value('stage_psp') == 0
        assert m.vm_value('trace_pin_mcb') == PARENT_EXTRA - 1
        assert m.vm_value('trace_pin_owner') == m.parent
        assert m.vm_value('trace_pin_target', 4) == segment << 16 | offset
        assert m.chain() == before_chain and m.context() == context
        assert m.psp_bytes() == psps
        result = m.run('child.cleanup_walk', stops=('child.launch', 'child.cleanup_failed'))
        assert result['stop'] == 'child.launch'
        assert set(m.free_calls()) == {(SHELL, PINNED), (SHELL, UNPINNED)}
        assert m.kernel_hits['int21_free_impl'] == 2
        assert m.chain()[SHELL] == before_chain[SHELL]
        assert m.chain()[PARENT_EXTRA] == before_chain[PARENT_EXTRA]
        assert bytes(m.u.mem_read((PARENT_EXTRA - 1) * 16, len(pinned))) == pinned
        assert bytes(m.u.mem_read(0, 1024)) == ivt
        assert m.context() == context and m.psp_bytes() == psps
        remaining = free_memory(m.chain())
        assert m.vm_value('trace_total_free') == initial['total']
        assert m.vm_value('trace_largest_free') == initial['largest']
        assert m.vm_value('trace_remaining_free') == remaining['total']
        assert m.vm_value('trace_remaining_largest') == remaining['largest']
        assert m.vm_value('trace_remaining_valid') == 1
        cases.append(dict(name='indirect-pin-preserves-embedded-owner-and-root-'
                               + ('header' if header else 'payload') + '-alias',
                          pinned_owner=m.parent, free_calls=m.free_calls(),
                          initial=initial, remaining=remaining,
                          kernel_execution=m.kernel_hits, passed=True))
    return cases


def test_malformed(make):
    cases = []
    for name, offset, corrupt in (('mcb-kind', 0, b'X'),
                                   ('mcb-overflow', 3, b'\xff\xff'),
                                   ('mcb-zero-wrap', 3, struct.pack('<H', 0xFFFF - (FOREIGN - 1))),
                                   ('mcb-over-ceiling', 3, b'\x00\x90')):
        m = make()
        m.vector(0xDA, SHELL + 0x10, 0)
        m.u.mem_write((FOREIGN - 1) * 16 + offset, corrupt)
        # The manager snapshot itself is deliberately tiny: restore_vectors
        # must refuse the malformed arena before looking at the copied IVT.
        m.u.mem_write(0xE0000, b'\xf8\xcb')  # clc; retf
        m.u.mem_write(m.base + m.vm_labels['entry'], struct.pack('<HH', 0, 0xE000))
        context, psps = m.context(), m.psp_bytes()
        ivt = bytes(m.u.mem_read(0, 1024))
        # The executing fixture's own block contains its stack/trace data.
        # Every other arena byte, including all MCBs, must remain unchanged.
        ranges = (((SHELL - 1) * 16, m.base),
                  ((m.segment + 0x800) * 16, (TOP + 1) * 16))
        before = [bytes(m.u.mem_read(start, end - start)) for start, end in ranges]
        initial_fields = ('trace_conventional_kb', 'trace_memory_valid',
                          'trace_total_free', 'trace_largest_free')
        initial = {field: m.vm_value(field) for field in initial_fields}
        result = m.run('restore_vectors')
        assert result['carry'], name
        assert bytes(m.u.mem_read(0, 1024)) == ivt
        assert not m.free_calls()
        result = m.run('prepare_compaction', forbid=('stage_vmfork',))
        assert result['carry'], name
        assert m.vm_value('compact_ready', 1) == 0
        assert m.vm_value('trace_pin_events') == 0
        result = m.run('child.cleanup_walk', stops=('child.launch', 'child.cleanup_failed'))
        assert result['stop'] == 'child.cleanup_failed', (name, result)
        reason = m.vm_value('trace_reason')
        result = m.run('trace_remaining_memory')
        assert m.vm_value('trace_remaining_valid') == 0
        assert {field: m.vm_value(field) for field in initial_fields} == initial
        assert result['before'] == result['after'] and result['flags'] == 0xA03
        assert not m.free_calls()
        assert m.context() == context and m.psp_bytes() == psps
        assert bytes(m.u.mem_read(0, 1024)) == ivt
        assert [bytes(m.u.mem_read(start, end - start)) for start, end in ranges] == before
        cases.append(dict(name='malformed-' + name, reason=reason,
                          remaining_valid=0, initial_preserved=initial, passed=True))
    return cases


def test_snapshot_refusal(make):
    m = make()
    m.vector(0xDA, SHELL + 0x10, 0)
    m.u.mem_write(0xE0000, b'\xf9\xcb')  # stc; retf
    m.u.mem_write(m.base + m.vm_labels['entry'], struct.pack('<HH', 0, 0xE000))
    ivt = bytes(m.u.mem_read(0, 1024))
    chain, context, psps = m.chain(), m.context(), m.psp_bytes()
    calls = list(m.dos_calls)
    result = m.run('restore_vectors')
    assert not result['carry'] and result['stop'] == 'return'
    assert m.dos_calls == calls and not m.free_calls()
    assert bytes(m.u.mem_read(0, 1024)) == ivt
    assert m.chain() == chain and m.context() == context and m.psp_bytes() == psps
    return [dict(name='manager-snapshot-refusal-remains-best-effort',
                 dos_calls=0, ivt_unchanged=True, passed=True)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='ciuki-vmfork-pins-') as directory:
        directory = Path(directory)
        kernel, kernel_labels = assemble(directory)
        vmfork, vm_labels = assemble_vmfork(directory, kernel_labels)
        def make(embedded=False):
            return ForkMachine(kernel, kernel_labels, vmfork, vm_labels, embedded)
        cases = (test_intervals(make) + test_root(make) + test_cleanup(make)
                 + test_indirect_owner(make) + test_malformed(make)
                 + test_snapshot_refusal(make))
    report = dict(passed=True, real_allocator=True, allocator_mocks=False,
                  kernel_sha256=hashlib.sha256(kernel).hexdigest(),
                  vmfork_sha256=hashlib.sha256(vmfork).hexdigest(),
                  fixture_ceiling_segment=TOP, cases=cases)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    for case in cases:
        print(case['name'], 'PASS')
    print(f'VMFORK pinned ancestors PASS: {len(cases)} cases; actual F149 allocator, '
          'root PSP/IVT preservation, alias boundaries, measured remaining arena; no disk I/O')


if __name__ == '__main__':
    main()
