#!/usr/bin/env python3
"""Change the real desktop volume control and verify its value after reboot.

QEMU AC'97 software regression only; this does not qualify T23 hardware.
"""
import argparse
import json
from pathlib import Path
import shutil
import time

from qemu_test_audio_preferences import (
    boot, image_delete_if_present, image_read, records, sha256, verify_audio_log,
)
from qemu_test_t23_runtime import T23WindowVM, assemble_shell
from qemu_test_native_utilities import Utilities


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.image.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    original_hash = sha256(source)
    disk = output / 'test.img'
    shutil.copyfile(source, disk)
    image_delete_if_present(disk, 'SYSTEM/VOLUME.CFG')
    image_delete_if_present(disk, 'SYSTEM/AUDIO.LOG')
    shell, listing = assemble_shell(output)
    assert shell.read_bytes() == image_read(disk, 'SYSTEM/SHELL.COM')
    vm = T23WindowVM(disk, output / 'adjust', 'std', boot_capture=True,
                     palette='platinum')
    try:
        vm.ready()
        ui = Utilities(vm, shell.read_bytes(), listing)
        vm.bind_pointer_observer(ui)
        vm.key('esc')  # About
        start = vm.offset()
        ui.click(80)  # exposed volume HUD, real PS/2 click
        vm.wait('[DESK] volume open', start, 20)
        start = vm.offset()
        vm.key('right')  # default 5 -> 6; persist through the shell service
        vm.wait('[DESKTOP] PAINT', start, 20)
        time.sleep(.5)
        vm.shot('volume-6-after-user-change')
        vm.key('esc')
    finally:
        vm.close()
    assert image_read(disk, 'SYSTEM/VOLUME.CFG') == b'\x06'
    initial = verify_audio_log(records(disk), '1A1A')
    image_delete_if_present(disk, 'SYSTEM/AUDIO.LOG')
    boot(disk, output, 'reboot')
    assert image_read(disk, 'SYSTEM/VOLUME.CFG') == b'\x06'
    restored = verify_audio_log(records(disk), '1919')
    assert sha256(source) == original_hash
    report = dict(passed=True, source_image_sha256_unchanged=original_hash,
                  input='Real PS/2 volume HUD click and Right key',
                  saved_volume=6, saved_byte_hex='06', initial=initial,
                  reboot=restored, hardware_qualified=False)
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print('[audio-slider] PASS user change 5 -> 6 retained after reboot')


if __name__ == '__main__':
    main()
