#!/usr/bin/env python3
"""Execute assembled VMFORK's guest S3 detachment against pinned TSR bytes.

uv run --with unicorn python scripts/test_vmfork_s3_guest.py
The two memory instances model private guest pages; no video hardware is run.
"""
import hashlib
from pathlib import Path
import struct
import subprocess
import tempfile

from unicorn import (Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR,
                     UC_HOOK_INSN, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE)
from unicorn import x86_const as x

from test_vmfork_launch_diagnostics import Machine, REGS, ROOT, symbols

S3, AUX, FIRST = 0x24fd, 0x2195, 0x11ff
PIN = '4072e46a340ae7d2c0f22d556857a74734b77e46134853d089af30a798d08f3f'


class S3Machine(Machine):
    def __init__(self, image, labels, resident, free_failure=False):
        super().__init__(image, labels)
        self.frees, self.free_failure = [], free_failure
        self.word('trace_vm', 1)
        self.word('first_mcb', FIRST)
        self.word('trace_memory_valid', 1)
        # Match diskseq63's captured T23 INT10 tuple: 24FD:0048 -> 2195:0470.
        self.u.mem_write(0x40, struct.pack('<HH', 0x48, S3))
        self.u.mem_write(S3 * 16, resident)
        self.u.mem_write(AUX * 16 + 0x100, b'\xe9\xe3')
        blocks = [(FIRST, 'M', 0x1200, AUX-1-FIRST-1),
                  (AUX-1, 'M', AUX, 0x4f),
                  (AUX+0x4f, 'M', 0, S3-1-(AUX+0x4f)-1),
                  (S3-1, 'M', S3, 0x40),
                  (S3+0x40, 'Z', 0, 0xa000-(S3+0x40)-1)]
        for segment, kind, owner, size in blocks:
            self.u.mem_write(segment*16, struct.pack('<BHH', ord(kind), owner, size))
        # Exercise upper general registers and upper EFLAGS (AC/ID), as well
        # as DF/IF and all segment registers. Only returned CF may differ.
        self.u.reg_write(x.UC_X86_REG_EFLAGS, 0x240ed7)
        self.u.hook_add(UC_HOOK_INSN, self.no_input, None, 1, 0, x.UC_X86_INS_IN)
        self.u.hook_add(UC_HOOK_INSN, self.no_output, None, 1, 0, x.UC_X86_INS_OUT)
        self.u.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, self.no_mmio, None, 0xa0000, 0xfffff)

    def no_input(self, uc, port, size, data):
        raise AssertionError(f'guest detachment read hardware port {port:x}')

    def no_output(self, uc, port, size, value, data):
        raise AssertionError(f'guest detachment wrote hardware port {port:x}')

    def no_mmio(self, uc, access, address, size, value, data):
        raise AssertionError(f'guest detachment touched MMIO/ROM at {address:x}')

    def interrupt(self, uc, number, data):
        ax = uc.reg_read(x.UC_X86_REG_AX)
        assert number == 0x21 and ax == 0xf149, (number, ax)
        es, bx = uc.reg_read(x.UC_X86_REG_ES), uc.reg_read(x.UC_X86_REG_BX)
        assert es == bx == S3, ('owner-qualified free', es, bx)
        self.frees.append((es, bx))
        assert len(self.frees) == 1
        if not self.free_failure:
            uc.mem_write((S3-1)*16+1, b'\0\0')
        uc.reg_write(x.UC_X86_REG_AX, 5 if self.free_failure else 0)
        uc.reg_write(x.UC_X86_REG_EFLAGS,
                     (uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1) | self.free_failure)


def test_pinned_install(binary):
    """Execute upstream install, excluding its hardware probing/configuration."""
    signature = bytes.fromhex('06fc0e07be0401bf4000b99903f3a4')
    assert binary.find(signature) == 0xa6b and binary.count(signature) == 1
    default_resident = None
    for extra_hook in (False, True):
        uc = Uc(UC_ARCH_X86, UC_MODE_16)
        uc.mem_map(0, 0x100000)
        uc.mem_write(S3*16 + 0x100, binary)
        uc.mem_write(S3*16 + 0x2c, struct.pack('<H', 0x2800))
        uc.mem_write(S3*16 + 0x110a, struct.pack('<H', 0x2000 if extra_hook else 0))
        uc.mem_write(0x40, struct.pack('<HH', 0x470, AUX))
        for reg in (x.UC_X86_REG_CS, x.UC_X86_REG_DS, x.UC_X86_REG_SS):
            uc.reg_write(reg, S3)
        uc.reg_write(x.UC_X86_REG_ES, AUX)
        uc.reg_write(x.UC_X86_REG_BX, 0x470)
        uc.reg_write(x.UC_X86_REG_SP, 0xf000)
        uc.mem_write(S3*16 + 0xf000, struct.pack('<H', 0x80))
        calls = []

        def dos(machine, number, data):
            ax = machine.reg_read(x.UC_X86_REG_AX)
            assert number == 0x21
            if ax in (0x2510, 0x256d):
                ds, dx = machine.reg_read(x.UC_X86_REG_DS), machine.reg_read(x.UC_X86_REG_DX)
                assert (ds, dx) == (S3, 0x48)
                machine.mem_write((ax & 255)*4, struct.pack('<HH', dx, ds))
                calls.append(ax)
            elif ax >> 8 == 0x49:
                assert machine.reg_read(x.UC_X86_REG_ES) == 0x2800
                calls.append(0x4900)
            else:
                raise AssertionError(('upstream installer unexpected DOS call', ax))
            machine.reg_write(x.UC_X86_REG_EFLAGS,
                              machine.reg_read(x.UC_X86_REG_EFLAGS) & ~1)

        def no_hardware(*args):
            raise AssertionError('upstream install subroutine touched hardware')

        def done(machine, address, size, data):
            if address == S3*16 + 0x80:
                machine.emu_stop()

        uc.hook_add(UC_HOOK_INTR, dos)
        uc.hook_add(UC_HOOK_CODE, done)
        uc.hook_add(UC_HOOK_INSN, no_hardware, None, 1, 0, x.UC_X86_INS_IN)
        uc.hook_add(UC_HOOK_INSN, no_hardware, None, 1, 0, x.UC_X86_INS_OUT)
        uc.emu_start(S3*16 + 0xb6b, 0x100000, count=2000)
        assert uc.reg_read(x.UC_X86_REG_IP) == 0x80
        assert calls == ([0x2510, 0x256d, 0x4900] if extra_hook else [0x2510, 0x4900])
        resident = bytes(uc.mem_read(S3*16, 0x400))
        expected = bytearray(binary[4:4+0x399])
        expected[0x11:0x15] = struct.pack('<HH', 0x470, AUX)
        assert resident[0x40:0x40+0x399] == expected
        if not extra_hook:
            default_resident = resident
    return default_resident


def test_shim(binary):
    for previous_offset in (0x470, 0x471):
        uc = Uc(UC_ARCH_X86, UC_MODE_16)
        uc.mem_map(0, 0x100000)
        uc.mem_write(S3*16+0x100, binary)
        uc.mem_write(S3*16+0x2c, struct.pack('<H', 0x2800))
        uc.mem_write((AUX-1)*16, struct.pack('<BHH', ord('M'), AUX, 0x4f))
        uc.mem_write(AUX*16+0x100, b'\xe9\xe3')
        uc.mem_write(0x40, struct.pack('<HH', previous_offset, AUX))
        for register in (x.UC_X86_REG_CS, x.UC_X86_REG_DS, x.UC_X86_REG_ES, x.UC_X86_REG_SS):
            uc.reg_write(register, S3)
        uc.reg_write(x.UC_X86_REG_SP, 0xfffe)
        calls = []
        finished = []

        def dos(machine, number, data):
            ax = machine.reg_read(x.UC_X86_REG_AX)
            if ax >> 8 == 0x49:
                ax = 0x4900
            calls.append(ax)
            assert number == 0x21, ('shim hardware interrupt', number)
            if ax == 0x3510:
                machine.reg_write(x.UC_X86_REG_ES, AUX)
                machine.reg_write(x.UC_X86_REG_BX, previous_offset)
            elif ax == 0x2510:
                assert machine.reg_read(x.UC_X86_REG_DS) == S3
                assert machine.reg_read(x.UC_X86_REG_DX) == 0x48
                machine.mem_write(0x40, struct.pack('<HH', 0x48, S3))
            elif ax >> 8 == 9:
                pass
            elif ax == 0x4900:
                assert machine.reg_read(x.UC_X86_REG_ES) == 0x2800
            elif ax == 0x3100:
                assert machine.reg_read(x.UC_X86_REG_DX) == 0x20
                assert 0x4900 in calls
                finished.append('resident')
                machine.emu_stop()
            elif ax == 0x4c01:
                finished.append('refused')
                machine.emu_stop()
            else:
                raise AssertionError(('shim unexpected DOS call', ax))

        def no_port(*args):
            raise AssertionError('test-only shim touched a hardware port')

        def no_mmio(*args):
            raise AssertionError('test-only shim touched MMIO/ROM')

        def reached_old_handler(machine, address, size, data):
            if address == AUX*16+0x470:
                finished.append('forwarded')
                machine.emu_stop()

        uc.hook_add(UC_HOOK_INTR, dos)
        uc.hook_add(UC_HOOK_INSN, no_port, None, 1, 0, x.UC_X86_INS_IN)
        uc.hook_add(UC_HOOK_INSN, no_port, None, 1, 0, x.UC_X86_INS_OUT)
        uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, no_mmio, None, 0xa0000, 0xfffff)
        uc.emu_start(S3*16+0x100, 0x100000, count=1000)
        assert finished == (['resident'] if previous_offset == 0x470 else ['refused'])
        if previous_offset != 0x470:
            assert 0x2510 not in calls and 0x4900 not in calls
            continue
        resident = bytes(uc.mem_read(S3*16, 512))
        assert resident[0x40:0x44] == b'fK\x60\0'
        assert resident[0x48:0x51] == bytes.fromhex('2e803e4600007405ea')
        assert resident[0x51:0x55] == struct.pack('<HH', 0x470, AUX)
        uc.hook_add(UC_HOOK_CODE, reached_old_handler)
        for flag in (0, 1):
            finished.clear()
            uc.reg_write(x.UC_X86_REG_CS, S3)
            uc.mem_write(S3*16+0x46, bytes([flag]))
            uc.emu_start(S3*16+0x48, 0x100000, count=20)
            assert finished == ['forwarded'], 'both shim branches must reach AUXSTACK'
    return resident


def test_stale_parent(binary, resident):
    cases = ('valid', 'not-test-shim', 'wrong-owner', 'wrong-size', 'wrong-vector')
    for case in cases:
        uc = Uc(UC_ARCH_X86, UC_MODE_16)
        uc.mem_map(0, 0x100000)
        uc.mem_write(0x40100, binary)
        uc.mem_write(S3 * 16, resident)
        uc.mem_write(S3 * 16 + 0x16, struct.pack('<H', 0x3333))
        uc.mem_write((S3-1) * 16, struct.pack('<BHH', ord('M'), S3, 0x20))
        if case == 'not-test-shim': uc.mem_write(S3 * 16 + 0x70, b'NONE')
        if case == 'wrong-owner': uc.mem_write((S3-1) * 16 + 1, b'\x11\x11')
        if case == 'wrong-size': uc.mem_write((S3-1) * 16 + 3, b'\x21\0')
        before = bytes(uc.mem_read((S3-1) * 16, 0x210))
        for reg in (x.UC_X86_REG_CS, x.UC_X86_REG_DS, x.UC_X86_REG_ES, x.UC_X86_REG_SS):
            uc.reg_write(reg, 0x4000)
        uc.reg_write(x.UC_X86_REG_SP, 0xFFFE)
        exits = []

        def dos(machine, number, data):
            assert number == 0x21
            ax = machine.reg_read(x.UC_X86_REG_AX)
            if ax == 0x3510:
                machine.reg_write(x.UC_X86_REG_ES, S3)
                machine.reg_write(x.UC_X86_REG_BX, 0x49 if case == 'wrong-vector' else 0x48)
            elif ax >> 8 == 9:
                pass
            elif ax >> 8 == 0x4C:
                exits.append(ax & 255)
                machine.emu_stop()
            else:
                raise AssertionError(('stale parent fixture unexpected DOS call', ax))

        def no_hardware(*args):
            raise AssertionError('stale parent fixture touched hardware')

        uc.hook_add(UC_HOOK_INTR, dos)
        uc.hook_add(UC_HOOK_INSN, no_hardware, None, 1, 0, x.UC_X86_INS_IN)
        uc.hook_add(UC_HOOK_INSN, no_hardware, None, 1, 0, x.UC_X86_INS_OUT)
        uc.hook_add(UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE, no_hardware, None, 0xA0000, 0xFFFFF)
        uc.emu_start(0x40100, 0x100000, count=1000)
        expected = bytearray(before)
        if case == 'valid': expected[0x26:0x28] = bytes(2)
        assert exits == [0 if case == 'valid' else 1], (case, exits)
        assert bytes(uc.mem_read((S3-1) * 16, 0x210)) == expected, case


def main():
    binary = (ROOT / 'assets/drivers/pack/S3VBEFIX/S3VBEFIX.COM').read_bytes()
    assert len(binary) == 4123 and hashlib.sha256(binary).hexdigest() == PIN
    resident = test_pinned_install(binary)
    with tempfile.TemporaryDirectory(prefix='ciuki-s3-guest-') as directory:
        directory = Path(directory)
        (directory/'kernel_layout.inc').write_text('KL_EXEC_PSP equ 20h\nKL_CURRENT_PSP equ 22h\n')
        binary, listing = directory/'VMFORK.COM', directory/'vmfork.lst'
        subprocess.run(['nasm', '-f', 'bin', '-I', str(directory)+'/', 'src/com/vmfork.asm',
                        '-o', str(binary), '-l', str(listing)], cwd=ROOT, check=True)
        image, labels = binary.read_bytes(), symbols(listing.read_text())
        shim = directory/'S3SHIM.COM'
        subprocess.run(['nasm', '-f', 'bin', 'src/probes/vm/s3shim.asm', '-o', str(shim)],
                       cwd=ROOT, check=True)
        fixture_resident = test_shim(shim.read_bytes())
        parent = directory/'S3PARENT.COM'
        subprocess.run(['nasm', '-f', 'bin', 'src/probes/vm/s3parent.asm', '-o', str(parent)],
                       cwd=ROOT, check=True)
        test_stale_parent(parent.read_bytes(), fixture_resident)
        cases = [
            ('valid captured tuple', None, None, 0, 1),
            ('system VM never detaches', 'trace_vm', 0, 0, 0),
            ('near-ceiling IVT never reads VGA', 0x42, struct.pack('<H', 0x9fff), 0, 0),
            ('unknown handler skipped', 0x40, struct.pack('<H', 0x49), 0, 0),
            ('unknown version skipped', S3*16+0x42, b'\x61\0', 0, 0),
            ('handler prefix rejected', S3*16+0x48, b'\x90', 0x80, 0),
            ('in-progress call rejected', S3*16+0x46, b'\x01\0', 0x80, 0),
            ('S3 MCB type rejected', (S3-1)*16, b'X', 0x81, 0),
            ('S3 MCB owner rejected', (S3-1)*16+1, b'\x01\x12', 0x81, 0),
            ('S3 short allocation rejected', (S3-1)*16+3, b'\x1f\0', 0x81, 0),
            ('S3 huge allocation rejected', (S3-1)*16+3, b'\x01\x05', 0x81, 0),
            ('unknown predecessor offset', S3*16+0x51, b'\x71\x04', 0x82, 0),
            ('unknown predecessor entry', AUX*16+0x100, b'\x90', 0x82, 0),
            ('predecessor ownership rejected', (AUX-1)*16+1, b'\0\x12', 0x82, 0),
            ('predecessor size rejected', (AUX-1)*16+3, b'\x50\0', 0x82, 0),
            ('invalid premeasured arena', 'trace_memory_valid', 0, 0x83, 0),
            ('plausible nonmember S3 MCB', (AUX+0x4f)*16+3,
             struct.pack('<H', S3+0x40-(AUX+0x4f)-1), 0x83, 0),
            ('INT6D aliases resident', 0x6d*4, struct.pack('<HH', 0x59, S3), 0x84, 0),
            ('other pointer aliases MCB header', 0x2e*4, struct.pack('<HH', 0, S3-1), 0x84, 0),
            ('other far pointer aliases allocation', 0x2f*4,
             struct.pack('<HH', 0x100, S3-1), 0x84, 0),
            ('free service fails', None, None, 0x85, 1),
        ]
        for name, address, corrupt, reason, frees in cases:
            system = S3Machine(image, labels, resident)
            original_system = bytes(system.u.mem_read(0, 0xa0000))
            guest = S3Machine(image, labels, resident, free_failure=reason == 0x85)
            if isinstance(address, str):
                guest.word(address, corrupt)
            elif address is not None:
                guest.u.mem_write(address, corrupt)
            original_ivt = bytes(guest.u.mem_read(0, 1024))
            original_arena = bytes(guest.u.mem_read(0x11ff0, 0xa0000-0x11ff0))
            before, after = guest.run('detach_s3_guest')
            assert before[:-1] == after[:-1], (name, before, after)
            assert (before[-1] & ~1) == (after[-1] & ~1), (name, before[-1], after[-1])
            assert bool(after[-1] & 1) == bool(reason), (name, after[-1], reason)
            assert guest.value('trace_reason') == reason, (name, guest.value('trace_reason'), reason)
            assert len(guest.frees) == frees, (name, guest.frees)
            assert bytes(system.u.mem_read(0, 0xa0000)) == original_system
            if frees:
                expected = bytearray(original_ivt)
                expected[0x40:0x44] = struct.pack('<HH', 0x470, AUX)
                assert bytes(guest.u.mem_read(0, 1024)) == expected
                assert guest.value('trace_s3_psp') == S3
                assert guest.value('trace_s3_paras') == 0x40
                assert bool(guest.value('trace_progress') & 0x400) == (reason == 0)
                assert guest.value('trace_dos_ax') == (5 if reason else 0)
            else:
                assert bytes(guest.u.mem_read(0, 1024)) == original_ivt
                # Trace and routine stack mutate their own image; the resident
                # interval and both MCB headers remain untouched on refusal.
                a, b = (AUX-1)*16, (S3+0x40)*16
                assert bytes(guest.u.mem_read(a, b-a)) == original_arena[a-0x11ff0:b-0x11ff0]
        print(f'VMFORK S3 guest PASS: {len(cases)} captured-tuple/pinned-byte cases; registers/FLAGS except CF, owner-qualified free, private copy, unknown hooks and no hardware access; 2 actual pinned COM install branches; S3SHIM environment free/AH31/refusal and both forwarding branches; 5 actual S3PARENT exact-two-byte/guard cases')


if __name__ == '__main__':
    main()
