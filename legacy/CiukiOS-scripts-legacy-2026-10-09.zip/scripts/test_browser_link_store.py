#!/usr/bin/env python3
"""ASan/UBSan fixture for Browser's production XMS link-record helpers."""
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    browser = (ROOT / 'src/apps/browser.c').read_text()
    helpers = browser.split('static u32 link_offset', 1)[1].split('static int attr(', 1)[0]
    node = browser.split('struct node {', 1)[1].split(';\n', 1)[0]
    prefix = r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#define NODE_MAX 6144
#define LINK_MAX 48
'''
    prefix += 'struct node {' + node + ';\nstatic struct node item;\n'
    prefix += r'''
static char base_url[128] = "https://example.com/";
static int link_count,partial,write_fail,read_fail,resolve_fail,writes,reads,navigations;
static u16 node_handle=9;
static unsigned char store[NODE_MAX*sizeof(struct node)+LINK_MAX*128+16];
static char destination[128];
static int webio_resolve(const char *base,const char *relative,char *out,int size)
{
    (void)base;
    if(resolve_fail||strlen(relative)>=(unsigned)size)return 0;
    strcpy(out,relative);return 1;
}
static int webstore_write(u16 handle,u32 offset,const void *data,u16 count)
{
    assert(handle==9&&count==128&&!(offset&1));
    assert(offset>=NODE_MAX*sizeof item&&offset+count<=sizeof store-16);
    writes++;
    if(write_fail)return 0;
    memcpy(store+offset,data,count);return 1;
}
static int webstore_read(u16 handle,u32 offset,void *data,u16 count)
{
    assert(handle==9&&count==128&&!(offset&1));
    assert(offset>=NODE_MAX*sizeof item&&offset+count<=sizeof store-16);
    reads++;
    if(read_fail)return 0;
    memcpy(data,store+offset,count);return 1;
}
static void navigate(const char *target,int remember)
{
    assert(remember==1);strcpy(destination,target);navigations++;
}
'''
    suffix = r'''
int main(void)
{
    int i,before;char name[128];
    memset(store,0xa5,sizeof store);
    assert(sizeof item==82);
    assert(link_offset(LINK_MAX)==sizeof store-16);
    for(i=1;i<LINK_MAX;i++){
        snprintf(name,sizeof name,"https://example.com/page/%d?test=1",i);
        assert(link_add(name)==i);
    }
    assert(link_count==47&&writes==47);
    before=writes;assert(link_add("overflow")==0&&writes==before);
    for(i=1;i<LINK_MAX;i++){
        snprintf(name,sizeof name,"https://example.com/page/%d?test=1",i);
        link_navigate(i);assert(!strcmp(destination,name));
    }
    assert(navigations==47);
    before=reads;link_navigate(-1);link_navigate(0);link_navigate(48);
    assert(reads==before);
    for(i=0;i<(int)(NODE_MAX*sizeof item);i++)assert(store[i]==0xa5);
    for(i=sizeof store-16;i<(int)sizeof store;i++)assert(store[i]==0xa5);
    link_count=0;write_fail=1;
    assert(link_add("failed write")==0&&link_count==0&&partial==1);
    write_fail=0;resolve_fail=1;before=writes;
    assert(link_add("bad resolve")==0&&writes==before);
    resolve_fail=0;node_handle=0;
    assert(link_add("no page")==0);link_navigate(1);assert(writes==before);
    node_handle=9;
    memset(name,'z',127);name[127]=0;
    assert(link_add(name)==1);
    link_navigate(1);assert(!strcmp(name,destination));
    before=navigations;read_fail=1;link_navigate(1);assert(navigations==before);
    puts("Browser links: 47 records, 128-byte bounds, node/canary isolation, failure publication and max URL PASS");
    return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='ciuki-browser-links-') as temporary:
        source, binary = (Path(temporary) / name for name in ('links.c', 'links'))
        source.write_text(prefix + 'static u32 link_offset' + helpers + suffix)
        subprocess.run(['gcc', '-std=c99', '-Wall', '-Wextra', '-Werror',
                        '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                        str(source), '-o', str(binary)], check=True)
        subprocess.run([str(binary)], check=True)


if __name__ == '__main__':
    main()
