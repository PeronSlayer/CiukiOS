#!/usr/bin/env python3
"""Run the full-profile kernel's F149 dispatcher and actual MCB allocator.

Use: uv run --with unicorn python scripts/test_kernel_f149_arena.py
--expect-regression records the old failure without treating it as a pass.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR
from unicorn import x86_const as x
from ciukidos_image import inspect_kernel

ROOT = Path(__file__).resolve().parents[1]
SEG = 0x0300
BASE = SEG * 16
SHELL = None
CHILD = 0x5000
TSR = 0x2505
LIVE = 0x6000
TOP = 0x9F00


def symbols(listing):
    result, pending = {}, []
    for line in listing.splitlines():
        source = line.split('<1>', 1)[-1].split(';', 1)[0].strip()
        match = re.match(r'([A-Za-z_]\w*)(?::|\s+(?:dw|db|dd|times)\b)', source)
        if match:
            pending.append(match[1])
        address = re.match(r'^\s*\d+\s+([0-9A-F]{8})\s', line)
        if address:
            for name in pending:
                result[name] = int(address[1], 16)
            pending.clear()
    return result


def assemble(directory):
    binary, listing = directory / 'kernel.bin', directory / 'kernel.lst'
    flags = dict(FAT_TYPE=16, CIUKIDOS_EXTERNAL_XMS=1, FAT_SPT=63,
                 FAT_HEADS=16, FAT_RESERVED_SECTORS=73, FAT_SECTORS_PER_CLUSTER=8,
                 FAT_SECTORS_PER_FAT=128, FAT_ROOT_DIR_SECTORS=32,
                 FAT_TOTAL_SECTORS=262144, FAT_LBA_OFFSET=0,
                 STAGE1_BOOT_EXTERNAL_SHELL=1, STAGE1_SELFTEST_AUTORUN=0,
                 STAGE1_RUNTIME_PROBE=0, STAGE1_DEBUG_COMMANDS=0,
                 STAGE2_AUTORUN=0, TRACE_WIN_MEMORY=0, TRACE_CHILD_INT21=0)
    subprocess.run(['nasm', '-f', 'bin', 'src/runtime/ciukidos.asm',
                    *[f'-D{k}={v}' for k, v in flags.items()],
                    '-l', str(listing), '-o', str(binary)], cwd=ROOT, check=True)
    return binary.read_bytes(), symbols(listing.read_text())


class Machine:
    def __init__(self, image, labels, parent, resident=True):
        self.u = Uc(UC_ARCH_X86, UC_MODE_16)
        self.u.mem_map(0, 0x100000)
        self.u.mem_write(BASE, image)
        self.labels, self.stop_at = labels, 0
        self.u.hook_add(UC_HOOK_CODE, self.stop)
        self.u.hook_add(UC_HOOK_INTR, self.interrupt)
        self.put('dos_mem_init', 1, 1)
        self.put('dos_mem_top_seg', TOP)
        self.put('dos_mem_chain_limit_seg', TOP)
        self.put('dos_exec_identity_psp', CHILD)
        self.put('current_psp_seg', CHILD)
        self.put('dos_mem_psp_mcb_end', CHILD + 0x100)
        self.psp(SHELL, 0x800, SHELL)
        self.psp(CHILD, 0x100, SHELL)
        self.psp(TSR, 0x50, parent)
        self.put('dos_mem_block_count', 2, 1)
        entries = struct.pack('<8H', TSR, 0x50, TSR, 7 if resident else 1, LIVE, 0x80, CHILD, 1)
        self.u.mem_write(BASE + labels['dos_mem_block_table'], entries)
        self.mcb(LIVE, 0x80, CHILD)
        self.call('int21_mem_rebuild_chain')
        assert self.value('dos_list_of_lists') == SHELL - 1
        assert self.chain()[SHELL]['owner'] == SHELL
        assert self.chain()[CHILD]['owner'] == CHILD

    def put(self, name, value, size=2):
        self.u.mem_write(BASE + self.labels[name], value.to_bytes(size, 'little'))

    def value(self, name):
        return int.from_bytes(self.u.mem_read(BASE + self.labels[name], 2), 'little')

    def psp(self, segment, size, parent):
        self.u.mem_write(segment * 16, struct.pack('<2H', 0x20CD, segment + size))
        self.u.mem_write(segment * 16 + 0x16, struct.pack('<H', parent))
        self.mcb(segment, size, segment)

    def mcb(self, segment, size, owner):
        self.u.mem_write((segment - 1) * 16, struct.pack('<BHH', ord('M'), owner, size))

    def stop(self, uc, address, size, data):
        if address == self.stop_at:
            uc.emu_stop()

    def interrupt(self, uc, number, data):
        raise AssertionError(f'unexpected interrupt {number:02x}')

    def call(self, name, ax=0, bx=0, es=TSR, interrupt=False):
        for reg, value in ((x.UC_X86_REG_CS, SEG), (x.UC_X86_REG_DS, CHILD),
                           (x.UC_X86_REG_ES, es), (x.UC_X86_REG_SS, 0x200),
                           (x.UC_X86_REG_AX, ax), (x.UC_X86_REG_BX, bx),
                           (x.UC_X86_REG_EFLAGS, 0x202)):
            self.u.reg_write(reg, value)
        if interrupt:
            frame = struct.pack('<3H', 0x100, 0x100, 0x202)
            self.stop_at = 0x1100
        else:
            frame = struct.pack('<H', 0xFFF0)
            self.stop_at = BASE + 0xFFF0
        sp = 0x800 - len(frame)
        self.u.reg_write(x.UC_X86_REG_SP, sp)
        self.u.mem_write(0x2000 + sp, frame)
        self.u.emu_start(BASE + self.labels[name], 0xFFFFF, count=2_000_000)
        pc = self.u.reg_read(x.UC_X86_REG_CS) * 16 + self.u.reg_read(x.UC_X86_REG_IP)
        assert pc == self.stop_at, f'kernel did not return, pc={pc:x}'
        return self.u.reg_read(x.UC_X86_REG_AX), bool(self.u.reg_read(x.UC_X86_REG_EFLAGS) & 1)

    def chain(self):
        out, segment = {}, self.value('dos_list_of_lists')
        for _ in range(64):
            kind, owner, size = struct.unpack('<BHH', self.u.mem_read(segment * 16, 5))
            assert kind in (ord('M'), ord('Z')), (segment, kind)
            out[segment + 1] = dict(owner=owner, size=size)
            if kind == ord('Z'):
                return out
            segment += size + 1
            assert segment < TOP
        raise AssertionError('MCB chain exceeded bound')


def run_case(image, labels, name, parent, owner=TSR, resident=True,
             expected_error=False, service=0xF149, target=TSR):
    m = Machine(image, labels, parent, resident)
    before = m.chain()
    ax, carry = m.call('int21_handler', ax=service, bx=owner, es=target, interrupt=True)
    after = m.chain()
    _, lol_carry = m.call('int21_handler', ax=0x5200, interrupt=True)
    lol_pointer = m.u.reg_read(x.UC_X86_REG_ES) * 16 + m.u.reg_read(x.UC_X86_REG_BX)
    published_root = int.from_bytes(m.u.mem_read(lol_pointer - 2, 2), 'little')
    assert not lol_carry and published_root == m.value('dos_list_of_lists')
    root_preserved = m.value('dos_list_of_lists') == SHELL - 1
    live_preserved = all(after.get(p) == before[p] for p in (SHELL, CHILD, LIVE) if p != target)
    tsr_freed = target not in after or after[target]['owner'] == 0
    identity_preserved = m.value('dos_exec_identity_psp') == CHILD
    cache_preserved = m.value('dos_mem_psp_mcb_end') == CHILD + 0x100
    owner_scope_restored = 'dos_mem_free_owner' not in labels or m.value('dos_mem_free_owner') == 0
    if expected_error:
        passed = carry and ax == 9 and after == before and identity_preserved
    else:
        passed = not carry and root_preserved and live_preserved and tsr_freed and identity_preserved
    passed = passed and cache_preserved and owner_scope_restored
    return dict(name=name, ax=ax, carry=carry,
                first_mcb=m.value('dos_list_of_lists'), expected_first_mcb=SHELL - 1,
                root_preserved=root_preserved, live_preserved=live_preserved,
                tsr_freed=tsr_freed, identity_preserved=identity_preserved,
                psp_end_cache_preserved=cache_preserved, owner_scope_restored=owner_scope_restored,
                ah52_first_mcb=published_root,
                passed=passed, expected_error=expected_error,
                before={f'{k:04X}': v for k, v in before.items()},
                after={f'{k:04X}': v for k, v in after.items()})


def resize_case(image, labels, service):
    m = Machine(image, labels, 0x2100)
    before = m.chain()
    ax, carry = m.call('int21_handler', ax=service, bx=0x80, es=CHILD, interrupt=True)
    after = m.chain()
    root_preserved = m.value('dos_list_of_lists') == SHELL - 1
    live_preserved = all(after.get(p) == before[p] for p in (SHELL, TSR, LIVE))
    resized = after.get(CHILD) == dict(owner=CHILD, size=0x80)
    return dict(name=f'active-child-resize-{service:04X}', ax=ax, carry=carry,
                first_mcb=m.value('dos_list_of_lists'), root_preserved=root_preserved,
                live_preserved=live_preserved, tsr_freed=False, resized=resized,
                passed=not carry and root_preserved and live_preserved and resized
                and m.value('dos_exec_identity_psp') == CHILD)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    parser.add_argument('--expect-regression', action='store_true')
    parser.add_argument('--kernel', type=Path)
    parser.add_argument('--listing', type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='ciukios-f149-') as work:
        if args.kernel:
            assert args.listing, '--kernel requires the matching --listing'
            image, labels = args.kernel.read_bytes(), symbols(args.listing.read_text())
        else:
            image, labels = assemble(Path(work))
        global SHELL
        SHELL = inspect_kernel(image)['regions']['com_arena']['start_segment']
        cases = [run_case(image, labels, 'resident-parent-non-PSP', 0x2100),
                 run_case(image, labels, 'resident-parent-zero', 0),
                 run_case(image, labels, 'resident-parent-live-root', SHELL),
                 run_case(image, labels, 'resident-parent-live-child', CHILD),
                 run_case(image, labels, 'resident-wrong-owner', 0x2100, owner=CHILD, expected_error=True),
                 run_case(image, labels, 'resident-zero-owner', 0x2100, owner=0, expected_error=True),
                 run_case(image, labels, 'allocated-correct-owner', 0x2100, resident=False),
                 run_case(image, labels, 'allocated-wrong-owner', 0x2100, resident=False,
                          owner=CHILD, expected_error=True),
                 run_case(image, labels, 'ordinary-free-live-owned-block', 0x2100,
                          service=0x4900, target=LIVE),
                 run_case(image, labels, 'ordinary-free-foreign-block', 0x2100,
                          service=0x4900, resident=False, expected_error=True),
                 run_case(image, labels, 'private-free-live-owned-block', 0x2100,
                          target=LIVE, owner=CHILD),
                 resize_case(image, labels, 0x4A00),
                 resize_case(image, labels, 0xF14A)]
    report = dict(kernel_sha256=hashlib.sha256(image).hexdigest(),
                  passed=all(c['passed'] for c in cases), cases=cases,
                  real_allocator=True, allocator_mocks=False)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'cases'}))
    for c in cases:
        print(c['name'], 'PASS' if c['passed'] else 'FAIL',
              f'first MCB {c["first_mcb"]:04X}', f'TSR freed {c["tsr_freed"]}',
              f'live allocations {c["live_preserved"]}')
    if args.expect_regression:
        assert not report['passed'], 'expected to reproduce the old failure'
    else:
        assert report['passed'], 'F149 changed the arena root or live allocations'


if __name__ == '__main__':
    main()
