#!/usr/bin/env python3
"""Execute the production VMSTART DOSMEM assembly under hooked DOS managers."""

from __future__ import annotations

import subprocess
import tempfile
import argparse
import json
from pathlib import Path

from unicorn import UC_ARCH_X86, UC_HOOK_CODE, UC_HOOK_INTR, UC_MODE_16, Uc
from unicorn.x86_const import (
    UC_X86_REG_AX, UC_X86_REG_AH, UC_X86_REG_BX,
    UC_X86_REG_BH, UC_X86_REG_CX, UC_X86_REG_DX, UC_X86_REG_DL,
    UC_X86_REG_EAX, UC_X86_REG_EBX,
    UC_X86_REG_ECX, UC_X86_REG_EDX, UC_X86_REG_ES, UC_X86_REG_DS,
    UC_X86_REG_CS, UC_X86_REG_IP, UC_X86_REG_EFLAGS,
)

from read_dos_memory import parse_record


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "scripts/fixtures/vm_memory_report_harness.asm"
SEG = 0x1000
XMS_SEG = 0x3000
LOAD = SEG * 16 + 0x100
XMS_ENTRY = XMS_SEG * 16
SENTINELS = (0x11223344, 0x22334455, 0x33445566, 0x44556677,
             0x55667788, 0x66778899, 0x778899AA)


def assemble() -> bytes:
    with tempfile.TemporaryDirectory() as directory:
        output = Path(directory) / "fixture.com"
        subprocess.run(["nasm", "-f", "bin", FIXTURE.name, "-o", str(output)],
                       cwd=FIXTURE.parent, check=True)
        return output.read_bytes()


def execute(image: bytes, *, xms="success", xms_status=0, largest=185000,
            total=200000, vcpi="success", vcpi_pages=12345,
            write="success") -> tuple[dict, bytes | None, str, int]:
    uc = Uc(UC_ARCH_X86, UC_MODE_16)
    uc.mem_map(SEG * 16, 0x10000)
    uc.mem_map(XMS_SEG * 16, 0x1000)
    uc.mem_write(LOAD, image)
    uc.mem_write(XMS_ENTRY, b"\xcb")  # Production code performs the far call/return.
    uc.reg_write(UC_X86_REG_CS, SEG)
    uc.reg_write(UC_X86_REG_DS, SEG)
    uc.reg_write(UC_X86_REG_ES, SEG)
    uc.reg_write(UC_X86_REG_IP, 0x100)
    uc.reg_write(UC_X86_REG_EFLAGS, 0x202)
    written = None
    console = bytearray()
    xms_calls: list[int] = []
    allocation_calls: list[int] = []
    writes = 0

    def set_carry(enabled: bool) -> None:
        flags = uc.reg_read(UC_X86_REG_EFLAGS)
        uc.reg_write(UC_X86_REG_EFLAGS, (flags | 1) if enabled else (flags & ~1))

    def xms_code(machine: Uc, address: int, size: int, _data) -> None:
        nonlocal xms_calls
        function = machine.reg_read(UC_X86_REG_AH)
        xms_calls.append(function)
        if function == 0:
            machine.reg_write(UC_X86_REG_AX, 0x0200 if xms == "old" else 0x0300)
        elif function == 0x88:
            if xms != "success":
                allocation_calls.append(function)
            machine.reg_write(UC_X86_REG_EAX, largest)
            machine.reg_write(UC_X86_REG_EDX, total)
            # BL is the defined XMS status return for AH=88h.
            machine.reg_write(UC_X86_REG_EBX,
                              (machine.reg_read(UC_X86_REG_EBX) & 0xFFFFFF00) | xms_status)
        else:
            allocation_calls.append(function)
            machine.emu_stop()

    def interrupt(machine: Uc, number: int, _data) -> None:
        nonlocal written, writes
        if number == 0x2F:
            ax = machine.reg_read(UC_X86_REG_AX)
            if ax == 0x4300:
                machine.reg_write(UC_X86_REG_AX, 0x0080 if xms != "missing" else 0)
            elif ax == 0x4310 and xms != "missing":
                machine.reg_write(UC_X86_REG_BX, 0)
                machine.reg_write(UC_X86_REG_ES, XMS_SEG)
            else:
                raise AssertionError(f"unexpected INT 2Fh AX={ax:04X}")
            return
        if number == 0x67:
            ax = machine.reg_read(UC_X86_REG_AX)
            if ax == 0xDE00:
                if vcpi == "absent":
                    machine.reg_write(UC_X86_REG_AX, 0x8400)
                else:
                    machine.reg_write(UC_X86_REG_AX, 0)
                    machine.reg_write(UC_X86_REG_BH, 0x10)
            elif ax == 0xDE03:
                if vcpi == "error":
                    machine.reg_write(UC_X86_REG_AX, 0x8400)
                else:
                    machine.reg_write(UC_X86_REG_AX, 0)
                    machine.reg_write(UC_X86_REG_EDX, vcpi_pages)
            else:
                raise AssertionError(f"unexpected INT 67h AX={ax:04X}")
            return
        if number != 0x21:
            raise AssertionError(f"unexpected interrupt {number:02X}h")
        ah = machine.reg_read(UC_X86_REG_AH)
        if ah == 0x02:
            console.append(machine.reg_read(UC_X86_REG_DL))
        elif ah == 0x3C:
            if write == "open_error":
                machine.reg_write(UC_X86_REG_AX, 5)
                set_carry(True)
            else:
                machine.reg_write(UC_X86_REG_AX, 5)
                set_carry(False)
        elif ah == 0x40:
            writes += 1
            count = machine.reg_read(UC_X86_REG_CX)
            offset = machine.reg_read(UC_X86_REG_DX)
            ds = machine.reg_read(UC_X86_REG_DS)
            written = bytes(machine.mem_read(ds * 16 + offset, count))
            if write == "write_error":
                machine.reg_write(UC_X86_REG_AX, 5)
                set_carry(True)
            elif write == "short_write":
                machine.reg_write(UC_X86_REG_AX, count - 1)
                set_carry(False)
            else:
                machine.reg_write(UC_X86_REG_AX, count)
                set_carry(False)
        elif ah == 0x3E:
            set_carry(False)
        elif ah == 0x4C:
            machine.emu_stop()
        else:
            raise AssertionError(f"unexpected INT 21h AH={ah:02X}")

    uc.hook_add(UC_HOOK_CODE, xms_code, begin=XMS_ENTRY, end=XMS_ENTRY)
    uc.hook_add(UC_HOOK_INTR, interrupt)
    uc.emu_start(LOAD, SEG * 16 + 0x10000, count=1000000)
    if allocation_calls:
        raise AssertionError(f"XMS allocation/unsupported function invoked: {allocation_calls}")
    if writes > 1:
        raise AssertionError(f"expected at most one record write, got {writes}")
    # The final 32 bytes before the stack are the harness result block; locate
    # its label by reassembling the NASM listing is unnecessary because the
    # fixture emits it immediately before the 256-byte stack.
    results = bytes(uc.mem_read(LOAD + len(image) - 288, 32))
    regs = tuple(int.from_bytes(results[i:i + 4], "little") for i in range(0, 28, 4))
    segments = tuple(int.from_bytes(results[i:i + 2], "little") for i in (28, 30))
    if regs != SENTINELS or segments != (SEG, SEG):
        raise AssertionError(f"vm_memory_report clobbered state: {regs!r}, {segments!r}")
    report = parse_record(written) if written is not None and len(written) == 32 else None
    return report, written, console.decode("ascii", errors="replace"), len(xms_calls)


def check(name: str, **kwargs) -> tuple[dict | None, bytes | None, str, int]:
    report, record, console, xms_calls = execute(IMAGE, **kwargs)
    if report is None and kwargs.get("write", "success") == "success":
        raise AssertionError(f"{name}: missing complete record")
    return report, record, console, xms_calls


IMAGE = assemble()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path,
                        default=ROOT / "build/tests/dosmem-queries-r15/report.json")
    args = parser.parse_args()
    cases = {}
    cases["success"] = check("success", vcpi="success")
    cases["xms_missing"] = check("xms_missing", xms="missing", vcpi="absent")
    cases["xms_old"] = check("xms_old", xms="old", vcpi="absent")
    cases["xms_zero_available"] = check("xms_zero_available", xms_status=0xA0,
                                        largest=0, total=0, vcpi="absent")
    cases["xms_query_error"] = check("xms_query_error", xms_status=0x81,
                                     largest=4096, total=8192, vcpi="absent")
    cases["vcpi_absent"] = check("vcpi_absent", vcpi="absent")
    cases["vcpi_query_error"] = check("vcpi_query_error", vcpi="error")
    cases["write_error"] = check("write_error", write="write_error")
    cases["open_error"] = check("open_error", write="open_error")
    cases["short_write"] = check("short_write", write="short_write")

    success = cases["success"][0]
    assert success["xms"]["largest_free_kib"] == 185000
    assert success["xms"]["total_free_kib"] == 200000
    assert success["vcpi"]["free_4k_pages"] == 12345
    assert success["result_flags"]["xms_query_ok"] and success["result_flags"]["vcpi_query_ok"]
    assert cases["xms_missing"][0]["error_flags"]["xms_missing_or_old"]
    assert cases["xms_old"][0]["xms"]["query_status"] == 0x80
    assert cases["xms_zero_available"][0]["xms"]["query_status"] == 0xA0
    assert cases["xms_zero_available"][0]["xms"]["largest_free_kib"] == 0
    assert cases["xms_zero_available"][0]["xms"]["total_free_kib"] == 0
    assert cases["xms_zero_available"][0]["error_flags"]["xms_query_error"]
    assert cases["xms_query_error"][0]["xms"]["query_status"] == 0x81
    assert cases["xms_query_error"][0]["error_flags"]["xms_query_error"]
    assert cases["vcpi_absent"][0]["error_flags"]["vcpi_absent"]
    assert cases["vcpi_query_error"][0]["error_flags"]["vcpi_query_error"]
    for name in ("write_error", "open_error", "short_write"):
        assert "write failed" in cases[name][2], (name, cases[name][2])
    assert cases["success"][3] == 2  # XMS version + AH=88; no allocator function.
    assert cases["xms_old"][3] == 1  # AH=88 is not called on pre-3.0 managers.
    assert cases["xms_missing"][3] == 0
    scenario_results = {}
    for name, (decoded, raw, console, xms_calls) in cases.items():
        scenario_results[name] = {
            "passed": True,
            "record": decoded,
            "record_hex": raw.hex() if raw is not None else None,
            "console": console,
            "xms_function_calls": xms_calls,
            "xms_allocations_attempted": False,
        }
    report = {
        "fixture": "scripts/fixtures/vm_memory_report_harness.asm",
        "module": "src/com/vm_memory_report.inc",
        "execution": "Unicorn 16-bit x86; assembled module with hooked INT 2Fh, INT 67h, INT 21h, and XMS far-call entry",
        "passed": True,
        "scenario_count": len(cases),
        "allocation_calls": 0,
        "caller_registers_and_segments_preserved": True,
        "scenarios": scenario_results,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(f"[DOSMEM-UNICORN] PASS {len(cases)} assembled manager/query/write scenarios; no allocations")
    print(f"[DOSMEM-UNICORN] REPORT {args.report}")


if __name__ == "__main__":
    main()
