#!/usr/bin/env python3
"""Execute the complete LFN.COM binder and production far kernel bridges.

Unicorn supplies CPU execution, not hardware qualification. Sector routines
are observable near-procedure fixtures; production bridge and import code is
assembled unchanged. Optional real kernels test the same complete module.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16
from unicorn import x86_const as x

ROOT = Path(__file__).resolve().parents[1]
MSEG, STOP, STACK = 0x6000, 0xfe00, 0xf000
REGS = ('BX', 'CX', 'DX', 'SI', 'DI', 'BP', 'DS', 'ES')


def word(data, offset):
    return struct.unpack_from('<H', data, offset)[0]


def putword(data, offset, value):
    struct.pack_into('<H', data, offset, value)


def fixture(out, table_pad=0, extra=0):
    source = (ROOT/'src/boot/floppy_stage1.asm').read_text()
    start = source.index('\nfat12_flush_cache:\n', source.index('read_sector_lba32:'))
    end = source.index('\n%else\n', start)
    flush = source[start:end]
    text = f'''cpu 386
bits 16
org 0
%include "src/runtime/ciukidos_abi.inc"
%define DOS_FAT_BUF_SEG 0x2800
%define FAT1_LBA 73
%define FAT2_LBA 201
    jmp short trampoline
    db 'CIUKIDOS'
    dw 26, 2, {13+extra}, 8, 0x3F, image_end, runtime_table, 0x900
trampoline:
    jmp unused
    times {table_pad} db 0
runtime_table:
    db 'RTSV'
    dw 2, {13+extra}, 8
%assign id 1
%rep 12
    dw id, 1, unused, 0
%assign id id+1
%endrep
    dw 13, 1, kernel_runtime_lfn_api_service, 0
%rep {extra}
    dw id+1, 1, unused, 0
%assign id id+1
%endrep
unused:
    retf
%include "src/runtime/ciukidos_lfn_services.inc"
read_sector_lba32:
    inc word [cs:reads]
    jmp record
write_sector_lba32:
    inc word [cs:writes]
record:
    mov [cs:last_lba], ax
    mov [cs:last_lba+2], dx
    mov [cs:last_buffer], bx
    mov [cs:last_buffer+2], es
    cmp byte [cs:fail_io], 0
    jne failed
    clc
    ret
failed:
    stc
    ret
write_sector_lba:
    push dx
    xor dx, dx
    call write_sector_lba32
    pop dx
    ret
{flush}
fat_cache_sector dw 0xffff
fat_cache_valid db 0
fat_cache_dirty db 0
dos_indos_flag db 0
fail_io db 0
reads dw 0
writes dw 0
last_lba dd 0
last_buffer dd 0
    db 'LFNFIX1!'
    dw kernel_lfn_api_table, reads, writes, last_lba, last_buffer
    dw fail_io, fat_cache_sector, fat_cache_valid, fat_cache_dirty, dos_indos_flag
image_end:
'''
    asm = out/f'kernel-pad{table_pad}-extra{extra}.asm'
    binary = asm.with_suffix('.bin')
    asm.write_text(text)
    subprocess.run(['nasm', '-f', 'bin', str(asm), '-o', str(binary)],
                   cwd=ROOT, check=True)
    data = binary.read_bytes()
    pos = data.index(b'LFNFIX1!')+8
    fields = ('api', 'reads', 'writes', 'last_lba', 'last_buffer', 'fail_io',
              'fat_sector', 'fat_valid', 'fat_dirty', 'indos')
    return data, dict(zip(fields, struct.unpack_from('<10H', data, pos)))


class Machine:
    def __init__(self, module, symbols, kernel, segment=0x300):
        self.s, self.kseg = symbols, segment
        self.u = Uc(UC_ARCH_X86, UC_MODE_16)
        self.u.mem_map(0, 0x100000)
        self.u.mem_write(MSEG*16+0x100, module)
        self.u.mem_write(segment*16, bytes(kernel))
        self.u.mem_write(MSEG*16+STOP, b'\xf4')

    def call(self, name, ax=0x1234):
        values = dict(BX=0xb123, CX=0xc123, DX=0xd123, SI=0x9123,
                      DI=0x8123, BP=0x7123, DS=MSEG, ES=self.kseg)
        for reg, value in values.items():
            self.u.reg_write(getattr(x, 'UC_X86_REG_'+reg), value)
        self.u.reg_write(x.UC_X86_REG_AX, ax)
        self.u.reg_write(x.UC_X86_REG_CS, MSEG)
        self.u.reg_write(x.UC_X86_REG_SS, MSEG)
        self.u.reg_write(x.UC_X86_REG_SP, STACK)
        self.u.reg_write(x.UC_X86_REG_EFLAGS, 0x202)
        self.u.mem_write(MSEG*16+STACK, struct.pack('<H', STOP))
        self.u.emu_start(MSEG*16+self.s[name], MSEG*16+STOP, count=100000)
        assert self.u.reg_read(x.UC_X86_REG_IP) == STOP, name
        assert self.u.reg_read(x.UC_X86_REG_SP) == STACK+2, name
        for reg, value in values.items():
            actual = self.u.reg_read(getattr(x, 'UC_X86_REG_'+reg))
            assert actual == value, (name, reg, actual, value)
        return self.u.reg_read(x.UC_X86_REG_AX), self.u.reg_read(x.UC_X86_REG_EFLAGS)&1

    def pointers(self):
        raw = self.u.mem_read(MSEG*16+self.s['lfn_entries'], 24)
        return list(struct.unpack('<12H', raw))

    def bind(self, expected=True):
        result = self.call('lfn_bind_runtime')
        assert result == ((0, 0) if expected else (1, 1)), result
        if not expected:
            assert self.pointers() == [0]*12
        return self

    def read(self, offset, size=2):
        return int.from_bytes(self.u.mem_read(self.kseg*16+offset, size), 'little')

    def write(self, offset, value, size=2):
        self.u.mem_write(self.kseg*16+offset, value.to_bytes(size, 'little'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'build/tests/lfn-public-abi')
    parser.add_argument('--module-dir', type=Path)
    parser.add_argument('--kernel', type=Path, action='append', default=[])
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    module_dir = args.module_dir or out/'module'
    subprocess.run(['bash', 'scripts/build_lfn.sh', str(module_dir)], cwd=ROOT, check=True)
    module = (module_dir/'LFN.COM').read_bytes()
    symbols = {m[2]: int(m[1], 16) for m in re.finditer(
        r'^([0-9A-Fa-f]{8})[+*]?\s+(\w+)\s*$',
        (module_dir/'lfn.map').read_text(), re.M)}
    assert 'lfn_bind_runtime' in symbols and 'lfn_entries' in symbols
    # Build-time dependency regression: imports must come from public ABI
    # definitions, never the kernel listing/private offsets/code signatures.
    for path in ('scripts/build_lfn.sh', 'src/lfn/lfn_start.asm', 'src/lfn/lfn.c'):
        source = (ROOT/path).read_text()
        for private in ('KL_READ', 'KL_WRITE', 'KL_RETF', 'KL_FAT', 'KL_INDOS',
                        'lfn_kernel.inc', 'ciukidos.lst'):
            assert private not in source, (path, private)
    kernel, f = fixture(out)
    table = word(kernel, 22)
    service = table+10+12*8
    api = f['api']
    cases = []
    for segment, padding, extra in ((0x300, 0, 0), (0x700, 20, 1)):
        data, fields = fixture(out, padding, extra)
        machine = Machine(module, symbols, data, segment).bind()
        expected = []
        for i in range(6):
            expected += [word(data, fields['api']+16+i*8+4), segment]
        assert machine.pointers() == expected
        cases.append(f'bind relocated segment {segment:04X}, table padding {padding}, additive {extra}')

    negatives = []
    def negative(name, edits):
        bad = bytearray(kernel)
        for offset, raw in edits:
            bad[offset:offset+len(raw)] = raw
        try:
            Machine(module, symbols, bad).bind(False)
        except AssertionError as error:
            raise AssertionError(name) from error
        negatives.append(name)

    def w(name, offset, value):
        negative(name, [(offset, struct.pack('<H', value))])

    negative('kernel identity', [(2, b'X')])
    for name, offset, value in (
        ('kernel ABI', 12, 3), ('header too short', 10, 25),
        ('image too short', 20, 26), ('image beyond limit', 20, 0xf001),
        ('table wrap', 22, 0xffff), ('table below header', 22, 10),
        ('table truncated', 22, len(kernel)-4), ('header descriptor size', 16, 9),
        ('RTSV ABI', table+4, 3), ('RTSV descriptor size', table+8, 9),
        ('missing service count', 14, 12), ('count mismatch', table+6, 14),
        ('missing service ID', service, 99), ('service ABI', service+2, 2),
        ('service reserved', service+6, 1), ('getter in table', service+4, table),
        ('getter outside image', service+4, len(kernel)), ('CLFN ABI', api+4, 2),
        ('CLFN size mismatch', api+6, 63), ('CLFN short count', api+8, 5),
        ('CLFN oversized count', api+8, 0x2000), ('CLFN stride', api+10, 9),
        ('CLFN flags', api+12, 0), ('CLFN reserved', api+14, 1),
        ('missing entry ID', api+16+5*8, 99), ('duplicate ID', api+16+5*8, 1),
        ('entry ABI', api+16+2, 2),
        ('entry in header', api+16+4, 2), ('entry in CLFN', api+16+4, api),
        ('entry outside image', api+16+4, len(kernel)),
    ):
        w(name, offset, value)
    negative('RTSV magic', [(table, b'X')])
    negative('CLFN magic', [(api, b'X')])
    negative('RTSV count overflow', [(14, b'\x00\x20'), (table+6, b'\x00\x20')])
    getter = word(kernel, service+4)
    # The production getter correctly relocates segments from CS. To test
    # the consumer against a genuinely malformed returned far pointer,
    # substitute a getter returning the table without repairing its fields.
    returned = [(api+16+i*8+6, struct.pack('<H', 0x300)) for i in range(6)]
    returned += [(api+16+6, struct.pack('<H', 0x301)),
                 (getter, b'\x0e\x1f\xbe'+struct.pack('<H', api)
                  +b'\xb8\x01\x00\xb9\x40\x00\xf8\xcb')]
    negative('returned entry wrong segment', returned)
    negative('getter reports carry', [(getter, b'\xf9\xcb')])
    negative('getter reports wrong version', [(getter, b'\xb8\x02\x00\xf8\xcb')])
    negative('getter reports wrong segment', [(getter, b'\xb8\x00\x07\x8e\xd8\xb8\x01\x00\xf8\xcb')])
    negative('getter reports short size', [(getter, b'\xb8\x01\x00\xb9\x3f\x00\xf8\xcb')])

    machine = Machine(module, symbols, kernel).bind()
    q = struct.pack('<IHHH', 0x12345678, 0xe400, 0x5000, 0)
    machine.u.mem_write(MSEG*16+0xe000, q)
    assert machine.call('kio_', 0xe000)[0] == 0
    assert machine.read(f['reads']) == 1 and machine.read(f['writes']) == 0
    assert machine.read(f['last_lba'], 4) == 0x12345678
    assert machine.read(f['last_buffer'], 4) == 0x5000e400
    machine.u.mem_write(MSEG*16+0xe008, b'\x01\x00')
    assert machine.call('kio_', 0xe000)[0] == 0
    assert machine.read(f['writes']) == 1
    machine.write(f['fail_io'], 1, 1)
    assert machine.call('kio_', 0xe000)[0] == 1
    machine.write(f['fat_sector'], 3)
    machine.write(f['fat_valid'], 1, 1)
    machine.write(f['fat_dirty'], 1, 1)
    assert machine.call('kflush_')[0] == 1
    assert machine.read(f['fat_dirty'], 1) == 1
    machine.write(f['fail_io'], 0, 1)
    before = machine.read(f['writes'])
    assert machine.call('kflush_')[0] == 0
    assert machine.read(f['writes']) == before+2
    assert machine.read(f['last_lba'], 4) == 204
    assert machine.read(f['last_buffer'], 4) == 0x28000000
    assert machine.read(f['fat_dirty'], 1) == 0
    assert machine.call('kinvalidate_')[0] == 0
    assert machine.read(f['fat_sector']) == 0xffff
    assert machine.read(f['fat_valid'], 1) == machine.read(f['fat_dirty'], 1) == 0
    machine.write(f['indos'], 7, 1)
    assert machine.call('kenter_')[0] == 0 and machine.read(f['indos'], 1) == 8
    assert machine.call('kleave_')[0] == 0 and machine.read(f['indos'], 1) == 7
    machine.write(f['indos'], 255, 1)
    assert machine.call('kenter_')[0] == 1 and machine.read(f['indos'], 1) == 255
    machine.write(f['indos'], 0, 1)
    assert machine.call('kleave_')[0] == 1 and machine.read(f['indos'], 1) == 0
    cases += ['read/write far ABI and error propagation', 'real kernel FAT flush body and invalidation',
              'balanced InDOS enter/leave and wrap rejection', 'all bridge register/stack preservation']

    real = []
    for path in args.kernel:
        data = path.read_bytes()
        machine = Machine(module, symbols, data).bind()
        assert all(machine.pointers()[i*2+1] == 0x300 for i in range(6))
        real.append(dict(path=str(path), bytes=len(data),
                         sha256=hashlib.sha256(data).hexdigest()))
    report = dict(result='PASS', module_bytes=len(module),
                  module_sha256=hashlib.sha256(module).hexdigest(), positives=cases,
                  rejected=negatives, actual_kernels=real,
                  limitation='CPU/public ABI checks; no physical hardware qualification')
    (out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(f'[lfn-public-abi] PASS: {len(cases)} positive groups, '
          f'{len(negatives)} rejected contracts, {len(real)} actual kernels; {out}/report.json')


if __name__ == '__main__':
    main()
