#!/usr/bin/env python3
"""Run the production VM0 disk binder with deterministic BIOS/JLM contracts.

Checks immediate DPTE copy, AH08 translation, reference re-read after reset,
temporary firmware stack, error handling and preservation of caller registers.
Hardware I/O and timing are not emulated here.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from unicorn import x86_const as x
from test_vmfork_launch_diagnostics import Machine, REGS, symbols, ROOT

API, DPTE, BIOS_STACK = 0xe0000, 0xf1000, 0x6000


class BinderMachine(Machine):
    def __init__(self, image, labels, *, reset=False, fail=None, ready=False, optional=False, short=False, crossing=False, dpte_address=DPTE):
        self.need_reset, self.fail, self.ready = reset, fail, ready
        self.optional, self.short, self.crossing = optional, short, crossing
        self.dpte_address=dpte_address
        self.discovery, self.aborted = False, False
        self.prepared = self.observed = False
        self.bios, self.allocs, self.frees, self.operations = [], [], [], []
        self.saved_status = self.saved_binding = None
        self.dpte = bytearray(16)
        struct.pack_into('<HHBBB',self.dpte,0,0x1f0,0x3f6,0xe0,0,14)
        struct.pack_into('<H',self.dpte,10,0x10)
        self.dpte[14]=0x11
        self.dpte[15]=(-sum(self.dpte)) & 255
        super().__init__(image,labels)
        self.u.mem_write(self.base+labels['entry'],struct.pack('<HH',0,API>>4))
        self.u.mem_write(API,b'\xcd\xfe\xcb')
        self.u.mem_write(self.dpte_address,bytes(self.dpte))

    def interrupt(self, uc, number, data):
        ax=uc.reg_read(x.UC_X86_REG_AX)
        ds,es,si,di=(uc.reg_read(r) for r in (x.UC_X86_REG_DS,x.UC_X86_REG_ES,
                                             x.UC_X86_REG_SI,x.UC_X86_REG_DI))
        cf,result=0,ax
        if number==0xfe:
            self.operations.append(ax)
            if ax==0x53:
                status=[int(self.ready),2 if self.ready else int(self.prepared),0,
                        0x1f0,0x3f6,0xe0,14,int(self.observed),0,7,0,0x50,0,0,
                        100000,16,63,100]
                uc.mem_write(es*16+di,struct.pack('<4sHH18I',b'CDS1',1,80,*status))
                uc.reg_write(x.UC_X86_REG_BX,0x80)
                result=0
                if self.fail=='query': cf,result=1,3
            elif ax==0x54:
                packet=bytes(uc.mem_read(es*16+di,64))
                assert packet[:8]==b'ADP1\x40\0\x80\0'
                assert packet[40:56]==self.dpte, 'DPTE must be copied before AH08'
                assert struct.unpack_from('<3H',packet,56)==(16,63,100)
                assert packet[38:40]==packet[62:64]==b'\0\0'
                self.prepared=True
                result=0
                if self.fail=='prepare': cf,result=1,3
            elif ax==0x55:
                assert self.prepared
                assert bytes(uc.mem_read(es*16+di,512))==bytes([0x5a])*512
                assert self.observed
                self.ready=True
                result=0
                if self.fail=='bind': cf,result=1,6
            elif ax==0x56:
                assert not self.prepared and not self.ready
                self.discovery=True; result=0
                if self.fail=='discovery_begin': cf,result=1,3
            elif ax==0x57:
                assert self.discovery
                self.discovery=False; result=0
                if uc.reg_read(x.UC_X86_REG_CX)==0:
                    self.aborted=True
                else:
                    assert 0 in self.bios and 0x42 in self.bios and self.observed
                    self.prepared=True
                    uc.mem_write(es*16+di+40,bytes(self.dpte))
                    if self.fail=='discovery_end': cf,result=1,3
            else: raise AssertionError(hex(ax))
        elif number==0x13:
            assert self.allocs==[BIOS_STACK] and not self.frees
            assert uc.reg_read(x.UC_X86_REG_SS)==BIOS_STACK
            assert 0xf00<=uc.reg_read(x.UC_X86_REG_SP)<=0x1000
            assert uc.reg_read(x.UC_X86_REG_DL)==0x80
            self.bios.append(ax>>8)
            # Firmware is permitted to use most of its private 4K stack.
            uc.mem_write(BIOS_STACK*16,bytes([0xda])*0xe00)
            if ax>>8==0x41:
                uc.reg_write(x.UC_X86_REG_BX,0xaa55)
                uc.reg_write(x.UC_X86_REG_CX,1 if self.optional else 5)
            elif ax>>8==0x48:
                edd=bytearray(30)
                struct.pack_into('<H',edd,0,26 if self.short else 30)
                struct.pack_into('<QH',edd,16,100000,512)
                # Preserve the exact physical T23 BDA spelling in its case.
                off,seg=(0xc6,0x40) if self.dpte_address==0x4c6 else (self.dpte_address&15,self.dpte_address>>4)
                struct.pack_into('<HH',edd,26,off,seg)
                if self.fail=='dpte' or self.optional or self.short:
                    struct.pack_into('<HH',edd,26,0xffff,0xffff)
                if self.crossing:
                    struct.pack_into('<HH',edd,26,0xfff8,(DPTE-0xfff8)>>4)
                    # Same physical table but a segment spelling crossing FFFFh.
                    cross=((DPTE-0xfff8)>>4)*16+0xfff8
                    uc.mem_write(cross,bytes(self.dpte))
                uc.mem_write(ds*16+si,bytes(edd))
            elif ax>>8==8:
                uc.reg_write(x.UC_X86_REG_CX,(99<<8)|63)
                uc.reg_write(x.UC_X86_REG_DX,0x0f80)
                uc.mem_write(self.dpte_address,b'\xcc'*16)  # temporary firmware table expires
            elif ax>>8==0x42:
                dap=struct.unpack('<BBHHHQ',bytes(uc.mem_read(ds*16+si,16)))
                assert dap[0:3]==(16,0,1) and dap[-1]==0
                uc.mem_write(dap[4]*16+dap[3],bytes([0x5a])*512)
                uc.mem_write(ds*16+si+2,b'\0\0') # next read must reset count
                if not self.need_reset or 0 in self.bios:
                    self.observed=True
            elif ax==0: pass
            else: raise AssertionError(hex(ax))
            if self.fail==f'bios{ax>>8:x}': cf,result=1,0x2000
            # The binder protects caller segments against firmware clobbers.
            uc.reg_write(x.UC_X86_REG_DS,0xdead)
            uc.reg_write(x.UC_X86_REG_ES,0xbeef)
        elif number==0x21:
            if ax>>8==0x48:
                assert uc.reg_read(x.UC_X86_REG_BX)==256
                if self.fail=='memory': cf,result=1,8
                else: self.allocs.append(BIOS_STACK); result=BIOS_STACK
            elif ax>>8==0x49:
                assert es==BIOS_STACK
                self.frees.append(es); result=0
            elif ax>>8==0x3c:
                path=bytes(uc.mem_read(ds*16+uc.reg_read(x.UC_X86_REG_DX),64)).split(b'\0')[0]
                assert path in (b'C:\\SYSTEM\\DISKATA.BIN',b'C:\\SYSTEM\\DISKBIND.BIN')
                result=7 if path.endswith(b'DISKATA.BIN') else 8
            elif ax>>8==0x40:
                assert uc.reg_read(x.UC_X86_REG_CX)==80
                record=bytes(uc.mem_read(ds*16+uc.reg_read(x.UC_X86_REG_DX),80))
                if uc.reg_read(x.UC_X86_REG_BX)==7: self.saved_status=record
                else: self.saved_binding=record
                result=80
            elif ax>>8==0x3e: result=0
            else: raise AssertionError(hex(ax))
        else: raise AssertionError(number)
        uc.reg_write(x.UC_X86_REG_AX,result)
        uc.reg_write(x.UC_X86_REG_EFLAGS,(uc.reg_read(x.UC_X86_REG_EFLAGS)&~1)|cf)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'kernel_layout.inc').write_text('KL_EXEC_PSP equ 20h\nKL_CURRENT_PSP equ 22h\n')
    binary,listing=a.output/'VMFORK.COM',a.output/'vmfork.lst'
    subprocess.run(['nasm','-f','bin','-I',str(a.output)+'/',
                    'src/com/vmfork.asm','-o',str(binary),'-l',str(listing)],cwd=ROOT,check=True)
    image,labels=binary.read_bytes(),symbols(listing.read_text()); cases=[]
    for reset in (False,True):
        m=BinderMachine(image,labels,reset=reset)
        before,after=m.run('disk_prepare_parent')
        assert before==after and m.ready and m.value('disk_prepare_result')==0
        assert m.bios==[0x41,0x48,8,0x42]+([0,0x42] if reset else [])
        assert m.allocs==m.frees==[BIOS_STACK] and m.value('disk_bios_stack')==0
        assert m.saved_status[:8]==b'CDS1\1\0P\0'
        assert m.saved_binding[:8]==b'CDB1\1\0P\0'
        assert struct.unpack_from('<H',m.saved_binding,8)[0]==5
        cases.append('bind exact DPTE,4K transient stack and '+('reset/fresh read' if reset else 'observed reference read'))
    m=BinderMachine(image,labels,ready=True)
    before,after=m.run('disk_prepare_parent')
    assert before==after and not m.bios and not m.allocs and not m.frees
    cases.append('existing native binding reused without firmware or allocation')
    for address in (0x400,0x4c6,0x500,0xff0,0x1000,0xfffe0,0xffff0):
        m=BinderMachine(image,labels,dpte_address=address)
        before,after=m.run('disk_prepare_parent')
        assert before==after and m.ready and m.value('disk_prepare_result')==0,hex(address)
        assert 0x54 in m.operations and 0x56 not in m.operations,hex(address)
        assert m.saved_binding[56:72]==m.dpte
        if address==0x4c6: assert struct.unpack_from('<HH',m.saved_binding,50)==(0xc6,0x40)
        cases.append(f'DPTE physical {address:05X} copied before BIOS reuse without discovery')
    for failure,phase in (('query',1),('memory',10),('bios41',2),('bios48',3),
                          ('bios8',5),('prepare',6),('bios42',7),
                          ('bind',8),('bios0',9)):
        m=BinderMachine(image,labels,reset=failure=='bios0',fail=failure)
        before,after=m.run('disk_prepare_parent')
        assert before==after,(failure,before,after)
        assert m.allocs==m.frees,failure
        assert m.value('disk_prepare_result')>>8==phase,failure
        cases.append(f'{failure} refusal preserves caller and frees transient stack')
    for mode in ('invalid_pointer','optional','short','crossing'):
        m=BinderMachine(image,labels,fail='dpte' if mode=='invalid_pointer' else None,
                        optional=mode=='optional',short=mode=='short',crossing=mode=='crossing')
        before,after=m.run('disk_prepare_parent')
        assert before==after and m.ready and m.value('disk_prepare_result')==0,mode
        assert m.allocs==m.frees==[BIOS_STACK]
        if mode=='crossing':
            assert 0x56 not in m.operations
        else:
            assert 0x56 in m.operations and 0x57 in m.operations
            assert m.bios==[0x41,0x48,8,0,0x42]
            assert m.saved_binding[12]==1
            assert m.saved_binding[50:54]==b'\xff'*4
            assert not m.discovery and not m.aborted
        cases.append(mode+' uses validated mapping or normalized direct DPTE')
    for failure,phase in (('discovery_begin',11),('discovery_end',13),('bios0',12),('bios42',12)):
        m=BinderMachine(image,labels,optional=True,fail=failure)
        before,after=m.run('disk_prepare_parent')
        assert before==after and m.allocs==m.frees
        assert m.value('disk_prepare_result')>>8==phase,(failure,m.value('disk_prepare_result'))
        if failure in ('bios0','bios42'): assert m.aborted and not m.discovery
        cases.append(failure+' observed-mapping refusal cleans callbacks and firmware stack')
    report={'passed':True,'hardware_validation':False,'unicorn':'2.1.4','cases':cases,
            'source_sha256':hashlib.sha256((ROOT/'src/com/vmfork_disk.inc').read_bytes()).hexdigest()}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
