#!/usr/bin/env python3
"""Execute actual 16-bit Paint BMP I/O with its far scratch under Unicorn."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_INTR, UC_HOOK_CODE, UC_HOOK_INSN
from unicorn import x86_const as x

ROOT = Path(__file__).resolve().parents[1]
SEG = 0x2000
BASE = SEG * 16
ROW_OFF, ROW_BYTES = 4800, 3072


def compile_bridge(out):
    flags = ['-q', '-2', '-ms', '-s', '-zl', '-os', '-d0', '-wx', '-we', '-zq', '-zm', '-i=src/apps']
    subprocess.run(['nasm', '-f', 'obj', 'src/apps/app_start.asm', '-o', str(out / 'start.obj')], cwd=ROOT, check=True)
    for source, unit in [('src/apps/rt.c', 'rt'), ('src/apps/ui.c', 'ui'),
                         ('scripts/fixtures/paint_scratch_bridge.c', 'paint')]:
        subprocess.run(['/opt/watcom/binl64/wcc', *flags, f'-fo={out / (unit + ".obj")}', source], cwd=ROOT, check=True)
    subprocess.run(['/opt/watcom/binl64/wlink', 'option', 'quiet', 'format', 'raw', 'bin',
                    'option', 'offset=0x100', 'option', 'start=app_entry', 'option', 'eliminate',
                    'reference', 'paint_scratch_call_', 'option', f'map={out / "paint.map"}',
                    'name', str(out / 'paint.bin'), 'file',
                    ','.join(str(out / (unit + '.obj')) for unit in ('start', 'paint', 'rt', 'ui'))], cwd=ROOT, check=True)
    text = (out / 'paint.map').read_text()
    symbols = {m[2]: int(m[1], 16) for m in re.finditer(r'^([0-9a-f]{8})\s+[+*]?\s*(\w+)\s*$', text, re.M)}
    stack = re.search(r'^STACK\s+STACK\s+DGROUP\s+([0-9a-f]{8})\s+([0-9a-f]{8})', text, re.M)
    top = int(stack[1], 16) + int(stack[2], 16)
    assert top <= 65536 and int(stack[2], 16) == 4096
    return (out / 'paint.bin').read_bytes(), symbols['paint_scratch_call_'], top


def bitmap(width, bpp):
    height = 3
    # These exact BGR colours exist in Paint's fixed palette. Use a pattern
    # that does not repeat at the 3072-byte chunk boundaries.
    colors = (b'\x14\x10\x10', b'\xff\xff\xff')
    palette = b''.join(c + b'\0' for c in colors) if bpp <= 8 else b''
    rowbytes = ((width * bpp + 31) // 32) * 4
    data = bytearray()
    expected = []
    for y in range(height):
        row = bytearray(rowbytes)
        pixels = []
        for i in range(width):
            v = int((i * 13 + i // 11 + y * 7) % 17 < 8)
            pixels.append(colors[v])
            if bpp == 8: row[i] = v
            elif bpp == 4: row[i // 2] |= v << (0 if i & 1 else 4)
            elif bpp == 1: row[i // 8] |= v << (7 - (i & 7))
            else: row[i * (bpp // 8):i * (bpp // 8) + 3] = pixels[-1]
        data.extend(row)
        expected.append(b''.join(pixels))
    off = 54 + len(palette)
    header = b'BM' + struct.pack('<IHHI', off + len(data), 0, 0, off)
    header += struct.pack('<IiiHHIIiiII', 40, width, height, 1, bpp, 0, len(data), 0, 0,
                          2 if palette else 0, 0)
    return header + palette + data, expected


class Machine:
    def __init__(self, image, entry, stack, source):
        self.u = Uc(UC_ARCH_X86, UC_MODE_16)
        self.u.mem_map(0, 0x100000)
        self.u.mem_write(BASE + 0x100, image)
        # The tested file operation notifies the shell of filesystem changes.
        # Supply its external service boundary; Paint/rt file and memory paths
        # remain the actual compiled production code.
        self.u.mem_write(BASE + 0x108, struct.pack('<HH', 0, 0x9000))
        self.u.mem_write(0x90000, b'\x31\xc0\xcb')  # xor ax,ax; retf
        self.entry, self.stack = entry, stack
        self.next_seg, self.allocs, self.freed = 0x5000, {}, []
        self.files, self.opened = {'IN.BMP': bytearray(source)}, {}
        self.next_handle, self.far_io, self.tabs = 5, [], 0
        self.u.hook_add(UC_HOOK_INTR, self.interrupt)
        self.u.hook_add(UC_HOOK_CODE, self.stop)
        self.u.hook_add(UC_HOOK_INSN, lambda *args: 0x20, None, 1, 0, x.UC_X86_INS_IN)
        self.u.hook_add(UC_HOOK_INSN, lambda *args: None, None, 1, 0, x.UC_X86_INS_OUT)

    def stop(self, uc, address, size, data):
        if address == BASE + 0x80: uc.emu_stop()

    def reg(self, name):
        return self.u.reg_read(getattr(x, 'UC_X86_REG_' + name))

    def result(self, ax, carry=False):
        self.u.reg_write(x.UC_X86_REG_AX, ax)
        self.u.reg_write(x.UC_X86_REG_EFLAGS, (self.reg('EFLAGS') & ~1) | carry)

    def interrupt(self, uc, number, data):
        assert number == 0x21, number
        ax, bx, cx, dx, ds = (self.reg(r) for r in ('AX', 'BX', 'CX', 'DX', 'DS'))
        ah = ax >> 8
        if ah == 0x71: self.result(0x7100, True); return
        if ah == 0x48:
            size = bx * 16
            segment = self.next_seg
            self.next_seg += bx + 2
            assert self.next_seg < 0x9F00
            self.allocs[segment] = size
            uc.mem_write(segment * 16, bytes([0xA5]) * (size + 16))
            self.result(segment); return
        if ah == 0x49:
            segment = self.reg('ES')
            assert segment in self.allocs and segment not in self.freed
            self.freed.append(segment); self.result(0); return
        if ah in (0x3C, 0x3D):
            path = bytes(uc.mem_read(ds * 16 + dx, 80)).split(b'\0')[0].decode('ascii')
            if ah == 0x3D and path not in self.files:
                self.result(2, True); return
            if ah == 0x3C: self.files[path] = bytearray()
            handle = self.next_handle; self.next_handle += 1
            self.opened[handle] = [path, 0]
            self.result(handle); return
        if ah == 0x3E:
            del self.opened[bx]; self.result(0); return
        if ah == 0x42:
            off = (cx << 16) | dx
            assert ax & 255 == 0
            self.opened[bx][1] = off
            self.result(off & 65535); uc.reg_write(x.UC_X86_REG_DX, off >> 16); return
        if ah in (0x3F, 0x40):
            name, pos = self.opened[bx]
            if ds != SEG:
                assert ds == self.tabs and dx == ROW_OFF and cx <= ROW_BYTES
                self.far_io.append(dict(operation='read' if ah == 0x3F else 'write', size=cx, offset=dx))
            if ah == 0x3F:
                chunk = bytes(self.files[name][pos:pos + cx])
                uc.mem_write(ds * 16 + dx, chunk)
                n = len(chunk)
            else:
                chunk = bytes(uc.mem_read(ds * 16 + dx, cx))
                self.files[name][pos:pos + cx] = chunk
                n = cx
            self.opened[bx][1] += n
            self.result(n); return
        raise AssertionError(f'unexpected INT21 {ax:04X}')

    def call(self, operation):
        for reg in ('CS', 'DS', 'ES', 'SS'): self.u.reg_write(getattr(x, 'UC_X86_REG_' + reg), SEG)
        self.u.reg_write(x.UC_X86_REG_SP, self.stack - 2)
        self.u.reg_write(x.UC_X86_REG_AX, operation)
        self.u.mem_write(BASE + self.stack - 2, struct.pack('<H', 0x80))
        self.u.emu_start(BASE + self.entry, 0xFFFFF, count=30_000_000)
        assert self.reg('IP') == 0x80, 'Paint operation did not return'
        return self.reg('AX')

    def canaries(self):
        assert bytes(self.u.mem_read(self.tabs * 16, ROW_OFF)) == bytes([0xA5]) * ROW_OFF
        for segment, size in self.allocs.items():
            assert bytes(self.u.mem_read(segment * 16 + size, 16)) == bytes([0xA5]) * 16


def output_pixels(raw):
    width, height = struct.unpack_from('<ii', raw, 18)
    off, colors = struct.unpack_from('<I', raw, 10)[0], struct.unpack_from('<I', raw, 46)[0]
    assert raw[:2] == b'BM' and struct.unpack_from('<H', raw, 28)[0] == 8
    palette = [raw[54 + i * 4:57 + i * 4] for i in range(colors)]
    stride = (width + 3) & ~3
    return [b''.join(palette[i] for i in raw[off + y * stride:off + y * stride + width])
            for y in range(height)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    cases = []
    with tempfile.TemporaryDirectory(prefix='ciukios-paint-scratch-') as work:
        image, entry, stack = compile_bridge(Path(work))
        for width, bpp in ((1280, 24), (2048, 24), (2048, 32), (2048, 8), (1281, 4), (2047, 1)):
            source, expected = bitmap(width, bpp)
            m = Machine(image, entry, stack, source)
            m.tabs = m.call(0)
            assert m.allocs[m.tabs] == ROW_OFF + ROW_BYTES
            assert m.call(1) == 0
            m.canaries()
            assert m.call(2) == 0
            m.canaries()
            assert output_pixels(m.files['OUT.BMP']) == expected, (width, bpp)
            assert m.far_io
            cases.append(dict(width=width, input_bpp=bpp, output_bpp=8,
                              lossless_palette_colors=True, far_io_calls=len(m.far_io),
                              largest_transfer=max(c['size'] for c in m.far_io), canaries_preserved=True))
            m.call(3)
            assert set(m.freed) == set(m.allocs), 'Paint leaked a DOS allocation'
    report = dict(passed=True, actual_16bit_paint=True, stack_bytes=4096,
                  scratch_offset=ROW_OFF, scratch_size=ROW_BYTES, cases=cases)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
