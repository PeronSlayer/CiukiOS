"""Launch an installed TestGames shortcut through real Files double-clicks.

Reusable by the current WindowVM/Utilities gates. This deliberately exercises
Files' working-directory change and an empty game argument string, unlike a
Run field containing a command plus -warp. No RAM writes or fixture files.
"""
from pathlib import Path
import json
import os
import re
import struct
import subprocess
import time

from qemu_test_desktop_apps import Gate
from qemu_test_installed_hdd import FAT16

FILES_WINDOW = 8
TESTGAMES = r'C:\DESKTOP\TestGames'


def files_menu_state(memory, binding=None):
    """Observe Files' actual near-pointer menubar; reject ambiguous bindings.

    The public CAPP menu ABI is in app.h. Bind through all five exact menu
    titles and their source-defined table, rather than guessing BSS offsets.
    """
    titles = (b'&File', b'&Edit', b'&View', b'&Go', b'&Help')

    def text(pointer):
        assert 0x180 <= pointer < len(memory), 'Menu string outside Files allocation'
        end = memory.find(b'\0', pointer, min(len(memory), pointer + 64))
        assert end >= 0, 'Unterminated Files menu string'
        return memory[pointer:end]

    def occurrences(needle):
        found, at = [], memory.find(needle)
        while at >= 0:
            if at % 2 == 0:
                found.append(at)
            at = memory.find(needle, at + 1)
        return found

    if binding is None:
        pointers = []
        for title in titles:
            assert memory.count(title + b'\0') == 1, 'Files menu title is ambiguous'
            pointers.append(memory.index(title + b'\0'))
        tables = [at for at in occurrences(struct.pack('<H', pointers[0]))
                  if at + 30 <= len(memory) and all(
                      struct.unpack_from('<H', memory, at + i * 6)[0] == pointer
                      for i, pointer in enumerate(pointers))]
        assert len(tables) == 1, f'Files menu table is ambiguous: {tables}'
        table = tables[0]
        bars = [at for at in occurrences(struct.pack('<HH', table, 5))
                if at + 30 <= len(memory) and
                -1 <= struct.unpack_from('<h', memory, at + 10)[0] < 5 and
                struct.unpack_from('<H', memory, at + 12)[0] in (0, 1)]
        assert len(bars) == 1, f'Files menubar is ambiguous: {bars}'
        binding = dict(menus=table, bar=bars[0])
    table, bar = binding['menus'], binding['bar']
    assert 0 <= table <= len(memory) - 30 and 0 <= bar <= len(memory) - 30
    assert struct.unpack_from('<HH', memory, bar) == (table, 5), 'Files menu binding changed'
    assert all(text(struct.unpack_from('<H', memory, table + i * 6)[0]) == title
               for i, title in enumerate(titles)), 'Files menu titles changed'
    view, count = struct.unpack_from('<HH', memory, table + 14)
    assert count == 12 and view + count * 8 <= len(memory), 'Files View menu layout changed'
    checked = {}
    for index, label, name, command in ((2, b'&Details', 'details', 17),
                                       (4, b'Sort by &Name', 'name', 18)):
        pointer, _, actual_command, flags = struct.unpack_from('<4H', memory, view + index * 8)
        assert text(pointer) == label and actual_command == command, 'Files View command layout changed'
        checked[name] = bool(flags & 4)
    active, keyboard, opened = struct.unpack_from('<hHH', memory, bar + 10)
    assert -1 <= active < 5 and keyboard in (0, 1) and opened in (0, 1), 'Invalid Files menu state'
    return dict(binding=binding, active=active, keyboard=keyboard, opened=opened, **checked)


def address_fields(memory, field_offset=None):
    """Locate Files' real near-pointer field; reject ambiguous observations."""
    found = []
    offsets = range(0, len(memory) - 12, 2) if field_offset is None else (field_offset,)
    for offset in offsets:
        if not 0 <= offset <= len(memory) - 12:
            continue
        pointer, capacity, length, cursor, selected, scroll = struct.unpack_from('<6H', memory, offset)
        if capacity != 260 or not (0x180 <= pointer <= len(memory) - capacity):
            continue
        if length >= capacity or cursor > length or selected > 1 or scroll > length:
            continue
        text = memory[pointer:pointer + capacity].split(b'\0', 1)[0]
        if len(text) != length or any(value < 32 for value in text):
            continue
        # Discovery requires the initialized drive/path. Once bound to this
        # exact structure, typing necessarily passes through "c" and "c:".
        if field_offset is None and not re.match(rb'[A-Za-z]:\\', text):
            continue
        found.append(dict(offset=offset, pointer=pointer, length=length, cursor=cursor,
                          selected=selected, text=text.decode('cp437')))
    return found


def observed_double_click(send_button, observe, executed, *, attempts=3,
                          timeout=30, clock=time.monotonic, sleep=time.sleep,
                          record=None):
    """Send real edges only after the shell acknowledges their predecessors.

    The BIOS clock bounds the interval conservatively: the first app callback
    cannot precede the sample taken before its injected press. An expired
    pair is released before retrying; no completed-paint wait extends it.
    """
    deadline = clock() + timeout
    events = []

    def event(data):
        events.append(data)
        if record is not None:
            record(data)

    def edge(button, description):
        edge_deadline = min(deadline, clock() + 10)
        state = None
        while clock() < edge_deadline:
            if executed():
                return None
            state = observe()
            consumed = (state['buttons'] & 1) == button and state['previous'] == button
            routed = state['capture'] == (FILES_WINDOW + 1 if button else 0)
            if consumed and routed and state['active'] == FILES_WINDOW:
                if button:
                    assert not (state['shift'] & 7), f'Modifier held during Files click: {state}'
                event(dict(edge=description, **state))
                return state
            sleep(.01)
        raise AssertionError(f'Files did not acknowledge {description}: {state}; events={events}')

    def fresh_after(tick):
        while clock() < deadline:
            if executed():
                return
            state = observe()
            if ((state['ticks'] - tick) & 0xffff) >= 9:
                return
            sleep(.01)
        raise AssertionError(f'Files double-click retry did not become fresh: {events}')

    try:
        send_button(0)
        released = edge(0, 'initial release')
        if released is None:
            return dict(attempts=0, events=events, executed_during_edge=True)
        for attempt in range(1, attempts + 1):
            # This sample precedes the first real down. Its tick is an earlier
            # bound than Files' last_click_tick, avoiding a false short pair.
            anchor = observe()['ticks']
            send_button(1)
            pressed = edge(1, f'press1 attempt{attempt}')
            if pressed is None:
                return dict(attempts=attempt, events=events, executed_during_edge=True)
            send_button(0)
            released = edge(0, f'release1 attempt{attempt}')
            if released is None:
                return dict(attempts=attempt, events=events, executed_during_edge=True)
            elapsed = (released['ticks'] - anchor) & 0xffff
            if elapsed >= 9:
                event(dict(expired=True, attempt=attempt, ticks=elapsed))
                fresh_after(pressed['ticks'])
                continue
            send_button(1)
            pressed = edge(1, f'press2 attempt{attempt}')
            if pressed is None:
                return dict(attempts=attempt, events=events, executed_during_edge=True)
            elapsed = (pressed['ticks'] - anchor) & 0xffff
            send_button(0)
            released = edge(0, f'release2 attempt{attempt}')
            if released is None or executed():
                return dict(attempts=attempt, events=events, executed_during_edge=True)
            if elapsed < 9:
                event(dict(pair_complete=True, attempt=attempt, first_to_second_ticks=elapsed))
                # Input delivery alone is not successful dispatch. Replaying
                # a timely pair could mask a routing or rename defect.
                while clock() < deadline:
                    if executed():
                        event(dict(executed=True, attempt=attempt))
                        return dict(attempts=attempt, events=events, first_to_second_ticks=elapsed)
                    sleep(.01)
                raise AssertionError(f'Files did not execute after a timely double-click: {events}')
            event(dict(expired=True, attempt=attempt, ticks=elapsed))
            fresh_after(pressed['ticks'])
        raise AssertionError(f'Files double-click expired after {attempts} attempts: {events}')
    except Exception as error:
        event(dict(error=str(error)))
        raise
    finally:
        # EXEC may switch active windows before a down can be sampled. Always
        # release the physical button, including failures and that transition.
        send_button(0)


def launch_testgames_from_files(vm, ui, disk, name):
    """Return the pre-launch serial offset and evidence for DOOM/WOLF3D.COM."""
    name = name.upper()
    assert name in ('DOOM.COM', 'WOLF3D.COM'), name
    disk = Path(disk)
    fat = FAT16(disk)
    volume = f'{disk}@@{fat.start}'
    entries = subprocess.check_output([
        'mdir', '-b', '-i', volume, '::DESKTOP/TestGames'
    ]).decode('utf-8', 'replace').splitlines()
    # The installed TestGames directory contains only visible COM launchers.
    # Read it independently so a changed catalog cannot silently click a
    # different application at a hard-coded row index.
    names = [entry.rsplit('/', 1)[-1] for entry in entries if entry.strip()]
    assert names and all(value.upper().endswith('.COM') for value in names), entries
    names.sort(key=str.upper)
    index = next((i for i, value in enumerate(names) if value.upper() == name), None)
    assert index is not None, (name, names)
    stem = 'files-launch-' + name.lower().replace('.', '-')
    sequence = len(list(vm.output.glob(stem + '-*.jsonl'))) + 1
    trace_path = vm.output / f'{stem}-{sequence}.jsonl'

    def trace(event, **values):
        record = dict(event=event, monotonic=time.monotonic(), **values)
        with trace_path.open('a') as stream:
            stream.write(json.dumps(record, sort_keys=True) + '\n')
            stream.flush()
            os.fsync(stream.fileno())

    trace('start', path=TESTGAMES + '\\' + name, catalog=names, row=index)
    files_binary = fat.read('SYSTEM/APPS/FILES.APP')
    assert files_binary[:4] == b'CAPP', 'Installed Files binary is not CAPP'
    files_bytes = struct.unpack_from('<H', files_binary, 6)[0] * 16
    assert 0x180 <= files_bytes <= 65536, 'Invalid Files allocation size'
    gate = Gate(vm)
    ui.refresh()
    if not (ui.b('ui_window_flags', FILES_WINDOW) & 1):
        opened = vm.offset(); vm.key('meta_l-e')
        vm.wait('WINDOW 08 OPEN', opened, 30)
        ui.until(lambda: ui.b('ui_active_window') == FILES_WINDOW, 'Files did not become active', 20)
    elif ui.b('ui_active_window') != FILES_WINDOW:
        # Use the exposed title, independently of taskbar routing.
        ui.click(62, FILES_WINDOW)
        ui.until(lambda: ui.b('ui_active_window') == FILES_WINDOW, 'Files title raise failed', 20)

    address_binding = {}

    def address():
        ui.refresh()
        segment = ui.w('app_segs', 0)  # Files is the source-defined module slot0.
        assert segment, 'Files module is not loaded'
        dump = vm.output / 'files-observed.bin'
        vm.hmp(f'pmemsave {segment << 4} 65536 "{dump}"')
        if address_binding:
            assert segment == address_binding['segment'], 'Files module changed during address editing'
        fields = address_fields(dump.read_bytes(), address_binding.get('offset'))
        assert len(fields) <= 1, f'Files address field is ambiguous: {fields}'
        if not fields:
            return None  # Bounded observer waits for initialization/update.
        if address_binding:
            assert fields[0]['pointer'] == address_binding['pointer'], 'Files address buffer moved'
        else:
            address_binding.update(segment=segment, offset=fields[0]['offset'], pointer=fields[0]['pointer'])
        return fields[0]

    def key(value):
        vm.key(value)

    menu_sequence = 0
    menu_binding = None

    def menu_key(value, opened, checked=None):
        nonlocal menu_sequence, menu_binding
        menu_sequence += 1
        stem = trace_path.stem + f'-menu-{menu_sequence}'
        dump = vm.output / (stem + '.bin')
        keyflags_dump = vm.output / 'files-keyflags.bin'

        def observe_menu():
            nonlocal menu_binding
            ui.refresh()
            segment = ui.w('app_segs', 0)
            assert segment == address_binding['segment'], 'Files module changed during menu input'
            vm.hmp(f'memsave {segment << 4} {files_bytes} "{dump}"')
            raw = dump.read_bytes()
            assert len(raw) == files_bytes and raw[0x100:0x108] == files_binary[:8], 'Files menu snapshot mismatch'
            state = files_menu_state(raw, menu_binding)
            menu_binding = state['binding']
            vm.hmp(f'pmemsave 1047 1 "{keyflags_dump}"')  # BIOS keyboard flags at 40:17
            flags = keyflags_dump.read_bytes()
            assert len(flags) == 1, 'Incomplete keyboard modifier observation'
            state['bios_shift'] = flags[0]
            return raw, state

        _, before = observe_menu()
        assert (before['active'] == -1 and not before['opened']) if opened else (
            before['active'] == 2 and before['opened']), f'Wrong menu before {value}: {before}'
        trace('menu_input', key=value, before=before)
        vm.hmp(f'sendkey {value} 150')
        deadline = time.monotonic() + 10
        while True:
            raw, current = observe_menu()
            accepted = (current['active'] == 2 and current['opened']) if opened else (
                current['active'] == -1 and not current['opened'] and not current['keyboard'])
            accepted = accepted and not (current['bios_shift'] & 0x0f)
            accepted = accepted and (checked is None or current[checked])
            if accepted and ui.b('ui_composing') == 0 and ui.b('ui_pointer_visible') == 1:
                break
            if time.monotonic() >= deadline:
                trace('menu_failed', key=value, state=current, dump=dump.name)
                raise AssertionError(f'Files did not acknowledge menu {value}: {current}; {trace_path.name}')
            time.sleep(.02)
        vm.shot(stem)
        trace('menu_after', key=value, dump=dump.name, screenshot=stem + '.ppm',
              menu=current,
              active=ui.b('ui_active_window'), cursor=ui.b('ui_cursor_type'),
              buttons=ui.w('ui_mouse_buttons'), previous=ui.b('ui_previous_button'),
              capture=ui.b('app_capture'), x=ui.w('ui_mouse_x'), y=ui.w('ui_mouse_y'),
              host_shift=struct.unpack_from('<H', raw, 0x124)[0],
              host_ticks=struct.unpack_from('<H', raw, 0x128)[0])

    def observed(predicate, description, timeout=10):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            state = address()
            if state is not None and predicate(state):
                return state
            time.sleep(.1)
        raise AssertionError(f'{description}: {state}')

    # Click the actual address field instead of depending on an Alt+D whose
    # modifier may have been released before the app receives its queued key.
    ui.refresh()
    fx, fy = (ui.w(label, FILES_WINDOW) for label in ('ui_window_x', 'ui_window_y'))
    vm.completed_control_click(fx + 90, fy + 95)
    key('ctrl-a')
    observed(lambda state: state['selected'] == 1, 'Address was not selected')
    navigate = vm.offset()
    prefix = ''
    for ch in TESTGAMES.lower():
        prefix += ch
        value = {'\\': 'backslash', ':': 'shift-semicolon'}.get(ch, ch)
        key(value)
        # Wait for each actual field update before adding another key. An
        # expensive wallpaper paint must not fill the BIOS keyboard queue.
        state = observed(lambda current: current['text'] == prefix,
                         f'Address did not accept prefix {prefix!r}')
    assert state['text'].upper() == TESTGAMES.upper(), f'Address lost input: {state}'
    key('ret')
    vm.wait('[FILES] list', navigate, 30)
    log = gate.serial(navigate)
    assert re.search(r'\[FILES\] list C:\\DESKTOP\\TESTGAMES\s+\d+', log, re.IGNORECASE), log[-1000:]
    # Details plus ascending Name sort gives a stable row layout. Files'
    # menu command explicitly resets sort_desc=0; only header clicks toggle
    # the direction. Do not substitute clicking the Name header here.
    menu_key('alt-v', True); menu_key('d', False, 'details')
    menu_key('alt-v', True); menu_key('n', False, 'name')
    ui.refresh()
    fx, fy, fw = (ui.w(label, FILES_WINDOW) for label in
                  ('ui_window_x', 'ui_window_y', 'ui_window_width'))
    # Production files.c layout: client=(x+3,y+30), menu20, toolbar34,
    # address28, details header22, row18; Places occupies160 at width>=566.
    places = 160 if fw - 6 >= 560 else 0
    px = fx + 65 + places
    py = fy + 143 + index * 18
    vm.position(px, py)
    launch = vm.offset()
    trace('click_target', point=[px, py], address=state, binding=address_binding)
    labels = ('ui_mouse_buttons', 'ui_previous_button', 'app_capture',
              'ui_active_window', 'app_segs')
    offsets = {label: ui.base + ui.offset(label) for label in labels}
    module_base = address_binding['segment'] << 4
    # One bounded read captures the BIOS tick, module HOST and listing-bound
    # shell fields together. It avoids three monitor round trips per edge.
    observed_bytes = max(max(offsets.values()) + 2, module_base + 0x134)
    assert observed_bytes <= 1048576, f'Files/shell state outside low memory: {observed_bytes}'
    mouse_dump = vm.output / 'files-mouse-observed.bin'

    def mouse_state():
        vm.hmp(f'pmemsave 0 {observed_bytes} "{mouse_dump}"')
        memory = mouse_dump.read_bytes()
        assert len(memory) == observed_bytes, 'Incomplete Files mouse observation'
        word = lambda offset: struct.unpack_from('<H', memory, offset)[0]
        assert word(offsets['app_segs']) == address_binding['segment'], 'Files module changed during click'
        return dict(buttons=word(offsets['ui_mouse_buttons']),
                    previous=memory[offsets['ui_previous_button']],
                    capture=memory[offsets['app_capture']],
                    active=memory[offsets['ui_active_window']], ticks=word(0x46c),
                    host_ticks=word(module_base + 0x128),
                    shift=word(module_base + 0x124))

    def send_button(button):
        trace('button_input', button=button)
        vm.hmp(f'mouse_button {button}')

    try:
        mouse_evidence = observed_double_click(
            send_button, mouse_state,
            lambda: '[FILES] execute ' in gate.serial(launch),
            record=lambda event: trace('mouse_observed', **event))
        trace('double_click_return', evidence=mouse_evidence)
        vm.wait('[FILES] execute', launch, 30)
        vm.wait('[DOSVM] open', launch, 30)
    except Exception as error:
        trace('failed', error=str(error), state=mouse_state())
        raise AssertionError(f'{error}; Files input evidence: {trace_path.name}') from error
    log = gate.serial(launch)
    executed = re.search(r'\[FILES\] execute ([^\r\n]+)', log)
    opened = re.search(r'\[DOSVM\] open ([^\r\n]+)', log)
    wanted = TESTGAMES + '\\' + name
    assert executed and executed.group(1).upper() == wanted.upper(), log[-1800:]
    assert opened and opened.group(1).upper() == wanted.upper(), log[-1800:]
    return launch, dict(route='Files double-click', path=wanted, arguments='',
                        files_directory=TESTGAMES, catalog=names, row=index,
                        click_point=[px, py], address_verified=state,
                        address_characters_verified=len(prefix), address_binding=address_binding,
                        mouse_edges_verified=mouse_evidence, input_trace=trace_path.name)
