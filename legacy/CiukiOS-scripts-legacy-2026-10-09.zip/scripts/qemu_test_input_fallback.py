#!/usr/bin/env python3
"""Exercise the OEM BIOS mouse fallback using stock CuteMouse and real PS/2 I/O.

Pass --loader and --loader-listing with a normal image to force only DH=E5 in
its private Stage1 copy. The older --kernel mode remains available for a
native-init-disabled kernel fixture. Neither mode establishes physical
E500/T23 firmware compatibility.
"""
import argparse, hashlib, json, shutil, subprocess, time
from pathlib import Path
from PIL import Image
from qemu_test_installed_hdd import FAT16
from qemu_test_native_windows import WindowVM

def sha(data):return hashlib.sha256(data).hexdigest()

def sha_file(path):
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()

STAGE1_IMAGE_OFFSET = 512


def loader_marker_offset(loader, listing_path):
    """Find and verify the default DH immediate from its assembled listing."""
    import re
    listing = listing_path.read_text()
    def instruction(pattern, name):
        matches = [re.match(pattern, line) for line in listing.splitlines()]
        found = [m for m in matches if m]
        assert len(found) == 1, f'expected one assembled {name} instruction, found {len(found)}'
        return int(found[0].group(1), 16)

    call = instruction(r'^\s*\d+\s+([0-9A-F]{8})\s+E8[0-9A-F]{4}\s+.*call input_platform_firmware_first\s*$', 'PCI probe call')
    set_default = instruction(r'^\s*\d+\s+([0-9A-F]{8})\s+B600\s+.*mov dh, 0\s*$', 'default DH marker')
    branch = instruction(r'^\s*\d+\s+([0-9A-F]{8})\s+7302\s+.*jnc \.input_policy_ready\s*$', 'PCI carry branch')
    set_match = instruction(r'^\s*\d+\s+([0-9A-F]{8})\s+B6E5\s+.*mov dh, 0xE5\s*$', 'matching DH marker')
    assert set_default == call + 3, 'default DH write no longer immediately follows the PCI probe call'
    assert branch == set_default + 2, 'PCI carry branch moved from the validated default write'
    assert set_match == branch + 2, 'matching marker write is no longer the branch target body'
    assert len(loader) > set_default + 1 and loader[set_default:set_default + 2] == b'\xB6\x00', \
        'loader bytes disagree with listing at default DH write'
    assert loader[branch:branch + 2] == b'\x73\x02', 'loader bytes disagree with listing at JNC'
    assert loader[set_match:set_match + 2] == b'\xB6\xE5', 'loader bytes disagree with matching marker write'
    return set_default + 1


def image_differences(before, after, keep=32):
    count, offsets = 0, []
    with before.open('rb') as left, after.open('rb') as right:
        offset = 0
        while True:
            a, b = left.read(1024 * 1024), right.read(1024 * 1024)
            assert len(a) == len(b), 'private fixture image size changed'
            if not a:
                break
            if a != b:
                for index, (x, y) in enumerate(zip(a, b)):
                    if x != y:
                        count += 1
                        if len(offsets) < keep:
                            offsets.append(offset + index)
            offset += len(a)
    return count, offsets



def patch_private_loader(disk, loader, listing_path):
    immediate = loader_marker_offset(loader, listing_path)
    with disk.open('r+b') as target:
        target.seek(STAGE1_IMAGE_OFFSET)
        image_loader = target.read(len(loader))
        assert image_loader == loader, 'image Stage1 bytes do not match supplied loader/listing build'
        target.seek(STAGE1_IMAGE_OFFSET + immediate)
        old = target.read(1)
        assert old == b'\x00', f'expected default DH immediate 00, got {old.hex()}'
        target.seek(STAGE1_IMAGE_OFFSET + immediate)
        target.write(b'\xE5')
    return {'loader_size':len(loader),'loader_sha256_before':sha(loader),
            'loader_immediate_offset':immediate,'image_byte_offset':STAGE1_IMAGE_OFFSET+immediate,
            'old_byte':'00','new_byte':'e5',
            'loader_sha256_after':sha(loader[:immediate]+b'\xE5'+loader[immediate+1:])}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--image',type=Path,required=True)
    p.add_argument('--kernel',type=Path)
    p.add_argument('--loader',type=Path)
    p.add_argument('--loader-listing',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if bool(a.loader) != bool(a.loader_listing):
        p.error('--loader and --loader-listing must be supplied together')
    if a.loader and a.kernel:
        p.error('--kernel cannot be combined with the marker-only --loader fixture')
    if not a.loader and not a.kernel:
        p.error('supply --loader/--loader-listing for a marker-only fixture, or --kernel for the legacy override')
    a.output.mkdir(parents=True,exist_ok=True)
    disk=a.output/'controlled-oem-mouse-fallback.img';shutil.copyfile(a.image,disk)
    stock=FAT16(a.image)
    names=('SYSTEM/SHELL.COM','DRIVERS/INPUTINI.COM','DRIVERS/MOUSE/CTMOUSE.EXE')
    stock_kernel = stock.read('SYSTEM/CIUKIDOS.SYS')
    image_hash = sha_file(a.image)
    report={'fixture':('normal kernel; private Stage1 DH=E5 override' if a.loader else
                       'ENABLE_PS2_MOUSE_INIT=0 kernel override'),
            'source_image_sha256':image_hash,'kernel_sha256':sha(stock_kernel),
            'stock_payload_sha256':{n:sha(stock.read(n)) for n in names},'memory_mib':128,
            'firmware_scope':'generic QEMU BIOS path only; no Compaq/E500 compatibility claim'}
    if a.loader:
        loader = a.loader.read_bytes()
        report['loader_patch'] = patch_private_loader(disk, loader, a.loader_listing)
        report['kernel_replaced']=False
    elif a.kernel:
        report['kernel_input_sha256']=sha(a.kernel.read_bytes())
        subprocess.run(['mcopy','-o','-i',str(disk),str(a.kernel),'::SYSTEM/CIUKIDOS.SYS'],check=True)
        report['kernel_replaced']=True
    modified=FAT16(disk)
    assert all(sha(modified.read(n))==report['stock_payload_sha256'][n] for n in names)
    if a.loader:
        assert modified.read('SYSTEM/CIUKIDOS.SYS') == stock_kernel, 'kernel payload changed in marker-only fixture'
        difference_count, difference_offsets = image_differences(a.image, disk)
        expected_offset = report['loader_patch']['image_byte_offset']
        assert difference_count == 1 and difference_offsets == [expected_offset], \
            f'marker-only fixture changed {difference_count} image bytes at {difference_offsets[:8]}'
        report['private_image_diff']={'changed_byte_count':difference_count,'offsets':difference_offsets}
        report['private_image_sha256']=sha_file(disk)
    vm=WindowVM(disk,a.output,'std',memory=128,palette='platinum')
    report['qemu_command']=vm.process.args
    try:
        vm.wait('[INPUT] Trying BIOS PS/2 mouse driver.',timeout=90)
        vm.wait('[INPUT] BIOS PS/2 mouse ready.',timeout=60)
        vm.ready();vm.shot('fallback-desktop')
        report['mode']=list(Image.open(a.output/'fallback-desktop.ppm').size)
        before=vm.pointer();vm.move(26,-17);after=vm.pointer()
        assert before!=after,'actual PS/2 movement did not move the rendered cursor'
        report['pointer_before_after']=[before,after]
        # WindowVM's native-driver harness assumes two pixels per packet.
        # CuteMouse has its own sensitivity/acceleration. Calibrate against
        # rendered movement rather than modifying guest driver settings.
        gain=[abs((after[0]-before[0])/26),abs((after[1]-before[1])/-17)]
        report['measured_pixels_per_packet']=gain.copy()
        report['pointer_positioning']=[]
        def position(x,y):
            for _ in range(50):
                old=vm.pointer();delta=[x-old[0],y-old[1]]
                if all(abs(d)<=3 for d in delta):return
                packet=[max(-80,min(80,round(delta[i]/max(gain[i],1)))) for i in range(2)]
                for i in range(2):
                    if abs(delta[i])>3 and not packet[i]:packet[i]=1 if delta[i]>0 else -1
                vm.move(*packet);new=vm.pointer()
                report['pointer_positioning'].append({'from':old,'packet':packet,'to':new})
                for i in range(2):
                    if packet[i] and new[i]!=old[i]:gain[i]=abs((new[i]-old[i])/packet[i])
            raise AssertionError(f'calibrated pointer did not reach {(x,y)}: {vm.pointer()}')
        vm.position=position
        original=vm.active_rect()
        vm.repaint_key('f3');opened=vm.active_rect();vm.shot('keyboard-opened-run')
        assert opened!=original,'F3 did not open Run'
        x,y,w=opened
        vm.click_at(x+w-16,y+15)
        assert vm.active_rect()==original,'real mouse click did not close Run'
        vm.shot('mouse-closed-run')
        offset=vm.offset();vm.key('f4');vm.wait('[DESKTOP] DOS',offset,30)
        offset=vm.offset();vm.text('echo FALLBACK KEYBOARD OK')
        vm.wait('\r\nFALLBACK KEYBOARD OK\r\nCiukiOS SHELL',offset,30)
        offset=vm.offset();vm.text('mouse info')
        vm.wait('ver=0x0705',offset,30)
        vm.wait('type=0x0004',offset,30)
        vm.shot('cutemouse-version-and-keyboard')
        offset=vm.offset();vm.text('exit');vm.ready(offset)
        before=vm.pointer();vm.move(-19,13);after=vm.pointer()
        assert before!=after,'resident fallback mouse failed after DOS roundtrip'
        vm.shot('fallback-after-dos')
        report['checks']=['stock helper/driver retained','fallback reported ready','rendered cursor moved',
                          'keyboard opened Run','mouse closed Run','DOS echo executed',
                          'actual CuteMouse 7.05 PS/2 INT33 interface','mouse survived DOS roundtrip']
        report['passed']=True
    except Exception as exc:
        report['passed']=False;report['error']=repr(exc)
        try:vm.shot('failure')
        except Exception:pass
        raise
    finally:
        vm.close()
        (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        assert sha_file(a.image)==report['source_image_sha256'],'source image changed'
    print('PASS controlled BIOS CuteMouse fallback and real GUI/DOS input')

if __name__=='__main__':main()
