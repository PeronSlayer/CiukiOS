#!/usr/bin/env python3
"""Run VMFORK MZ selection/load/entry against the actual full DOS kernel.

The synthetic parent has the physical capture's FREE1049/MAX687 paragraphs.
File reads supply the assembled binary; allocation, PSP and MZ logic execute
unchanged in the real kernel. No filesystem, QEMU or physical disk is used.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import tempfile

from unicorn import x86_const as x
from build_vmfork_exe import wrap
from test_kernel_f149_arena import BASE, SEG, SHELL, TOP, Machine, assemble
from test_vmfork_pinned_ancestors import assemble_vmfork, free_memory


class MzMachine(Machine):
    def __init__(self, image, labels, exe):
        self.exe, self.expected_entry, self.disk_reads = exe, None, []
        super().__init__(image, labels, SHELL)
        self.psp(SHELL, 0xF9A, SHELL)
        self.put('dos_exec_identity_psp', SHELL)
        self.put('current_psp_seg', SHELL)
        self.put('dos_mem_psp_mcb_end', SHELL + 0xF9A)
        self.put('dos_exec_parent_identity_psp', SHELL)
        self.put('dos_indos_flag', 1, 1)
        self.put('current_mz_context_slot', 1)
        self.put('runtime_status_flags', 1)
        self.put('runtime_table_seg', SEG)
        self.put('runtime_table_off', labels['runtime_service_table'])
        self.entries = [(0x211B, 0x8000 - 0x211B - 1, SHELL, 1),
                        (0x8000 + 688, 0x9000 - (0x8000 + 688) - 1, SHELL, 1),
                        (0x9000 + 363, TOP - (0x9000 + 363), SHELL, 1)]
        self.put('dos_mem_block_count', len(self.entries), 1)
        self.u.mem_write(BASE + labels['dos_mem_block_table'],
                         b''.join(struct.pack('<4H', *e) for e in self.entries))
        for segment, size, owner, _ in self.entries:
            self.mcb(segment, size, owner)
            self.u.mem_write(segment * 16, b'\xA5' * (size * 16))
        self.call('int21_mem_rebuild_chain')
        assert free_memory(self.chain()) == dict(total=1049, largest=687)

    def stop(self, uc, address, size, data):
        if self.expected_entry is not None and address == self.expected_entry:
            self.stop_at = address
            uc.emu_stop()
            return
        if address == BASE + self.labels['int21_exec_load_to_es']:
            length = self.value('search_found_size_lo')
            assert self.value('search_found_size_hi') == 0 and length <= len(self.exe)
            segment, offset = uc.reg_read(x.UC_X86_REG_ES), uc.reg_read(x.UC_X86_REG_DI)
            uc.mem_write(segment * 16 + offset, self.exe[:length])
            self.disk_reads.append(length)
            uc.reg_write(x.UC_X86_REG_AX, 0)
            uc.reg_write(x.UC_X86_REG_EFLAGS, uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1)
            self.near_return(uc)
            return
        super().stop(uc, address, size, data)

    @staticmethod
    def near_return(uc):
        ss, sp = uc.reg_read(x.UC_X86_REG_SS), uc.reg_read(x.UC_X86_REG_SP)
        target = int.from_bytes(uc.mem_read(ss * 16 + sp, 2), 'little')
        uc.reg_write(x.UC_X86_REG_SP, sp + 2)
        uc.reg_write(x.UC_X86_REG_IP, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='ciukios-vmfork-mz-') as tmp:
        kernel, labels = assemble(Path(tmp))
        com, symbols = assemble_vmfork(Path(tmp), labels)
        exe = wrap(com)
        assert exe[32:] == com and len(com) + 0x100 == symbols['stack_top']
        m = MzMachine(kernel, labels, exe)
        protected = {p: bytes(m.u.mem_read(p * 16, size * 16)) for p, size, _, _ in m.entries}
        m.put('search_found_size_lo', len(com))
        m.put('search_found_size_hi', 0)
        _, carry = m.call('int21_exec_com_required_paras')
        assert not carry
        com_required = m.u.reg_read(x.UC_X86_REG_BX)
        assert com_required > 687
        error, carry = m.call('int21_exec_select_com_region')
        assert carry and error == 8
        m.put('search_found_size_lo', len(exe))
        _, carry = m.call('int21_exec_select_mz_region')
        assert not carry
        mz_required = m.value('dos_mem_block_req_size')
        assert mz_required < 687 and mz_required > (len(com) + 0x100) // 16
        _, carry = m.call('int21_exec_load_mz')
        assert not carry, ('MZ load refused', m.value('tmp_exec_mz_fail_stage'))
        load = m.value('current_load_seg')
        m.expected_entry = (load + 2) * 16
        _, carry = m.call('int21_exec_run_mz')
        assert not carry, ('MZ entry refused', m.value('tmp_exec_mz_run_fail_stage'))
        psp = m.value('mz_psp_seg')
        registers = {name: m.u.reg_read(reg) for name, reg in
                     (('cs', x.UC_X86_REG_CS), ('ss', x.UC_X86_REG_SS),
                      ('ds', x.UC_X86_REG_DS), ('es', x.UC_X86_REG_ES),
                      ('ip', x.UC_X86_REG_IP), ('sp', x.UC_X86_REG_SP))}
        assert all(registers[n] == psp for n in ('cs', 'ss', 'ds', 'es')), registers
        assert registers['ip'] == 0x100 and registers['sp'] == symbols['stack_top']
        # The kernel PUSH/POP FLAGS at the private stack top sets entry IF.
        assert bytes(m.u.mem_read(psp * 16 + 0x100, len(com) - 2)) == com[:-2]
        assert bytes(m.u.mem_read(psp * 16 + symbols['stack_top'] - 2, 2)) == b'\x02\x02'
        assert m.chain()[psp]['owner'] == psp
        assert m.chain()[psp]['size'] >= (symbols['image_end'] + 15) // 16
        assert all(bytes(m.u.mem_read(p * 16, len(blob))) == blob for p, blob in protected.items())
        initial_size, initial_free = m.chain()[psp]['size'], free_memory(m.chain())
        initial_ceiling = int.from_bytes(m.u.mem_read(psp * 16 + 2, 2), 'little')
        m.expected_entry = None
        need = (symbols['image_end'] + 15) // 16
        _, carry = m.call('int21_handler', ax=0x4A00, bx=need, es=psp, interrupt=True)
        assert not carry and m.chain()[psp]['size'] == need
        assert int.from_bytes(m.u.mem_read(psp * 16 + 2, 2), 'little') == initial_ceiling
        assert initial_ceiling > psp + need
        for name, value in (('old_psp', psp), ('root_end', SHELL + 0xF9A), ('first_mcb', SHELL - 1)):
            m.u.mem_write(psp * 16 + symbols[name], struct.pack('<H', value))
        for reg in (x.UC_X86_REG_CS, x.UC_X86_REG_SS, x.UC_X86_REG_DS, x.UC_X86_REG_ES):
            m.u.reg_write(reg, psp)
        m.u.reg_write(x.UC_X86_REG_SP, symbols['stack_top'] - 2)
        m.u.mem_write(psp * 16 + symbols['stack_top'] - 2, struct.pack('<H', 0x80))
        m.stop_at = psp * 16 + 0x80
        m.u.emu_start(psp * 16 + symbols['use_owned_staging'], 0xFFFFF, count=100_000)
        assert m.u.reg_read(x.UC_X86_REG_IP) == 0x80
        assert not (m.u.reg_read(x.UC_X86_REG_EFLAGS) & 1)
        assert int.from_bytes(m.u.mem_read(psp * 16 + symbols['stage_psp'], 2), 'little') == psp
        report = dict(status='pass', parent_free=1049, parent_max=687,
                      com_required=com_required, com_error=error, mz_required=mz_required,
                      child_psp=psp, child_size=initial_size,
                      after=initial_free, registers=registers, disk_reads=m.disk_reads,
                      shrunk_size=need, initial_psp_ceiling_preserved=True,
                      owned_staging_after_real_resize=True,
                      exe_sha256=hashlib.sha256(exe).hexdigest(),
                      kernel_sha256=hashlib.sha256(kernel).hexdigest())
        if args.out_dir:
            args.out_dir.mkdir(parents=True, exist_ok=True)
            (args.out_dir/'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
