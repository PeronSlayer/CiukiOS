#!/usr/bin/env python3
"""Check the actual Display S3 caller's polling/persistence gates on the CPU."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="ciukios-display-qualify-") as work:
        exe = Path(work) / "display_qualify_host"
        subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-g",
                        "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                        "-fno-pie", "-no-pie", str(ROOT / "scripts/fixtures/display_qualify_host.c"),
                        "-o", str(exe)], check=True)
        report = json.loads(subprocess.check_output([str(exe)], text=True))
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
