; Unicorn fixture for the production DOSMEM report module.
bits 16
cpu 386
org 100h

start:
    cli
    mov ax,cs
    mov ss,ax
    mov sp,stack_top
    mov ds,ax
    mov es,ax
    sti
    mov eax,11223344h
    mov ebx,22334455h
    mov ecx,33445566h
    mov edx,44556677h
    mov esi,55667788h
    mov edi,66778899h
    mov ebp,778899AAh
    call vm_memory_report
    mov [cs:results],eax
    mov [cs:results+4],ebx
    mov [cs:results+8],ecx
    mov [cs:results+12],edx
    mov [cs:results+16],esi
    mov [cs:results+20],edi
    mov [cs:results+24],ebp
    mov ax,ds
    mov [cs:results+28],ax
    mov ax,es
    mov [cs:results+30],ax
    mov ax,4C00h
    int 21h

print:
    lodsb
    test al,al
    jz .done
    mov dl,al
    mov ah,02h
    int 21h
    jmp print
.done:
    ret

%include "../../src/com/vm_memory_report.inc"

results times 32 db 0
stack_bottom times 256 db 0
stack_top:
