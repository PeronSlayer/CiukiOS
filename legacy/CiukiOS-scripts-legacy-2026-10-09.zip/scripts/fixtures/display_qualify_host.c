/* Execute the production Display caller; adapter and DOS persistence are
 * explicit mocks. This proves sequencing, not physical hardware behavior. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
struct regs {u16 ax,bx,cx,dx,si,di,ds,es,flags;};
static int notice, native_ok, preview, page;
static u16 vm_seg=0x1234, vm_off=0x0056;
static u8 native[192], adapter[192], pending[400], durable[400];
static int calls, repaints, messages, reads, writes, closes, query_ok;
static int open_fail, short_write, close_fail, fail_stage, flags_only;
static int unreadable_at, missing_ready, unsupported, short_pending;
static int mach64_target;
static int packed_fallback;
#define QUALIFY_CALLS 25
static int stages[QUALIFY_CALLS+1];
#define WIN_DISPLAY 18
#define mem_set memset
#define mem_copy memcpy
#define str_copy strcpy
#define str_cat strcat
static u32 value(const u8 *p, int off) {u32 v;memcpy(&v,p+off,4);return v;}
static void put(u8 *p,int off,u32 v) {memcpy(p+off,&v,4);}
static int token_at(int call) {
    assert(call>=1&&call<=QUALIFY_CALLS+1);
    if(call==QUALIFY_CALLS+1) { assert(packed_fallback);return 5; }
    return mach64_target ? call : call==1?1:call<=22?0x100+call-1:call-21;
}
static u32 result_for(int token,u32 status) {
    return token>0x100?((u32)(token&255)<<16)|status|2:status|(unsigned)token;
}
static u32 nfield(int off) {return value(native,off);}
static void native_read(void) {
    ++reads;native_ok=reads!=unreadable_at;
    if(native_ok)memcpy(native,adapter,192);
}
static int session_query_lfb(void) {return query_ok;}
static u16 app_seg(void) {return 0x4321;}
static int dos_create(const char *path) {
    assert(!strcmp(path,mach64_target?"\\SYSTEM\\VIDEO\\ATIQUAL.LOG":"\\SYSTEM\\VIDEO\\S3QUAL.LOG"));
    ++writes;short_pending=0;
    return writes==open_fail?-5:7;
}
static int dos_write(int h,const void *buf,unsigned len) {
    assert(h==7&&len==400);
    memcpy(pending,buf,400);short_pending=writes==short_write;
    return short_pending?399:400;
}
static int dos_close(int h) {
    assert(h==7);++closes;
    if(writes==close_fail)return -5;
    if(!short_pending)memcpy(durable,pending,400);
    return 0;
}
static int far_regs(u16 seg,u16 off,struct regs *r) {
    assert(seg==vm_seg&&off==vm_off&&r->ax==0x0118);
    assert(r->ds==app_seg()&&r->es==app_seg());
    assert(calls<QUALIFY_CALLS+1&&r->bx==token_at(calls+1));
    /* The complete before snapshot must already be closed on disk. */
    assert(!memcmp(durable,"CG3D\x00\x01\x10\x00",8));
    assert(value(durable,8)==result_for(r->bx,0x100)&&value(durable,12)==0);
    assert(!memcmp(durable+16,native,192));
    for(int i=208;i<400;++i)assert(durable[i]==0);
    stages[calls++]=r->bx;
    if(packed_fallback&&r->bx==4) {
        put(adapter,64,0);put(adapter,68,packed_fallback==9?0:8);
        put(adapter,72,packed_fallback==5?8:9);
        put(adapter,156,packed_fallback==4?1:0);
        put(adapter,140,packed_fallback==7?0:1);
        put(adapter,188,packed_fallback==6?0:1);
        put(adapter,8,packed_fallback==8?3:0);
        r->ax=8;return 1;
    }
    if(r->bx==5) {
        assert(packed_fallback&&!mach64_target);
        if(packed_fallback==3) {r->ax=8;return 1;}
        put(adapter,8,3);put(adapter,64,1);put(adapter,156,1);
        put(adapter,60,packed_fallback==2?0x80000007u:0x80000005u);
        put(adapter,68,13);put(adapter,72,0);
        r->ax=0;return 0;
    }
    if(r->bx==fail_stage||unsupported) {
        r->ax=unsupported?1:8;
        r->flags=flags_only?1:0;
        return flags_only?0:1;
    }
    if(r->bx==4) {
        put(adapter,8,missing_ready==2?0:mach64_target?4:3);
        put(adapter,60,mach64_target?(missing_ready==3?0x40000001u:0x40000005u):missing_ready==3?0x80000003u:0x80000007u);
        put(adapter,64,missing_ready==1?0:1);put(adapter,156,1);
    }
    r->ax=0;return 0;
}
static void fmt_hex4(char *s,u16 n) {snprintf(s,5,"%04X",n);}
static void app_log(const char *a,const char *b) {(void)a;(void)b;}
static void msgbox(int *d,const char *title,const char *message,const char *buttons) {
    assert(d==&notice&&message[0]&&!strcmp(title,"Display settings")&&!strcmp(buttons,"OK"));
    ++messages;
}
static void ui_repaint_win(int id) {assert(id==WIN_DISPLAY);++repaints;}

#include "../../src/apps/display_qualify.inc"

static void reset(void) {
    calls=repaints=messages=reads=writes=closes=0;
    open_fail=short_write=close_fail=fail_stage=flags_only=0;
    unreadable_at=missing_ready=unsupported=short_pending=0;
    preview=qualify_step=qualify_probe=qualify_wait=qualify_requested=0;
    native_ok=query_ok=1;qualify_status[0]=0;
    mach64_target=qualify_mach64=0;
    packed_fallback=0;
    memset(adapter,0,sizeof adapter);memset(durable,0,sizeof durable);
    memcpy(adapter,"CVGD\x00\x01\xc0\x00",8);
    put(adapter,16,1024);put(adapter,20,768);put(adapter,24,4096);put(adapter,28,32);
    put(adapter,44,0xe8000000u);put(adapter,48,3145728);
    put(adapter,60,0x80000000u);put(adapter,76,0x8c2e5333u);
    memcpy(native,adapter,sizeof native);
}
static void start(void) {
    assert(qualify_begin(0)==1&&qualify_step==1&&qualify_wait==1);
    assert(page==3&&!calls&&!writes);
    assert(qualify_poll()==2&&qualify_wait==0&&!calls&&!writes);
}
int main(void) {
    int checks=0;
    reset();start();
    for(int call=1;call<=QUALIFY_CALLS;++call) {
        assert(qualify_poll()==(call==QUALIFY_CALLS?1:2));
        assert(calls==call&&stages[call-1]==token_at(call)&&writes==call*2&&closes==writes);
        assert(value(durable,8)==result_for(token_at(call),0x200)&&value(durable,12)==0);
    }
    assert(!qualify_step&&!qualify_probe&&repaints==QUALIFY_CALLS-1&&!messages);
    assert(!strcmp(qualify_status,"Hardware acceleration enabled for this desktop session."));
    assert(qualify_poll()==0&&calls==QUALIFY_CALLS&&writes==QUALIFY_CALLS*2);++checks;

    reset();put(adapter,76,0);assert(qualify_begin(0)==1&&!qualify_step&&!calls&&!writes);++checks;
    reset();put(adapter,76,0);unsupported=1;
    assert(qualify_begin(1)==1&&qualify_poll()==2&&qualify_poll()==1);
    assert(calls==1&&value(durable,8)==0x301&&value(durable,12)==1&&!qualify_step);++checks;
    reset();put(adapter,56,1);query_ok=0;
    assert(qualify_begin(0)==1&&!calls&&!writes&&messages==1);
    assert(strstr(qualify_status,"Close DOS windows"));++checks;
    reset();unreadable_at=1;assert(qualify_begin(0)==1&&!qualify_step&&!calls&&!writes);++checks;
    reset();query_ok=0;assert(qualify_begin(0)==1&&!qualify_step&&!calls&&!writes);++checks;
    reset();put(adapter,8,3);put(adapter,64,1);put(adapter,60,0x80000007u);
    assert(qualify_begin(0)==1&&!qualify_step&&!calls&&strstr(qualify_status,"already enabled"));++checks;
    reset();put(adapter,8,3);put(adapter,64,1);put(adapter,60,0x80000005u);
    assert(qualify_begin(0)==1&&!qualify_step&&!calls&&strstr(qualify_status,"already enabled"));++checks;
    reset();put(adapter,8,3);assert(qualify_begin(0)==1&&!qualify_step&&!calls&&strstr(qualify_status,"Restart"));++checks;
    reset();preview=1;assert(qualify_begin(0)==1&&!qualify_step&&!calls&&!writes);++checks;

    /* A failed pre-call checkpoint must never reach the resident operation;
     * a failed result checkpoint must never permit the following phase. */
    for(int kind=0;kind<3;++kind)for(int at=1;at<=QUALIFY_CALLS*2;++at) {
        reset();start();
        if(kind==0)open_fail=at;
        else if(kind==1)short_write=at;
        else close_fail=at;
        while(qualify_step)qualify_poll();
        assert(calls==at/2&&messages==1&&writes==at);
        assert(qualify_poll()==0);++checks;
    }
    for(int at=1;at<=QUALIFY_CALLS;++at)for(int flags=0;flags<2;++flags) {
        reset();start();fail_stage=token_at(at);flags_only=flags;
        while(qualify_step)qualify_poll();
        assert(calls==at&&writes==at*2&&messages==1);
        assert(value(durable,8)==result_for(token_at(at),0x300)&&value(durable,12)==8);
        assert(strstr(qualify_status,"0008"));++checks;
    }
    reset();start();unreadable_at=reads+1;
    assert(qualify_poll()==1&&!qualify_step&&!calls&&!writes);++checks;
    reset();start();unreadable_at=reads+2;
    assert(qualify_poll()==1&&!qualify_step&&calls==1&&writes==2);
    assert(value(durable,8)==0x301&&value(durable,12)==9);++checks;
    for(int missing=1;missing<=3;++missing) {
        reset();start();missing_ready=missing;
        while(qualify_step)qualify_poll();
        assert(calls==QUALIFY_CALLS&&value(durable,8)==0x304&&value(durable,12)==9);++checks;
    }
    /* Reentry and cancellation between every restored prefix must preserve
     * the finished checkpoint and never submit the following prefix. */
    for(int at=1;at<QUALIFY_CALLS;++at) {
        reset();start();
        for(int i=0;i<at;++i)assert(qualify_poll()==2);
        int step=qualify_step,probe=qualify_probe;
        assert(qualify_begin(0)==1&&qualify_step==step&&qualify_probe==probe&&calls==at);
        qualify_cancel();
        assert(!qualify_step&&!qualify_probe&&qualify_poll()==0&&calls==at);
        assert(value(durable,8)==result_for(token_at(at),0x200));++checks;
    }
    /* A mode or DOS-session change between prefix calls forbids hardware
     * submission, including geometry/address changes on an available LFB. */
    for(int guard=0;guard<9;++guard) {
        reset();start();assert(qualify_poll()==2&&qualify_poll()==2);
        if(guard==0)preview=1;
        else if(guard==1)query_ok=0;
        else if(guard==2)put(adapter,56,1);
        else put(adapter,guard<7?16+(guard-3)*4:44+(guard-7)*4,1);
        assert(qualify_poll()==1&&!qualify_step&&calls==2&&writes==4);
        assert(qualify_poll()==0);++checks;
    }
    /* CVGD40 counts completed operations, so progress must not invalidate
     * an otherwise identical framebuffer binding. */
    reset();start();assert(qualify_poll()==2&&qualify_poll()==2);
    put(adapter,40,value(adapter,40)+17);
    assert(qualify_poll()==2&&qualify_step==2&&calls==3&&writes==6);++checks;
    /* CVGD48 is the mapped extent. Refuse an extent-only change even with
     * the same width, height, pitch, bpp, and physical base. */
    reset();start();assert(qualify_poll()==2&&qualify_poll()==2);
    put(adapter,48,value(adapter,48)+4096);
    assert(!memcmp(adapter+16,native+16,16)&&value(adapter,44)==value(native,44));
    assert(qualify_poll()==1&&!qualify_step&&calls==2&&writes==4);
    assert(qualify_poll()==0);++checks;
    reset();qualify_requested=1;qualify_cancel();assert(!qualify_requested&&!qualify_step&&!calls);++checks;
    /* ATI uses the same durable four-phase protocol without S3 prefixes or
     * triangle claims. A missing copy capability must reject final success. */
    for(int missing=0;missing<=3;++missing) {
        reset();mach64_target=1;missing_ready=missing;
        put(adapter,60,0x40000000u);put(adapter,76,0x4c4d1002u);
        put(adapter,24,3072);put(adapter,28,24);put(adapter,44,0x40000000u);
        put(adapter,48,4718592);start();
        for(int call=1;call<=4;++call) {
            assert(qualify_poll()==(call==4?1:2));
            assert(calls==call&&stages[call-1]==call&&!qualify_probe);
        }
        assert(value(durable,8)==(missing?0x304u:0x204u));
        assert(value(durable,12)==(missing?9u:0u));
        assert(messages==(missing?1:0)&&!qualify_step);++checks;
    }
    /* Failed triangles do not discard independently proven 2D. A retained
     * engine, failed restore, or missing fill/copy evidence forbids retry. */
    for(int mode=1;mode<=9;++mode) {
        reset();packed_fallback=mode;start();
        while(qualify_step)qualify_poll();
        assert(calls==(mode<=3?QUALIFY_CALLS+1:QUALIFY_CALLS));
        assert(messages==(mode==1?0:1));
        assert(value(durable,8)==(mode==1?0x205u:mode<=3?0x305u:0x304u));
        if(mode==1) {
            assert(strstr(qualify_status,"Hardware 2D acceleration enabled"));
            assert(!(value(durable+208,60)&2));
        }
        ++checks;
    }
    /* Both phase5 checkpoints remain mandatory; failed persistence cannot
     * submit or conceal the result of a live hardware bind. */
    for(int kind=0;kind<3;++kind)for(int at=51;at<=52;++at) {
        reset();packed_fallback=1;start();
        if(kind==0)open_fail=at;else if(kind==1)short_write=at;else close_fail=at;
        while(qualify_step)qualify_poll();
        assert(calls==at/2&&messages==1&&writes==at);++checks;
    }
    printf("{\"status\":\"PASS\",\"caller_cases\":%d,\"hardware_evidence\":false}\n",checks);
    return 0;
}
