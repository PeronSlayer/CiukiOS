/* Production text geometry/key functions are extracted without substitutions. */
#define main shared_field_tests
#include "ui_field_host.c"
#undef main
static struct field text_edit;
static char text[201];
#define text_len text_edit.len
static int tx = 20, ty = 30, text_scale = 2;
static int glyph_w(char ch) { return ch == 'W' ? 12 : 6; }
static int imax(int a, int b) { return a > b ? a : b; }
#include "paint_text_actual.inc"

int main(void)
{
    int x, y, w, h, last;
    field_set(&text_edit, text, sizeof text, "WWW\nabc def\nlast");
    HOST.shift = 0;
    text_extent(&w, &h, &last);
    CHECK(w == 84 && h == 96 && last == 48);
    text_position(5, &x, &y); CHECK(x == 32 && y == 62);
    CHECK(text_at(49, 62) == 6); /* scaled proportional midpoint */
    CHECK(text_at(-100, 62) == 4); CHECK(text_at(999, 62) == 11);
    CHECK(text_at(20, -1) == 0); CHECK(text_at(20, 999) == text_len);
    CHECK(text_contains(21, 31)); CHECK(!text_contains(200, 31));
    text_edit.cursor = text_edit.anchor = 6;
    CHECK(text_key(K_HOME << 8)); CHECK(text_edit.cursor == 4);
    HOST.shift = SH_SHIFT;
    CHECK(text_key(K_END << 8)); CHECK(text_edit.cursor == 11 && text_edit.anchor == 4);
    HOST.shift = 0;
    CHECK(text_key('X')); CHECK(!strcmp(text, "WWW\nX\nlast"));
    CHECK(text_key(13)); CHECK(!strcmp(text, "WWW\nX\n\nlast"));
    CHECK(text_key(K_UP << 8)); CHECK(text_edit.cursor == 4);
    CHECK(text_key(K_DOWN << 8)); CHECK(text_edit.cursor == 6);
    HOST.shift = SH_CTRL; CHECK(text_key(1));
    HOST.shift = 0; CHECK(text_key('a')); CHECK(!strcmp(text, "a"));
    field_set(&text_edit, text, sizeof text, "alpha beta");
    HOST.ticks = 50;
    field_select(&text_edit, MOUSE_DOWN, text_at(44, 31), 0);
    field_select(&text_edit, MOUSE_UP, text_at(44, 31), 0);
    HOST.ticks += 4;
    field_select(&text_edit, MOUSE_DOWN, text_at(44, 31), 0);
    CHECK(text_edit.anchor == 0 && text_edit.cursor == 5);
    field_select(&text_edit, MOUSE_MOVE, text_at(120, 31), 0);
    CHECK(text_edit.anchor == 0 && text_edit.cursor == 10);
    printf("{\"passed\":true,\"assertions\":%u,\"paint_actual_functions\":5}\n", checks);
    return 0;
}
