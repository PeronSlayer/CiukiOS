/* Compile the production editor with drawing/input services replaced by spies. */
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "../../src/apps/app.h"
#undef HOST
static struct host test_host;
#define HOST test_host

static int clip_x, clip_w, highlight_px, rendered_chars, mask_only;
static char rendered[1024];
int str_len(const char *s) { return (int)strlen(s); }
void str_ncopy(char *d, const char *s, int n)
{
    if (n <= 0) return;
    while (--n > 0 && *s) *d++ = *s++;
    *d = 0;
}
void mem_move(void *d, const void *s, int n) { assert(n >= 0); memmove(d, s, (size_t)n); }
int ui_measure(const char *s)
{
    int n = 0;
    while (*s) n += *s++ == 'W' ? 12 : 6;
    return n;
}
void ui_inset(int x, int y, int w, int h)
{ (void)y; assert(h == 22); clip_x = x; clip_w = w; }
void ui_rect(int x, int y, int w, int h, int color)
{
    (void)y; (void)h;
    assert(x >= clip_x + 3 && x + w <= clip_x + clip_w - 3);
    if (color == C_TITLE) highlight_px += w;
}
void ui_text(int x, int y, const char *s, int color)
{
    (void)y; (void)color;
    assert(x >= clip_x + 3 && x + ui_measure(s) <= clip_x + clip_w - 3);
    if (mask_only) for (const char *p = s; *p; ++p) assert(*p == '*');
    assert(strlen(rendered) + strlen(s) < sizeof rendered);
    strcat(rendered, s); rendered_chars += str_len(s);
}
#include "../../src/apps/ui_field.inc"

/* The actual Run application must preserve aliases, argument tails and the
 * close-before-launch service ordering. The shell executes those requests. */
static char run_arg[128], launched[128], services[8];
static int run_w, run_h, service_count, launched_window;
char app_title[64];
#undef APP_ARG
#undef HDR_WIDTH
#undef HDR_HEIGHT
#define APP_ARG run_arg
#define HDR_WIDTH run_w
#define HDR_HEIGHT run_h
char to_upper(char c) { return c >= 'a' && c <= 'z' ? c - 32 : c; }
void str_copy(char *d, const char *s) { strcpy(d, s); }
void app_window_cmd(int win, int cmd)
{ assert(win == WIN_RUN && cmd == 2); services[service_count++] = 'C'; }
void app_open(int win, const char *arg)
{ services[service_count++] = 'O'; launched_window = win; strcpy(launched, arg); }
void app_command(const char *arg)
{ services[service_count++] = 'F'; strcpy(launched, arg); }
void app_log(const char *what, const char *detail) { (void)what; (void)detail; }
void app_close(void) { services[service_count++] = 'X'; }
void ui_button(int x, int y, int w, int h, const char *s, int id)
{ (void)x; (void)y; (void)w; (void)h; (void)s; (void)id; }
void draw_focus(int x, int y, int w, int h)
{ (void)x; (void)y; (void)w; (void)h; }
void ui_cursor(int type) { (void)type; }
#include "../../src/apps/run.c"

static void run_begin(const char *s)
{
    memset(services, 0, sizeof services); service_count = 0; launched[0] = 0;
    launched_window = -1; strcpy(run_arg, s); app_event(EV_OPEN, 0, 0, 0);
}

static unsigned checks;
#define CHECK(value) do { ++checks; assert(value); } while (0)
static void reset(struct field *f, char *b, int cap, const char *s)
{ field_set(f, b, cap, s); memset(&test_host, 0, sizeof test_host); HOST.dblclick = 9; }
static void key(struct field *f, int scan, int shift)
{ CHECK(field_key(f, scan << 8, shift)); }
static void draw(struct field *f, int w, int focus)
{ highlight_px = rendered_chars = 0; rendered[0] = 0; field_draw(f, 10, 10, w, focus); }
int main(void)
{
    struct field f;
    struct { unsigned char a; char s[64]; unsigned char b; } buf = {0xA5, "", 0x5A};
    char *b = buf.s;
    reset(&f, b, 64, "alpha beta");
    key(&f, K_HOME, 0); key(&f, K_RIGHT, SH_SHIFT); key(&f, K_RIGHT, SH_SHIFT);
    CHECK(f.anchor == 0 && f.cursor == 2 && f.sel == 2);
    CHECK(field_key(&f, 'X', 0)); CHECK(!strcmp(b, "Xpha beta") && f.cursor == 1);
    key(&f, K_END, SH_SHIFT); key(&f, K_LEFT, 0);
    CHECK(f.cursor == 1 && !f.sel);  /* collapse to the leading edge */
    CHECK(field_key(&f, 1, SH_CTRL)); key(&f, K_RIGHT, 0);
    CHECK(f.cursor == f.len && !f.sel);
    key(&f, K_HOME, SH_SHIFT); CHECK(f.anchor == f.len && f.cursor == 0);
    CHECK(field_key(&f, 8, 0)); CHECK(!f.len && !*b && !f.sel);
    reset(&f, b, 64, "alpha beta.gamma");
    key(&f, K_LEFT, SH_CTRL); CHECK(f.cursor == 11);
    key(&f, K_LEFT, SH_CTRL | SH_SHIFT); CHECK(f.anchor == 11 && f.cursor == 10);
    CHECK(field_key(&f, K_DEL << 8, 0)); CHECK(!strcmp(b, "alpha betagamma"));
    key(&f, 0x73, 0); CHECK(f.cursor == 6); /* BIOS Ctrl+Left variant */
    key(&f, 0x77, SH_SHIFT); CHECK(f.cursor == 0 && f.anchor == 6);
    CHECK(field_insert(&f, "one ")); CHECK(!strcmp(b, "one betagamma"));
    reset(&f, b, 5, "abcdEF"); CHECK(f.len == 4 && !strcmp(b, "abcd"));
    CHECK(!field_key(&f, 'e', 0)); f.sel = 1;
    CHECK(field_key(&f, 'e', 0)); CHECK(!strcmp(b, "e"));
    CHECK(!field_insert(&f, "1234")); CHECK(!strcmp(b, "e"));
    reset(&f, b, 64, "alpha beta"); HOST.ticks = 100;
    field_mouse(&f, MOUSE_DOWN, 10, 160, 14 + 6 * 2, 0);
    field_mouse(&f, MOUSE_MOVE, 10, 160, 14 + 6 * 7, 0);
    field_mouse(&f, MOUSE_UP, 10, 160, 14 + 6 * 7, 0);
    CHECK(f.anchor == 2 && f.cursor == 7 && !f.drag);
    draw(&f, 160, 1); CHECK(highlight_px == 30 && !strcmp(rendered, b));
    draw(&f, 160, 0); CHECK(highlight_px == 0);
    f.click_valid = 0; HOST.ticks = 200;
    field_mouse(&f, MOUSE_DOWN, 10, 160, 26, 0);
    field_mouse(&f, MOUSE_UP, 10, 160, 26, 0); HOST.ticks += 9;
    field_mouse(&f, MOUSE_DOWN, 10, 160, 26, 0);
    CHECK(f.anchor == 0 && f.cursor == 5 && f.drag == 2);
    field_mouse(&f, MOUSE_MOVE, 10, 160, 62, 0);
    CHECK(f.anchor == 0 && f.cursor == 10);
    field_mouse(&f, MOUSE_UP, 10, 160, 62, 0); CHECK(!f.drag);
    reset(&f, b, 64, "alpha beta"); HOST.ticks = 65532;
    field_mouse(&f, MOUSE_DOWN, 10, 160, 56, 0);
    field_mouse(&f, MOUSE_UP, 10, 160, 56, 0); HOST.ticks = 2;
    field_mouse(&f, MOUSE_DOWN, 10, 160, 56, 0);
    CHECK(f.anchor == 6 && f.cursor == 10); /* BIOS low-word tick wrap */
    field_mouse(&f, MOUSE_MOVE, 10, 160, 20, 0);
    CHECK(f.anchor == 10 && f.cursor == 0); /* reverse whole-word drag */
    reset(&f, b, 64, "abcdefghijklmnopqrstuv");
    draw(&f, 40, 1); CHECK(f.scroll > 10);
    field_mouse(&f, MOUSE_DOWN, 10, 40, 42, 0);
    for (int i = 0; i < 30; i++) field_mouse(&f, MOUSE_MOVE, 10, 40, 0, 0);
    CHECK(f.cursor == 0 && f.scroll == 0 && f.anchor > f.cursor);
    for (int i = 0; i < 30; i++) field_mouse(&f, MOUSE_MOVE, 10, 40, 200, 0);
    CHECK(f.cursor == f.len && f.scroll > 10);
    field_mouse(&f, MOUSE_UP, 10, 40, 200, 0); CHECK(!f.drag);
    f.cursor = 999; f.anchor = -4; f.scroll = 999; f.sel = 2;
    draw(&f, 40, 1); CHECK(f.cursor == f.len && f.anchor == 0);
    reset(&f, b, 64, "WWWsecret"); f.password = 1; f.sel = 1; mask_only = 1;
    draw(&f, 160, 1); CHECK(highlight_px == 54 && !strcmp(rendered, "*********"));
    field_mouse(&f, MOUSE_DOWN, 10, 160, 32, 0); CHECK(f.cursor == 3);
    mask_only = 0;
    reset(&f, b, 64, "WWWabc"); f.sel = 1;
    draw(&f, 40, 1); CHECK(highlight_px <= 32 && f.scroll > 0);
    reset(&f, b, 64, "\xC3\xA9\xFF"); f.sel = 1;
    draw(&f, 12, 1); CHECK(f.cursor == 3 && rendered_chars == 0);
    /* Code-page bytes stay bounded; UTF-8 is not interpreted as graphemes. */
    key(&f, K_LEFT, SH_SHIFT); CHECK(f.cursor == 2);
    CHECK(buf.a == 0xA5 && buf.b == 0x5A);
    reset(&f, b, 64, "first second");
    CHECK(!field_key(&f, 'x', SH_ALT)); CHECK(!field_key(&f, 'x', SH_CTRL));
    f.sel = 1; CHECK(field_insert(&f, "line 1\nline 2"));
    CHECK(!strcmp(b, "line 1\nline 2"));
    field_select(&f, MOUSE_DOWN, -5, 0); CHECK(f.cursor == 0);
    field_select(&f, MOUSE_MOVE, 999, 0); CHECK(f.cursor == f.len);
    run_begin("  NoTePaD   C:\\MY DOCS\\README.TXT"); app_event(EV_KEY, 13, 0, 0);
    CHECK(!strcmp(services, "CO") && launched_window == WIN_NOTEPAD);
    CHECK(!strcmp(launched, "C:\\MY DOCS\\README.TXT"));
    run_begin("notepad2 file"); app_event(EV_ACTION, 40, 0, 0);
    CHECK(launched_window == WIN_DOS && !strcmp(launched, "notepad2 file"));
    run_begin("C:\\DOOM\\DOOM.EXE -nosound"); app_event(EV_ACTION, 40, 0, 0);
    CHECK(!strcmp(services, "CO") && launched_window == WIN_DOS);
    CHECK(!strcmp(launched, "C:\\DOOM\\DOOM.EXE -nosound"));
    run_begin("dir C:\\"); app_event(EV_ACTION, 42, 0, 0);
    CHECK(!strcmp(services, "CF") && !strcmp(launched, "dir C:\\"));
    run_begin("   \t"); app_event(EV_KEY, 13, 0, 0); CHECK(!service_count);
    run_begin("explorer C:\\TEST"); app_event(EV_KEY, 1, 0, 0);
    CHECK(run_input.sel == 1); app_event(EV_KEY, 'x', 0, 0);
    CHECK(!strcmp(run_command, "x")); app_event(EV_SUSPEND, 0, 0, 0);
    CHECK(!strcmp(run_arg, "x"));
    printf("{\"passed\":true,\"assertions\":%u,\"production_editor\":\"src/apps/ui_field.inc\",\"run_application\":true}\n", checks);
    return 0;
}
