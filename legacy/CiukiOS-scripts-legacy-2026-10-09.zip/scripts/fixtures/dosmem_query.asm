; Focused live fixture for the VMSTART SYSTEM/DOSMEM.BIN query record.
; It performs no XMS or VCPI allocations.
bits 16
cpu 386
org 100h

start:
    cli
    mov ax,cs
    mov ss,ax
    mov sp,stack_top
    sti
    mov ds,ax
    mov es,ax
    mov bx,(image_end-$$+100h+15)/16
    mov ah,4Ah
    int 21h
    jc .fail

    mov dx,dosmem_path
    mov ax,3D00h
    int 21h
    jc .fail
    mov [file_handle],ax
    mov bx,ax
    mov dx,record
    mov cx,32
    mov ah,3Fh
    int 21h
    pushf
    push ax
    mov bx,[file_handle]
    mov ah,3Eh
    int 21h
    pop ax
    popf
    jc .fail
    cmp ax,32
    jne .fail
    cmp dword [record],0524D4443h ; little-endian bytes "CDMR"
    jne .fail
    cmp byte [record+4],1
    jne .fail
    cmp byte [record+5],32
    jne .fail
    test byte [record+6],80h
    jz .fail
    mov si,pass_record
    call puts

    ; Confirm that the live XMS3 and VCPI query APIs return normally. Values
    ; are printed from DOSMEM by the decoder; this fixture checks query health.
    mov ax,4300h
    int 2Fh
    cmp al,80h
    jne .fail
    mov ax,4310h
    int 2Fh
    mov [xms_entry],bx
    mov [xms_entry+2],es
    mov ah,88h
    call far [xms_entry]
    test bl,bl
    jnz .fail
    test byte [record+6],02h
    jz .fail
    mov si,pass_xms
    call puts

    mov ax,0DE00h
    int 67h
    test ah,ah
    jnz .fail
    test bh,bh
    jz .fail
    mov ax,0DE03h
    int 67h
    test ah,ah
    jnz .fail
    test byte [record+6],08h
    jz .fail
    mov si,pass_vcpi
    call puts
    mov ax,4C00h
    int 21h

.fail:
    mov si,fail_msg
    call puts
    mov ax,4C01h
    int 21h

puts:
    lodsb
    test al,al
    jz .done
    mov dl,al
    mov ah,2
    int 21h
    jmp puts
.done:
    ret

dosmem_path db '\SYSTEM\DOSMEM.BIN',0
file_handle dw 0
xms_entry dd 0
record times 32 db 0
pass_record db '[DOSMEMQ] PASS record signature/version/size',13,10,0
pass_xms db '[DOSMEMQ] PASS XMS3 AH=88 read-only query',13,10,0
pass_vcpi db '[DOSMEMQ] PASS VCPI DE00/DE03 read-only query',13,10,0
fail_msg db '[DOSMEMQ] FAIL',13,10,0
stack_bottom times 128 db 0
stack_top:
image_end:
