/* Host fixture for the shared CiukiOS master-volume preference reader/writer. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint8_t u8;
typedef uint16_t u16;

static char stored[16];
static int stored_size, fail_read, fail_write, fail_close, closed;
static char last_path[48];

static int dos_open(const char *path, int mode)
{
    (void)mode;
    strcpy(last_path, path);
    return 7;
}

static int dos_create(const char *path)
{
    strcpy(last_path, path);
    stored_size = 0;
    return 7;
}

static int dos_read(int handle, void *buffer, int size)
{
    int n;
    assert(handle == 7);
    if (fail_read) return -5;
    n = stored_size < size ? stored_size : size;
    memcpy(buffer, stored, (size_t)n);
    return n;
}

static int dos_write(int handle, const void *buffer, int size)
{
    assert(handle == 7);
    if (fail_write) return -5;
    memcpy(stored, buffer, (size_t)size);
    stored_size = size;
    return size;
}

static int dos_close(int handle)
{
    assert(handle == 7);
    closed++;
    return fail_close ? -5 : 0;
}

#include "../../src/apps/audio_settings.h"

static void check_load(const char *contents, int length, int expected_level,
                      int expected_mute)
{
    int level = -1, mute = -1;
    memcpy(stored, contents, (size_t)length);
    stored_size = length;
    fail_read = fail_close = 0;
    closed = 0;
    assert(audio_settings_load(&level, &mute));
    assert(level == expected_level && mute == expected_mute);
    assert(closed == 1);
    assert(strcmp(last_path, "\\SYSTEM\\VOLUME.CFG") == 0);
}

static void check_invalid(const char *contents, int length)
{
    int level = 77, mute = 88;
    memcpy(stored, contents, (size_t)length);
    stored_size = length;
    fail_read = fail_close = 0;
    assert(!audio_settings_load(&level, &mute));
    assert(level == 77 && mute == 88);
}

int main(void)
{
    check_load("\x1f", 1, 31, 0);
    check_load("\x8c", 1, 12, 1);
    check_load("\0", 1, 0, 0);
    check_invalid("\x20", 1); /* reserved bit */
    check_invalid("\x8cX", 2);

    stored_size = 1;
    memcpy(stored, "\x05", 1);
    fail_read = 1;
    {
        int level = 77, mute = 88;
        assert(!audio_settings_load(&level, &mute));
        assert(level == 77 && mute == 88);
    }
    fail_read = 0;
    fail_close = 1;
    {
        int level = 77, mute = 88;
        assert(!audio_settings_load(&level, &mute));
        assert(level == 77 && mute == 88);
    }
    fail_close = 0;

    assert(audio_settings_save(12, 1));
    assert(stored_size == 1 && memcmp(stored, "\x8c", 1) == 0);
    assert(strcmp(last_path, "\\SYSTEM\\VOLUME.CFG") == 0);
    assert(audio_settings_save(31, 0));
    assert(stored_size == 1 && memcmp(stored, "\x1f", 1) == 0);
    fail_write = 1;
    assert(!audio_settings_save(5, 0));
    fail_write = 0;
    fail_close = 1;
    assert(!audio_settings_save(5, 0));
    fail_close = 0;
    assert(audio_settings_save(99, 0));
    assert(stored_size == 1 && memcmp(stored, "\x1f", 1) == 0);

    puts("audio settings host fixture: PASS");
    return 0;
}
