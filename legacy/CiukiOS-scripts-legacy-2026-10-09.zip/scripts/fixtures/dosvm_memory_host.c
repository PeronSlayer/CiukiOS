/* Host fixture for the production DOSVM parent-memory audit include. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
struct regs { u16 ax, bx, cx, dx, si, di, ds, es, flags, cxh, dxh, axh; };

static u8 realmem[0x100000];
static u16 returned_lol_seg, returned_lol_off;
static u16 da_off, da_seg;
static int intr_calls, intr_fail, logged, peek_after_log, log_calls;
static int intr_no, intr_ax, intr_ds;
static char log_event[2][48], log_detail[2][180];
static u16 log_code[2];

static u32 physical(u16 seg, u16 off)
{
    return (((u32)seg << 4) + off) & 0xFFFFFUL;
}
static void put8(u16 seg, u16 off, u8 value)
{
    realmem[physical(seg, off)] = value;
}
static void put16(u16 seg, u16 off, u16 value)
{
    put8(seg, off, (u8)value);
    put8(seg, (u16)(off + 1), (u8)(value >> 8));
}
u8 peek8(u16 seg, u16 off)
{
    if (logged) peek_after_log = 1;
    return realmem[physical(seg, off)];
}
u16 peek16(u16 seg, u16 off)
{
    return (u16)(peek8(seg, off) | ((u16)peek8(seg, (u16)(off + 1)) << 8));
}
static void mem_set(void *dst, int value, int bytes)
{
    memset(dst, value, (size_t)bytes);
}
static void str_copy(char *dst, const char *src) { strcpy(dst, src); }
static void str_cat(char *dst, const char *src) { strcat(dst, src); }
static void fmt_hex4(char *dst, u16 value)
{
    static const char hex[] = "0123456789ABCDEF";
    int i;
    for (i = 0; i < 4; ++i) dst[i] = hex[(value >> (12 - i * 4)) & 15];
    dst[4] = 0;
}
static void fmt_u32(char *dst, u32 value) { sprintf(dst, "%lu", (unsigned long)value); }
static u16 app_seg(void) { return 0x2345; }
static int intr(int n, struct regs *r)
{
    ++intr_calls; intr_no = n; intr_ax = r->ax; intr_ds = r->ds;
    if (intr_fail) return 1;
    r->es = returned_lol_seg;
    r->bx = returned_lol_off;
    return 0;
}
static void disk_log(const char *event, const char *detail, u16 code)
{
    int slot = log_calls < 2 ? log_calls : 1;
    ++log_calls;
    logged = 1;
    strncpy(log_event[slot], event, sizeof log_event[slot] - 1);
    strncpy(log_detail[slot], detail, sizeof log_detail[slot] - 1);
    log_code[slot] = code;
}

#include "../../src/apps/dosvm_memory.inc"

static void reset_case(void)
{
    memset(realmem, 0, sizeof realmem);
    returned_lol_seg = 0x3000; returned_lol_off = 0x1000;
    da_off = 0x00F0; da_seg = 0x1234;
    put16(0, 0x0368, da_off); put16(0, 0x036A, da_seg);
    put16(returned_lol_seg, (u16)(returned_lol_off - 2), 0x0100);
    put8(0x0100, 0, 'M'); put16(0x0100, 1, 0x0008); put16(0x0100, 3, 0x0010);
    put8(0x0111, 0, 'M'); put16(0x0111, 1, 0); put16(0x0111, 3, 0x0020);
    put8(0x0132, 0, 'Z'); put16(0x0132, 1, 0x0300); put16(0x0132, 3, 0x0030);
    intr_calls = intr_fail = logged = peek_after_log = log_calls = 0;
    intr_no = intr_ax = intr_ds = 0;
    memset(log_code, 0, sizeof log_code);
    memset(log_event, 0, sizeof log_event);
    memset(log_detail, 0, sizeof log_detail);
}

static void test_valid_chain(void)
{
    reset_case();
    launch_memory_log();
    assert(intr_calls == 1 && intr_no == 0x21 && intr_ax == 0x5200);
    assert(intr_ds == app_seg());
    assert(log_calls == 2 && log_code[0] == 0 && log_code[1] == 0x5207);
    assert(!peek_after_log);
    assert(strcmp(log_event[0], "Parent memory") == 0);
    assert(strstr(log_detail[0], "FIRST=0100 ROOT=0008/0010") != NULL);
    assert(strstr(log_detail[0], "FREE=32 MAX=32 USED=64 BLOCKS=3") != NULL);
    assert(strcmp(log_event[1], "Parent DA") == 0);
    assert(strstr(log_detail[1], "DA=1234:00F0 MCB=INVALID N=0") != NULL);
}

static void test_ah52_failure(void)
{
    reset_case(); intr_fail = 1;
    launch_memory_log();
    assert(intr_calls == 1 && log_calls == 1 && log_code[0] == 0x5201);
    assert(strstr(log_detail[0], "ROOT=INVALID FREE=INVALID MAX=INVALID USED=INVALID") != NULL);
    assert(!peek_after_log);
}

static void test_bad_lol_pointer(void)
{
    reset_case(); returned_lol_seg = 0xA000;
    launch_memory_log();
    assert(log_code[0] == 0x5202 && log_calls == 1);
    assert(strstr(log_detail[0], "FIRST=----") != NULL);
}

static void test_bad_first_mcb(void)
{
    reset_case(); put16(returned_lol_seg, 0x0FFE, 0xA000);
    launch_memory_log();
    assert(log_code[0] == 0x5203);
    assert(strstr(log_detail[0], "FIRST=A000") != NULL);
}

static void test_bad_type_and_oversized_extent(void)
{
    reset_case(); put8(0x0100, 0, 'Q');
    launch_memory_log();
    assert(log_code[0] == 0x5204);
    assert(strstr(log_detail[0], "FREE=INVALID") != NULL);

    reset_case(); put16(0x0100, 3, 0xFFFF);
    launch_memory_log();
    assert(log_code[0] == 0x5205);
}

static void test_unterminated_chain_bound(void)
{
    u16 seg;
    reset_case();
    for (seg = 0x0100; seg < 0x0180; ++seg) {
        put8(seg, 0, 'M'); put16(seg, 1, 0x0008); put16(seg, 3, 0);
    }
    launch_memory_log();
    assert(log_code[0] == 0x5206 && log_calls == 1);
    assert(strstr(log_detail[0], "MAX=INVALID") != NULL);
}

static void set_da(u16 seg, u16 off)
{
    put16(0, 0x0368, off); put16(0, 0x036A, seg);
}

static void test_da_alias_and_header(void)
{
    reset_case();
    set_da(0x010F, 0x0000); /* physical 010F0h */
    put8(0x010F, 0, 0xA5);
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "DA=010F:0000 MCB=0100 OWNER=0008 PARAS=0010 DATA N=16") != NULL);
    assert(strstr(log_detail[1], "BYTES=A5") != NULL);
    assert(!peek_after_log);

    reset_case();
    set_da(0x0100, 0x00F0); /* same physical byte, different far alias */
    put8(0x010F, 0, 0xA5);
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "DA=0100:00F0 MCB=0100 OWNER=0008 PARAS=0010 DATA N=16") != NULL);
    assert(strstr(log_detail[1], "BYTES=A5") != NULL);

    reset_case();
    set_da(0x0100, 0x0004); /* target lies within the MCB header */
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "MCB=0100 OWNER=0008 PARAS=0010 HDR N=16") != NULL);
    assert(strstr(log_detail[1], "BYTES=00 00 00") != NULL);
}

static void test_da_conventional_boundary(void)
{
    reset_case();
    put16(returned_lol_seg, (u16)(returned_lol_off - 2), 0x9FEF);
    put8(0x9FEF, 0, 'Z'); put16(0x9FEF, 1, 0x4567); put16(0x9FEF, 3, 0x0010);
    set_da(0x9FFF, 0x000F); /* last byte below A0000h */
    put8(0x9FFF, 0x000F, 0x5A);
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "MCB=9FEF OWNER=4567 PARAS=0010 DATA N=1 BYTES=5A") != NULL);

    reset_case();
    put16(returned_lol_seg, (u16)(returned_lol_off - 2), 0x9FEF);
    put8(0x9FEF, 0, 'Z'); put16(0x9FEF, 1, 0x4567); put16(0x9FEF, 3, 0x0010);
    set_da(0xA000, 0x0000); /* outside conventional memory */
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0x5207);
    assert(strstr(log_detail[1], "MCB=INVALID N=0 BYTES=INVALID") != NULL);
}

static void setup_da_window(void)
{
    reset_case();
    put8(0x0100, 0, 'M'); put16(0x0100, 1, 0x0008); put16(0x0100, 3, 0x80FF);
    put8(0x8200, 0, 'M'); put16(0x8200, 1, 0x4567); put16(0x8200, 3, 0x0053);
    put8(0x8254, 0, 'Z'); put16(0x8254, 1, 0x7777); put16(0x8254, 3, 0x0001);
}

static void test_observed_da_targets(void)
{
    setup_da_window();
    set_da(0x8232, 0x01F0); /* physical 82510h */
    put8(0x8251, 0x0000, 0xA1);
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "DA=8232:01F0 MCB=8200 OWNER=4567 PARAS=0053 DATA N=16") != NULL);
    assert(strstr(log_detail[1], "BYTES=A1") != NULL);

    setup_da_window();
    set_da(0x8233, 0x01F0); /* physical 82520h */
    put8(0x8252, 0x0000, 0xB2);
    launch_memory_log();
    assert(log_calls == 2 && log_code[1] == 0);
    assert(strstr(log_detail[1], "DA=8233:01F0 MCB=8200 OWNER=4567 PARAS=0053 DATA N=16") != NULL);
    assert(strstr(log_detail[1], "BYTES=B2") != NULL);
}

int main(void)
{
    test_valid_chain();
    test_ah52_failure();
    test_bad_lol_pointer();
    test_bad_first_mcb();
    test_bad_type_and_oversized_extent();
    test_unterminated_chain_bound();
    test_da_alias_and_header();
    test_da_conventional_boundary();
    test_observed_da_targets();
    puts("DOSVM parent-memory audit host fixture: PASS");
    return 0;
}
