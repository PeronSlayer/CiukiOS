/* Host fixture for DOSVM's held-launch trace persistence include. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
struct regs { u16 ax, bx, cx, dx, si, di, ds, es, flags, cxh, dxh, axh; };
struct guest_window {
    u16 vm, generation;
    u8 trace_failed, launch_snapshot_saved;
    char title[32];
};
#define SNAP_LAUNCH 4
#define VM_READY 1
#define VM_FREE 0

static int create_result, write_result, close_result;
static int query_result, query_cx, ack_result, kill_result;
static int status_result, status_calls;
static u16 status_code, status_generation;
static int create_calls, write_calls, close_calls, log_calls;
static int query_calls, ack_calls, kill_calls;
static int snapshot_sample_calls, snapshot_save_calls, snapshot_save_result;
static int write_bytes;
static u16 ack_vm, ack_generation, ack_sequence_low, ack_sequence_high;
static u16 saved_reason, saved_state, saved_code;
static char created_path[48], log_event[48];
static const char *log_detail;
static char events[32];
static int event_count;
static u8 pending_record[256], durable_dpmirun[256], durable_vmfork[256];
static int durable_dpmirun_calls, durable_vmfork_calls;

static void event(char c) { events[event_count++] = c; events[event_count] = 0; }
static void mem_set(void *dst, int value, int bytes) { memset(dst, value, (size_t)bytes); }
static void str_copy(char *dst, const char *src) { strcpy(dst, src); }
static int dos_create(const char *path)
{
    ++create_calls; event('C');
    strncpy(created_path, path, sizeof created_path - 1);
    return create_result;
}
static int dos_write(int h, const void *data, int bytes)
{
    assert(h == create_result && bytes == sizeof pending_record);
    memcpy(pending_record, data, sizeof pending_record);
    ++write_calls; event('W'); write_bytes = bytes;
    return write_result;
}
static int dos_close(int h)
{
    assert(h == create_result);
    ++close_calls; event('X');
    if (write_result == sizeof pending_record && close_result >= 0) {
        if (!strcmp(created_path, "\\SYSTEM\\DPMIRUN3.BIN")) {
            memcpy(durable_dpmirun, pending_record, sizeof pending_record);
            ++durable_dpmirun_calls;
        } else {
            assert(!strcmp(created_path, "\\SYSTEM\\VMFORK3.BIN"));
            memcpy(durable_vmfork, pending_record, sizeof pending_record);
            ++durable_vmfork_calls;
        }
    }
    return close_result;
}
static void disk_log(const char *name, const char *detail, u16 code)
{
    (void)code; ++log_calls; event('L');
    strncpy(log_event, name, sizeof log_event - 1);
    log_detail = detail;
}
static void snapshot_sample(struct guest_window *g)
{
    (void)g; ++snapshot_sample_calls; event('M');
}
static int snapshot_save(struct guest_window *g, u16 reason, u16 state, u16 code)
{
    (void)g; ++snapshot_save_calls; event('S');
    saved_reason = reason; saved_state = state; saved_code = code;
    return snapshot_save_result;
}
static int vm_status(int vm, u16 *code, u16 *generation)
{
    assert(vm == 3);
    ++status_calls; event('V');
    *code = status_code; *generation = status_generation;
    return status_result;
}
static int vm_call(struct regs *r);

#include "../../src/apps/dosvm_launch_trace.inc"

static void put16(u8 *p, u16 value)
{
    p[0] = (u8)value; p[1] = (u8)(value >> 8);
}
static void put32(u8 *p, u32 value)
{
    p[0] = (u8)value; p[1] = (u8)(value >> 8);
    p[2] = (u8)(value >> 16); p[3] = (u8)(value >> 24);
}
static int vm_call(struct regs *r)
{
    event('P');
    if (r->ax == 0x52 && r->cx == 1) {
        ++query_calls;
        r->cx = (u16)query_cx;
        return query_result;
    }
    if (r->ax == 0x52 && r->cx == 2) {
        /* No ACK attempt may occur until this exact packet has been fully
         * written and successfully closed under its own checkpoint path. */
        const u8 *durable = !strcmp(created_path, "\\SYSTEM\\DPMIRUN3.BIN")
            ? durable_dpmirun : durable_vmfork;
        assert(write_result == 256 && close_result >= 0);
        assert(!memcmp(durable, launch_record, sizeof launch_record));
        ++ack_calls; event('A');
        ack_vm = r->bx; ack_generation = r->dx;
        ack_sequence_low = r->si; ack_sequence_high = r->cxh;
        return ack_result;
    }
    if (r->ax == 0x45) {
        ++kill_calls; event('K');
        return kill_result;
    }
    assert(!"unexpected VM API call");
    return -1;
}

static void reset_case(struct guest_window *g)
{
    memset(launch_record, 0, sizeof launch_record);
    memset(events, 0, sizeof events);
    memset(created_path, 0, sizeof created_path);
    memset(log_event, 0, sizeof log_event);
    memset(pending_record, 0, sizeof pending_record);
    memset(durable_dpmirun, 0, sizeof durable_dpmirun);
    memset(durable_vmfork, 0, sizeof durable_vmfork);
    durable_dpmirun_calls = durable_vmfork_calls = 0;
    create_result = 7; write_result = 256; close_result = 0;
    query_result = 0; query_cx = 1; ack_result = 0; kill_result = 0;
    status_result = VM_READY; status_calls = 0;
    status_code = 0; status_generation = 0x1234;
    create_calls = write_calls = close_calls = log_calls = 0;
    query_calls = ack_calls = kill_calls = write_bytes = 0;
    snapshot_sample_calls = snapshot_save_calls = 0;
    snapshot_save_result = 1;
    ack_vm = ack_generation = ack_sequence_low = ack_sequence_high = 0;
    saved_reason = saved_state = saved_code = 0;
    log_detail = 0; event_count = 0;
    memset(g, 0, sizeof *g);
    g->vm = 3; g->generation = 0x1234; strcpy(g->title, "DOS window");
    put32(launch_record + 0, 0x4C465643UL);
    put32(launch_record + 4, 0x01000001UL);
    put16(launch_record + 8, g->vm);
    put16(launch_record + 10, g->generation);
    put32(launch_record + 40, 0x89ABCDEFUL);
}

static void assert_failed_once(struct guest_window *g)
{
    assert(g->trace_failed == 1);
    assert(log_calls == 1 && strcmp(log_event, "Launch checkpoint failed") == 0);
    assert(kill_calls == 1);
    launch_trace_poll(g);
    assert(write_calls <= 1 && create_calls <= 1 && close_calls <= 1);
    assert(snapshot_sample_calls <= 1 && snapshot_save_calls <= 1);
    assert(log_calls == 1 && kill_calls == 1);
}

static void test_success_waits_for_close(void)
{
    struct guest_window g;
    reset_case(&g);
    launch_trace_poll(&g);
    assert(!g.trace_failed && query_calls == 1);
    assert(create_calls == 1 && write_calls == 1 && close_calls == 1);
    assert(write_bytes == 256 && strcmp(created_path, "\\SYSTEM\\VMFORK3.BIN") == 0);
    assert(ack_calls == 1 && kill_calls == 0 && log_calls == 0);
    assert(ack_vm == g.vm && ack_generation == g.generation);
    assert(ack_sequence_low == 0xCDEF && ack_sequence_high == 0x89AB);
    assert(snapshot_sample_calls == 1 && snapshot_save_calls == 1);
    assert(saved_reason == SNAP_LAUNCH && saved_state == VM_READY && saved_code == 0xFFFF);
    assert(g.launch_snapshot_saved == 1);
    assert(strchr(events, 'X') < strchr(events, 'A'));
    assert(strchr(events, 'M') < strchr(events, 'S') && strchr(events, 'S') < strchr(events, 'A'));
    assert(strcmp(events, "PCWXMSPA") == 0);
}

static void test_launch_snapshot_only_once(void)
{
    struct guest_window g;
    reset_case(&g);
    launch_trace_poll(&g);
    put32(launch_record + 40, 0x89ABCDF0UL);
    launch_trace_poll(&g);
    assert(snapshot_sample_calls == 1 && snapshot_save_calls == 1);
    assert(g.launch_snapshot_saved == 1 && ack_calls == 2 && !g.trace_failed);
    assert(create_calls == 2 && write_calls == 2 && close_calls == 2);
}

static void test_dpmi_boundaries_survive_vmfork_exit(void)
{
    struct guest_window g;
    u8 last_dpmi[256];
    reset_case(&g);
    put16(launch_record + 12, 77);
    launch_trace_poll(&g);
    assert(!g.trace_failed && ack_calls == 1);
    assert(!strcmp(created_path, "\\SYSTEM\\DPMIRUN3.BIN"));
    assert(durable_dpmirun_calls == 1 && durable_vmfork_calls == 0);

    put16(launch_record + 12, 78);
    put32(launch_record + 40, 0x89ABCDF0UL);
    launch_trace_poll(&g);
    assert(!g.trace_failed && ack_calls == 2);
    assert(!strcmp(created_path, "\\SYSTEM\\DPMIRUN3.BIN"));
    assert(durable_dpmirun_calls == 2 && durable_vmfork_calls == 0);
    memcpy(last_dpmi, durable_dpmirun, sizeof last_dpmi);

    put16(launch_record + 12, 8);
    put32(launch_record + 40, 0x89ABCDF1UL);
    launch_trace_poll(&g);
    assert(!g.trace_failed && ack_calls == 3);
    assert(!strcmp(created_path, "\\SYSTEM\\VMFORK3.BIN"));
    assert(durable_dpmirun_calls == 2 && durable_vmfork_calls == 1);
    assert(!memcmp(last_dpmi, durable_dpmirun, sizeof last_dpmi));
    assert(!memcmp(launch_record, durable_vmfork, sizeof launch_record));
    assert(ack_sequence_low == 0xCDF1 && ack_sequence_high == 0x89AB);
    assert(snapshot_sample_calls == 1 && snapshot_save_calls == 1);
    assert(create_calls == 3 && write_calls == 3 && close_calls == 3);
}

static void test_dpmi_boundaries_never_ack_persistence_failure(void)
{
    struct guest_window g;
    const u16 stages[] = {77, 78};
    unsigned stage;
    int failure;
    for (stage = 0; stage < sizeof stages / sizeof stages[0]; ++stage) {
        for (failure = 0; failure < 5; ++failure) {
            reset_case(&g);
            put16(launch_record + 12, stages[stage]);
            if (failure == 0) create_result = -1;
            if (failure == 1) write_result = -1;
            if (failure == 2) write_result = 0;
            if (failure == 3) write_result = 255;
            if (failure == 4) close_result = -1;
            launch_trace_poll(&g);
            assert(!strcmp(created_path, "\\SYSTEM\\DPMIRUN3.BIN"));
            assert(ack_calls == 0);
            assert(durable_dpmirun_calls == 0 && durable_vmfork_calls == 0);
            assert_failed_once(&g);
        }
    }
}

static void test_persistence_failures(void)
{
    struct guest_window g;
    reset_case(&g); create_result = -1; launch_trace_poll(&g);
    assert(create_calls == 1 && write_calls == 0 && close_calls == 0 && ack_calls == 0);
    assert_failed_once(&g);

    reset_case(&g); write_result = -1; launch_trace_poll(&g);
    assert(create_calls == 1 && write_calls == 1 && close_calls == 1 && ack_calls == 0);
    assert(strchr(events, 'X') && strchr(events, 'K') && strchr(events, 'X') < strchr(events, 'K'));
    assert_failed_once(&g);

    reset_case(&g); write_result = 255; launch_trace_poll(&g);
    assert(write_calls == 1 && close_calls == 1 && ack_calls == 0);
    assert_failed_once(&g);

    reset_case(&g); close_result = -1; launch_trace_poll(&g);
    assert(write_calls == 1 && close_calls == 1 && ack_calls == 0);
    assert_failed_once(&g);

    reset_case(&g); snapshot_save_result = 0; launch_trace_poll(&g);
    assert(write_calls == 1 && close_calls == 1 && snapshot_save_calls == 1);
    assert(!g.launch_snapshot_saved && ack_calls == 0);
    assert(strchr(events, 'S') < strchr(events, 'K'));
    assert_failed_once(&g);
}

static void test_invalid_and_stale_records(void)
{
    struct guest_window g;
    reset_case(&g); launch_record[0] ^= 1; launch_trace_poll(&g);
    assert(create_calls == 0 && ack_calls == 0); assert_failed_once(&g);

    reset_case(&g); put32(launch_record + 4, 0x01000002UL); launch_trace_poll(&g);
    assert(create_calls == 0 && ack_calls == 0); assert_failed_once(&g);

    reset_case(&g); put16(launch_record + 8, 2); launch_trace_poll(&g);
    assert(create_calls == 0 && ack_calls == 0); assert_failed_once(&g);

    reset_case(&g); put16(launch_record + 10, 0x4321); launch_trace_poll(&g);
    assert(create_calls == 0 && ack_calls == 0); assert_failed_once(&g);

    reset_case(&g); put32(launch_record + 40, 0); launch_trace_poll(&g);
    assert(create_calls == 0 && write_calls == 0 && ack_calls == 0); assert_failed_once(&g);

    reset_case(&g); query_cx = 0; launch_trace_poll(&g);
    assert(query_calls == 1 && create_calls == 0 && ack_calls == 0 && kill_calls == 0);
    assert(!g.trace_failed && log_calls == 0);

    reset_case(&g); query_result = -1; launch_trace_poll(&g);
    assert(query_calls == 1 && status_calls == 1);
    assert(create_calls == 0 && write_calls == 0 && close_calls == 0 && ack_calls == 0);
    assert(kill_calls == 1 && g.trace_failed && log_calls == 1);
    assert(strcmp(log_event, "Launch checkpoint failed") == 0);

    reset_case(&g); query_result = -1; status_result = VM_FREE; launch_trace_poll(&g);
    assert(query_calls == 1 && status_calls == 1);
    assert(create_calls == 0 && write_calls == 0 && close_calls == 0);
    assert(ack_calls == 0 && kill_calls == 0 && log_calls == 0 && !g.trace_failed);

    reset_case(&g); query_result = -1; status_generation = 0x4321; launch_trace_poll(&g);
    assert(query_calls == 1 && status_calls == 1);
    assert(create_calls == 0 && write_calls == 0 && close_calls == 0);
    assert(ack_calls == 0 && kill_calls == 0 && log_calls == 0 && !g.trace_failed);
}

static void test_ack_failure_kills(void)
{
    struct guest_window g;
    reset_case(&g); ack_result = -1; launch_trace_poll(&g);
    assert(create_calls == 1 && write_calls == 1 && close_calls == 1);
    assert(ack_calls == 1 && kill_calls == 1);
    assert(strchr(events, 'X') < strchr(events, 'A'));
    assert_failed_once(&g);
}

int main(void)
{
    test_success_waits_for_close();
    test_launch_snapshot_only_once();
    test_dpmi_boundaries_survive_vmfork_exit();
    test_dpmi_boundaries_never_ack_persistence_failure();
    test_persistence_failures();
    test_invalid_and_stale_records();
    test_ack_failure_kills();
    puts("DOSVM launch-trace host fixture: PASS");
    return 0;
}
