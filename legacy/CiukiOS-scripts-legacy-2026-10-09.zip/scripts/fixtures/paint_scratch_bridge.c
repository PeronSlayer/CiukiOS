/* Test entry points; production Paint and its real DOS/far-pointer code. */
#include "../../src/apps/paint.c"

int paint_scratch_call(int op)
{
    if (op == 0) { tabs = dos_alloc(paras(ROWBUF_OFF + ROWBUF_BYTES)); return tabs; }
    if (op == 1) return load_bmp("IN.BMP");
    if (op == 2) return save_bmp("OUT.BMP");
    release_memory();
    return 0;
}
