#!/usr/bin/env python3
"""Exercise external MCB ownership across real full-kernel TSR/EXEC operations.

The direct carve reproduces pinned HDPMI HELPERS.ASM _AllocDosMemory's MCB
split and owner assignment; hardware, BIOS and a full HDPMI client are not run.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import tempfile

from unicorn import x86_const as x
from test_kernel_f149_arena import BASE, SEG, SHELL, TOP, Machine, assemble

HOST = 0x2500
FRAME = 0xB000
CARVE = 0x8081
IMAGE = Path('build/full/t23-next/ciukios-t23-diskseq33-r12.img')


class ExternalMachine(Machine):
    def stop(self, uc, address, size, data):
        if hasattr(self, 'labels') and address in (
                BASE + self.labels['int21_com_terminate_trampoline'],
                BASE + self.labels['int21_mz_terminate_trampoline']):
            # AH31's dispatcher redirects IRET to this termination boundary.
            # Stop before launcher/file cleanup outside the allocator contract.
            self.stop_at = address
        if getattr(self, 'io_active', False):
            if address == BASE + self.labels['int21_handler']:
                uc.reg_write(x.UC_X86_REG_DS, CARVE)
            for name in ('int21_mem_refresh_owners', 'int21_mem_rebuild_chain',
                         'int21_alloc', 'int21_resize', 'int21_free_impl'):
                if address == BASE + self.labels[name]:
                    self.io_allocator_hits.append(name)
            if address == BASE + self.labels['int21_cluster_for_pos']:
                uc.reg_write(x.UC_X86_REG_AX, 2)
                uc.reg_write(x.UC_X86_REG_DX, self.value('file_handle_pos') & 0xfff)
                self.fs_return(uc)
                return
            if address == BASE + self.labels['read_sector_lba32']:
                target = uc.reg_read(x.UC_X86_REG_ES) * 16 + uc.reg_read(x.UC_X86_REG_BX)
                uc.mem_write(target, b'\x39' * 512)
                self.io_reads += 1
                self.fs_return(uc)
                return
            if address == BASE + self.labels['write_sector_lba32']:
                self.io_writes += 1
                self.fs_return(uc)
                return
            if address == BASE + self.labels['int21_update_root_entry_size']:
                self.fs_return(uc)
                return
        super().stop(uc, address, size, data)

    @staticmethod
    def fs_return(uc):
        ss, sp = uc.reg_read(x.UC_X86_REG_SS), uc.reg_read(x.UC_X86_REG_SP)
        target = int.from_bytes(uc.mem_read(ss * 16 + sp, 2), 'little')
        uc.reg_write(x.UC_X86_REG_SP, sp + 2)
        uc.reg_write(x.UC_X86_REG_IP, target)
        uc.reg_write(x.UC_X86_REG_EFLAGS, uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1)

    def __init__(self, image, labels):
        super().__init__(image, labels, SHELL)
        self.psp(SHELL, 0x1000, SHELL)
        self.put('dos_exec_identity_psp', SHELL)
        self.put('current_psp_seg', SHELL)
        self.put('dos_mem_psp_mcb_end', SHELL + 0x1000)
        # Only the final hole is large enough for the exact dynamic TLB.
        self.entries = [(0x2181, HOST - 0x2181 - 1, SHELL, 1),
                        (0x2801, CARVE - 0x2801 - 1, SHELL, 1)]
        self.set_entries()
        self.call('int21_mem_rebuild_chain')
        self.state_start = labels['dos_mem_exec_state_begin']
        self.state_size = labels['dos_mem_exec_state_end'] - self.state_start
        self.u.mem_write(FRAME * 16, bytes(self.u.mem_read(BASE + self.state_start, self.state_size)))
        self.u.mem_write(FRAME * 16 + self.state_size,
                         bytes(self.u.mem_read(BASE + labels['dos_list_of_lists'], 6)))
        self.psp(HOST, 0x300, SHELL)
        self.entries.append((HOST, 0x300, HOST, 5))
        self.set_entries()
        self.put('dos_exec_identity_psp', HOST)
        self.put('current_psp_seg', HOST)
        self.put('dos_mem_psp_mcb_end', HOST + 0x300)
        self.put('dos_exec_parent_identity_psp', SHELL)
        self.put('dos_exec_state_depth', 1, 1)
        self.call('int21_mem_rebuild_chain')
        assert self.chain()[CARVE]['owner'] == 0

    def set_entries(self):
        self.entries.sort()
        self.put('dos_mem_block_count', len(self.entries), 1)
        self.u.mem_write(BASE + self.labels['dos_mem_block_table'],
                         b''.join(struct.pack('<4H', *entry) for entry in self.entries))
        for segment, size, owner, _ in self.entries:
            self.mcb(segment, size, owner)

    def carve(self, paragraphs, tracked):
        if tracked:
            result, carry = self.call('int21_handler', ax=0x4800,
                                      bx=paragraphs, interrupt=True)
            assert not carry and result == CARVE, (result, carry)
        else:
            # Exact _AllocDosMemory split: original data size N becomes
            # wanted-size owned MCB, followed by free (N-wanted-1) MCB.
            original = self.chain()[CARVE]
            assert original['size'] > paragraphs and original['owner'] == 0
            old_type = bytes(self.u.mem_read((CARVE - 1) * 16, 1))
            self.u.mem_write((CARVE - 1) * 16,
                             struct.pack('<BHH', ord('M'), HOST, paragraphs))
            following_mcb = CARVE + paragraphs
            self.u.mem_write(following_mcb * 16,
                             struct.pack('<BHH', old_type[0], 0,
                                         original['size'] - paragraphs - 1))
        self.sentinel = bytes([0xA7]) * (paragraphs * 16)
        self.u.mem_write(CARVE * 16, self.sentinel)
        self.expected_header = bytes(self.u.mem_read((CARVE - 1) * 16, 5))

    def preserved(self):
        return (bytes(self.u.mem_read((CARVE - 1) * 16, 5)) == self.expected_header
                and bytes(self.u.mem_read(CARVE * 16, len(self.sentinel))) == self.sentinel)

    def return_parent(self):
        # Execute actual resident merge, then the same allocator-frame and
        # LoL copy performed by int21_exec.done, followed by actual rebuild.
        self.call('int21_mem_merge_exec_residents', es=FRAME)
        self.u.mem_write(BASE + self.state_start,
                         bytes(self.u.mem_read(FRAME * 16, self.state_size)))
        self.u.mem_write(BASE + self.labels['dos_list_of_lists'],
                         bytes(self.u.mem_read(FRAME * 16 + self.state_size, 6)))
        self.put('current_psp_seg', SHELL)
        self.put('dos_exec_state_depth', 0, 1)
        self.call('int21_mem_rebuild_chain')


def run_case(kernel, labels, size, tracked):
    m = ExternalMachine(kernel, labels)
    m.carve(size, tracked)
    checkpoints = []
    checkpoints.append(dict(call='external carve', preserved=m.preserved()))
    m.call('int21_mem_refresh_owners')
    checkpoints.append(dict(call='int21_mem_refresh_owners', preserved=m.preserved()))
    # Test AH31 directly, not a Python approximation of TSR ownership commit.
    m.u.reg_write(x.UC_X86_REG_DX, 0xA0)
    result, carry = m.call('int21_handler', ax=0x3103, es=HOST, interrupt=True)
    assert not carry, (result, carry)
    checkpoints.append(dict(call='INT21 AH31 (resize and TSR commit)',
                            preserved=m.preserved(),
                            owner_after=struct.unpack('<BHH', m.u.mem_read((CARVE - 1) * 16, 5))[1]))
    m.return_parent()
    checkpoints.append(dict(call='int21_mem_merge_exec_residents + parent frame restore + rebuild',
                            preserved=m.preserved()))
    result, carry = m.call('int21_handler', ax=0x4800, bx=0x20, interrupt=True)
    assert not carry
    overlap = result < CARVE + size and result + 0x20 > CARVE
    m.u.mem_write(result * 16, b'\x5C' * (0x20 * 16))
    checkpoints.append(dict(call='next INT21 AH48 allocation', preserved=m.preserved(),
                            allocation_segment=result, overlap=overlap))
    return dict(paragraphs=size, bytes=size * 16,
                allocation='AH48 tracked control' if tracked else 'direct MCB carve',
                source_relevance='actual permanent-TLB allocation API' if tracked else
                    ('exact dynamic-TLB size; lifespan across TSR is a synthetic allocator contract' if size == 0xFE0 else
                     'synthetic 8KiB direct-carve control; not an observed HDPMI startup path'),
                checkpoints=checkpoints,
                contract_pass=all(point['preserved'] for point in checkpoints) and not overlap)


def isolated_rebuild(kernel, labels):
    m = ExternalMachine(kernel, labels)
    m.carve(0xFE0, False)
    m.call('int21_mem_refresh_owners')
    after_refresh = m.preserved()
    m.call('int21_mem_rebuild_chain')
    return dict(after_refresh_preserved=after_refresh,
                after_rebuild_preserved=m.preserved(),
                owner_after_rebuild=struct.unpack('<BHH', m.u.mem_read((CARVE - 1) * 16, 5))[1])


def actual_file_io_lifetime(kernel, labels, write):
    m = ExternalMachine(kernel, labels)
    m.carve(0xFE0, False)
    m.io_active, m.io_reads, m.io_writes = True, 0, 0
    m.io_allocator_hits = []
    for name, value, width in (('file_handle_open', 1, 1),
                               ('file_handle_mode', 2 if write else 0, 1),
                               ('file_handle_start_cluster', 2, 2),
                               ('file_handle_size_lo', 0x4000, 2),
                               ('file_handle_size_hi', 0, 2),
                               ('file_handle_pos', 0, 2),
                               ('file_handle_pos_hi', 0, 2)):
        m.put(name, value, width)
    m.u.reg_write(x.UC_X86_REG_CX, 0x4000)
    m.u.reg_write(x.UC_X86_REG_DX, 0)
    # The entry hook supplies the actual user DS because shared Machine.call
    # normally selects its fixed CHILD segment for allocator fixtures.
    result, carry = m.call('int21_handler', ax=0x4000 if write else 0x3F00,
                          bx=5, es=CARVE, interrupt=True)
    m.io_active = False
    header_ok = bytes(m.u.mem_read((CARVE - 1) * 16, 5)) == m.expected_header
    expected = m.sentinel if write else b'\x39' * 0x4000 + m.sentinel[0x4000:]
    payload_ok = bytes(m.u.mem_read(CARVE * 16, len(expected))) == expected
    return dict(operation='AH40' if write else 'AH3F', bytes=0x4000,
                result=result, carry=carry, allocator_calls=m.io_allocator_hits,
                sector_reads=m.io_reads, sector_writes=m.io_writes,
                owned_header_preserved=header_ok, payload_or_read_tail_preserved=payload_ok,
                limitations='Filesystem extent resolution, sector I/O and directory-size persistence are modeled; actual dispatcher/read/write/copy/SFT code runs.',
                contract_pass=not carry and result == 0x4000 and header_ok and payload_ok
                              and not m.io_allocator_hits)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expect-regression', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    original = subprocess.check_output(['mtype', '-i', str(IMAGE), '::SYSTEM/CIUKIDOS.SYS'])
    with tempfile.TemporaryDirectory(prefix='ciukios-external-mcb-') as tmp:
        kernel, labels = assemble(Path(tmp))
        rows = [run_case(kernel, labels, 0xFE0, False),
                run_case(kernel, labels, 0x200, False),
                run_case(kernel, labels, 0x200, True)]
        isolated = isolated_rebuild(kernel, labels)
        file_io = [actual_file_io_lifetime(kernel, labels, False),
                   actual_file_io_lifetime(kernel, labels, True)]
    report = dict(original_image=str(IMAGE),
                  original_image_sha256=hashlib.sha256(IMAGE.read_bytes()).hexdigest(),
                  original_kernel_sha256=hashlib.sha256(original).hexdigest(),
                  fixture_kernel_sha256=hashlib.sha256(kernel).hexdigest(),
                  fixture_kernel_matches_original=kernel == original,
                  source='https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HELPERS.ASM',
                  first_destructive_kernel_call='int21_mem_rebuild_chain' if not isolated['after_rebuild_preserved'] else None,
                  isolated=isolated, cases=rows, actual_file_io_lifetime=file_io)
    (args.output / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    assert rows[2]['contract_pass'], 'tracked AH48 control must remain valid'
    assert all(row['contract_pass'] for row in file_io), 'file I/O disturbed the live dynamic TLB'
    if args.expect_regression:
        assert isolated['after_refresh_preserved'] and not isolated['after_rebuild_preserved']
        assert not rows[0]['contract_pass'] and not rows[1]['contract_pass']
    else:
        assert all(row['contract_pass'] for row in rows), 'external carve was lost or reallocated'


if __name__ == '__main__':
    main()
