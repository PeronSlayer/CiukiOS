#!/usr/bin/env python3
"""Execute actual fixed-sector PIO helpers against modeled 16-bit ATA ports.

Verifies exact word count, CPU destination/source, canaries, cdecl registers,
segment restoration and FLAGS/DF, including nonflat caller DS and ES.
"""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_INSN
from unicorn import x86_const as x
from test_session_scheduler import section

ROOT=Path(__file__).resolve().parents[1]
BASE,BUFFER,STACK,GDT,STOP=0x100000,0x21000,0x300000,0x18000,0x700000


def build(out):
    source=(ROOT/'src/vm/session_disk.inc').read_text()
    routines='\n'.join(section(source,n+' proc',n+' endp')
                       for n in ('cvata_pio_read','cvata_pio_write'))
    text='.386p\n.model flat,stdcall\noption casemap:none\n.code\n'+routines+'\nend\n'
    out.mkdir(parents=True,exist_ok=True)
    asm,obj,elf,binary=[out/('pio'+s) for s in ('.asm','.o','.elf','.bin')]
    asm.write_text(text)
    link=out/'link.ld'; link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'),
                    '-nologo','-elf','-Cp','-Fo'+str(obj),str(asm)],check=True)
    subprocess.run(['ld','-m','elf_i386','-T',str(link),'-o',str(elf),str(obj)],check=True)
    subprocess.run(['objcopy','-O','binary',str(elf),str(binary)],check=True)
    symbols={f[2].lstrip('_'):int(f[0],16) for line in subprocess.check_output(['nm',str(elf)],text=True).splitlines()
             if len(f:=line.split())==3}
    return binary.read_bytes(),symbols,hashlib.sha256(routines.encode()).hexdigest()


def descriptor(base,access):
    return struct.pack('<HHBBBB',0xffff,base&0xffff,(base>>16)&255,access,0xcf,(base>>24)&255)


def exercise(image,symbols,write,df,port):
    u=Uc(UC_ARCH_X86,UC_MODE_32); u.mem_map(0,0x800000); u.mem_write(BASE,image)
    u.mem_write(GDT,b'\0'*8+descriptor(0,0x9b)+descriptor(0,0x93)
                +descriptor(0x400000,0x93)+descriptor(0x500000,0x93))
    u.reg_write(x.UC_X86_REG_GDTR,(0,GDT,39,0))
    for reg,value in ((x.UC_X86_REG_CS,8),(x.UC_X86_REG_SS,16),
                       (x.UC_X86_REG_DS,24),(x.UC_X86_REG_ES,32)):
        u.reg_write(reg,value)
    preserved=(x.UC_X86_REG_EBX,x.UC_X86_REG_ESI,x.UC_X86_REG_EDI,
               x.UC_X86_REG_EBP,x.UC_X86_REG_EDX,x.UC_X86_REG_DS,x.UC_X86_REG_ES)
    for index,reg in enumerate(preserved[:5]): u.reg_write(reg,0xabc10000+index*0x111)
    expected=struct.pack('<256H',*((i*0x101+0x7654)&65535 for i in range(256)))
    u.mem_write(BUFFER-16,b'\xa5'*544)
    u.mem_write(BUFFER+0x400000-16,b'\xb6'*544)
    u.mem_write(BUFFER+0x500000-16,b'\xc7'*544)
    if write: u.mem_write(BUFFER,expected)
    calls=[]
    def input_word(uc,actual_port,size,data):
        assert actual_port==port and size==2 and len(calls)<256
        value=int.from_bytes(expected[len(calls)*2:len(calls)*2+2],'little')
        calls.append(value); return value
    def output_word(uc,actual_port,size,value,data):
        assert actual_port==port and size==2 and len(calls)<256
        calls.append(value)
    u.hook_add(UC_HOOK_INSN,input_word,None,1,0,x.UC_X86_INS_IN)
    u.hook_add(UC_HOOK_INSN,output_word,None,1,0,x.UC_X86_INS_OUT)
    u.mem_write(STACK,struct.pack('<3I',STOP,port,BUFFER))
    u.reg_write(x.UC_X86_REG_ESP,STACK)
    u.reg_write(x.UC_X86_REG_EFLAGS,0xa97 | (0x400 if df else 0))
    flags=u.reg_read(x.UC_X86_REG_EFLAGS)
    before=[u.reg_read(r) for r in preserved]
    u.emu_start(symbols['cvata_pio_write' if write else 'cvata_pio_read'],STOP,count=4000)
    assert len(calls)==256 and struct.pack('<256H',*calls)==expected
    assert bytes(u.mem_read(BUFFER,512))==expected
    assert bytes(u.mem_read(BUFFER-16,16))==bytes(u.mem_read(BUFFER+512,16))==b'\xa5'*16
    assert bytes(u.mem_read(BUFFER+0x400000-16,544))==b'\xb6'*544
    assert bytes(u.mem_read(BUFFER+0x500000-16,544))==b'\xc7'*544
    assert [u.reg_read(r) for r in preserved]==before
    assert u.reg_read(x.UC_X86_REG_EFLAGS)==flags
    assert u.reg_read(x.UC_X86_REG_ESP)==STACK+4, 'cdecl leaves arguments for caller'
    assert u.reg_read(x.UC_X86_REG_ECX)==0


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); image,symbols,digest=build(a.output); cases=[]
    for write in (False,True):
        for df in (False,True):
            for port in (0x1f0,0x170):
                exercise(image,symbols,write,df,port)
                cases.append(f'{"OUTSW" if write else "INSW"} port={port:x} DF={int(df)}:256words/canaries/segments/registers/flags/cdecl')
    report={'passed':True,'hardware_validation':False,'cases':cases,
            'production_helpers_sha256':digest,'unicorn':importlib.metadata.version('unicorn')}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
