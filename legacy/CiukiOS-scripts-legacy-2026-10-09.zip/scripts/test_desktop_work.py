#!/usr/bin/env python3
"""Execute production Desktop poll routing and caption drawing with host stubs.

Checks the worker/shell boundary that previously turned background work into
idle IRQ waits, and caption coverage over arbitrary wallpaper pixels. This is
CPU evidence; the full image still needs the compositor/runtime gate.
"""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def function(source: str, declaration: str) -> str:
    start = source.index(declaration)
    body = source.index("{", start)
    depth = 1
    end = body + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


STUBS = r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint16_t u16;
typedef uint32_t u32;
struct webmodule {u16 segment,error,dos_error;};
struct app_wallpaper_info {u16 generation;int kind;};
struct host {unsigned ticks;int active;} host;
#define HOST host
#define EV_OPEN 1
#define EV_POLL 6
#define C_PAPER 15
#define C_INK 0
#define C_TITLE 1
#define CELL_W 84
#define LFN_NAME 256
static struct app_wallpaper_info supplied;
static int worker_result, open_result, desktop_result, poll_calls;
static int app_wallpaper(struct app_wallpaper_info *p) {*p=supplied;return 1;}
static int webmodule_load(struct webmodule *p,const char *s) {(void)s;p->segment=1;return 1;}
static int webmodule_call(struct webmodule *p,int event,const void *arg) {
    (void)p;(void)arg;if(event==EV_OPEN)return open_result;
    assert(event==EV_POLL);++poll_calls;return worker_result;
}
static void wallpaper_log_load_error(void) {}
static void app_log(const char *a,const char *b) {(void)a;(void)b;}
static void fmt_u32(char *s,u32 n) {sprintf(s,"%u",n);}
static int poll(void) {return desktop_result;}
struct dicon {int x,y,sel;char name[LFN_NAME];};
static struct dicon icons[1];
static unsigned icon_label_lines[1],icon_label_width[1];
static int cur=-1,drop_i=-1,renaming=-1,rename_field;
static unsigned char pixels[300][300];
static int glyph_calls,icon_calls;
static void ui_rect(int x,int y,int w,int h,int c) {
    int xx,yy;assert(x>=0&&y>=0&&x+w<=300&&y+h<=300);
    for(yy=y;yy<y+h;++yy)for(xx=x;xx<x+w;++xx)pixels[yy][xx]=(unsigned char)c;
}
static int ui_measure(const char *s) {return (int)strlen(s)*6;}
static void ui_text(int x,int y,const char *s,int c) {
    int xx,yy;assert(c==C_PAPER);++glyph_calls;
    /* Every foreground glyph cell starts on the chosen solid backing,
     * regardless of the original wallpaper pixel values. */
    for(yy=y;yy<y+16;++yy)for(xx=x;xx<x+ui_measure(s);++xx)
        assert(pixels[yy][xx]==(icons[0].sel?C_TITLE:C_INK));
}
static void ui_icon(int x,int y,int id) {(void)x;(void)y;assert(id==17);++icon_calls;}
static int icon_id(const struct dicon *p) {(void)p;return 17;}
static const char *icon_label(int i) {return icons[i].name;}
static void field_draw(int *f,int x,int y,int w,int on) {(void)f;(void)x;(void)y;(void)w;(void)on;}
static void draw_focus(int x,int y,int w,int h) {(void)x;(void)y;(void)w;(void)h;}
#include "iconlabel.h"
'''

CASES = r'''
int main(void) {
    static const int expected[3][3]={{0,1,3},{1,1,1},{2,1,3}};
    static const int desk_modes[]={0,1,3};
    static const char *names[]={"Computer","Control Panel","TestGames",
        "A complete long filename that must wrap without truncation.txt"};
    int w,d,n,selected,bg,width,prior;
    wallpaper_module.segment=1;wallpaper_generation=7;
    supplied.generation=7;supplied.kind=2;
    for(w=0;w<3;++w)for(d=0;d<3;++d) {
        worker_result=w;desktop_result=desk_modes[d];
        assert(desktop_poll()==expected[w][d]);
    }
    supplied.generation=8;worker_result=2;desktop_result=0;
    assert(desktop_poll()==1); /* first request gets the format-setting paint */
    assert(desktop_poll()==2); /* subsequent chunks avoid repaint and HLT */
    worker_result=1;assert(desktop_poll()==1);
    worker_result=0;assert(desktop_poll()==0);
    supplied.generation=9;open_result=1;prior=poll_calls;
    assert(desktop_poll()==0&&poll_calls==prior); /* rejected generation is not polled */
    puts("desktop poll: all nine worker/HUD result combinations, commit and rejection PASS");
    icons[0].x=8;icons[0].y=5;
    for(n=0;n<4;++n)for(selected=0;selected<2;++selected)for(bg=0;bg<3;++bg) {
        memset(pixels,bg==0?15:bg==1?0:7,sizeof pixels);
        strcpy(icons[0].name,names[n]);icons[0].sel=selected;
        icon_label_lines[0]=ciuki_label_layout(names[n],CELL_W-6,&width);
        icon_label_width[0]=width;glyph_calls=icon_calls=0;
        draw_icon(0,0,0,0);
        assert(glyph_calls==(int)icon_label_lines[0]&&icon_calls==1);
    }
    puts("desktop captions: 24 bright/dark/mid-tone selection/wrapping cases; one glyph pass per line PASS");
    return 0;
}
'''


def main() -> None:
    desktop = (ROOT / "src/apps/desktop.c").read_text()
    state = desktop[desktop.index("static struct webmodule wallpaper_module;"):
                    desktop.index("static void wallpaper_log_load_error(void)")]
    event = desktop.index("int app_event(int ev,")
    poll_case = desktop[desktop.index("    case EV_POLL:", event):
                        desktop.index("    case EV_SUSPEND:", event)]
    code = STUBS + state + function(desktop, "static int wallpaper_poll(void)")
    code += "\nstatic int desktop_poll(void) {int r=0,poll_result;switch(EV_POLL){\n"
    code += poll_case + "\n}return r;}\n"
    code += function(desktop, "static void draw_icon(int i,") + CASES
    with tempfile.TemporaryDirectory(prefix="ciuki-desktop-work-") as temp:
        source = Path(temp) / "desktop_work.c"
        binary = Path(temp) / "desktop_work"
        source.write_text(code)
        subprocess.run(["cc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror",
                        "-I", str(ROOT / "src/apps"), str(source), "-o", str(binary)], check=True)
        subprocess.run([str(binary)], check=True)


if __name__ == "__main__":
    main()
