#!/usr/bin/env python3
"""Compile and run the host fixture for DOSVM launch-trace persistence."""
import argparse
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    args.output.mkdir(parents=True, exist_ok=True)
    binary = args.output / 'dosvm_launch_trace_host'
    subprocess.run([
        'cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
        '-Wno-pointer-to-int-cast',
        str(root / 'scripts/fixtures/dosvm_launch_trace_host.c'), '-o', str(binary),
    ], cwd=root, check=True)
    subprocess.run([str(binary)], cwd=root, check=True)


if __name__ == '__main__':
    main()
