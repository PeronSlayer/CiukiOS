#!/usr/bin/env python3
"""Regress the forced-S3 QEMU capture without another heavy runtime job."""
from pathlib import Path
import struct

from s3_guest_launch_evidence import completed_guest_launch

FIXTURES = Path(__file__).resolve().parent / 'fixtures'


def changed(record, offset, value):
    result = bytearray(record)
    struct.pack_into('<H', result, offset, value)
    return bytes(result)


def main():
    launch = (FIXTURES / 'vmfork-s3-launch-return.cvfl').read_bytes()
    manager = (FIXTURES / 'vmfork-s3-launch-return.cdvs').read_bytes()
    result = completed_guest_launch(launch, manager, 1)
    assert result and result['state'] == 'free' and result['reason'] == 'observed_exit'
    assert result['generation'] == 1 and result['exit_code'] == 0
    for offset, value in ((8, 2), (10, 2), (12, 7), (14, 0x85),
                          (16, 0x17f), (16, 0x43f), (16, 0x53f), (38, 1)):
        assert completed_guest_launch(changed(launch, offset, value), manager, 1) is None
    for offset, value in ((8, 2), (10, 2), (16, 1), (16, 3), (18, 1), (18, 2), (20, 1)):
        assert completed_guest_launch(launch, changed(manager, offset, value), 1) is None
    assert completed_guest_launch(launch[:-1], manager, 1) is None
    assert completed_guest_launch(launch, manager, 2) is None
    print('S3 launch evidence PASS: captured natural FREE exit accepted; stale generation, other VM, running/dead/forced-close, missing milestones and mismatched exit rejected')


if __name__ == '__main__':
    main()
