import importlib.util
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
spec = importlib.util.spec_from_file_location(
    "build_kernel_component", SCRIPTS / "build_kernel_component.py"
)
component = importlib.util.module_from_spec(spec)
spec.loader.exec_module(component)


def kernel_fixture():
    data = bytearray(512)
    data[0:2] = b"\xEB\x00"
    data[2:10] = b"CIUKIDOS"
    struct.pack_into("<8H", data, 10, 26, 2, 13, 8, 0x003F, len(data), 29, 0x0900)
    data[29:33] = b"RTSV"
    struct.pack_into("<3H", data, 33, 2, 13, 8)
    table_end = 29 + 10 + 13 * 8
    for index in range(13):
        struct.pack_into("<4H", data, 39 + index * 8, index + 1, 1, table_end + 1, 0)
    cmly = 180
    data[cmly : cmly + 4] = b"CMLY"
    struct.pack_into("<4H", data, cmly + 4, 1, 84, 9, 8)
    kernel_paragraphs = 32
    sysvars = 0x0300 + kernel_paragraphs
    exec_seg = sysvars + 0x70
    records = [
        (1, 0x0300, kernel_paragraphs, 1),
        (2, sysvars, 0x70, 1),
        (3, exec_seg, 0x100, 1),
        (4, exec_seg + 0x80, 0x20, 2),
        (5, exec_seg + 0x100, 0x100, 1),
        (6, exec_seg + 0x200, 0x100, 1),
        (7, exec_seg + 0x300, 0x30, 1),
        (8, exec_seg + 0x330, 0x50, 1),
        (9, exec_seg + 0x380, 0, 4),
    ]
    for index, record in enumerate(records):
        struct.pack_into("<4H", data, cmly + 12 + index * 8, *record)
    return bytes(data)


class FakeFat16:
    start = 0
    files = {}

    def __init__(self, _image):
        pass

    def read(self, path):
        return self.files[path.upper()]


class KernelComponentImageGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.kernel = self.root / "ciukidos.sys"
        self.listing = self.root / "ciukidos.lst"
        self.image = self.root / "disk.img"
        self.image.write_bytes(b"mock FAT16 image")
        self.data = kernel_fixture()
        self.kernel.write_bytes(self.data)
        self.session = self.root / "vm-window" / "session"
        self.session.mkdir(parents=True)
        (self.root / "lfn").mkdir()
        (self.root / "vm-window").mkdir(exist_ok=True)

        self.offsets = {source: 0x100 + index for index, source in enumerate(component.PRIVATE_SYMBOLS)}
        lines = []
        for index, (source, offset) in enumerate(self.offsets.items(), start=1):
            if source == "int_default_iret":
                lines.extend((f"{index:5d} {'':48s}<1> int_default_iret:",
                              f"{index + 1:5d} {offset:08X} CF <1> iret"))
            else:
                directive = "dw" if source in ("fat_cache_sector", "dos_mem_last_mcb_seg",
                                                "dos_exec_identity_psp", "current_psp_seg") else "db"
                lines.append(f"{index:5d} {offset:08X} 00 <1> {source} {directive} 0")
        self.listing.write_text("\n".join(lines) + "\n", encoding="ascii")

        layout = ["KL_PRESENT equ 1"]
        for source, key in component.PRIVATE_SYMBOLS.items():
            layout.append(f"{key} equ {self.offsets[source]:05X}h")
        (self.session / "kernel_layout.inc").write_text("\n".join(layout) + "\n", encoding="ascii")

        (self.root / "lfn" / "LFN.COM").write_bytes(b"lfn-module")
        (self.session / "CVSESSION.DLL").write_bytes(b"session-module")
        (self.root / "vm-window" / "VMFORK.COM").write_bytes(b"vmfork-com")
        (self.root / "vm-window" / "VMFORK.EXE").write_bytes(b"vmfork-exe")
        FakeFat16.files = {
            "SYSTEM/CIUKIDOS.SYS": self.data,
            "SYSTEM/LFN.COM": b"lfn-module",
            "VM/CVSESS.DLL": b"session-module",
            "VM/VMFORK.COM": b"vmfork-com",
            "VM/VMFORK.EXE": b"vmfork-exe",
        }
        self.fake_module = types.ModuleType("qemu_test_installed_hdd")
        self.fake_module.FAT16 = FakeFat16

    def call_guard(self):
        def fake_mcopy(argv, **_kwargs):
            self.assertEqual(argv[0], "mcopy")
            FakeFat16.files["SYSTEM/CIUKIDOS.SYS"] = Path(argv[-2]).read_bytes()

        with patch.dict(sys.modules, {"qemu_test_installed_hdd": self.fake_module}), \
             patch.object(component.subprocess, "run", side_effect=fake_mcopy) as run:
            component.patch_image(self.image, self.kernel, self.listing, self.data)
        return run

    def assert_rejected_before_mcopy(self, message):
        with patch.dict(sys.modules, {"qemu_test_installed_hdd": self.fake_module}), \
             patch.object(component.subprocess, "run") as run:
            with self.assertRaisesRegex(ValueError, message):
                component.patch_image(self.image, self.kernel, self.listing, self.data)
            run.assert_not_called()

    def test_matching_offsets_and_modules_allow_kernel_injection(self):
        run = self.call_guard()
        run.assert_called_once()
        self.assertEqual(FakeFat16.files["SYSTEM/CIUKIDOS.SYS"], self.data)

    def test_changed_private_offset_rejects_before_mcopy(self):
        path = self.session / "kernel_layout.inc"
        path.write_text(path.read_text().replace("KL_INDOS equ 00100h", "KL_INDOS equ 00101h"))
        self.assert_rejected_before_mcopy("KL_INDOS")

    def test_changed_cvsess_rejects_before_mcopy(self):
        FakeFat16.files["VM/CVSESS.DLL"] = b"stale-session-module"
        self.assert_rejected_before_mcopy("VM/CVSESS.DLL")

    def test_changed_lfn_rejects_before_mcopy(self):
        FakeFat16.files["SYSTEM/LFN.COM"] = b"stale-lfn-module"
        self.assert_rejected_before_mcopy("SYSTEM/LFN.COM")

    def test_missing_vmfork_artifact_rejects_before_mcopy(self):
        (self.root / "vm-window" / "VMFORK.EXE").unlink()
        self.assert_rejected_before_mcopy("VMFORK.EXE")


if __name__ == "__main__":
    unittest.main()
