import struct
import tempfile
import unittest
import importlib.util
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "ciukidos_image.py"
spec = importlib.util.spec_from_file_location("ciukidos_image", SCRIPT)
ciukidos_image = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ciukidos_image)
inspect_kernel = ciukidos_image.inspect_kernel
read_build_parameters = ciukidos_image.read_build_parameters


def make_image(size=1024):
    image = bytearray(size)
    image[0:2] = b"\xEB\x00"
    image[2:10] = b"CIUKIDOS"
    struct.pack_into("<8H", image, 10, 26, 2, 13, 8, 0x003F, size, 29, 0x0900)
    image[29:33] = b"RTSV"
    struct.pack_into("<3H", image, 33, 2, 13, 8)
    table_end = 29 + 10 + 13 * 8
    for index in range(13):
        struct.pack_into("<4H", image, 39 + index * 8, index + 1, 1, table_end + 1, 0)

    start = 180
    image[start : start + 4] = b"CMLY"
    struct.pack_into("<4H", image, start + 4, 1, 12 + 9 * 8, 9, 8)
    kernparas = (size + 15) // 16
    sysvars = 0x0300 + kernparas
    execseg = sysvars + 0x70
    records = [
        (1, 0x0300, kernparas, 1),
        (2, sysvars, 0x70, 1),
        (3, execseg, 0x100, 1),
        (4, execseg + 0x80, 0x20, 2),
        (5, execseg + 0x100, 0x100, 1),
        (6, execseg + 0x200, 0x100, 1),
        (7, execseg + 0x300, 0x30, 1),
        (8, execseg + 0x330, 0x50, 1),
        (9, execseg + 0x380, 0, 4),
    ]
    for index, record in enumerate(records):
        struct.pack_into("<4H", image, start + 12 + index * 8, *record)
    return image


class CiukiDOSImageTests(unittest.TestCase):
    def test_valid_image_reports_dynamic_layout(self):
        result = inspect_kernel(make_image())
        self.assertEqual(result["header"]["service_count"], 13)
        self.assertEqual(result["regions"]["kernel"]["paragraphs"], 64)
        self.assertEqual(result["regions"]["sysvars"]["start_segment"], 0x0340)
        self.assertEqual(result["regions"]["com_arena"]["paragraphs"], 0)

    def test_rejects_bad_magic(self):
        image = make_image()
        image[2:10] = b"NOPE!!!!"
        with self.assertRaisesRegex(ValueError, "magic"):
            inspect_kernel(image)

    def test_rejects_bad_service_count(self):
        image = make_image()
        struct.pack_into("<H", image, 14, 12)
        with self.assertRaisesRegex(ValueError, "service count"):
            inspect_kernel(image)

    def test_rejects_truncated_header_and_table(self):
        with self.assertRaisesRegex(ValueError, "truncated kernel header"):
            inspect_kernel(b"CIUKIDOS")
        image = make_image()
        truncated = image[:140]
        struct.pack_into("<H", truncated, 20, len(truncated))
        with self.assertRaisesRegex(ValueError, "truncated RTSV service table"):
            inspect_kernel(truncated)

    def test_rejects_bad_handler_pointers(self):
        image = make_image()
        struct.pack_into("<H", image, 39 + 3 * 8 + 4, 1024)
        with self.assertRaisesRegex(ValueError, "handler offset out of bounds"):
            inspect_kernel(image)
        image = make_image()
        struct.pack_into("<H", image, 39 + 3 * 8 + 4, 100)
        with self.assertRaisesRegex(ValueError, "handler offset out of bounds"):
            inspect_kernel(image)

    def test_rejects_overlapping_regions(self):
        image = make_image()
        cmly = image.find(b"CMLY")
        # Make META begin inside FAT while preserving the record structure.
        struct.pack_into("<H", image, cmly + 12 + 4 * 8 + 2, 0x0500)
        with self.assertRaisesRegex(ValueError, "META must immediately follow EXEC|overlapping"):
            inspect_kernel(image)

    def test_rejects_images_over_maximum(self):
        with self.assertRaisesRegex(ValueError, "exceeds maximum size"):
            inspect_kernel(make_image(0xF001))

    def test_rejects_wrong_kernel_paragraph_count(self):
        image = make_image()
        cmly = image.find(b"CMLY")
        struct.pack_into("<H", image, cmly + 12 + 4, 63)
        with self.assertRaisesRegex(ValueError, "kernel CMLY paragraph count"):
            inspect_kernel(image)

    def test_reads_numeric_nasm_build_defines(self):
        source = "%define CIUKIDOS_ABI_VERSION 2\n%define CIUKIDOS_SERVICE_COUNT 13\n%define CIUKIDOS_KERNEL_MAX_BYTES 0xF000\n%define CIUKIDOS_RUNTIME_SEG 0x0300\n"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "abi.inc"
            path.write_text(source, encoding="ascii")
            self.assertEqual(
                read_build_parameters(path),
                {"ABI_VERSION": 2, "SERVICE_COUNT": 13, "KERNEL_MAX_BYTES": 0xF000, "RUNTIME_SEG": 0x0300},
            )

    def test_reads_repository_abi_include(self):
        params = read_build_parameters()
        self.assertEqual(params["ABI_VERSION"], 2)
        self.assertEqual(params["SERVICE_COUNT"], 13)
        self.assertEqual(params["KERNEL_MAX_BYTES"], 0xF000)
        self.assertEqual(params["RUNTIME_SEG"], 0x0300)


if __name__ == "__main__":
    unittest.main()
