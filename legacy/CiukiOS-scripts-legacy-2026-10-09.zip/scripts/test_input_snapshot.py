#!/usr/bin/env python3
"""Run the shipping diagnostic COM with observed ports and foreground DOS I/O."""
import json
from pathlib import Path
import struct
import subprocess
from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_INSN, UC_HOOK_INTR
from unicorn import x86_const as x
from inspect_input_snapshot import parse_input_snapshot
from inspect_dos_audio_timing import parse_audio_timing

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/tests/input-snapshot-r16'
OUT.mkdir(parents=True, exist_ok=True)
subprocess.run(['nasm','-f','bin','src/com/inputstate.asm','-o',str(OUT/'INPUTST.COM')],cwd=ROOT,check=True)
code = (OUT/'INPUTST.COM').read_bytes()
results = []
for stage, absent, ports in [
    (0,False,{0x21:0xA8,0xA1:0xEF,0x64:0}),
    (1,False,{0x21:0xAA,0xA1:0xFF,0x64:0x23}),
    (2,False,{0x21:0xA8,0xA1:0xEF,0x64:0x21}),
    (2,True,{0x21:0xA8,0xA1:0xEF,0x64:0}),
]:
    u = Uc(UC_ARCH_X86,UC_MODE_16)
    u.mem_map(0,0x100000)
    base = 0x20000
    u.mem_write(base+0x100,code)
    u.mem_write(base+0x80,bytes([2,32,48+stage,13]))
    u.mem_write(0x417,b'\x03\x12')
    u.mem_write(0x41A,struct.pack('<HH',0x1E,0x20))
    u.mem_write(0x480,struct.pack('<HH',0x1E,0x3E))
    u.mem_write(0x496,b'\x10')
    u.mem_write(0x46C,struct.pack('<I',0xAABBCCDD))
    for number in (9,0x74,0x16,0x33,0x15):
        u.mem_write(number*4,struct.pack('<HH',0x100+number,0xF000))
    for reg in (x.UC_X86_REG_CS,x.UC_X86_REG_DS,x.UC_X86_REG_ES):
        u.reg_write(reg,0x2000)
    u.reg_write(x.UC_X86_REG_EFLAGS,0x202)
    reads, calls, record, paths = [],[],[],[]
    def incoming(uc,port,size,data):
        assert size == 1 and port in ports, ('unexpected/consuming input',port)
        assert not (uc.reg_read(x.UC_X86_REG_EFLAGS)&0x200)
        reads.append(port);return ports[port]
    def outgoing(uc,port,size,value,data):
        raise AssertionError(f'diagnostic changed hardware port {port:04x}')
    def interrupt(uc,number,data):
        assert number == 0x21
        assert uc.reg_read(x.UC_X86_REG_EFLAGS)&0x200, 'DOS I/O under CLI'
        command = uc.reg_read(x.UC_X86_REG_AH);calls.append(command)
        address = (uc.reg_read(x.UC_X86_REG_DS)<<4)+uc.reg_read(x.UC_X86_REG_DX)
        flags = uc.reg_read(x.UC_X86_REG_EFLAGS)&~1
        if command == 0x3C:
            paths.append(bytes(uc.mem_read(address,32)).split(b'\0')[0].decode())
            uc.reg_write(x.UC_X86_REG_AX,5 if absent else 7)
            if absent: flags|=1
        elif command == 0x40:
            assert uc.reg_read(x.UC_X86_REG_BX)==7 and uc.reg_read(x.UC_X86_REG_CX)==64
            record.append(bytes(uc.mem_read(address,64)));uc.reg_write(x.UC_X86_REG_AX,64)
        elif command == 0x3E:
            assert uc.reg_read(x.UC_X86_REG_BX)==7
        elif command == 0x4C:
            assert uc.reg_read(x.UC_X86_REG_AL)==0;uc.emu_stop()
        else: raise AssertionError(command)
        uc.reg_write(x.UC_X86_REG_EFLAGS,flags)
    u.hook_add(UC_HOOK_INSN,incoming,None,1,0,x.UC_X86_INS_IN)
    u.hook_add(UC_HOOK_INSN,outgoing,None,1,0,x.UC_X86_INS_OUT)
    u.hook_add(UC_HOOK_INTR,interrupt)
    u.emu_start(base+0x100,base+0x100+len(code),count=10000)
    assert reads==[0x21,0xA1,0x64]
    assert paths==[f'\\SYSTEM\\INPUT{stage}.BIN']
    assert calls==([0x3C,0x4C] if absent else [0x3C,0x40,0x3E,0x4C])
    if record:
        parsed = parse_input_snapshot(record[0])
        assert parsed['stage']==stage and parsed['bios_ticks']==0xAABBCCDD
        assert parsed['keyboard_ring']==dict(head=0x1E,tail=0x20,start=0x1E,end=0x3E)
        assert parsed['controller_status']==ports[0x64]
        assert parsed['vectors']['mouse_api']==dict(segment=0xF000,offset=0x133)
        (OUT/f'INPUT{stage}.BIN').write_bytes(record[0])
    results.append(dict(stage=stage,disk_absent=absent,readonly_ports=reads,foreground_dos_calls=calls))

audio = b'CVAT'+struct.pack('<HH30I',0x100,128,*range(30))
assert parse_audio_timing(audio)['generation']==0
assert parse_audio_timing(audio)['total_render_cycles']==20|(21<<32)
for bad in (audio[:-1],b'BAD!'+audio[4:],audio[:4]+b'\x02\x00'+audio[6:]):
    try: parse_audio_timing(bad)
    except ValueError: pass
    else: raise AssertionError('invalid timing ABI accepted')
(OUT/'report.json').write_text(json.dumps(dict(passed=True,scope='actual COM/CPU fixture; no hardware certification',cases=results),indent=2)+'\n')
print(f'Input snapshots passed: {OUT}/report.json')
