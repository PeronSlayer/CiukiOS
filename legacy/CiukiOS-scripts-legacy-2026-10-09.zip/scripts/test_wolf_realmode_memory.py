#!/usr/bin/env python3
"""Execute original Wolf MZ startup/MM_Startup with actual kernel AH4A.

Uses physical R14 FREE/MAX in a single controlled hole; later game managers
are not executed. BIOS clock/equipment are fixture boundaries, not T23 emulation.
"""
from pathlib import Path
import struct,sys,hashlib,json,tempfile,argparse
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from test_kernel_f149_arena import BASE,SEG,SHELL,TOP,Machine,assemble
from test_vmfork_mz_memory import MzMachine
from test_vmfork_pinned_ancestors import free_memory
from test_launch_trace_com import compile_com
from unicorn import x86_const as x

class WolfMachine(MzMachine):
    def __init__(self,kernel,labels,exe,reserve):
        self.exe=exe;self.expected_entry=None;self.disk_reads=[];self.calls=[]
        self.game_active=False;self.game_stop=None
        Machine.__init__(self,kernel,labels,SHELL)
        rootsize=TOP-SHELL-34558-1
        self.psp(SHELL,rootsize,SHELL)
        self.put('dos_exec_identity_psp',SHELL);self.put('current_psp_seg',SHELL)
        self.put('dos_mem_psp_mcb_end',SHELL+rootsize)
        self.put('dos_mem_block_count',0,1);self.call('int21_mem_rebuild_chain')
        assert free_memory(self.chain())==dict(total=34558,largest=34558)
        self.reservations=[]
        for name,size in reserve:
            p,carry=self.call('int21_handler',ax=0x4800,bx=size,interrupt=True)
            assert not carry
            self.reservations.append(dict(name=name,size=size,segment=p))
        self.put('dos_exec_parent_identity_psp',SHELL)
        self.put('dos_indos_flag',1,1);self.put('current_mz_context_slot',1)
        self.put('runtime_status_flags',1);self.put('runtime_table_seg',SEG)
        self.put('runtime_table_off',labels['runtime_service_table'])
        self.put('search_found_size_lo',len(exe)&65535);self.put('search_found_size_hi',len(exe)>>16)
        for n in ('int21_exec_select_mz_region','int21_exec_load_mz'):
            a,c=self.call(n);assert not c,(n,a,self.value('tmp_exec_mz_fail_stage'))
        h=struct.unpack_from('<14H',exe)
        self.expected_entry=(self.value('current_load_seg')+h[4]+h[11])*16+h[10]
        self.call('int21_exec_run_mz')
        self.pspseg=self.value('mz_psp_seg')
        self.module=self.u.reg_read(x.UC_X86_REG_CS)
        self.initial=self.chain()[self.pspseg]['size']
        self.expected_entry=None;self.stop_at=0
        self.game_active=True
        # Original Turbo startup environment parser requires a double NUL.
        env=int.from_bytes(self.u.mem_read(self.pspseg*16+0x2c,2),'little')
        self.u.mem_write(env*16,b'\0\0\1\0C:\\APPS\\WOLF3D\\WOLF3D.EXE\0')
    def stop(self,u,address,size,data):
        if self.game_active:
            if address in getattr(self,'threshold_points',{}):
                self.threshold_branch=self.threshold_points[address];u.emu_stop();return
            if address==self.game_stop:
                u.emu_stop();return
        if address==BASE+self.labels['int21_exec_load_to_es']:
            length=self.value('search_found_size_lo')+(self.value('search_found_size_hi')<<16)
            assert length<=len(self.exe)
            u.mem_write(u.reg_read(x.UC_X86_REG_ES)*16+u.reg_read(x.UC_X86_REG_DI),self.exe[:length])
            u.reg_write(x.UC_X86_REG_AX,0)
            u.reg_write(x.UC_X86_REG_EFLAGS,u.reg_read(x.UC_X86_REG_EFLAGS)&~1)
            self.near_return(u);return
        return MzMachine.stop(self,u,address,size,data)
    def interrupt(self,u,num,data):
        if not self.game_active:return Machine.interrupt(self,u,num,data)
        if num==0x1a:
            u.reg_write(x.UC_X86_REG_AX,0);u.reg_write(x.UC_X86_REG_CX,0);u.reg_write(x.UC_X86_REG_DX,100);return
        if num==0x11:u.reg_write(x.UC_X86_REG_AX,0);return
        if num==0x10:
            ah=u.reg_read(x.UC_X86_REG_AX)>>8
            assert ah in (0x0f,3,0x12,8),hex(ah)
            if ah==0x0f:u.reg_write(x.UC_X86_REG_AX,0x5003);u.reg_write(x.UC_X86_REG_BX,0)
            if ah==3:u.reg_write(x.UC_X86_REG_DX,0);u.reg_write(x.UC_X86_REG_CX,0x607)
            if ah==0x12:u.reg_write(x.UC_X86_REG_BX,3);u.reg_write(x.UC_X86_REG_CX,9)
            if ah==8:u.reg_write(x.UC_X86_REG_AX,0x720)
            return
        if num!=0x21:
            assert num in range(0x34,0x3f),hex(num)
            ip,cs=struct.unpack('<HH',u.mem_read(num*4,4));assert cs!=0,(num,ip,cs)
            self.cpu_interrupt(u,cs,ip);return
        ax=u.reg_read(x.UC_X86_REG_AX)
        self.calls.append(dict(ax=ax,bx=u.reg_read(x.UC_X86_REG_BX),es=u.reg_read(x.UC_X86_REG_ES),cs=u.reg_read(x.UC_X86_REG_CS),ip=u.reg_read(x.UC_X86_REG_IP)))
        assert ax>>8 in (0x30,0x35,0x25,0x4a,0x48,0x49,0x58,0x67,0x44),hex(ax)
        self.cpu_interrupt(u,SEG,self.labels['int21_handler'])
    def cpu_interrupt(self,u,cs,ip):
        flags=u.reg_read(x.UC_X86_REG_EFLAGS);sp=(u.reg_read(x.UC_X86_REG_SP)-6)&65535
        u.mem_write(u.reg_read(x.UC_X86_REG_SS)*16+sp,struct.pack('<HHH',u.reg_read(x.UC_X86_REG_IP),u.reg_read(x.UC_X86_REG_CS),flags&65535))
        u.reg_write(x.UC_X86_REG_SP,sp);u.reg_write(x.UC_X86_REG_EFLAGS,flags&~0x300)
        u.reg_write(x.UC_X86_REG_CS,cs);u.reg_write(x.UC_X86_REG_IP,ip)
    def run_startup(self):
        self.game_stop=self.module*16+(0x88d2-0x2c00)
        self.u.emu_start(self.module*16,0xfffff,count=300000)
        assert self.u.reg_read(x.UC_X86_REG_CS)*16+self.u.reg_read(x.UC_X86_REG_IP)==self.game_stop,'startup did not reach main'
        self.after_startup=free_memory(self.chain());self.startup_size=self.chain()[self.pspseg]['size']
        self.ds=self.u.reg_read(x.UC_X86_REG_DS)
        # Main hasn't called other managers. Execute actual MM_Startup directly;
        # retain original DS/stack with a controlled far return sentinel.
        ss=self.u.reg_read(x.UC_X86_REG_SS);sp=(self.u.reg_read(x.UC_X86_REG_SP)-4)&65535
        self.u.mem_write(ss*16+sp,struct.pack('<HH',0x80,self.pspseg))
        self.u.reg_write(x.UC_X86_REG_SP,sp)
        self.u.reg_write(x.UC_X86_REG_CS,self.module+0x180b);self.u.reg_write(x.UC_X86_REG_IP,0x2a0)
        self.game_stop=self.pspseg*16+0x80
        self.u.emu_start((self.module+0x180b)*16+0x2a0,0xfffff,count=500000)
        assert self.u.reg_read(x.UC_X86_REG_CS)*16+self.u.reg_read(x.UC_X86_REG_IP)==self.game_stop,'MM startup did not return'
        mm=struct.unpack('<6I',self.u.mem_read(self.ds*16+0x9594,24))
        self.game_stop=None
        self.threshold_points={self.module*16+0x83c1-0x2c00:'insufficient_memory',self.module*16+0x8402-0x2c00:'continue'}
        self.u.reg_write(x.UC_X86_REG_CS,self.module+0x453)
        self.u.reg_write(x.UC_X86_REG_IP,0x83b0-0x7130)
        self.u.emu_start(self.module*16+0x83b0-0x2c00,0xfffff,count=100)
        assert self.threshold_branch==('continue' if mm[4]>=235000 else 'insufficient_memory')
        return dict(reservations=self.reservations,mz_initial_size=self.initial,startup_size=self.startup_size,
                    after_startup=self.after_startup,nearheap=mm[0],farheap=mm[1],mainmem=mm[4],
                    all_mminfo=mm,original_initgame_branch=self.threshold_branch,after_mm=free_memory(self.chain()),calls=self.calls)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wolf-exe',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    exe=args.wolf_exe.read_bytes()
    expected='50d3e0a424279b6a1ea8a184f695cc226afcf1fb0a9409040cf0261ec4c56c31'
    assert hashlib.sha256(exe).hexdigest()==expected,'unsupported original Wolf binary'
    _,dpmi_symbols=compile_com(args.output,'dpmirun')
    dpmi_paras=(dpmi_symbols['image_end']+15)//16
    # The declared shortcut has 16 extra bytes. Its actual assembled size is
    # checked separately by test_dpmirun_mode and read back here.
    import subprocess
    shortcut=args.output/'WOLF3D.COM'
    subprocess.run(['nasm','-f','bin','-DGAME_KIND=2','src/com/testgame_launch.asm','-o',str(shortcut)],cwd=ROOT,check=True)
    shortcut_paras=(shortcut.stat().st_size+0x100+15)//16
    with tempfile.TemporaryDirectory(prefix='ciukios-wolf-mem-') as td:
        kernel,labels=assemble(Path(td))
        old=[('R14 DPMIRUN',340),('HDPMI16',160),('HDPMITLB',512),('workspace',32),('R14 shortcut',70)]
        declared=[('current assembled DPMIRUN',dpmi_paras),('current declared shortcut',shortcut_paras)]
        rows=[WolfMachine(kernel,labels,exe,r).run_startup() for r in ([],old,declared)]
    assert rows[0]['original_initgame_branch']=='continue'
    assert rows[1]['original_initgame_branch']=='insufficient_memory'
    assert rows[2]['original_initgame_branch']=='continue'
    result=dict(passed=True,hardware_qualified=False,wolf_sha256=expected,
                kernel_sha256=hashlib.sha256(kernel).hexdigest(),physical_r14_free_paras=34558,
                physical_r14_largest_paras=34558,current_dpmirun_paras=dpmi_paras,
                current_shortcut_paras=shortcut_paras,cases=rows,
                limitations=[
                    'Physical R14 FREE/MAX reproduced in one synthetic hole; complete physical topology not captured.',
                    'Host retained GROUP16/TLB/workspace reservations are measured/source-derived controlled allocations, not a full HDPMI EXEC replay.',
                    'Actual original MZ entry, Turbo C startup, MM_Startup/coreleft/farcoreleft/farmalloc, and InitGame memory threshold execute.',
                    'Actual unchanged full-kernel DOS allocation/resize/vector/IOCTL services execute; file loading and BIOS equipment/video/clock are bounded boundaries.',
                    'Later game managers and gameplay are not emulated.'])
    (args.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Original Wolf memory: negative/positive CPU controls PASS; main heaps',*[r['mainmem'] for r in rows])
if __name__=='__main__':main()
