#!/usr/bin/env python3
"""Check wallpaper file validation and non-destructive pack generation."""
import json
import struct
import subprocess
import tempfile
from pathlib import Path

from PIL import Image

from build_wallpapers import (build, catalog_bytes, convert, convert_photo, discover,
                             read_catalog, select_photos, PHOTO_NAMES)


def main():
    checks = []
    with tempfile.TemporaryDirectory(prefix='ciukios-wallpaper-') as temp:
        root = Path(temp)
        inputs = root/'inputs'; inputs.mkdir()
        source = Image.new('RGB',(17,19))
        source.putdata([((x%4)*50,(y%4)*50,90) for y in range(19) for x in range(17)])
        source.save(inputs/'Pattern.PNG')
        source.save(inputs/'Other.BmP',format='BMP')
        found = discover(inputs)
        assert len(found) == 2
        for item in found:
            payload, dimensions = convert(item)
            assert dimensions == (17,19)
            pal = payload[16:784]
            pixels = b''.join(pal[i*3:i*3+3] for i in payload[784:])
            assert pixels == source.tobytes()
        checks.append('case-insensitive PNG/BMP conversion is pixel-exact')
        output = root/'output'
        build(output, found, personal=True)
        records = read_catalog((output/'WALLS.DAT').read_bytes())
        assert len(records) == 2
        checks.append('catalog roundtrip')
        before = {p.name:p.read_bytes() for p in output.iterdir()}
        oversized = root/'oversized.png'; Image.new('RGB',(257,1)).save(oversized)
        transparent = root/'transparent.png'; Image.new('RGBA',(3,3),(1,2,3,0)).save(transparent)
        colors = root/'colors.png'; im=Image.new('RGB',(256,2));im.putdata([(i%256,i//256,1) for i in range(512)]);im.save(colors)
        corrupt = root/'corrupt.bmp';corrupt.write_bytes(b'not an image')
        for bad in (oversized,transparent,colors,corrupt):
            try: build(output, found+[bad], personal=True)
            except (ValueError,OSError): pass
            else: raise AssertionError(f'Invalid input accepted: {bad}')
            assert {p.name:p.read_bytes() for p in output.iterdir()} == before
        checks.append('invalid input leaves existing catalog and every tile unchanged')
        large = [(f'WALL{i:02}.CWP',b'Tile'.ljust(31,b'\0')) for i in range(1,100)]
        assert len(read_catalog(catalog_bytes(large))) == 99
        assert len(catalog_bytes(large)) == 4608
        try: catalog_bytes(large+[('WALL100.CWP',b'Tile'.ljust(31,b'\0'))])
        except ValueError: pass
        else: raise AssertionError('100th tile accepted')
        checks.append('99-slot bound and sector-sized catalog')
        pack = root/'pack'
        command=['python3','scripts/add_wallpapers.py','--after','11','--output',str(pack),str(found[0])]
        subprocess.run(command,check=True,capture_output=True)
        assert (pack/'WALL12.CWP').exists() and not (pack/'WALLS.DAT').exists()
        existing=(pack/'WALL12.CWP').read_bytes()
        assert subprocess.run(command,capture_output=True).returncode != 0
        assert (pack/'WALL12.CWP').read_bytes() == existing
        checks.append('append-only pack refuses overwrite and never replaces catalog')
        photos = root / 'photos'; photos.mkdir()
        originals = []
        for name in PHOTO_NAMES:
            path = photos / name
            Image.new('RGB', (17, 11), (12, 34, 56)).save(path)
            originals.append(path)
        selected, adaptive = select_photos(photos)
        assert selected == originals and not adaptive
        manifest = build(output, found, personal=True, photo_sources=selected)
        assert (output / 'WALL.CFG').read_bytes() == bytes([3, 1])
        assert manifest['default_selection']['position'] == 'Fit'
        adaptive_dir = photos / 'adaptive'; adaptive_dir.mkdir()
        Image.new('RGB', (15, 13), (98, 76, 54)).save(adaptive_dir / PHOTO_NAMES[0])
        try: select_photos(photos)
        except ValueError: pass
        else: raise AssertionError('Partial adaptive set accepted')
        for name in PHOTO_NAMES[1:]:
            Image.new('RGB', (15, 13), (98, 76, 54)).save(adaptive_dir / name)
        selected, adaptive = select_photos(photos)
        manifest = build(output, found, personal=True, photo_sources=selected, adaptive_photos=adaptive)
        assert (output / 'WALL.CFG').read_bytes() == bytes([3, 0])
        assert manifest['default_selection']['position'] == 'Fill'
        assert [record[1].split(b'\0', 1)[0] for record in read_catalog(
            (output / 'WALLS.DAT').read_bytes())][-3:] == [b'Ciuk1', b'Ciuk2', b'Ciuk3']
        for entry in manifest['wallpapers'][-3:]:
            assert entry['original_source_sha256'] and entry['source_sha256']
        for dimensions in [(1, 1), (15, 13), (1536, 1152), (2048, 1536)]:
            path = root / 'photo.png'
            Image.new('RGB', dimensions, (123, 45, 67)).save(path)
            payload, actual, size = convert_photo(path)
            magic, w, h, stride, fmt, flags, length = struct.unpack_from('<4sHHHBBI', payload)
            assert actual == dimensions and magic == b'CWP2' and fmt == 1 and flags == 0
            assert stride == (w * 3 + 1) & ~1 and size == length == stride * h
            assert len(payload) == 16 + length
            for row in range(h):
                pixels = payload[16 + row * stride:16 + (row + 1) * stride]
                assert pixels[:w * 3] == bytes((123, 45, 67)) * w
                assert pixels[w * 3:] == (b'\0' if w & 1 else b'')
        for dimensions in [(2049, 1), (1, 1537)]:
            path = root / 'photo.png'; Image.new('RGB', dimensions).save(path)
            try: convert_photo(path)
            except ValueError: pass
            else: raise AssertionError(f'Out-of-bounds photo accepted: {dimensions}')
        checks.append('adaptive all-or-none selection preserves three names, hashes and Fill/Fit defaults')
        checks.append('CWP2 boundary dimensions and odd row padding retain every RGB sample')
    print(json.dumps({'status':'pass','checks':checks},indent=2))


if __name__ == '__main__': main()
