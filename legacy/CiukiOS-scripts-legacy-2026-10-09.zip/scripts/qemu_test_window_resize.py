#!/usr/bin/env python3
"""Full-image resize/cursor integration gate; real input, read-only observations.

Run after build-full, under the repository's bounded systemd scope. The active
test budget is 90 seconds after boot; this is QEMU evidence, not T23 validation.
"""
import argparse
import hashlib
import json
import math
import shutil
import struct
import subprocess
import time
from pathlib import Path

import numpy as np
from PIL import Image

from qemu_test_installed_hdd import FAT16
from qemu_test_native_utilities import Utilities
from qemu_test_native_windows import WindowVM

ROOT = Path(__file__).resolve().parents[1]
FILES = 8


class ResizeGate:
    def __init__(self, vm, ui, report, resource, seconds):
        self.vm, self.ui, self.report, self.resource = vm, ui, report, resource
        self.deadline = time.monotonic() + seconds

    def wait(self, predicate, description, seconds=8):
        remaining = self.deadline - time.monotonic()
        assert remaining > 0, 'active resize gate exceeded its time budget'
        self.ui.until(predicate, description, min(seconds, remaining))

    def quiet(self):
        self.wait(lambda: self.ui.b('ui_composing') == 0 and
                  self.ui.b('ui_pointer_visible') == 1, 'completed composition and visible pointer')

    def geometry(self, slot):
        self.ui.refresh()
        if slot == 0:
            return tuple(self.ui.w(name) for name in ('ui_wx', 'ui_wy', 'ui_ww', 'ui_wh'))
        return tuple(self.ui.w(name, slot) for name in
                     ('ui_window_x', 'ui_window_y', 'ui_window_width', 'ui_window_height'))

    def position(self, x, y, exact=False):
        # Read the hotspot independently of its seven possible cursor masks.
        # Every movement is still an actual relative PS/2 event through QEMU.
        for attempt in range(32):
            self.ui.refresh()
            px, py = self.ui.w('ui_mouse_x'), self.ui.w('ui_mouse_y')
            tolerance = 0 if exact else 1
            if abs(px - x) <= tolerance and abs(py - y) <= tolerance:
                return px, py
            speed = max(1, self.ui.b('app_set_mouse'))
            dx = max(-127, min(127, math.ceil(abs(x - px) / speed) * (1 if x > px else -1))) if x != px else 0
            dy = max(-127, min(127, math.ceil(abs(y - py) / speed) * (1 if y > py else -1))) if y != py else 0
            self.vm.hmp(f'mouse_move {dx} {dy} 0')
            self.wait(lambda: (self.ui.w('ui_mouse_x'), self.ui.w('ui_mouse_y')) != (px, py),
                      'real pointer motion')
        raise AssertionError(f'pointer did not reach {(x, y)}')

    def button(self, down):
        self.vm.hmp('mouse_button ' + ('1' if down else '0'))
        self.wait(lambda: bool(self.ui.w('ui_mouse_buttons') & 1) == down and
                  bool(self.ui.b('ui_previous_button')) == down,
                  'left button transition')

    def click(self, x, y):
        self.position(x, y)
        self.button(True)
        time.sleep(.08)
        self.button(False)
        self.quiet()

    def event(self, name, **data):
        self.report['checks'].append({'name': name, **data})
        print('[resize] PASS ' + name, flush=True)

    def shot(self, name):
        self.quiet()
        path = self.vm.shot(name)
        with Image.open(path) as image:
            frame = np.array(image)
            image.save(path.with_suffix('.png'))
        return frame

    def hover(self, point, edge, cursor, target):
        self.position(*point)
        self.wait(lambda: self.ui.b('ui_resize_edge') == edge and
                  self.ui.b('ui_cursor_type') == cursor and
                  self.ui.b('ui_hit_target') == target, 'border ownership and cursor')
        scheme = self.ui.b('ui_cursor_scheme')
        start = 28 + scheme * 478 + cursor * 66
        actual = self.ui.ram[self.ui.offset('ui_pointer_black'):self.ui.offset('ui_pointer_black') + 64]
        assert actual == self.resource[start:start + 64], 'active cursor mask differs from the built resource'

    def cancel(self, before):
        self.vm.key('esc')
        self.wait(lambda: self.ui.b('ui_dragging') == 0, 'Escape releases resize capture')
        self.button(False)
        assert self.geometry(FILES) == before, ('Escape geometry', before, self.geometry(FILES))
        self.quiet()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, default=Path('build/full/ciukios-full.img'))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=90)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    shell, listing, disk = out / 'SHELL.COM', out / 'SHELL.lst', out / 'disk.img'
    subprocess.run(['nasm', '-f', 'bin', 'src/com/shell.asm', '-o', str(shell), '-l', str(listing)],
                   cwd=ROOT, check=True)
    source = FAT16(args.image)
    assert source.read('SYSTEM/SHELL.COM') == shell.read_bytes(), 'image/source SHELL mismatch'
    resource = source.read('SYSTEM/UI/CURSORS.DAT')
    assert struct.unpack_from('<8sHH', resource) == (b'CIUKCUR2', 3, 478)
    shutil.copyfile(args.image, disk)
    report = {'passed': False, 'physical_hardware_qualified': False, 'checks': [],
              'input': 'QEMU keyboard and relative mouse only; guest RAM observation is read-only',
              'source_image_sha256': hashlib.sha256(args.image.read_bytes()).hexdigest(),
              'shell_sha256': hashlib.sha256(shell.read_bytes()).hexdigest()}
    vm = WindowVM(disk, out, 'std', memory=512, palette='platinum')
    try:
        vm.ready()
        ui = Utilities(vm, shell.read_bytes(), listing)
        gate = ResizeGate(vm, ui, report, resource, args.seconds)
        start = time.monotonic()
        vm.key('meta_l-d')
        gate.wait(lambda: not ui.b('ui_window_visible') and
                  all(ui.b('ui_window_flags', i) != 1 for i in range(1, 21)), 'bare desktop')
        gate.wait(lambda: ui.b('wp_kind') == 2 and ui.b('ui_cursor_loaded') == 1,
                  'photo wallpaper and complete cursor theme', 20)
        def wallpaper_painted():
            serial = subprocess.check_output([
                'scripts/serial_log_normalize.py', str(vm.serial)]).decode('cp437', 'replace')
            ready = serial.rfind('[WALLP] ready ')
            return ready >= 0 and serial.find('[DESKTOP] PAINT', ready) >= 0
        gate.wait(wallpaper_painted, 'finished desktop paint after wallpaper preparation', 25)
        width, height = ui.w('ui_width'), ui.w('ui_height')
        report['resolution'] = [width, height]
        park = (14, height - 48)
        gate.position(*park)
        baseline = gate.shot('desktop-before')
        vm.key('meta_l-e')
        gate.wait(lambda: ui.b('ui_active_window') == FILES and ui.b('ui_window_flags', FILES) == 1,
                  'Files opens')
        before = gate.geometry(FILES)
        x, y, w, h = before
        cases = [((x + 1, y + h // 2), 1, 3, (24, 0)),
                 ((x + w - 2, y + h // 2), 2, 3, (-24, 0)),
                 ((x + w // 2, y + 1), 4, 4, (0, 18)),
                 ((x + w // 2, y + h - 2), 8, 4, (0, -18)),
                 ((x + 1, y + 1), 5, 5, (24, 18)),
                 ((x + w - 2, y + 1), 6, 6, (-24, 18)),
                 ((x + 1, y + h - 2), 9, 6, (24, -18)),
                 ((x + w - 2, y + h - 2), 10, 5, (-24, -18))]
        for point, edge, cursor, delta in cases:
            gate.hover(point, edge, cursor, FILES + 1)
            gate.button(True)
            gate.wait(lambda: ui.b('ui_dragging') == 4 and ui.b('ui_resize_drag_edge') == edge,
                      'sizing capture')
            gate.position(point[0] + delta[0], point[1] + delta[1])
            gate.wait(lambda: tuple(ui.w(name, FILES) for name in
                      ('ui_window_x', 'ui_window_y', 'ui_window_width', 'ui_window_height')) != before,
                      'resized geometry')
            after = gate.geometry(FILES)
            assert ui.b('ui_cursor_type') == cursor, 'capture changed sizing direction'
            if edge & 1:
                assert after[0] + after[2] == x + w and after[2] < w
            elif edge & 2:
                assert after[0] == x and after[2] < w
            else:
                assert (after[0], after[2]) == (x, w)
            if edge & 4:
                assert after[1] + after[3] == y + h and after[3] < h
            elif edge & 8:
                assert after[1] == y and after[3] < h
            else:
                assert (after[1], after[3]) == (y, h)
            gate.shot(f'edge-{edge:02d}')
            gate.cancel(before)
            gate.event(f'edge {edge}: cursor, drag, stationary opposite edge and Escape', before=before, resized=after)

        # Minimum dimensions and actual work-area maximum through real drags.
        for label, target, expected in (
            ('minimum', (x + 80, y + 70), (320, 200)),
            ('work-area maximum', (width - 1, height - 1), (width - 8 - x, height - 37 - y))):
            gate.hover((x + w - 2, y + h - 2), 10, 5, FILES + 1)
            gate.button(True)
            gate.wait(lambda: ui.b('ui_dragging') == 4, 'corner capture')
            gate.position(*target, exact=label.startswith('work'))
            gate.wait(lambda: (ui.w('ui_window_width', FILES), ui.w('ui_window_height', FILES)) == expected,
                      label + ' dimensions')
            gate.shot(label.replace(' ', '-'))
            gate.cancel(before)
            gate.event(label + ' clamp', size=expected)

        gate.click(x + w - 42, y + 15)
        gate.wait(lambda: ui.w('app_saved_w', FILES) != 0, 'Files maximizes')
        mx, my, mw, mh = gate.geometry(FILES)
        gate.hover((mx + 1, my + mh // 2), 0, 0, FILES + 1)
        gate.click(mx + mw - 42, my + 15)
        gate.wait(lambda: ui.w('app_saved_w', FILES) == 0, 'Files restores')
        assert gate.geometry(FILES) == before
        gate.event('maximized frame exposes no sizing border and restores')

        # Put Programs behind Files with an exposed border inside its client.
        # F2 belongs to the active application (both Files and Desktop use it
        # for Rename). Ctrl+Esc is the shell's global Programs shortcut: its
        # ui_keyboard path bypasses app_key before returning action 1.
        vm.key('meta_l-d')
        gate.wait(lambda: not ui.b('ui_window_visible') and
                  all(ui.b('ui_window_flags', i) != 1 for i in range(1, 21)),
                  'desktop owns keyboard before Programs shortcut')
        vm.key('ctrl-esc')
        gate.wait(lambda: ui.b('ui_window_visible') == 1 and ui.b('ui_active_window') == 0,
                  'Programs opens')
        px, py, pw, ph = gate.geometry(0)
        gate.position(px + 90, py + 15)
        gate.button(True)
        gate.wait(lambda: ui.b('ui_dragging') == 1, 'Programs title drag')
        gate.position(x + 40 + 90, y + 40 + 15)
        gate.button(False)
        gate.wait(lambda: ui.b('ui_dragging') == 0, 'Programs title releases')
        program_before = gate.geometry(0)
        vm.key('meta_l-e')
        gate.wait(lambda: ui.b('ui_active_window') == FILES, 'Files raised over Programs')
        point = (program_before[0] + 1, program_before[1] + 65)
        assert x + 10 < point[0] < x + w - 20 and y + 35 < point[1] < y + h - 20
        gate.position(*point)
        gate.wait(lambda: ui.b('ui_resize_edge') == 0 and ui.b('ui_hit_target') == FILES + 1,
                  'covered Programs border belongs to Files')
        assert gate.geometry(0) == program_before
        gate.shot('overlap-ownership')
        gate.event('covered background sizing border cannot steal pointer ownership')

        vm.key('meta_l-r')
        gate.wait(lambda: ui.b('ui_active_window') == 1 and ui.b('ui_window_flags', 1) == 1,
                  'fixed Run dialog opens')
        rx, ry, rw, rh = run_before = gate.geometry(1)
        assert ui.b('app_win_style', 1) & 1
        gate.hover((rx + rw - 2, ry + rh // 2), 0, 0, 2)
        gate.button(True)
        gate.position(rx + rw + 20, ry + rh // 2 + 12)
        gate.button(False)
        assert gate.geometry(1) == run_before and ui.b('ui_dragging') == 0
        vm.key('esc')
        gate.wait(lambda: ui.b('ui_window_flags', 1) == 0, 'Run closes')
        gate.event('fixed Run dialog refuses border resizing')

        vm.key('meta_l-d')
        gate.wait(lambda: not ui.b('ui_window_visible') and
                  all(ui.b('ui_window_flags', i) != 1 for i in range(1, 21)), 'all windows hidden')
        gate.position(*park)
        final = gate.shot('desktop-after')
        stable = np.ones(final.shape[:2], dtype=bool)
        stable[:29, :] = False
        stable[height - 32:, :] = False
        # A 2x mouse rate can leave the hotspot one pixel either side of the
        # requested park point after screen-edge saturation changes parity.
        stable[max(29, park[1] - 16):park[1] + 24, max(0, park[0] - 16):park[0] + 32] = False
        changed = int(np.count_nonzero(np.any(final != baseline, axis=2) & stable))
        assert changed == 0, f'{changed} desktop pixels failed to restore after window operations'
        gate.event('desktop pixels restore exactly after hiding all exercised windows',
                   changed_pixels=changed, checked_pixels=int(stable.sum()),
                   excluded='top/status bars and parked software cursor only')
        report['elapsed_after_boot_seconds'] = time.monotonic() - start
        report['passed'] = True
    except Exception as error:
        report['error'] = str(error)
        try:
            vm.shot('failure')
        except Exception:
            pass
        raise
    finally:
        report['qemu_command'] = vm.process.args
        (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        vm.close()


if __name__ == '__main__':
    main()
