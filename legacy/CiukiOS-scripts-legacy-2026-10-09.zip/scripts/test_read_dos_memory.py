#!/usr/bin/env python3
"""Focused decoder fixture for the versioned DOSMEM capture."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from read_dos_memory import parse_record  # noqa: E402


FIXTURE = ROOT / "scripts/fixtures/dosmem-v1.hex"


def main() -> None:
    record = bytes.fromhex(FIXTURE.read_text().strip())
    report = parse_record(record)
    assert report["complete"]
    assert report["result_flags"]["xms_query_ok"]
    assert report["xms"]["largest_free_kib"] == 126_976
    assert report["xms"]["total_free_kib"] == 520_192
    assert report["result_flags"]["vcpi_query_ok"]
    assert report["vcpi"]["free_4k_pages"] == 30_720
    assert report["firmware_ceiling"]["usable_kib_above_1m"] is None
    for bad in (record[:-1], record + b"\0", record[:4] + b"\x02" + record[5:]):
        try:
            parse_record(bad)
        except ValueError:
            continue
        raise AssertionError("invalid DOSMEM fixture was accepted")
    print("[dosmem] PASS versioned 32-byte XMS/VCPI fixture and invalid records")


if __name__ == "__main__":
    main()
