#!/usr/bin/env python3
"""Execute child compaction and real EXEC lookup/load using immutable FAT sectors.

This is a software CPU fixture, not T23 firmware emulation. Only INT 13h is
modeled; the actual assembled kernel resolves directories/FAT and loads COM.
The arena includes the two captured pinned allocations but is not represented
as a complete dump of physical RAM (which the disk capture does not contain).
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import tempfile

from unicorn import x86_const as x

from test_kernel_f149_arena import BASE, SEG, SHELL, assemble
from test_vmfork_pinned_ancestors import assemble_vmfork, free_memory
from test_vmfork_low_compaction import CompactionMachine, AUX, LFN


class FilesystemMachine(CompactionMachine):
    def __init__(self, *args, disk):
        self.disk, self.reads, self.loaded = disk, [], False
        self.exec_pointer = None
        super().__init__(*args)
        self.put('runtime_status_flags', 1)
        self.put('runtime_table_seg', SEG)
        self.put('runtime_table_off', self.labels['runtime_service_table'])
        self.put('boot_drive', 0x80, 1)
        self.put('dos_default_drive', 2, 1)
        self.put('cwd_cluster', 0)
        self.u.mem_write(BASE + self.labels['cwd_buf'], b'\0')
        entries = [(AUX, 0x4F, AUX, 7), (LFN, 0x451, LFN, 7),
                   (0x31CF, 0x1000, SHELL, 1),
                   (self.parent, 0x80, self.parent, 1),
                   (0x7519, 0xFFA, SHELL, 1)]
        self.put('dos_mem_block_count', len(entries), 1)
        self.u.mem_write(BASE + self.labels['dos_mem_block_table'],
                         b''.join(struct.pack('<4H', *e) for e in entries))
        for segment, size, owner, _ in entries:
            self.mcb(segment, size, owner)
        self.vector(0xDD, 0x3FBA, 0x1030)
        self.vector(0xDA, 0x8232, 0x1F0)
        self.call('int21_mem_rebuild_chain')

    def stop(self, uc, address, size, data):
        if address == BASE + self.labels['int21_exec_run_com']:
            target = self.value('current_com_load_seg') * 16 + 0x100
            length = self.value('search_found_size_lo')
            self.loaded = bytes(uc.mem_read(target, length))
            self.stopped = 'loaded_com'
            uc.emu_stop()
            return
        super().stop(uc, address, size, data)

    def interrupt(self, uc, number, data):
        if number == 0x13:
            ax = uc.reg_read(x.UC_X86_REG_AX)
            assert ax == 0x4200, hex(ax)
            address = uc.reg_read(x.UC_X86_REG_DS) * 16 + uc.reg_read(x.UC_X86_REG_SI)
            dap = bytes(uc.mem_read(address, 16))
            size, reserved, count, off, seg, lba = struct.unpack('<BBHHHQ', dap)
            assert size == 16 and reserved == 0 and count == 1
            self.disk.seek(lba * 512)
            sector = self.disk.read(512)
            assert len(sector) == 512
            uc.mem_write(seg * 16 + off, sector)
            self.reads.append(dict(lba=lba, segment=seg, offset=off,
                                   prefix=sector[:16].hex()))
            uc.reg_write(x.UC_X86_REG_AX, 0)
            uc.reg_write(x.UC_X86_REG_EFLAGS, uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1)
            return
        if number == 0x21 and uc.reg_read(x.UC_X86_REG_AX) == 0x4B00:
            ds, es = uc.reg_read(x.UC_X86_REG_DS), uc.reg_read(x.UC_X86_REG_ES)
            dx, bx = uc.reg_read(x.UC_X86_REG_DX), uc.reg_read(x.UC_X86_REG_BX)
            path = bytes(uc.mem_read(ds * 16 + dx, 128)).split(b'\0')[0]
            self.exec_pointer = dict(ds=ds, es=es, cs=uc.reg_read(x.UC_X86_REG_CS),
                                     path=path.decode(), parameter_offset=bx)
            assert ds == es == uc.reg_read(x.UC_X86_REG_CS)
            flags = uc.reg_read(x.UC_X86_REG_EFLAGS)
            cs, ip = uc.reg_read(x.UC_X86_REG_CS), uc.reg_read(x.UC_X86_REG_IP)
            ss, sp = uc.reg_read(x.UC_X86_REG_SS), uc.reg_read(x.UC_X86_REG_SP)
            sp = (sp - 6) & 0xFFFF
            uc.mem_write(ss * 16 + sp, struct.pack('<HHH', ip, cs, flags & 0xFFFF))
            uc.reg_write(x.UC_X86_REG_SP, sp)
            uc.reg_write(x.UC_X86_REG_EFLAGS, flags & ~0x300)
            uc.reg_write(x.UC_X86_REG_CS, SEG)
            uc.reg_write(x.UC_X86_REG_IP, self.labels['int21_handler'])
            return
        super().interrupt(uc, number, data)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--image', type=Path, required=True)
    p.add_argument('--expected-com', type=Path, required=True)
    p.add_argument('--out-dir', type=Path)
    args = p.parse_args()
    with tempfile.TemporaryDirectory(prefix='ciukios-child-fs-') as temporary, args.image.open('rb') as disk:
        kernel, labels = assemble(Path(temporary))
        com, symbols = assemble_vmfork(Path(temporary), labels)
        m = FilesystemMachine(kernel, labels, com, symbols, disk=disk)
        r = m.relocated_run('prepare_compaction')
        assert not r['carry'], r
        r = m.relocated_run('compact_residents', stops=('child.again',))
        assert r['stop'] == 'child.again', r
        r = m.run('child.again', stops=('child.launch',))
        assert r['stop'] == 'child.launch', r
        free = free_memory(m.chain())
        assert m.chain()[0x31CF]['owner'] == m.chain()[0x7519]['owner'] == SHELL
        r = m.run('child.launch', stops=('child.exec_failed',))
        assert r['stop'] == 'loaded_com', (r, m.vm_value('trace_dos_ax'), m.reads)
        expected = args.expected_com.read_bytes()
        assert m.loaded == expected, (len(m.loaded), len(expected))
        report = dict(status='pass', actual_kernel_lookup_and_com_load=True,
                      firmware_emulated=False, complete_physical_arena=False,
                      target=m.exec_pointer, free_after_compaction=free,
                      pinned_allocations_retained=[0x31CF, 0x7519],
                      com_bytes=len(m.loaded), com_sha256=hashlib.sha256(m.loaded).hexdigest(),
                      reads=m.reads)
        if args.out_dir:
            args.out_dir.mkdir(parents=True, exist_ok=True)
            (args.out_dir/'report.json').write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
