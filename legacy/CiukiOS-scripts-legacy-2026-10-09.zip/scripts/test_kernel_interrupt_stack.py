#!/usr/bin/env python3
"""Exercise the production INT 21h stack gateway with real 16-bit code.

Run with: uv run --with unicorn==2.1.4 python scripts/test_kernel_interrupt_stack.py

NASM assembles the checked-in gateway include together with a small DOS-like
caller and dispatcher stub. Unicorn executes INT 21h, nested calls, the slot
limit, and IRET; this does not model a complete DOS kernel or BIOS.
"""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR
from unicorn.x86_const import *

ROOT = Path(__file__).resolve().parents[1]
INCLUDE = ROOT / "src/runtime/kernel_interrupt_stack.inc"
CODE_SEG = 0x1000
MEMORY_SIZE = 0x100000
CANARY = 0xCC
RESULT_FLAGS = 0x0647  # reserved bit, CF/PF/AF/ZF, IF, DF

INPUT_GPRS = {
    UC_X86_REG_EAX: 0x11000001,
    UC_X86_REG_EBX: 0x22000002,
    UC_X86_REG_ECX: 0x33000003,
    UC_X86_REG_EDX: 0x44000004,
    UC_X86_REG_ESI: 0x55000005,
    UC_X86_REG_EDI: 0x66000006,
    UC_X86_REG_EBP: 0x77000007,
}
RESULT_GPRS = {
    UC_X86_REG_EAX: 0xE1000001,
    UC_X86_REG_EBX: 0xE2000002,
    UC_X86_REG_ECX: 0xE3000003,
    UC_X86_REG_EDX: 0xE4000004,
    UC_X86_REG_ESI: 0xE5000005,
    UC_X86_REG_EDI: 0xE6000006,
    UC_X86_REG_EBP: 0xE7000007,
}
SEGMENTS = {
    UC_X86_REG_DS: 0x1111,
    UC_X86_REG_ES: 0x2222,
    UC_X86_REG_FS: 0x3333,
    UC_X86_REG_GS: 0x4444,
}


def assemble(output):
    asm = output / "kernel_interrupt_stack_fixture.asm"
    binary = output / "kernel_interrupt_stack_fixture.bin"
    listing = output / "kernel_interrupt_stack_fixture.lst"
    asm.write_text(f'''BITS 16
ORG 0
%define DOS_EXEC_STATE_FRAME_MAX 11
%define FIXTURE_RESULT_FLAGS 0x0647

fixture_call:
    int 0x21
fixture_return:
    nop

kernel_int21_vector:
    jmp kernel_int21_enter

; This stub deliberately performs nested software INTs while the outer
; dispatcher is active. Each level returns distinct GPR results.
int21_dispatch:
    inc byte [cs:dispatch_depth]
    mov al, [cs:dispatch_depth]
    cmp al, [cs:max_dispatch_depth]
    jbe .depth_recorded
    mov [cs:max_dispatch_depth], al
.depth_recorded:
    mov bx, [cs:kernel_int21_stack_depth]
    dec bx
    shl bx, 2
    mov ax, ss
    mov [cs:dispatch_stack_records + bx], ax
    mov ax, sp
    mov [cs:dispatch_stack_records + bx + 2], ax

    cmp word [cs:nest_remaining], 0
    je .return_values
    dec word [cs:nest_remaining]
    cmp byte [cs:dispatch_depth], 12
    jne .nested_call
    cmp byte [cs:capture_overflow], 0
    je .nested_call
    mov ax, ds
    mov [cs:overflow_pre_ds], ax
    mov ax, es
    mov [cs:overflow_pre_es], ax
    mov ax, fs
    mov [cs:overflow_pre_fs], ax
    mov ax, gs
    mov [cs:overflow_pre_gs], ax
    mov [cs:overflow_pre_eax], eax
    mov [cs:overflow_pre_ebx], ebx
    mov [cs:overflow_pre_ecx], ecx
    mov [cs:overflow_pre_edx], edx
    mov [cs:overflow_pre_esi], esi
    mov [cs:overflow_pre_edi], edi
    mov [cs:overflow_pre_ebp], ebp
.nested_call:
    int 0x21
    pushf
    pop word [cs:overflow_scratch_flags]
    mov [cs:overflow_scratch_ax], ax
    cmp byte [cs:dispatch_depth], 12
    jne .return_values
    cmp byte [cs:capture_overflow], 0
    je .return_values
    mov [cs:overflow_post_eax], eax
    mov [cs:overflow_post_ebx], ebx
    mov [cs:overflow_post_ecx], ecx
    mov [cs:overflow_post_edx], edx
    mov [cs:overflow_post_esi], esi
    mov [cs:overflow_post_edi], edi
    mov [cs:overflow_post_ebp], ebp
    mov ax, ds
    mov [cs:overflow_post_ds], ax
    mov ax, es
    mov [cs:overflow_post_es], ax
    mov ax, fs
    mov [cs:overflow_post_fs], ax
    mov ax, gs
    mov [cs:overflow_post_gs], ax
    mov ax, [cs:overflow_scratch_ax]
    mov [cs:overflow_ax], ax
    mov ax, [cs:overflow_scratch_flags]
    mov [cs:overflow_flags], ax

.return_values:
    mov bp, sp
    mov word [ss:bp + 4], FIXTURE_RESULT_FLAGS
    mov ax, 0xA101
    mov ds, ax
    mov ax, 0xA202
    mov es, ax
    mov eax, 0xE1000001
    mov ebx, 0xE2000002
    mov ecx, 0xE3000003
    mov edx, 0xE4000004
    mov esi, 0xE5000005
    mov edi, 0xE6000006
    mov ebp, 0xE7000007
    dec byte [cs:dispatch_depth]
    jmp kernel_int21_leave

dispatch_depth db 0
max_dispatch_depth db 0
capture_overflow db 0
nest_remaining dw 0
overflow_ax dw 0
overflow_flags dw 0
overflow_scratch_ax dw 0
overflow_scratch_flags dw 0
overflow_pre_eax dd 0
overflow_pre_ebx dd 0
overflow_pre_ecx dd 0
overflow_pre_edx dd 0
overflow_pre_esi dd 0
overflow_pre_edi dd 0
overflow_pre_ebp dd 0
overflow_pre_ds dw 0
overflow_pre_es dw 0
overflow_pre_fs dw 0
overflow_pre_gs dw 0
overflow_post_eax dd 0
overflow_post_ebx dd 0
overflow_post_ecx dd 0
overflow_post_edx dd 0
overflow_post_esi dd 0
overflow_post_edi dd 0
overflow_post_ebp dd 0
overflow_post_ds dw 0
overflow_post_es dw 0
overflow_post_fs dw 0
overflow_post_gs dw 0
dispatch_stack_records times 12 * 2 dw 0

%include "{INCLUDE.as_posix()}"
kernel_int21_test_end: db 0
''')
    subprocess.run(["nasm", "-f", "bin", "-o", str(binary), "-l", str(listing), str(asm)],
                   check=True, capture_output=True, text=True)
    return binary.read_bytes(), listing.read_text()


def symbol(listing, name):
    lines = listing.splitlines()
    for i, line in enumerate(lines):
        if re.search(r"\b" + re.escape(name) + r"(?=:|\s+(?:times\b|d[bwd]\b))", line):
            for instruction in lines[i:]:
                match = re.match(r"\s*\d+\s+([0-9A-F]{8})\s", instruction)
                if match:
                    return int(match[1], 16)
    raise AssertionError(f"missing assembled symbol: {name}")


def run_case(binary, listing, *, nesting, tight_stack=False, overflow=False):
    offsets = {name: symbol(listing, name) for name in (
        "fixture_call", "fixture_return", "kernel_int21_vector",
        "int21_dispatch", "dispatch_depth", "max_dispatch_depth",
        "capture_overflow", "nest_remaining", "overflow_ax",
        "overflow_flags", "overflow_scratch_ax", "overflow_scratch_flags",
        "overflow_pre_eax", "overflow_pre_ebx", "overflow_pre_ecx",
        "overflow_pre_edx", "overflow_pre_esi", "overflow_pre_edi",
        "overflow_pre_ebp", "overflow_pre_ds", "overflow_pre_es",
        "overflow_pre_fs", "overflow_pre_gs", "overflow_post_eax",
        "overflow_post_ebx", "overflow_post_ecx", "overflow_post_edx",
        "overflow_post_esi", "overflow_post_edi", "overflow_post_ebp",
        "overflow_post_ds", "overflow_post_es", "overflow_post_fs",
        "overflow_post_gs",
        "dispatch_stack_records",
        "kernel_int21_stack_depth", "kernel_int21_stack_context",
        "kernel_int21_stacks", "kernel_int21_stacks_end")}
    slot_count = 12
    slot_bytes = 512
    stack_bytes = slot_count * slot_bytes
    assert offsets["kernel_int21_stacks_end"] - offsets["kernel_int21_stacks"] == stack_bytes
    assert offsets["kernel_int21_stacks_end"] <= len(binary)

    cpu = Uc(UC_ARCH_X86, UC_MODE_16)
    cpu.mem_map(0, MEMORY_SIZE)
    base = CODE_SEG << 4
    cpu.mem_write(base, binary)
    slot_address = base + offsets["kernel_int21_stacks"]
    cpu.mem_write(slot_address, bytes([CANARY]) * stack_bytes)

    vector = offsets["kernel_int21_vector"]
    cpu.mem_write(0x21 * 4, struct.pack("<HH", vector, CODE_SEG))

    caller_ss = CODE_SEG if tight_stack else 0x5000
    if tight_stack:
        # The only caller-stack capacity is exactly the 36-byte register/segment
        # snapshot plus the 6-byte INT frame, directly after the assembled image.
        caller_stack_start = len(binary)
        sp0 = caller_stack_start + 42
        cpu.mem_write(base + caller_stack_start, b"\xA5" * 128)
    else:
        sp0 = 0x9001  # odd SP exercises byte-aligned real-mode frames
        caller_stack_start = None

    cpu.reg_write(UC_X86_REG_CS, CODE_SEG)
    cpu.reg_write(UC_X86_REG_SS, caller_ss)
    cpu.reg_write(UC_X86_REG_ESP, sp0)
    for reg, value in INPUT_GPRS.items():
        cpu.reg_write(reg, value)
    for reg, value in SEGMENTS.items():
        cpu.reg_write(reg, value)
    cpu.reg_write(UC_X86_REG_EFLAGS, 0x0647)

    for name, value in (("dispatch_depth", 0), ("max_dispatch_depth", 0),
                        ("capture_overflow", int(overflow)),
                        ("nest_remaining", nesting), ("overflow_ax", 0),
                        ("overflow_flags", 0), ("overflow_scratch_ax", 0),
                        ("overflow_scratch_flags", 0),
                        ("kernel_int21_stack_depth", 0)):
        cpu.mem_write(base + offsets[name], struct.pack("<H" if name in
                       ("nest_remaining", "overflow_ax", "overflow_flags",
                        "overflow_scratch_ax", "overflow_scratch_flags",
                        "kernel_int21_stack_depth") else "<B", value))

    dispatch_entries = []
    dispatch_address = base + offsets["int21_dispatch"]
    def on_code(machine, address, size, user_data):
        if address != dispatch_address:
            return
        depth = struct.unpack("<H", machine.mem_read(
            base + offsets["kernel_int21_stack_depth"], 2))[0]
        dispatch_entries.append({
            "depth": depth,
            "ss": machine.reg_read(UC_X86_REG_SS),
            "sp": machine.reg_read(UC_X86_REG_SP),
            "eflags": machine.reg_read(UC_X86_REG_EFLAGS),
            "gprs": {str(reg): machine.reg_read(reg) for reg in INPUT_GPRS},
            "segments": {str(reg): machine.reg_read(reg) for reg in SEGMENTS},
        })
    cpu.hook_add(UC_HOOK_CODE, on_code)

    def interrupt(machine, number, user_data):
        if number != 0x21:
            raise AssertionError(f"unexpected software interrupt {number:#x}")
        flags = machine.reg_read(UC_X86_REG_EFLAGS) & 0xFFFF
        cs = machine.reg_read(UC_X86_REG_CS)
        ip = machine.reg_read(UC_X86_REG_IP) & 0xFFFF
        ss = machine.reg_read(UC_X86_REG_SS)
        sp = (machine.reg_read(UC_X86_REG_SP) - 2) & 0xFFFF
        machine.mem_write((ss << 4) + sp, struct.pack("<H", flags))
        sp = (sp - 2) & 0xFFFF
        machine.mem_write((ss << 4) + sp, struct.pack("<H", cs))
        sp = (sp - 2) & 0xFFFF
        machine.mem_write((ss << 4) + sp, struct.pack("<H", ip))
        machine.reg_write(UC_X86_REG_ESP, sp)
        machine.reg_write(UC_X86_REG_EFLAGS, flags & ~0x0300)
        vector_offset, vector_segment = struct.unpack("<HH", machine.mem_read(0x21 * 4, 4))
        machine.reg_write(UC_X86_REG_CS, vector_segment)
        machine.reg_write(UC_X86_REG_IP, vector_offset)
    cpu.hook_add(UC_HOOK_INTR, interrupt)

    recent = []
    def trace_code(machine, address, size, user_data):
        recent.append(address)
        del recent[:-16]
    cpu.hook_add(UC_HOOK_CODE, trace_code)
    try:
        cpu.emu_start(base + offsets["fixture_call"], base + offsets["fixture_return"], count=500000)
    except Exception as exc:
        regs = {name: cpu.reg_read(reg) for name, reg in (
            ("CS", UC_X86_REG_CS), ("IP", UC_X86_REG_IP), ("SS", UC_X86_REG_SS),
            ("SP", UC_X86_REG_SP), ("EFLAGS", UC_X86_REG_EFLAGS))}
        raise AssertionError(f"fixture CPU exception at {regs}; recent linear IPs={list(map(hex, recent))}") from exc
    assert cpu.reg_read(UC_X86_REG_IP) == offsets["fixture_return"], \
        "INT21 did not return to the caller"

    depth = struct.unpack("<H", cpu.mem_read(base + offsets["kernel_int21_stack_depth"], 2))[0]
    assert depth == 0, f"private stack depth leaked: {depth}"
    assert cpu.reg_read(UC_X86_REG_SS) == caller_ss, "caller SS was not restored"
    assert cpu.reg_read(UC_X86_REG_SP) == sp0, "caller SP was not restored"
    assert len(dispatch_entries) == min(nesting + 1, slot_count), \
        f"wrong number of dispatcher entries: {len(dispatch_entries)}"

    for index, event in enumerate(dispatch_entries):
        expected_depth = index + 1
        expected_sp = offsets["kernel_int21_stacks_end"] - 6 - (index * slot_bytes)
        assert event["depth"] == expected_depth, f"wrong private slot depth: {event}"
        assert event["ss"] == CODE_SEG, f"dispatcher stayed on caller stack: {event}"
        assert event["sp"] == expected_sp, f"private stack slot overlap/placement error: {event}"
        assert not (event["eflags"] & 0x2400), \
            f"dispatcher should run with IF=DF=0: {event['eflags']:#x}"
    assert dispatch_entries[0]["gprs"] == {str(reg): value for reg, value in INPUT_GPRS.items()}, \
        f"entry did not restore caller GPRs before dispatch: {dispatch_entries[0]}"
    assert dispatch_entries[0]["segments"] == {str(reg): value for reg, value in SEGMENTS.items()}, \
        f"entry did not restore caller segments before dispatch: {dispatch_entries[0]}"

    for reg, value in RESULT_GPRS.items():
        expected = value
        assert cpu.reg_read(reg) == expected, \
            f"dispatcher result {reg} changed: {cpu.reg_read(reg):08x} != {expected:08x}"
    assert cpu.reg_read(UC_X86_REG_ESP) == sp0, "32-bit ESP/caller SP changed"
    assert cpu.reg_read(UC_X86_REG_DS) == 0xA101 and cpu.reg_read(UC_X86_REG_ES) == 0xA202, \
        "dispatcher DS/ES results were not returned"
    assert cpu.reg_read(UC_X86_REG_FS) == SEGMENTS[UC_X86_REG_FS] and \
        cpu.reg_read(UC_X86_REG_GS) == SEGMENTS[UC_X86_REG_GS], "FS/GS changed"
    flags = cpu.reg_read(UC_X86_REG_EFLAGS)
    for bit, name in ((0x001, "CF"), (0x040, "ZF"), (0x200, "IF"), (0x400, "DF")):
        assert bool(flags & bit) == bool(RESULT_FLAGS & bit), \
            f"returned {name} wrong: {flags:#x}"

    if overflow:
        overflow_ax = struct.unpack("<H", cpu.mem_read(base + offsets["overflow_ax"], 2))[0]
        overflow_flags = struct.unpack("<H", cpu.mem_read(base + offsets["overflow_flags"], 2))[0]
        assert overflow_ax == 8 and overflow_flags & 1, \
            f"13th active call did not get DOS insufficient-stack error: {overflow_ax}, {overflow_flags:#x}"
        for name in ("eax", "ebx", "ecx", "edx", "esi", "edi", "ebp", "ds", "es", "fs", "gs"):
            size = 2 if name in ("ds", "es", "fs", "gs") else 4
            before = int.from_bytes(cpu.mem_read(base + offsets[f"overflow_pre_{name}"], size), "little")
            after = int.from_bytes(cpu.mem_read(base + offsets[f"overflow_post_{name}"], size), "little")
            if name == "eax":
                assert after == ((before & 0xFFFF0000) | 8), \
                    f"overflow changed unexpected EAX bits: {before:#x}->{after:#x}"
            else:
                assert before == after, f"overflow changed {name.upper()}: {before:#x}->{after:#x}"

    # The private stack uses only the high 64 bytes of each occupied slot.
    used_slots = min(nesting + 1, slot_count)
    private_after = bytes(cpu.mem_read(slot_address, stack_bytes))
    for slot in range(slot_count):
        start = slot * slot_bytes
        occupied = slot_count - 1 - slot < used_slots
        prefix_len = slot_bytes - (64 if occupied else 0)
        assert private_after[start:start + prefix_len] == bytes([CANARY]) * prefix_len, \
            f"private stack slot {slot} wrote outside its active frame"

    if tight_stack:
        caller_tail = bytes(cpu.mem_read(base + caller_stack_start + 42, 86))
        assert caller_tail == b"\xA5" * 86, "tight caller frame wrote beyond its 42-byte allowance"

    return {
        "nesting_requested": nesting,
        "tight_stack": tight_stack,
        "overflow_expected": overflow,
        "dispatch_depths": [entry["depth"] for entry in dispatch_entries],
        "maximum_dispatch_depth": cpu.mem_read(base + offsets["max_dispatch_depth"], 1)[0],
        "caller_stack_restored": True,
        "result_flags": flags & 0x0FD7,
        "overflow_ax": struct.unpack("<H", cpu.mem_read(base + offsets["overflow_ax"], 2))[0],
        "private_stack_bytes": stack_bytes,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("build/tests/kernel-interrupt-stack"))
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    binary, listing = assemble(output)
    results = [
        run_case(binary, listing, nesting=0, tight_stack=True),
        run_case(binary, listing, nesting=11),
        run_case(binary, listing, nesting=12, overflow=True),
    ]
    report = {
        "fixture": "actual src/runtime/kernel_interrupt_stack.inc in Unicorn real-mode execution",
        "image_bytes": len(binary),
        "checks": [
            "single INT21 fits an exact 42-byte caller frame with odd stack alignment",
            "caller SS:SP and 32-bit GPR/segment/IF/DF results round-trip",
            "12 active private slots are distinct and bounded",
            "13th active call returns AX=8 with CF set without increasing depth",
        ],
        "cases": results,
        "passed": True,
    }
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
