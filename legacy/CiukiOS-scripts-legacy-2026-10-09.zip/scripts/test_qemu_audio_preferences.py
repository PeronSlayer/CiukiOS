#!/usr/bin/env python3
"""Exercise audio-preference integration helpers without starting QEMU."""
from pathlib import Path
import struct
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import qemu_test_audio_preferences as test_audio


def wav(pcm):
    fmt = struct.pack('<IHHIIHH', 16, 1, 2, 48000, 192000, 4, 16)
    body = b'fmt ' + fmt + b'data' + struct.pack('<I', len(pcm)) + pcm
    return b'RIFF' + struct.pack('<I', len(body) + 4) + b'WAVE' + body


class AudioPreferenceHarnessTests(unittest.TestCase):
    def test_image_delete_uses_mtype_presence_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            disk = Path(tmp) / 'disk.img'
            disk.write_bytes(bytes(512))
            absent = SimpleNamespace(returncode=1, stdout=b'')
            with patch.object(test_audio.subprocess, 'run', return_value=absent) as run:
                test_audio.image_delete_if_present(disk, 'SYSTEM/VOLUME.CFG')
            self.assertEqual(run.call_count, 1)
            self.assertIn('::SYSTEM/VOLUME.CFG', run.call_args.args[0])

            present = SimpleNamespace(returncode=0, stdout=b'05 0')
            deleted = SimpleNamespace(returncode=0, stdout=b'')
            with patch.object(test_audio.subprocess, 'run',
                              side_effect=[present, deleted]) as run:
                test_audio.image_delete_if_present(disk, 'SYSTEM/VOLUME.CFG')
            self.assertEqual(run.call_count, 2)
            self.assertEqual(run.call_args.args[0][0], 'mdel')

    def test_image_write_checks_mcopy_result_from_mtype(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            disk = root / 'disk.img'
            disk.write_bytes(bytes(512))
            stage = root / 'stage'
            stage.mkdir()
            copied = SimpleNamespace(returncode=0, stdout=b'')
            readback = SimpleNamespace(returncode=0, stdout=b'\x8c')
            with patch.object(test_audio.subprocess, 'run',
                              side_effect=[copied, readback]) as run:
                test_audio.image_write(disk, 'SYSTEM/VOLUME.CFG', b'\x8c', stage)
            self.assertEqual(run.call_count, 2)
            self.assertEqual(run.call_args.args[0][0], 'mtype')

    def test_audio_log_order_and_register(self):
        result = test_audio.verify_audio_log([
            '[AUDIO] native event=I master=1A1A stage=0007',
            '[AUDIO] native event=S master=1A1A stage=0017',
        ], '1A1A')
        self.assertIn('event=I', result['init_record'])
        self.assertIn('event=S', result['startup_record'])
        with self.assertRaises(AssertionError):
            test_audio.verify_audio_log([
                '[AUDIO] native event=S master=1A1A',
                '[AUDIO] native event=I master=1A1A',
            ], '1A1A')

    def test_emulated_pcm_silence_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'audio.wav'
            path.write_bytes(wav(b'\0\0\0\0'))
            self.assertEqual(test_audio.pcm_summary(path, True)['pcm_bytes'], 4)
            path.write_bytes(wav(b'\x01\0\x02\0'))
            self.assertGreater(test_audio.pcm_summary(path, False)['nonzero_pcm_bytes'], 0)
            with self.assertRaises(AssertionError):
                test_audio.pcm_summary(path, True)

    def test_boot_waits_captures_screenshot_and_closes_vm(self):
        class FakeVM:
            auto_enter_dos = True
            instances = []

            def __init__(self, disk, output, qemu_args):
                self.output = output
                self.closed = False
                self.waited = None
                FakeVM.instances.append(self)

            def wait(self, marker, timeout):
                self.waited = (marker, timeout)

            def shot(self, name):
                return self.output / (name + '.ppm')

            def close(self):
                self.closed = True

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = root / 'image.img'
            image.write_bytes(b'')
            with patch.object(test_audio, 'AudioVM', FakeVM), \
                    patch.object(test_audio.Image, 'open') as image_open, \
                    patch.object(test_audio.time, 'sleep'):
                image_open.return_value.convert.return_value.save.return_value = None
                audio, screenshot = test_audio.boot(image, root, 'first')
            vm = FakeVM.instances[-1]
            self.assertEqual(vm.waited, ('[DESKTOP] READY', 120))
            self.assertFalse(vm.auto_enter_dos)
            self.assertTrue(vm.closed)
            self.assertEqual(audio.name, 'audio.wav')
            self.assertEqual(screenshot.name, 'desktop-volume-5.png')


if __name__ == '__main__':
    unittest.main()
