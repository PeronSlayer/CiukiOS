"""Opt-in PS/2 feedback for listing-bound UI gates with changing cursor shapes.

All input is injected through QEMU. The shell coordinates are read only and
are never used to force a pointer position, focus, button or captured control.
Other WindowVM gates retain their existing pixel-based pointer checks.
"""
import math


class ObservedPointerMixin:
    def bind_pointer_observer(self, ui):
        assert ui.vm is self, 'Pointer observer belongs to a different VM'
        self._observed_pointer_ui = ui

    def pointer(self):
        ui = getattr(self, '_observed_pointer_ui', None)
        if ui is None:
            return super().pointer()
        ui.until(lambda: ui.b('ui_composing') == 0 and ui.b('ui_pointer_visible') == 1,
                 'Completed pointer presentation', 10)
        return ui.w('ui_mouse_x'), ui.w('ui_mouse_y')

    def position(self, x, y):
        ui = getattr(self, '_observed_pointer_ui', None)
        if ui is None:
            return super().position(x, y)
        # The shell uses the configured integer mouse scale. Bound each
        # relative event to a signed PS/2 packet and observe its consumption.
        for _ in range(32):
            ui.refresh()
            px, py = ui.w('ui_mouse_x'), ui.w('ui_mouse_y')
            if abs(px - x) <= 1 and abs(py - y) <= 1:
                return self.pointer()
            speed = max(1, ui.b('app_set_mouse'))
            dx = max(-127, min(127, math.ceil(abs(x - px) / speed) * (1 if x > px else -1))) if x != px else 0
            dy = max(-127, min(127, math.ceil(abs(y - py) / speed) * (1 if y > py else -1))) if y != py else 0
            self.hmp(f'mouse_move {dx} {dy} 0')
            ui.until(lambda: (ui.w('ui_mouse_x'), ui.w('ui_mouse_y')) != (px, py),
                     'Real PS/2 pointer motion', 8)
        raise AssertionError(f'Pointer did not reach {(x, y)}')
