#!/usr/bin/env python3
"""Execute production launch-mailbox/guest-range assembly with modeled VM slots.

This proves bounded protocol transitions, not physical T23 scheduling or I/O.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn.x86_const import (UC_X86_REG_EAX, UC_X86_REG_EBP,
                              UC_X86_REG_ESP, UC_X86_REG_EFLAGS)
from test_session_scheduler import section

ROOT = Path(__file__).resolve().parents[1]
BASE, FRAME, KERNEL, BUFFER, PTES, STACK, STOP = (
    0x100000, 0x300000, 0x18000, 0x20000, 0x210000, 0x310000, 0x700000)


def build(out):
    vmm = (ROOT/'src/vm/session_vmm.inc').read_text()
    jlm = (ROOT/'src/vm/session_jlm.asm').read_text()
    names = ('state', 'generation', 'launch_enabled', 'launch_pending',
             'launch_sequence', 'launch_record')
    exports = ('vmm_launch_trace', 'vmm_table', 'vmm_current', 'vmm_input_urgent',
               'vmm_kbase', 'record_size', *('off_'+n for n in names))
    fields = ('Client_EDI', 'Client_ESI', 'Client_EBP', 'Client_ESP0',
              'Client_EBX', 'Client_EDX', 'Client_ECX', 'Client_EAX',
              'Client_Error', 'Client_EIP', 'Client_CS', 'Client_Reserved',
              'Client_EFlags', 'Client_ESP', 'Client_SS', 'Client_ES',
              'Client_DS', 'Client_FS', 'Client_GS')
    text = ('.386p\n.model flat\noption casemap:none\ninclude session_abi.inc\n'
            'VMM_MAX equ 4\nVMM_CTX_BYTES equ 2048\nVMM_FRAME equ 76\n'
            'VMM_CV_BYTES equ 64\nVMM_PTES equ 192\nVMM_BIOS_MAX equ 48\n'
            'VM_SLOT_READY equ 1\nKL_INDOS equ 1\nKL_FAT_DIRTY equ 2\n'
            f'PAGE_MAP equ {PTES}\nClient_Reg_Struc struct\n'
            + ''.join(n+' dd ?\n' for n in fields)+'Client_Reg_Struc ends\n'
            + section(vmm, 'VMREC struct', 'VMREC ends')+'\n.data\npublic '
            + ','.join(exports)+'\nrecord_size dd sizeof VMREC\n'
            + ''.join('off_'+n+' dd VMREC.'+n+'\n' for n in names)
            + f'vmm_current dd 1\nvmm_kbase dd {KERNEL}\n'
            'vmm_input_urgent dd -1\nvmm_table VMREC 4 dup (<>)\n.code\n'
            + section(vmm, 'vmm_record proc', 'vmm_record endp')+'\n'
            + section(jlm, 'guest_destination proc', 'guest_destination endp')
            + '\ninclude session_launch_trace.inc\nend\n')
    out.mkdir(parents=True, exist_ok=True)
    asm, obj, elf, binary = [out/('mailbox'+s) for s in ('.asm','.o','.elf','.bin')]
    asm.write_text(text)
    link = out/'link.ld'
    link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } '
                    '.data : { *(.data*) } .bss : { *(.bss*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'),
                    '-nologo','-elf','-Cp','-I'+str(ROOT/'src/vm'),
                    '-Fo'+str(obj),str(asm)], check=True)
    subprocess.run(['ld','-m','elf_i386','-T',str(link),'-o',str(elf),str(obj)], check=True)
    subprocess.run(['objcopy','-O','binary',str(elf),str(binary)], check=True)
    symbols = {f[2]: int(f[0],16) for line in subprocess.check_output(
        ['nm',str(elf)], text=True).splitlines() if len(f := line.split()) == 3}
    return binary.read_bytes(), symbols


class Machine:
    def __init__(self, image, symbols):
        self.s = symbols
        self.u = Uc(UC_ARCH_X86, UC_MODE_32)
        self.u.mem_map(0, 0x800000)
        self.u.mem_write(BASE,image)
        self.size = self.read('record_size')
        self.offset = {n:self.read('off_'+n) for n in ('state','generation',
                       'launch_enabled','launch_pending','launch_sequence','launch_record')}
        for vm in range(4):
            self.set(vm,'state',1)
            self.set(vm,'generation',7)
            self.set(vm,'launch_enabled',int(vm != 0))
        self.u.mem_write(PTES,struct.pack('<256I',*(i*4096+7 for i in range(256))))
        self.record = bytearray(256)
        struct.pack_into('<4s6H',self.record,0,b'CVFL',1,256,1,7,6,0)
        self.record[64:69] = b'TEST\0'
        self.u.mem_write(BUFFER,bytes(self.record))

    def read(self,address):
        return int.from_bytes(self.u.mem_read(self.s.get(address,address),4),'little')

    def write(self,address,value):
        self.u.mem_write(self.s.get(address,address),struct.pack('<I',value & 0xffffffff))

    def addr(self,vm,name):
        return self.s['vmm_table']+vm*self.size+self.offset[name]

    def set(self,vm,name,value):
        self.write(self.addr(vm,name),value)

    def get(self,vm,name):
        return self.read(self.addr(vm,name))

    def call(self,operation,current=1,vm=1,generation=7,sequence=0,buffer=BUFFER,flags=0x202):
        frame = bytearray(76)
        struct.pack_into('<I',frame,0,buffer & 15)
        struct.pack_into('<I',frame,4,sequence & 65535)
        struct.pack_into('<I',frame,16,generation if operation in (0,3) else vm)
        struct.pack_into('<I',frame,20,generation)
        struct.pack_into('<I',frame,24,operation | (sequence & 0xffff0000))
        struct.pack_into('<I',frame,48,flags)
        struct.pack_into('<I',frame,60,buffer >> 4)
        self.u.mem_write(FRAME,bytes(frame))
        self.write('vmm_current',current)
        self.u.reg_write(UC_X86_REG_EBP,FRAME)
        self.u.reg_write(UC_X86_REG_ESP,STACK)
        self.u.reg_write(UC_X86_REG_EFLAGS,2)
        self.write(STACK,STOP)
        self.u.emu_start(self.s['vmm_launch_trace'],STOP,count=20000)
        assert self.u.reg_read(UC_X86_REG_ESP) == STACK+4, 'unbalanced protocol stack'
        return self.u.reg_read(UC_X86_REG_EAX)


def qualify(image,symbols):
    cases=[]
    def fresh(): return Machine(image,symbols)
    m=fresh(); assert m.call(0)==0 and m.get(1,'launch_pending')==1
    assert m.get(1,'launch_sequence')==1 and m.read('vmm_input_urgent')==0
    saved=bytes(m.u.mem_read(m.addr(1,'launch_record'),256))
    assert saved[:40]==m.record[:40] and saved[44:214]==m.record[44:214]
    assert saved[214:218]==b'PLOG' and saved[218:]==m.record[218:]
    m.u.mem_write(BUFFER,b'\xcc'*256)
    assert m.call(1,current=0)==0 and m.read(FRAME+24)==1
    assert bytes(m.u.mem_read(BUFFER,256))==saved
    assert m.get(1,'launch_pending')==1
    cases.append('publish immutable copy then parent read keeps child held')
    for label,args in (
        ('cross VM ACK',dict(current=2,sequence=1)),
        ('stale generation ACK',dict(current=0,generation=6,sequence=1)),
        ('stale sequence ACK',dict(current=0,sequence=2)),
        ('different slot ACK',dict(current=0,vm=2,sequence=1))):
        assert m.call(2,**args)!=0 and m.get(1,'launch_pending')==1
        cases.append(label+' refused')
    assert m.call(3)==0 and m.read(FRAME+20)&65535==1
    assert m.call(2,current=0,sequence=1)==0 and m.get(1,'launch_pending')==0
    assert m.call(3)==0 and m.read(FRAME+20)&65535==0
    assert m.call(2,current=0,sequence=1)!=0
    cases.append('exact ACK releases and replay refused')
    for name,mutate,kwargs in (
        ('system publish',lambda m:None,dict(current=0)),
        ('untraced child',lambda m:m.set(1,'launch_enabled',0),{}),
        ('dead child',lambda m:m.set(1,'state',2),{}),
        ('stale child generation',lambda m:None,dict(generation=6)),
        ('InDOS gate',lambda m:m.u.mem_write(KERNEL+1,b'\1'),{}),
        ('dirty FAT gate',lambda m:m.u.mem_write(KERNEL+2,b'\1'),{}),
        ('virtual CLI',lambda m:None,dict(flags=2)),
        ('bad magic',lambda m:m.u.mem_write(BUFFER,b'FAIL'),{}),
        ('bad version',lambda m:m.u.mem_write(BUFFER+4,b'\2'),{}),
        ('foreign record VM',lambda m:m.u.mem_write(BUFFER+8,b'\2'),{}),
        ('stale record generation',lambda m:m.u.mem_write(BUFFER+10,b'\6'),{}),
        ('outside memory',lambda m:None,dict(buffer=0x9ff80)),
        ('read only page',lambda m:m.write(PTES+(BUFFER>>12)*4,BUFFER+5),{})):
        m=fresh(); mutate(m)
        assert m.call(0,**kwargs)!=0 and m.get(1,'launch_pending')==0,name
        assert m.get(1,'launch_sequence')==0,name
        cases.append(name+' refused before publish')
    m=fresh(); m.set(1,'launch_sequence',0x1234ffff)
    assert m.call(0)==0 and m.get(1,'launch_sequence')==0x12350000
    assert m.call(0)!=0 and m.get(1,'launch_sequence')==0x12350000
    assert m.call(2,current=0,sequence=0x12350000)==0
    cases.append('32-bit sequence carry, duplicate publish refused')
    m=fresh(); m.set(1,'launch_sequence',0xffffffff)
    assert m.call(0)==0 and m.get(1,'launch_sequence')==1
    assert m.call(1,current=0,buffer=0xa0000)!=0 and m.get(1,'launch_pending')==1
    assert m.call(1,current=2)!=0 and m.get(1,'launch_pending')==1
    assert m.call(1,current=0,vm=4)!=0
    assert m.call(9)!=0
    cases.append('sequence wrap skips zero and invalid read leaves held')
    m=fresh(); assert m.call(1,current=0)==0 and m.read(FRAME+24)==0
    assert bytes(m.u.mem_read(BUFFER,256))==m.record
    cases.append('empty mailbox does not touch destination')
    return cases


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); image,symbols=build(a.output)
    report={'hardware_validation':False,'cases':qualify(image,symbols),
            'source_sha256':hashlib.sha256((ROOT/'src/vm/session_launch_trace.inc').read_bytes()).hexdigest(),
            'passed':True}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
