#!/usr/bin/env python3
"""Execute production DllMain detach with disk ownership states.

Only other-module cleanup services are modeled. An owned disk callback or
active request must refuse unload before any cleanup mutates other hooks.
"""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn import x86_const as x
from test_session_scheduler import section

ROOT=Path(__file__).resolve().parents[1]
BASE,STACK,STOP=0x100000,0x300000,0x700000
DISK=('disk_hooked','disk_trapped_port','disk_discovery_traps',
      'disk_busy','disk_firmware_active')
STATE=(*DISK,'sessions','active','mapped','hooked','trapped','fb_linear',
       'dev_active','scheduler_installed','scheduler_descriptor','native_page_live',
       'vmm_installed','owner_cr3','vmm_count','cleanup_calls')
CLEANUP=('guest_window_free','vmm_cmos_untrap','clock_stop','clock_untrap','tick_release','desk_remove')
READONLY=('dev_call','video_owned','vmm_umb_live','cvgpu_owned','cvsavage_owned',
          'vmm_snapshot_ivt','vmm_measure_tsc','desk_install','Host_Scheduler_Profile')


def build(out):
    source=(ROOT/'src/vm/session_jlm.asm').read_text()
    routine=section(source,'DllMain proc','DllMain endp')
    text=('.386p\n.model flat,stdcall\noption casemap:none\nTICK_VMM equ 1\n'
          '@VMMCall macro service\n call service\nendm\n.data\npublic '
          +','.join(STATE)+'\n'
          +''.join(name+' dd '+('1' if name=='vmm_count' else '0')+'\n' for name in STATE)
          +'.code\n'
          +''.join(name+' proc\n inc cleanup_calls\n xor eax,eax\n clc\n ret\n'+name+' endp\n' for name in CLEANUP)
          +''.join(name+' proc\n xor eax,eax\n clc\n ret\n'+name+' endp\n' for name in READONLY)
          +routine+'\nend\n')
    out.mkdir(parents=True,exist_ok=True)
    asm,obj,elf,binary=[out/('unload'+s) for s in ('.asm','.o','.elf','.bin')]
    asm.write_text(text)
    link=out/'link.ld'
    link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } '
                    '.data : { *(.data*) } .bss : { *(.bss*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'),
                    '-nologo','-elf','-Cp','-Fo'+str(obj),str(asm)],check=True)
    subprocess.run(['ld','-m','elf_i386','-T',str(link),'-o',str(elf),str(obj)],check=True)
    subprocess.run(['objcopy','-O','binary',str(elf),str(binary)],check=True)
    symbols={f[2].lstrip('_'):int(f[0],16) for line in subprocess.check_output(['nm',str(elf)],text=True).splitlines()
             if len(f:=line.split())==3}
    # JWasm ELF uses the stdcall argument-size suffix on the exported proc.
    entry=next(v for k,v in symbols.items() if 'DllMain' in k)
    return binary.read_bytes(),symbols,entry,hashlib.sha256(routine.encode()).hexdigest()


def run(image,symbols,entry,ownership,reason=0):
    u=Uc(UC_ARCH_X86,UC_MODE_32); u.mem_map(0,0x800000); u.mem_write(BASE,image)
    for name,value in ownership.items(): u.mem_write(symbols[name],struct.pack('<I',value))
    before={n:bytes(u.mem_read(symbols[n],4)) for n in STATE}
    u.mem_write(STACK,struct.pack('<4I',STOP,0x1234,reason,0))
    u.reg_write(x.UC_X86_REG_ESP,STACK)
    u.reg_write(x.UC_X86_REG_EFLAGS,2)
    u.emu_start(entry,STOP,count=20000)
    assert u.reg_read(x.UC_X86_REG_ESP)==STACK+16
    after={n:bytes(u.mem_read(symbols[n],4)) for n in STATE}
    return u.reg_read(x.UC_X86_REG_EAX),before,after


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); image,symbols,entry,digest=build(a.output); cases=[]
    for name in DISK:
        values=(1,3,14,0xffffffff) if name=='disk_discovery_traps' else (1,0xffffffff)
        for value in values:
            result,before,after=run(image,symbols,entry,{name:value})
            assert result==0 and before==after,(name,value,result,before,after)
            cases.append(f'{name}={value:x} refuses unload without changing any ownership')
    result,before,after=run(image,symbols,entry,dict.fromkeys(DISK,1))
    assert result==0 and before==after
    cases.append('all disk ownership states refuse before cleanup')
    result,before,after=run(image,symbols,entry,{})
    assert result==1 and int.from_bytes(after['cleanup_calls'],'little')==5
    assert all(before[n]==after[n] for n in DISK)
    cases.append('unowned module retains previous orderly detach behavior')
    result,before,after=run(image,symbols,entry,dict.fromkeys(DISK,1),reason=2)
    assert result==1 and before==after
    cases.append('non-detach notification does not clean up installed callbacks')
    report={'passed':True,'hardware_validation':False,'cases':cases,
            'production_dllmain_sha256':digest,'unicorn':importlib.metadata.version('unicorn')}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
