#!/usr/bin/env python3
"""Execute production INT13 adapter assembly; model only C ATA and Jemm services.

This tests packet translation/error/serialization contracts, not physical ATA
timing or T23 firmware. The C backend has its own task-file transaction tests.
"""
import argparse
import hashlib
import json
import importlib.metadata
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn import x86_const as x
from test_session_scheduler import section

ROOT = Path(__file__).resolve().parents[1]
BASE, FRAME, PTES, STACK, STOP = 0x100000, 0x300000, 0x210000, 0x310000, 0x700000
DAP, BUFFER = 0x18000, 0xf000
FIELDS = ('Client_EDI', 'Client_ESI', 'Client_EBP', 'Client_ESP0',
          'Client_EBX', 'Client_EDX', 'Client_ECX', 'Client_EAX',
          'Client_Error', 'Client_EIP', 'Client_CS', 'Client_Reserved',
          'Client_EFlags', 'Client_ESP', 'Client_SS', 'Client_ES',
          'Client_DS', 'Client_FS', 'Client_GS')


def build(out):
    source = (ROOT/'src/vm/session_disk.inc').read_text()
    names = ('disk_guest_range', 'disk_native_transfer', 'disk_interrupt')
    routines = '\n'.join(section(source, n+' proc', n+' endp') for n in names)
    exports = (*names, 'disk_args', 'disk_drive', 'disk_firmware_active',
               'disk_last_bios_error', 'model_status', 'model_call', 'firmware_calls')
    text = ('.386p\n.model flat\noption casemap:none\n'
            f'PAGE_MAP equ {PTES}\nClient_Reg_Struc struct\n'
            + ''.join(n+' dd ?\n' for n in FIELDS)+'Client_Reg_Struc ends\n'
            '@VMMCall macro service\n call service\nendm\n.data\npublic '
            + ','.join(exports)+'\n'
            'disk_args dd 3 dup (0)\ndisk_drive dd 80h\n'
            'disk_firmware_active dd 0\ndisk_last_bios_error db 0\nalign 4\n'
            'model_status dd 1,2,0,1F0h,3F6h,0E0h,14,1,0,0,0,50h,0,0,100000,16,63,100\n'
            'firmware_calls dd 0\n.code\n'
            'disk_call proc\nmodel_call::\n xor eax,eax\n ret\ndisk_call endp\n'
            'cvata_transfer proc\n ret\ncvata_transfer endp\n'
            'disk_status proc\n mov eax,offset model_status\n ret\ndisk_status endp\n'
            'Begin_Nest_Exec proc\n cmp disk_firmware_active,1\n jne bad_guard\n ret\n'
            'bad_guard::\n db 0Fh,0Bh\nBegin_Nest_Exec endp\n'
            'End_Nest_Exec proc\n cmp disk_firmware_active,1\n jne bad_guard\n ret\nEnd_Nest_Exec endp\n'
            'Exec_Int proc\n inc firmware_calls\n call disk_interrupt\n jnc bad_guard\n'
            'mov word ptr [ebp].Client_Reg_Struc.Client_EAX,400h\n'
            'or [ebp].Client_Reg_Struc.Client_EFlags,1\n ret\nExec_Int endp\n'
            + routines+'\nend\n')
    out.mkdir(parents=True, exist_ok=True)
    asm, obj, elf, binary = [out/('adapter'+s) for s in ('.asm','.o','.elf','.bin')]
    asm.write_text(text)
    link = out/'link.ld'
    link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } '
                    '.data : { *(.data*) } .bss : { *(.bss*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'),
                    '-nologo','-elf','-Cp','-Fo'+str(obj),str(asm)], check=True)
    subprocess.run(['ld','-m','elf_i386','-T',str(link),'-o',str(elf),str(obj)], check=True)
    subprocess.run(['objcopy','-O','binary',str(elf),str(binary)], check=True)
    symbols = {f[2]: int(f[0],16) for line in subprocess.check_output(
        ['nm',str(elf)],text=True).splitlines() if len(f := line.split()) == 3}
    return binary.read_bytes(), symbols


class Machine:
    def __init__(self, image, symbols):
        self.s, self.calls, self.fail_at, self.failure = symbols, [], None, 6
        self.u = Uc(UC_ARCH_X86, UC_MODE_32)
        self.u.mem_map(0, 0x800000)
        self.u.mem_write(BASE, image)
        self.u.mem_write(PTES, struct.pack('<256I', *(i*4096+7 for i in range(256))))
        self.u.hook_add(UC_HOOK_CODE, self.hook)
        self.frame = bytearray(76)
        self.put_frame('Client_EAX', 0x4200)
        self.put_frame('Client_EDX', 0x80)
        self.put_frame('Client_DS', DAP >> 4)
        self.put_frame('Client_EFlags', 0x203)
        self.dap()

    def read(self, addr):
        return int.from_bytes(self.u.mem_read(self.s.get(addr,addr),4),'little')

    def write(self, addr, value):
        self.u.mem_write(self.s.get(addr,addr), struct.pack('<I',value & 0xffffffff))

    def put_frame(self, name, value):
        struct.pack_into('<I', self.frame, FIELDS.index(name)*4, value)

    def dap(self, count=1, buffer=BUFFER, lba=10, size=16, reserved=0, offset=0):
        self.u.mem_write(DAP, struct.pack('<BBHHHQ', size,reserved,count,offset,
                                       (buffer-offset) >> 4,lba))

    def hook(self, uc, address, size, data):
        if address != self.s['model_call']:
            return
        args = struct.unpack('<3I', bytes(uc.mem_read(self.s['disk_args'],12)))
        self.calls.append(args)
        result = self.failure if len(self.calls) == self.fail_at else 0
        if result == 0 and args[0] == 0:
            uc.mem_write(args[2], bytes([args[1] & 255])*512)
        # Return directly from the modeled C trampoline, preserving the
        # actual adapter's caller-saved register contract.
        sp = uc.reg_read(x.UC_X86_REG_ESP)
        target = self.read(sp)
        uc.reg_write(x.UC_X86_REG_ESP, sp+4)
        uc.reg_write(x.UC_X86_REG_EAX,result)
        uc.reg_write(x.UC_X86_REG_ECX,0xdeadbeef)
        uc.reg_write(x.UC_X86_REG_EDX,0xdeadbeef)
        uc.reg_write(x.UC_X86_REG_EIP,target)

    def run(self):
        self.u.mem_write(FRAME,bytes(self.frame))
        self.u.reg_write(x.UC_X86_REG_EBP,FRAME)
        self.u.reg_write(x.UC_X86_REG_ESP,STACK)
        self.u.reg_write(x.UC_X86_REG_EFLAGS,2)
        self.write(STACK,STOP)
        self.u.emu_start(self.s['disk_interrupt'],STOP,count=20000)
        assert self.u.reg_read(x.UC_X86_REG_ESP) == STACK+4
        assert self.read('disk_firmware_active') == 0
        assert not self.u.reg_read(x.UC_X86_REG_EFLAGS) & 1, 'outer hook must handle'
        self.ax = self.read(FRAME+28) & 65535
        self.cf = bool(self.read(FRAME+48) & 1)
        return self.ax >> 8

    def count(self):
        return int.from_bytes(self.u.mem_read(DAP+2,2),'little')


def qualify(image, symbols):
    cases=[]
    def fresh(): return Machine(image,symbols)
    m=fresh(); m.dap(count=3); assert m.run()==0 and not m.cf
    assert m.calls==[(0,10,BUFFER),(0,11,BUFFER+512),(0,12,BUFFER+1024)]
    assert m.count()==3 and m.read('firmware_calls')==0
    cases.append('EDD three CPU-translated sectors including kernel low buffer')
    m=fresh(); m.put_frame('Client_EAX',0x4300); assert m.run()==0
    assert m.calls==[(1,10,BUFFER)] and m.count()==1
    cases.append('EDD write routes exact direction and LBA')
    for ax in (0x4200,0x4300):
        for error, bios_error in ((6,0x20),(7,0x80),(8,0x80),(9,4)):
            m=fresh(); m.put_frame('Client_EAX',ax); m.dap(count=3)
            m.fail_at=2; m.failure=error
            assert m.run()==bios_error and m.cf and m.count()==1
            assert len(m.calls)==2 and m.read('firmware_calls')==0
            cases.append(f'EDD {ax:04x} error {error} partial count and no firmware fallback')
    for name, mutate in (
        ('short DAP',lambda m:m.dap(size=15)),
        ('reserved DAP byte',lambda m:m.dap(reserved=1)),
        ('64-bit LBA',lambda m:m.dap(lba=1<<32)),
        ('zero count',lambda m:m.dap(count=0)),
        ('128 sectors',lambda m:m.dap(count=128)),
        ('capacity overflow',lambda m:m.dap(lba=99999,count=2)),
        ('offset wrap',lambda m:m.dap(buffer=0x2ff00,offset=0xff00)),
        ('video memory',lambda m:m.dap(buffer=0xa0000)),
        ('read-only page',lambda m:m.write(PTES+(BUFFER>>12)*4,BUFFER+5)),
        ('unmapped DAP',lambda m:m.write(PTES+(DAP>>12)*4,0)),
        ('write verify unsupported',lambda m:m.put_frame('Client_EAX',0x4301))):
        m=fresh(); mutate(m); assert m.run()!=0 and m.cf,name
        assert not m.calls and m.read('firmware_calls')==0,name
        cases.append(name+' rejected before native issue')
    for write in (0,1):
        m=fresh(); m.put_frame('Client_EAX',((2+write)<<8)|2)
        m.put_frame('Client_ECX',0x0203); m.put_frame('Client_EDX',0x0180)
        m.put_frame('Client_ES',BUFFER>>4)
        assert m.run()==0 and m.ax & 255==2
        assert m.calls==[(write,(2*16+1)*63+2,BUFFER),
                         (write,(2*16+1)*63+3,BUFFER+512)]
        assert m.read('firmware_calls')==0
        cases.append(f'CHS {write} uses AH08 translation and native CPU path')
    m=fresh(); m.put_frame('Client_EAX',0x0203); m.put_frame('Client_ECX',1)
    m.put_frame('Client_ES',BUFFER>>4); m.fail_at=2
    assert m.run()==0x20 and m.cf and m.ax & 255==1
    cases.append('CHS partial progress stops at error without BIOS retry')
    for name,cx,dx in (('zero sector',0,0x80),('sector too high',64,0x80),
                       ('head too high',1,0x1080),('cylinder too high',0x6401,0x80)):
        m=fresh(); m.put_frame('Client_EAX',0x0201); m.put_frame('Client_ECX',cx)
        m.put_frame('Client_EDX',dx); m.put_frame('Client_ES',BUFFER>>4)
        assert m.run()==1 and not m.calls and m.read('firmware_calls')==0
        cases.append('CHS '+name+' rejected')
    m=fresh(); m.put_frame('Client_EAX',0); assert m.run()==0
    assert not m.calls and m.read('firmware_calls')==0
    cases.append('bound reset is native no-op, never firmware retry')
    for drive in (0x80,0x81):
        m=fresh(); m.write(m.s['model_status']+4,3); m.put_frame('Client_EDX',drive)
        assert m.run()==0x80 and m.cf and not m.calls and m.read('firmware_calls')==0
        cases.append(f'quarantine prevents channel firmware access drive {drive:x}')
    for name, mutate in (
        ('unbound',lambda m:m.write('model_status',0)),
        ('other drive',lambda m:m.put_frame('Client_EDX',0x81)),
        ('geometry metadata',lambda m:m.put_frame('Client_EAX',0x0800))):
        m=fresh(); mutate(m)
        assert m.run()==4 and m.cf and not m.calls and m.read('firmware_calls')==1
        cases.append(name+' executes firmware once inside nested guard')
    return cases


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a=p.parse_args(); image,symbols=build(a.output)
    cases=qualify(image,symbols)
    report={'passed':True,'hardware_validation':False,'cases':cases,
            'unicorn':importlib.metadata.version('unicorn'),
            'source_sha256':hashlib.sha256((ROOT/'src/vm/session_disk.inc').read_bytes()).hexdigest()}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
