#!/usr/bin/env python3
"""Exercise assembled loader PCI selection and kernel DH handoff.

Only PCI BIOS B101/B102/B10A are modeled. Kernel interrupt vectors execute
normally. This is an instruction fixture, not a physical compatibility claim.
"""
import argparse
import json
import struct
from pathlib import Path

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR, UC_HOOK_INSN
from unicorn.x86_const import *

from test_input_fallback import cpu, enter_interrupt, symbol, Controller, call

ROOT = Path(__file__).resolve().parents[1]
KBASE, LBASE, LSEG, STOP = 0x9000, 0x8000, 0x800, 0xFF00
ATI, ESS = (0x1002, 0x4C4D), (0x125D, 0x1978)
BDFS = {ATI: 0x0208, ESS: 0x0510}
GOOD_SUBSYSTEM = 0xB1120E11


class PCI:
    def __init__(self, scenario='match'):
        self.scenario = scenario
        self.calls = []

    def invoke(self, u):
        ax = u.reg_read(UC_X86_REG_AX) & 0xFFFF
        dx, cx = u.reg_read(UC_X86_REG_DX) & 0xFFFF, u.reg_read(UC_X86_REG_CX) & 0xFFFF
        bx, di = u.reg_read(UC_X86_REG_BX) & 0xFFFF, u.reg_read(UC_X86_REG_DI) & 0xFFFF
        self.calls.append((ax, dx, cx, bx, di))
        cf, ah = False, 0
        if ax == 0xB101:
            if self.scenario == 'pci-absent':
                cf = True
            elif self.scenario == 'pci-error':
                cf, ah = True, 0x81
            else:
                u.reg_write(UC_X86_REG_EDX,
                            0x20494351 if self.scenario == 'malformed-signature' else 0x20494350)
        elif ax == 0xB102:
            key = (dx, cx)
            missing = ((self.scenario == 'ati-missing' and key == ATI) or
                       (self.scenario == 'ess-missing' and key == ESS))
            failed = ((self.scenario == 'ati-error' and key == ATI) or
                      (self.scenario == 'ess-error' and key == ESS))
            if missing:
                cf = True
            elif failed:
                cf, ah = True, 0x86
            else:
                u.reg_write(UC_X86_REG_BX, BDFS[key])
        elif ax == 0xB10A:
            assert bx == BDFS[ESS], f'config read used BDF {bx:04x}, expected ESS BDF'
            assert di == 0x2C, f'config read offset {di:04x}, expected 002c'
            if self.scenario == 'read-error':
                cf, ah = True, 0x87
            else:
                dword = 0x0E11B112 if self.scenario == 'subsystem-wrong' else GOOD_SUBSYSTEM
                u.reg_write(UC_X86_REG_ECX, dword)
        else:
            raise AssertionError(f'unexpected PCI BIOS function AX={ax:04x}')
        u.reg_write(UC_X86_REG_AX, (ah << 8) | (u.reg_read(UC_X86_REG_AX) & 0xFF))
        flags = u.reg_read(UC_X86_REG_EFLAGS)
        u.reg_write(UC_X86_REG_EFLAGS, (flags | 1) if cf else (flags & ~1))


def add_pci_interrupt(u, pci):
    def interrupt(uc, n, user_data):
        if n == 0x1A:
            pci.invoke(uc)
        else:
            enter_interrupt(uc, n, user_data)
    u.hook_add(UC_HOOK_INTR, interrupt)


def loader_cpu(binary, scenario):
    u = Uc(UC_ARCH_X86, UC_MODE_16)
    u.mem_map(0, 0x100000)
    u.mem_write(LBASE, binary)
    for reg in (UC_X86_REG_CS, UC_X86_REG_DS, UC_X86_REG_ES):
        u.reg_write(reg, LSEG)
    u.reg_write(UC_X86_REG_SS, 0x7000)
    pci = PCI(scenario)
    add_pci_interrupt(u, pci)
    return u, pci


def loader_probe(binary, listing, scenario):
    u, pci = loader_cpu(binary, scenario)
    u.reg_write(UC_X86_REG_SP, 0xFFF0)
    u.mem_write(0x7FFF0, struct.pack('<H', STOP))
    regs = (UC_X86_REG_EAX, UC_X86_REG_EBX, UC_X86_REG_ECX, UC_X86_REG_EDX,
            UC_X86_REG_EBP, UC_X86_REG_ESI, UC_X86_REG_EDI)
    values = (0xA0011234, 0xB0022345, 0xC0033456, 0xD0044567,
              0xE0055678, 0xF0066789, 0x900789AB)
    for reg, value in zip(regs, values):
        u.reg_write(reg, value)
    for reg, value in ((UC_X86_REG_DS, 0x1111), (UC_X86_REG_ES, 0x2222),
                       (UC_X86_REG_FS, 0x3333), (UC_X86_REG_GS, 0x4444)):
        u.reg_write(reg, value)
    flags = 0x602  # IF and DF set
    u.reg_write(UC_X86_REG_EFLAGS, flags)
    u.emu_start(LBASE + symbol(listing, 'input_platform_firmware_first'),
                LBASE + STOP, count=100000)
    assert u.reg_read(UC_X86_REG_IP) == STOP, 'loader PCI probe did not return'
    assert [u.reg_read(reg) for reg in regs] == list(values), 'probe changed a 32-bit GPR'
    assert [u.reg_read(reg) for reg in (UC_X86_REG_DS, UC_X86_REG_ES,
            UC_X86_REG_FS, UC_X86_REG_GS)] == [0x1111, 0x2222, 0x3333, 0x4444], \
        'probe changed a segment register'
    got = u.reg_read(UC_X86_REG_EFLAGS)
    assert got & 0x600 == flags & 0x600, 'probe changed IF/DF'
    assert got & 1 == int(scenario == 'match'), 'probe returned wrong CF'
    return pci.calls


def loader_handoff(binary, listing, scenario):
    """Run the production call/test/DH marker instructions at loader offsets."""
    u, pci = loader_cpu(binary, scenario)
    u.reg_write(UC_X86_REG_SP, 0xFFF0)
    u.reg_write(UC_X86_REG_EFLAGS, 0x202)
    u.reg_write(UC_X86_REG_DX, 0x7780)
    u.emu_start(LBASE + 0x3C, LBASE + 0x45, count=100000)
    expected = 0xE5 if scenario == 'match' else 0
    result_dx = u.reg_read(UC_X86_REG_DX)
    assert (result_dx >> 8) & 0xFF == expected, 'loader DH policy marker mismatch'
    assert result_dx & 0xFF == 0x80, 'loader DH marker changed bootdrive DL'
    return expected, pci.calls


def kernel_env(kernel, listing):
    u = cpu()
    u.mem_write(KBASE, kernel)
    ctrl = Controller()
    io = []
    u.hook_add(UC_HOOK_INTR, enter_interrupt)
    def read(uc, port, size, data):
        io.append(('in', port, size))
        return ctrl.read(uc, port, size, data)
    def write(uc, port, size, value, data):
        io.append(('out', port, size, value))
        ctrl.write(uc, port, size, value, data)
    u.hook_add(UC_HOOK_INSN, read, None, 1, 0, UC_X86_INS_IN)
    u.hook_add(UC_HOOK_INSN, write, None, 1, 0, UC_X86_INS_OUT)
    return u, ctrl, io


def kernel_init(kernel, listing, dh, expect_firmware):
    u, ctrl, io = kernel_env(kernel, listing)
    bios74 = struct.pack('<HH', 0x0300, 0xF000)
    u.mem_write(0x74 * 4, bios74)
    u.mem_write(0xF0300, b'\xcf')
    u.mem_write(KBASE + symbol(listing, 'old_int74_off'), bios74)
    u.mem_write(KBASE + symbol(listing, 'old_int15_off'), struct.pack('<HH', 0x0100, 0xF000))
    u.mem_write(0xF0100, b'\xb8\xef\xbe\xcf')
    u.mem_write(0x15 * 4, struct.pack('<HH', symbol(listing, 'int15_handler'), 0x900))
    u.reg_write(UC_X86_REG_DX, (dh << 8) | 0x80)
    call(u, symbol(listing, 'init_stage2_services'), 0x202)
    controller_io = [entry for entry in io if entry[1] in (0x60, 0x64)]
    assert bool(controller_io) == (not expect_firmware), f'DH={dh:02x} wrong controller path: {controller_io[:8]}'
    if expect_firmware:
        assert ctrl.pic == {0x21: 0xF8, 0xA1: 0xFF}, 'firmware path changed PIC masks'
        assert ctrl.config == 0x45, 'firmware path changed 8042 configuration'
        assert bytes(u.mem_read(0x74 * 4, 4)) == bios74, 'firmware IRQ12 vector not restored'
        int33 = struct.unpack('<HH', u.mem_read(0x33 * 4, 4))
        assert int33 == (symbol(listing, 'int_default_iret'), 0x900), 'INT33 is not inert'
        u.reg_write(UC_X86_REG_AX, 0)
        call(u, int33[0], 0x202, interrupt=True)
        assert u.reg_read(UC_X86_REG_AX) == 0, 'INT33 reset claims a mouse'
        u.reg_write(UC_X86_REG_AX, 0xC204)
        call(u, symbol(listing, 'int15_handler'), 0x202, interrupt=True)
        assert u.reg_read(UC_X86_REG_AX) == 0xBEEF, 'INT15 C2 did not reach OEM endpoint'
    else:
        assert ctrl.pic[0xA1] & 0x10 == 0, 'native mouse did not unmask IRQ12'
        assert u.mem_read(KBASE + symbol(listing, 'mouse_hw_ready'), 1)[0] == 1, 'native mouse init failed'
    return {'dh': dh, 'io_count': len(controller_io), 'firmware': expect_firmware}


def kernel_handoff(binary, listing, dh, expected):
    """Run the assembled stage1 prefix with only unrelated calls stubbed."""
    u = cpu()
    u.mem_write(KBASE, binary)
    u.reg_write(UC_X86_REG_DX, (dh << 8) | 0x80)
    u.reg_write(UC_X86_REG_AX, 2)
    u.reg_write(UC_X86_REG_SP, 0xFFF0)
    init_addr = KBASE + symbol(listing, 'init_stage2_services')
    stop = {'dh': None}
    stub_names = ('serial_init', 'print_string_serial', 'run_bios_diagnostics',
                  'install_int21_vector', 'hide_text_cursor', 'stage1_show_boot_splash',
                  'stage1_show_boot_loading_screen', 'stage1_runtime_init',
                  'stage1_boot_mark_step')
    stubs = {KBASE + symbol(listing, name): name for name in stub_names}
    def code(uc, address, size, user_data):
        if address == init_addr:
            stop['dh'] = (uc.reg_read(UC_X86_REG_DX) >> 8) & 0xFF
            uc.emu_stop()
            return
        if address in stubs:
            name = stubs[address]
            sp = uc.reg_read(UC_X86_REG_SP)
            ret = struct.unpack('<H', uc.mem_read((uc.reg_read(UC_X86_REG_SS) << 4) + sp, 2))[0]
            uc.reg_write(UC_X86_REG_SP, (sp + 2) & 0xFFFF)
            uc.reg_write(UC_X86_REG_IP, ret)
            if name == 'stage1_runtime_init':
                uc.reg_write(UC_X86_REG_EFLAGS, uc.reg_read(UC_X86_REG_EFLAGS) & ~1)
    u.hook_add(UC_HOOK_CODE, code)
    u.emu_start(KBASE + symbol(listing, 'stage1_start'), KBASE + 0x10000, count=100000)
    assert stop['dh'] == expected, f'stage1 DH marker transport {stop} expected {expected:02x}'
    assert u.reg_read(UC_X86_REG_DX) & 0xFF == 0x80, 'stage1 lost bootdrive DL'
    return stop['dh']


def main():
    p = argparse.ArgumentParser(description=__doc__)
    out = ROOT/'build/tests/notebook-input-platform-r17'
    p.add_argument('--loader', type=Path, default=out/'loader-r17.bin')
    p.add_argument('--loader-listing', type=Path, default=out/'loader-r17.lst')
    p.add_argument('--kernel', type=Path, default=out/'kernel-r17.sys')
    p.add_argument('--listing', type=Path, default=out/'kernel-r17.lst')
    p.add_argument('--old-kernel', type=Path, default=out/'kernel-r16.sys')
    p.add_argument('--old-listing', type=Path, default=out/'kernel-r16.lst')
    p.add_argument('--report', type=Path, default=out/'report.json')
    a = p.parse_args()
    loader, loader_lst = a.loader.read_bytes(), a.loader_listing.read_text()
    kernel, listing = a.kernel.read_bytes(), a.listing.read_text()
    scenarios = ('match', 'pci-absent', 'pci-error', 'malformed-signature',
                 'ati-missing', 'ess-missing', 'ati-error', 'ess-error',
                 'subsystem-wrong', 'read-error')
    probes = {s: loader_probe(loader, loader_lst, s) for s in scenarios}
    markers = {s: loader_handoff(loader, loader_lst, s)[0] for s in scenarios}
    assert markers['match'] == 0xE5 and all(markers[s] == 0 for s in scenarios if s != 'match')
    positive = kernel_init(kernel, listing, markers['match'], True)
    native = [kernel_init(kernel, listing, dh, False) for dh in (0x00, 0x01, 0xE4, 0xE6)]
    handoff = {dh: kernel_handoff(kernel, listing, dh, dh)
               for dh in (markers['match'], 0x00, 0x01, 0xE4, 0xE6)}
    old = kernel_init(a.old_kernel.read_bytes(), a.old_listing.read_text(), 0xE5, False)
    report = {'scope': 'assembled loader/kernel instructions with modeled PCI BIOS calls; no physical compatibility claim',
              'pci_probe_cases': probes, 'loader_dh_markers': markers,
              'kernel_firmware_path': positive, 'kernel_native_dh_cases': native,
              'stage1_dh_handoff': handoff, 'r16_matching_marker_negative_control': old}
    a.report.parent.mkdir(parents=True, exist_ok=True)
    a.report.write_text(json.dumps(report, indent=2) + '\n')
    print(f'PASS {len(probes)} PCI probe cases; DH handoff; firmware/native paths; R16 negative control')


if __name__ == '__main__':
    main()
