#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
SERIAL_NORMALIZER="$ROOT_DIR/scripts/serial_log_normalize.py"

DO_BUILD=1
IMG="build/full/ciukios-full-cd-direct.iso"
PREFIX="build/full/qemu-full-cd-shell-drive"
SERIAL_LOG="${PREFIX}.serial.log"
STRINGS_LOG="${PREFIX}.strings.log"
STDERR_LOG="${PREFIX}.stderr.log"
CMD_LOG="${PREFIX}.commands.log"
META_LOG="${PREFIX}.meta"
MON_SOCK="/tmp/ciukios-full-cd-shell-drive.monitor.sock"

ACTIVE_QEMU_PID=0
ACTIVE_MON_SOCK=""
ACTIVE_CMD_LOG=""

usage() {
  cat << 'TXT'
Usage: scripts/qemu_test_full_cd_shell_drive.sh [--no-build]

Boots the full-CD direct ISO headlessly and validates shell drive/CWD behavior:
  initial SHELL.COM D:\APPS prompt
  pwd reports D:\APPS
  CIUKRTST.COM confirms the CIUKIDOS runtime contract
  cd.. returns D:\ prompt
  cd APPS returns D:\APPS prompt

Artifacts:
  build/full/qemu-full-cd-shell-drive.{serial.log,strings.log,stderr.log,commands.log,meta}
TXT
}

mark_fail() {
  local marker="$1"
  local detail="$2"
  echo "[full-cd-shell-drive] FAIL ${marker}: ${detail}" >&2
  if [[ -f "$STDERR_LOG" ]]; then
    tail -n 40 "$STDERR_LOG" >&2 || true
  fi
  if [[ -f "$SERIAL_LOG" ]]; then
    tail -n 160 "$SERIAL_LOG" >&2 || true
  fi
  exit 1
}

mark_pass() {
  local marker="$1"
  echo "[full-cd-shell-drive] PASS ${marker}"
}

cleanup_active_qemu() {
  if [[ "$ACTIVE_QEMU_PID" -ne 0 ]] && kill -0 "$ACTIVE_QEMU_PID" >/dev/null 2>&1; then
    if [[ -n "$ACTIVE_MON_SOCK" ]] && [[ -S "$ACTIVE_MON_SOCK" ]] && [[ -n "$ACTIVE_CMD_LOG" ]]; then
      hmp "$ACTIVE_MON_SOCK" "$ACTIVE_CMD_LOG" "quit" >/dev/null 2>&1 || true
    fi
    kill "$ACTIVE_QEMU_PID" >/dev/null 2>&1 || true
    wait "$ACTIVE_QEMU_PID" >/dev/null 2>&1 || true
  fi
  if [[ -n "$ACTIVE_MON_SOCK" ]]; then
    rm -f "$ACTIVE_MON_SOCK"
  fi
}

trap cleanup_active_qemu EXIT

need_cmd() {
  local c="$1"
  if ! command -v "$c" >/dev/null 2>&1; then
    mark_fail "CMD_${c}" "missing command: $c"
  fi
}

pick_qemu() {
  if [[ -n "${QEMU_BIN:-}" ]]; then
    echo "$QEMU_BIN"
    return 0
  fi
  if command -v qemu-system-i386 >/dev/null 2>&1; then
    echo "qemu-system-i386"
    return 0
  fi
  if command -v qemu-system-x86_64 >/dev/null 2>&1; then
    echo "qemu-system-x86_64"
    return 0
  fi
  return 1
}

file_size() {
  local file="$1"
  if [[ -f "$file" ]]; then
    wc -c < "$file"
  else
    echo 0
  fi
}

wait_for_socket() {
  local sock="$1"
  local timeout_sec="$2"
  local start now
  start="$(date +%s)"
  while true; do
    if [[ -S "$sock" ]]; then
      return 0
    fi
    now="$(date +%s)"
    if (( now - start >= timeout_sec )); then
      return 1
    fi
    sleep 0.05
  done
}

wait_for_regex_from_offset() {
  local file="$1"
  local pattern="$2"
  local offset="$3"
  local timeout_sec="$4"
  local start now
  start="$(date +%s)"
  while true; do
    if [[ -f "$file" ]] && "$SERIAL_NORMALIZER" --offset "$offset" "$file" | grep -Eiq "$pattern"; then
      return 0
    fi
    now="$(date +%s)"
    if (( now - start >= timeout_sec )); then
      return 1
    fi
    sleep 0.05
  done
}

hmp() {
  local sock="$1"
  local cmd_log="$2"
  local cmd="$3"
  local out rc
  echo "[HMP] $cmd" >> "$cmd_log"
  set +e
  out="$(printf '%s\n' "$cmd" | socat - UNIX-CONNECT:"$sock" 2>&1)"
  rc=$?
  set -e
  if [[ -n "$out" ]]; then
    printf '%s\n' "$out" >> "$cmd_log"
  fi
  echo "[HMP_RC] $cmd => $rc" >> "$cmd_log"
  return $rc
}

send_key() {
  local sock="$1"
  local cmd_log="$2"
  local key="$3"
  hmp "$sock" "$cmd_log" "sendkey $key" >/dev/null 2>&1 || return 1
  return 0
}

send_text() {
  local sock="$1"
  local cmd_log="$2"
  local txt="$3"
  local i ch key

  for ((i=0; i<${#txt}; i++)); do
    ch="${txt:i:1}"
    case "$ch" in
      ' ') key="spc" ;;
      '.') key="dot" ;;
      '/') key="slash" ;;
      '\\') key="backslash" ;;
      '-') key="minus" ;;
      ':') key="shift-semicolon" ;;
      [A-Z]) key="shift-$(printf '%s' "$ch" | tr 'A-Z' 'a-z')" ;;
      [a-z0-9]) key="$ch" ;;
      *) continue ;;
    esac
    send_key "$sock" "$cmd_log" "$key" || return 1
  done

  return 0
}

send_text_and_enter() {
  local sock="$1"
  local cmd_log="$2"
  local txt="$3"

  send_text "$sock" "$cmd_log" "$txt" || return 1
  send_key "$sock" "$cmd_log" ret || return 1
  return 0
}

send_and_wait_for_prompt() {
  local command_text="$1"
  local prompt_pattern="$2"
  local marker="$3"
  local timeout_sec="$4"
  local offset
  offset="$(file_size "$SERIAL_LOG")"
  send_text_and_enter "$MON_SOCK" "$CMD_LOG" "$command_text" || mark_fail "SEND_${marker}" "cannot send command: $command_text"
  if ! wait_for_regex_from_offset "$SERIAL_LOG" "$prompt_pattern" "$offset" "$timeout_sec"; then
    mark_fail "$marker" "expected prompt did not appear after: $command_text"
  fi
  mark_pass "$marker"
}

send_and_wait_for_pattern_and_prompt() {
  local command_text="$1"
  local pattern="$2"
  local prompt_pattern="$3"
  local marker="$4"
  local timeout_sec="$5"
  local offset
  offset="$(file_size "$SERIAL_LOG")"
  send_text_and_enter "$MON_SOCK" "$CMD_LOG" "$command_text" || mark_fail "SEND_${marker}" "cannot send command: $command_text"
  if ! wait_for_regex_from_offset "$SERIAL_LOG" "$pattern" "$offset" "$timeout_sec"; then
    mark_fail "$marker" "expected marker did not appear after: $command_text"
  fi
  if ! wait_for_regex_from_offset "$SERIAL_LOG" "$prompt_pattern" "$offset" "$timeout_sec"; then
    mark_fail "$marker" "expected prompt did not appear after: $command_text"
  fi
  mark_pass "$marker"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-build)
      DO_BUILD=0
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "[full-cd-shell-drive] ERROR: unknown option: $1" >&2
      usage
      exit 1
      ;;
  esac
done

need_cmd socat
need_cmd strings
need_cmd timeout
need_cmd python3

if (( DO_BUILD )); then
  echo "[full-cd-shell-drive] build step"
  bash scripts/build_full_cd.sh
fi

if [[ ! -f "$IMG" ]]; then
  mark_fail "IMAGE" "missing image: $IMG"
fi

QEMU_CMD="$(pick_qemu || true)"
if [[ -z "$QEMU_CMD" ]]; then
  mark_fail "QEMU" "qemu-system-i386/x86_64 not found"
fi

mkdir -p build/full
rm -f "$SERIAL_LOG" "$STRINGS_LOG" "$STDERR_LOG" "$CMD_LOG" "$META_LOG" "$MON_SOCK"

QEMU_TIMEOUT_SEC="${QEMU_TIMEOUT_SEC:-240}"
PROMPT_TIMEOUT_SEC="${FULL_CD_SHELL_DRIVE_PROMPT_TIMEOUT_SEC:-120}"
COMMAND_TIMEOUT_SEC="${FULL_CD_SHELL_DRIVE_COMMAND_TIMEOUT_SEC:-60}"

SHELL_PROMPT_PREFIX='C+I+U+K+I+O+S+[[:space:]]+S+H+E+L+L+[[:space:]]+'
ROOT_PROMPT_PATTERN="${SHELL_PROMPT_PREFIX}D+[:]+[\\]+>+"
APPS_PROMPT_PATTERN="${SHELL_PROMPT_PREFIX}D+[:]+[\\]+A+P+P+S+>+"
CWD_APPS_PATTERN='C+U+R+R+E+N+T+[[:space:]]+D+I+R+E+C+T+O+R+Y+[:]+[[:space:]]+D+[:]+[\\]+A+P+P+S+'
CIUKRTST_PASS_PATTERN='\[CIUKRTST\][[:space:]]+OWNER=CIUKIDOS[[:space:]]+ABI=2[[:space:]]+SERVICES=11[[:space:]]+CHAIN=0[[:space:]]+STATE=PASS'
CD_ERROR_PATTERN='C+D+[:]+[[:space:]]+I+N+V+A+L+I+D+'

QEMU_ARGS=(
  -machine pc,vmport=off
  -cpu pentium3
  -m 128
  -drive "file=$IMG,format=raw,if=ide,index=2,media=cdrom,readonly=on"
  -boot d
  -nographic
  -chardev "file,id=ser0,path=$SERIAL_LOG"
  -serial chardev:ser0
  -monitor "unix:$MON_SOCK,server,nowait"
  -no-reboot
  -no-shutdown
)

set +e
timeout "$QEMU_TIMEOUT_SEC" "$QEMU_CMD" "${QEMU_ARGS[@]}" >/dev/null 2>"$STDERR_LOG" &
QEMU_PID=$!
set -e

ACTIVE_QEMU_PID=$QEMU_PID
ACTIVE_MON_SOCK="$MON_SOCK"
ACTIVE_CMD_LOG="$CMD_LOG"

if ! wait_for_socket "$MON_SOCK" 20; then
  mark_fail "MONITOR_SOCKET_READY" "monitor socket not ready"
fi
mark_pass "MONITOR_SOCKET_READY"

if ! kill -0 "$QEMU_PID" >/dev/null 2>&1; then
  mark_fail "QEMU_EARLY_EXIT" "qemu exited before shell prompt"
fi

if ! wait_for_regex_from_offset "$SERIAL_LOG" "$APPS_PROMPT_PATTERN" 0 "$PROMPT_TIMEOUT_SEC"; then
  mark_fail "INITIAL_D_APPS_PROMPT" "initial D:\\APPS shell prompt not detected"
fi
mark_pass "INITIAL_D_APPS_PROMPT"

send_and_wait_for_pattern_and_prompt 'pwd' "$CWD_APPS_PATTERN" "$APPS_PROMPT_PATTERN" "PWD_D_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_pattern_and_prompt 'ciukrtst' "$CIUKRTST_PASS_PATTERN" "$APPS_PROMPT_PATTERN" "CIUKRTST_D_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd..' "$ROOT_PROMPT_PATTERN" "CDDOTDOT_D_ROOT" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd APPS' "$APPS_PROMPT_PATTERN" "CD_APPS_D_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd C:\' "$APPS_PROMPT_PATTERN" "CD_C_ROOT_DEFAULT_D_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd C:APPS' "$APPS_PROMPT_PATTERN" "CD_C_REL_DEFAULT_D_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd D:/APPS/..' "$ROOT_PROMPT_PATTERN" "CD_D_PARENT_ROOT" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_prompt 'cd D:/APPS' "$APPS_PROMPT_PATTERN" "CD_D_ABS_APPS" "$COMMAND_TIMEOUT_SEC"
send_and_wait_for_pattern_and_prompt 'cd Z:\' "$CD_ERROR_PATTERN" "$APPS_PROMPT_PATTERN" "CD_BAD_DRIVE_REJECT" "$COMMAND_TIMEOUT_SEC"

hmp "$MON_SOCK" "$CMD_LOG" "quit" >/dev/null 2>&1 || true
set +e
wait "$QEMU_PID"
QEMU_RC=$?
set -e
if [[ "$QEMU_RC" -ne 0 ]]; then
  mark_fail "QEMU_EXIT" "unexpected qemu exit code: $QEMU_RC"
fi
ACTIVE_QEMU_PID=0
ACTIVE_MON_SOCK=""
ACTIVE_CMD_LOG=""
rm -f "$MON_SOCK"

"$SERIAL_NORMALIZER" "$SERIAL_LOG" | strings -a > "$STRINGS_LOG" || true

{
  echo "QEMU_CMD=$QEMU_CMD"
  echo "QEMU_RC=$QEMU_RC"
  echo "IMAGE=$IMG"
  echo "SERIAL_LOG=$SERIAL_LOG"
  echo "STRINGS_LOG=$STRINGS_LOG"
  echo "STDERR_LOG=$STDERR_LOG"
  echo "COMMAND_LOG=$CMD_LOG"
  echo "PROMPT_TIMEOUT_SEC=$PROMPT_TIMEOUT_SEC"
  echo "COMMAND_TIMEOUT_SEC=$COMMAND_TIMEOUT_SEC"
  echo "QEMU_TIMEOUT_SEC=$QEMU_TIMEOUT_SEC"
} > "$META_LOG"

echo "[full-cd-shell-drive] PASS (full-CD shell drive sequence verified)"
