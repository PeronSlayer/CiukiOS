"""Cross-check completed S3 detachment against the manager's natural exit."""
import struct

from inspect_dosvm_snapshot import parse_snapshot


def completed_guest_launch(cvfl, cdvs, slot):
    if len(cvfl) != 256 or cvfl[:8] != b'CVFL\x01\0\0\x01':
        return None
    vm, generation, stage, reason, progress = struct.unpack_from('<5H', cvfl, 8)
    # S3 detached, EXEC attempted and target returned; every milestone matters.
    if vm != slot or stage != 8 or reason != 0 or progress & 0x540 != 0x540:
        return None
    manager = parse_snapshot(cdvs)
    # vmm_exit first marks DEAD. vmm_switch frees its private pages and marks
    # FREE, retaining generation and exit_code. The gate checks after quit.
    if (manager['vm'] != slot or manager['generation'] != generation
            or manager['state'] != 'free' or manager['reason'] != 'observed_exit'
            or manager['exit_code'] != struct.unpack_from('<H', cvfl, 38)[0]):
        return None
    return manager
