#!/usr/bin/env python3
"""Execute production passive ATA discovery adapter assembly in Unicorn.

Only the C discovery decisions and Jemm services are modeled. This proves
callback forwarding, private-stack arguments, trap ownership and API cleanup;
it does not emulate T23 BIOS, ATA timing or physical device identification.
"""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn import x86_const as x
from test_session_disk_adapter import FIELDS
from test_session_disk_pio import descriptor
from test_session_scheduler import section

ROOT = Path(__file__).resolve().parents[1]
BASE, PTES, FRAME, STACK, STOP = 0x100000, 0x210000, 0x300000, 0x310000, 0x700000
PACKET, KBASE = 0x18000, 0x19000
PORTS = (0x1f2, 0x1f3, 0x1f4, 0x1f5, 0x1f6, 0x1f7, 0x3f6,
         0x172, 0x173, 0x174, 0x175, 0x176, 0x177, 0x376)
OUT, WORD, DWORD, STRING = 4, 8, 16, 32
REGS = (x.UC_X86_REG_EAX, x.UC_X86_REG_EBX, x.UC_X86_REG_ECX,
        x.UC_X86_REG_EDX, x.UC_X86_REG_ESI, x.UC_X86_REG_EDI,
        x.UC_X86_REG_EBP)
CARGS = {'cvata_prepare': 1, 'cvata_bind': 1, 'cvata_get_status': 0,
         'cvata_observe_control': 2, 'cvata_discovery_begin': 1,
         'cvata_discovery_io': 3, 'cvata_discovery_end': 1,
         'cvata_discovery_cancel': 0}
SERVICES = ('Simulate_IO', 'Install_IO_Handler', 'Remove_IO_Handler',
            'Hook_V86_Int_Chain')
ROUTINES = ('disk_call', 'disk_status', 'disk_control_port',
            'disk_discovery_port', 'disk_discovery_remove', 'disk_dispatch')
STATE = ('disk_args', 'disk_drive', 'disk_trapped_port', 'disk_discovery_traps',
         'disk_firmware_active', 'disk_busy', 'disk_saved_esp', 'disk_stack',
         'disk_stack_end', 'vmm_current', 'model_status')


def build(out):
    disk = (ROOT/'src/vm/session_disk.inc').read_text()
    jlm = (ROOT/'src/vm/session_jlm.asm').read_text()
    routines = '\n'.join(section(disk, n+' proc', n+' endp') for n in ROUTINES)
    destination = section(jlm, 'guest_destination proc', 'guest_destination endp')
    declarations = section(disk, 'disk_previous_int13 dd', 'disk_stack_end label byte')
    constants = ['OUTPUT equ 4', 'WORD_IO equ 8', 'DWORD_IO equ 16', 'STRING_IO equ 32',
                 f'PAGE_MAP equ {PTES}', 'KL_BOOT_DRIVE equ 0']
    abi = (ROOT/'src/vm/session_abi.inc').read_text()
    for name in ('VM_OP_DISK_STATUS', 'VM_OP_DISK_BIND', 'VM_OP_DISK_DISCOVER_BEGIN',
                 'VM_OP_DISK_DISCOVER_END', 'VM_DISK_STATUS_SIZE', 'VM_ERROR_CONTEXT',
                 'VM_ERROR_TRAP', 'VM_ERROR_ADDRESS'):
        constants.append(next(line for line in abi.splitlines()
                              if line.split() and line.split()[0] == name))
    text = ('.386p\n.model flat\noption casemap:none\n'+'\n'.join(constants)+'\n'
            'Client_Reg_Struc struct\n'+''.join(n+' dd ?\n' for n in FIELDS)+
            'Client_Reg_Struc ends\n@VMMCall macro service\n call service\nendm\n.data\n'
            'public '+','.join((*ROUTINES, *STATE, *SERVICES, *CARGS,
                               'guest_destination'))+'\n'+declarations+'\n'
            'vmm_current dd 0\nvmm_ready dd 1\nvmm_kbase dd '+str(KBASE)+'\n'
            'model_status dd 1,1,0,1F0h,3F6h,0E0h,14,1,0,0,0,50h,0,0,100000,16,63,100\n'
            '.code\n'+''.join(n+' proc\n ret\n'+n+' endp\n' for n in (*SERVICES, *CARGS))+
            'disk_interrupt proc\n ret\ndisk_interrupt endp\n'+
            destination+'\n'+routines+'\nend\n')
    out.mkdir(parents=True, exist_ok=True)
    asm, obj, elf, binary = [out/('discovery'+suffix) for suffix in ('.asm', '.o', '.elf', '.bin')]
    asm.write_text(text)
    link = out/'link.ld'
    link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } '
                    '.data : { *(.data*) } .bss : { *(.bss*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'),
                    '-nologo', '-elf', '-Cp', '-Fo'+str(obj), str(asm)], check=True)
    subprocess.run(['ld', '-m', 'elf_i386', '-T', str(link), '-o', str(elf), str(obj)], check=True)
    subprocess.run(['objcopy', '-O', 'binary', str(elf), str(binary)], check=True)
    symbols = {f[2]: int(f[0], 16) for line in subprocess.check_output(
        ['nm', str(elf)], text=True).splitlines() if len(f := line.split()) == 3}
    return binary.read_bytes(), symbols, hashlib.sha256(
        (declarations+destination+routines).encode()).hexdigest()


class Machine:
    def __init__(self, image, symbols):
        self.s = symbols
        self.u = Uc(UC_ARCH_X86, UC_MODE_32)
        self.u.mem_map(0, 0x800000)
        self.u.mem_write(BASE, image)
        # The production trampoline reloads DS/ES from a 32-bit SS. Null
        # Unicorn selectors do not model Jemm's flat, 32-bit stack segment.
        gdt = 0x17000
        self.u.mem_write(gdt, b'\0'*8+descriptor(0, 0x9b)+descriptor(0, 0x93))
        self.u.reg_write(x.UC_X86_REG_GDTR, (0, gdt, 23, 0))
        for reg, selector in ((x.UC_X86_REG_CS, 8), (x.UC_X86_REG_SS, 16),
                              (x.UC_X86_REG_DS, 16), (x.UC_X86_REG_ES, 16)):
            self.u.reg_write(reg, selector)
        self.u.mem_write(PTES, struct.pack('<256I', *(i*4096+7 for i in range(256))))
        self.u.mem_write(KBASE, b'\x80')
        packet = bytearray(64)
        packet[6] = 0x80
        self.u.mem_write(PACKET, bytes(packet))
        self.write('disk_drive', 0x80)
        self.frame = bytearray(76)
        self.put_frame('Client_ES', PACKET >> 4)
        self.put_frame('Client_EDI', 0)
        self.put_frame('Client_ECX', 1)
        self.put_frame('Client_EFlags', 0x203)
        self.events, self.traps = [], {}
        self.install_fail, self.remove_fail = None, None
        self.begin_result = self.end_result = self.destination_result = 0
        self.control_port = 0x3f6
        self.simulated = []
        self.addresses = {symbols[n]: n for n in (*CARGS, *SERVICES)}
        self.u.hook_add(UC_HOOK_CODE, self.hook)

    def read(self, address):
        return int.from_bytes(self.u.mem_read(self.s.get(address, address), 4), 'little')

    def write(self, address, value):
        self.u.mem_write(self.s.get(address, address), struct.pack('<I', value & 0xffffffff))

    def put_frame(self, name, value):
        struct.pack_into('<I', self.frame, FIELDS.index(name)*4, value)

    def snapshot(self):
        return tuple(self.u.reg_read(r) for r in REGS)

    def return_from_stub(self, value=None, failed=False, clobber=True):
        sp = self.u.reg_read(x.UC_X86_REG_ESP)
        target = self.read(sp)
        if clobber:
            for i, reg in enumerate((x.UC_X86_REG_EAX, x.UC_X86_REG_ECX, x.UC_X86_REG_EDX)):
                self.u.reg_write(reg, 0xdead0000+i)
        if value is not None:
            self.u.reg_write(x.UC_X86_REG_EAX, value)
        flags = self.u.reg_read(x.UC_X86_REG_EFLAGS)
        self.u.reg_write(x.UC_X86_REG_EFLAGS, (flags & ~1) | int(failed))
        self.u.reg_write(x.UC_X86_REG_ESP, sp+4)
        self.u.reg_write(x.UC_X86_REG_EIP, target)

    def hook(self, uc, address, size, data):
        name = self.addresses.get(address)
        if name is None:
            return
        if name in CARGS:
            sp = uc.reg_read(x.UC_X86_REG_ESP)
            assert self.s['disk_stack'] <= sp < self.s['disk_stack_end']
            assert self.read('disk_busy') == 1
            assert not uc.reg_read(x.UC_X86_REG_EFLAGS) & (0x200 | 0x400), 'C gets IF=DF=0'
            assert uc.reg_read(x.UC_X86_REG_DS) == uc.reg_read(x.UC_X86_REG_ES) == uc.reg_read(x.UC_X86_REG_SS)
            args = struct.unpack('<'+'I'*CARGS[name], bytes(uc.mem_read(sp+4, 4*CARGS[name])))
            self.events.append((name, *args))
            result = self.begin_result if name == 'cvata_discovery_begin' else (
                self.end_result if name == 'cvata_discovery_end' else 0)
            if name == 'cvata_get_status':
                self.write(self.s['model_status']+16, self.control_port)
                result = self.s['model_status']
            self.return_from_stub(result)
        elif name == 'Simulate_IO':
            registers = self.snapshot()
            self.simulated.append(registers)
            self.events.append((name, registers))
            self.return_from_stub(clobber=False)
        elif name in ('Install_IO_Handler', 'Remove_IO_Handler'):
            port = uc.reg_read(x.UC_X86_REG_EDX)
            handler = uc.reg_read(x.UC_X86_REG_ESI)
            self.events.append((name, port))
            failed = port == (self.install_fail if name == 'Install_IO_Handler' else self.remove_fail)
            if not failed:
                if name == 'Install_IO_Handler':
                    assert port not in self.traps, 'duplicate handler installation'
                    self.traps[port] = handler
                else:
                    assert port in self.traps, 'removing an unowned port'
                    del self.traps[port]
            self.return_from_stub(failed=failed)
        else:
            self.events.append((name,))
            self.return_from_stub(failed=False)

    def run(self, routine, registers=None):
        self.u.mem_write(FRAME, bytes(self.frame))
        values = (0x11223344, 0x55667788, 0, 0x3f6, 0x99aabbcc, 0x12345678, FRAME)
        for reg, value in zip(REGS, values):
            self.u.reg_write(reg, value)
        for reg, value in (registers or {}).items():
            self.u.reg_write(reg, value)
        self.u.reg_write(x.UC_X86_REG_ESP, STACK)
        self.u.reg_write(x.UC_X86_REG_EFLAGS, 0x602)
        self.write(STACK, STOP)
        before = self.snapshot()
        self.u.emu_start(self.s[routine], STOP, count=20000)
        assert self.u.reg_read(x.UC_X86_REG_ESP) == STACK+4
        assert not self.read('disk_busy')
        return self.u.reg_read(x.UC_X86_REG_EAX), before, self.snapshot()

    def begin(self):
        return self.run('disk_dispatch', {x.UC_X86_REG_EAX: 0x56})[0]

    def end(self, commit=True):
        self.put_frame('Client_ECX', int(commit))
        return self.run('disk_dispatch', {x.UC_X86_REG_EAX: 0x57})[0]


def qualify(image, symbols):
    cases = []
    def fresh(): return Machine(image, symbols)
    for current in (0, 1):
        for firmware in (0, 1):
            for flags in (0, OUT, OUT | WORD, OUT | DWORD, OUT | STRING, OUT | WORD | DWORD):
                m = fresh()
                m.write('vmm_current', current)
                m.write('disk_firmware_active', firmware)
                _, before, after = m.run('disk_discovery_port', {x.UC_X86_REG_ECX: flags})
                assert m.simulated == [before] and before == after
                observations = [e for e in m.events if e[0] == 'cvata_discovery_io']
                expected = [(0x3f6, before[0], 1 if flags == OUT else 0)] if (
                    current == 0 and firmware and flags & OUT) else []
                assert [e[1:] for e in observations] == expected
                cases.append(f'VM{current} firmware={firmware} I/O={flags:02x}: transparent one-time forwarding')
    for port in PORTS:
        m = fresh(); m.write('disk_firmware_active', 1)
        _, before, _ = m.run('disk_discovery_port', {x.UC_X86_REG_EDX: port, x.UC_X86_REG_ECX: OUT})
        assert m.events == [('cvata_discovery_io', port, before[0], 1), ('Simulate_IO', before)]
        cases.append(f'exact firmware OUT port {port:03x} observed before forwarding')
    m = fresh(); assert m.begin() == 0
    assert m.read('disk_discovery_traps') == 14
    assert list(m.traps) == list(PORTS)
    assert all(h == symbols['disk_discovery_port'] for h in m.traps.values())
    assert m.events[0] == ('cvata_discovery_begin', PACKET)
    cases.append('BEGIN installs exactly fourteen passive legacy task/control callbacks')
    before = list(m.events); assert m.begin() == 2 and m.events == before
    cases.append('nested BEGIN refuses without touching existing callbacks')
    for failed_port in PORTS:
        m = fresh(); m.install_fail = failed_port; assert m.begin() == 6
        count = PORTS.index(failed_port)
        assert not m.traps and m.read('disk_discovery_traps') == 0
        assert m.events == [('cvata_discovery_begin', PACKET)] + [
            ('Install_IO_Handler', p) for p in PORTS[:count+1]] + [
            ('Remove_IO_Handler', p) for p in reversed(PORTS[:count])] + [('cvata_discovery_cancel',)]
        cases.append(f'BEGIN install failure {failed_port:03x} rolls back only installed prefix')
    m = fresh(); m.begin_result = 3; assert m.begin() == 3
    assert m.events == [('cvata_discovery_begin', PACKET)] and not m.traps
    cases.append('C BEGIN rejection performs no port installation')
    for name, value in (('vmm_current', 1), ('disk_firmware_active', 1), ('disk_trapped_port', 0x3f6)):
        m = fresh(); m.write(name, value); assert m.begin() == 2 and not m.events
        cases.append(f'BEGIN invalid {name} rejected before C or Jemm mutation')
    m = fresh(); m.u.mem_write(PACKET+6, b'\x81'); assert m.begin() == 2 and not m.events
    cases.append('BEGIN wrong BIOS drive rejected before C')
    m = fresh(); m.put_frame('Client_ES', 0xa000); assert m.begin() == 7 and not m.events
    cases.append('BEGIN video-memory packet rejected by actual guest_destination')
    for control in (0x3f6, 0x376):
        m = fresh(); m.control_port = control; assert m.begin() == 0
        m.events.clear(); assert m.end() == 0
        assert m.read('disk_discovery_traps') == 0 and m.read('disk_trapped_port') == control
        assert m.events == [('cvata_discovery_end', PACKET)] + [
            ('Remove_IO_Handler', p) for p in reversed(PORTS)] + [
            ('cvata_get_status',), ('Install_IO_Handler', control)]
        assert m.traps == {control: symbols['disk_control_port']}
        assert not any(e[0] == 'cvata_bind' for e in m.events)
        cases.append(f'END removes all observers before installing exact validated control {control:03x}')
    m = fresh(); assert m.begin() == 0; m.events.clear(); assert m.end(False) == 0
    assert not m.traps and not m.read('disk_discovery_traps') and not m.read('disk_trapped_port')
    assert m.events == [('Remove_IO_Handler', p) for p in reversed(PORTS)] + [('cvata_discovery_cancel',)]
    cases.append('END client CX=0 abort removes observers and cancels without native preparation/bind')
    m = fresh(); assert m.end(False) == 0 and m.events == [('cvata_discovery_cancel',)]
    cases.append('abort with zero callbacks is harmless and does not bind')
    m = fresh(); assert m.end() == 2 and not m.events
    cases.append('commit without a complete discovery callback set is rejected')
    m = fresh(); assert m.begin() == 0; m.end_result = 8; m.events.clear(); assert m.end() == 8
    assert not m.traps and not m.read('disk_discovery_traps') and not m.read('disk_trapped_port')
    assert m.events == [('cvata_discovery_end', PACKET)] + [('Remove_IO_Handler', p) for p in reversed(PORTS)]
    cases.append('C END ambiguity rejection still cleans all observers and installs no control trap')
    for failed_port in PORTS:
        m = fresh(); assert m.begin() == 0; m.remove_fail = failed_port; m.events.clear()
        assert m.end() == 6
        remaining = PORTS.index(failed_port)+1
        assert m.read('disk_discovery_traps') == remaining and list(m.traps) == list(PORTS[:remaining])
        assert not m.read('disk_trapped_port')
        assert not any(e[0] in ('Install_IO_Handler', 'cvata_bind') for e in m.events)
        before = list(m.events); assert m.begin() == 2 and m.events == before
        m.remove_fail = None; assert m.end(False) == 0
        assert not m.traps and not m.read('disk_discovery_traps')
        cases.append(f'END failed removal {failed_port:03x} retains exact owned prefix until successful abort')
    m = fresh(); m.install_fail = PORTS[6]; m.remove_fail = PORTS[2]
    assert m.begin() == 6 and m.read('disk_discovery_traps') == 3
    assert list(m.traps) == list(PORTS[:3])
    assert m.events[-1] == ('cvata_discovery_cancel',)
    assert m.begin() == 2
    m.install_fail = m.remove_fail = None; assert m.end(False) == 0 and not m.traps
    cases.append('BEGIN rollback failure keeps live callbacks counted, blocks restart and can later abort')
    m = fresh(); assert m.begin() == 0; m.events.clear(); m.install_fail = 0x3f6
    assert m.end() == 6 and not m.traps and not m.read('disk_discovery_traps')
    assert not m.read('disk_trapped_port')
    cases.append('final control trap install failure reports trap error after observer cleanup')
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    image, symbols, digest = build(args.output)
    cases = qualify(image, symbols)
    report = {'passed': True, 'hardware_validation': False, 'case_count': len(cases),
              'cases': cases, 'production_routines_sha256': digest,
              'production_disk_source_sha256': hashlib.sha256(
                  (ROOT/'src/vm/session_disk.inc').read_bytes()).hexdigest(),
              'unicorn': importlib.metadata.version('unicorn')}
    (args.output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(f"Passive ATA discovery adapter: {len(cases)} checks PASS; report {args.output/'report.json'}")


if __name__ == '__main__':
    main()
