#!/usr/bin/env python3
"""Run the production ownership classifier/filter against bounded MCB cases.

The full T23 and Jemm loader are not emulated. This assembles the exact new
include and executes its instructions; all IVT/MCB inputs are controlled.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn import x86_const as x

ROOT = Path(__file__).resolve().parents[1]
BASE, FRAME, OUTPUT, STACK, STOP = 0x100000, 0x300000, 0x210000, 0x310000, 0x700000
KERNEL, FIRST, LAST, INDOS, IRET, LAST_OFF = 0x3000, 0x117F, 0x2170, 0x100, 0x200, 0x102
PUBLIC = ('vmm_ivt_baseline_register', 'vmm_ivt_baseline_filter', 'vmm_current',
          'vmm_count', 'ivt_snapshot', 'ivt_baseline_ready', 'ivt_baseline_kbase',
          'ivt_baseline_first', 'ivt_baseline_iret', 'ivt_baseline_free',
          'ivt_baseline_count', 'test_op_ivt')
STATE = ('ivt_baseline_ready', 'ivt_baseline_kbase', 'ivt_baseline_first',
         'ivt_baseline_iret', 'ivt_baseline_free', 'ivt_baseline_count')


def build(out):
    out.mkdir(parents=True, exist_ok=True)
    fields = ('Client_EDI','Client_ESI','Client_EBP','Client_ESP0','Client_EBX',
              'Client_EDX','Client_ECX','Client_EAX','Client_IntNo','Client_Error',
              'Client_EIP','Client_CS','Client_EFlags','Client_ESP','Client_SS',
              'Client_ES','Client_DS','Client_FS','Client_GS')
    vmm=(ROOT/'src/vm/session_vmm.inc').read_text()
    op=vmm.split('op_ivt:\n',1)[1].split('op_ivt_baseline:\n',1)[0]
    source = ('.386p\n.model flat\noption casemap:none\ninclude session_abi.inc\n'
              f'KL_PRESENT equ 1\nKL_INDOS equ {INDOS}\n'
              f'KL_DEFAULT_IRET equ {IRET}\nKL_LAST_MCB equ {LAST_OFF}\n'
              'Client_Reg_Struc struct\n' + ''.join(f+' dd ?\n' for f in fields)
              + 'Client_Reg_Struc ends\n.data\npublic '+','.join(PUBLIC)+'\n'
              'vmm_current dd 0\nvmm_count dd 1\nivt_snapshot dd 256 dup (0)\n'
              '.code\ninclude session_ivt_baseline.inc\n'
              f'guest_destination proc\n mov edi,{OUTPUT}\n xor eax,eax\n ret\nguest_destination endp\n'
              'test_op_ivt proc\n'+op+'test_op_ivt endp\nend\n')
    asm, obj, elf, binary = [out/('ivt'+suffix) for suffix in ('.asm','.o','.elf','.bin')]
    asm.write_text(source)
    link = out/'link.ld'
    link.write_text('SECTIONS { . = 0x100000; .text : { *(.text*) } '
                    '.data : { *(.data*) } .bss : { *(.bss*) } }\n')
    subprocess.run([str(ROOT/'build/external/JWasm/build/GccUnixR/jwasm'), '-nologo',
                    '-elf','-Cp','-I'+str(ROOT/'src/vm'),'-Fo'+str(obj),str(asm)],check=True)
    subprocess.run(['ld','-m','elf_i386','-T',str(link),'-o',str(elf),str(obj)],check=True)
    subprocess.run(['objcopy','-O','binary',str(elf),str(binary)],check=True)
    symbols = {f[2]:int(f[0],16) for line in subprocess.check_output(['nm',str(elf)],text=True).splitlines()
               if len(f:=line.split()) == 3}
    return binary.read_bytes(), symbols


class Machine:
    def __init__(self, image, symbols):
        self.s = symbols
        self.u = Uc(UC_ARCH_X86, UC_MODE_32)
        self.u.mem_map(0, 0x800000)
        self.u.mem_write(BASE, image)
        self.u.mem_write(KERNEL+IRET, b'\xCF')
        self.u.mem_write(KERNEL+LAST_OFF, struct.pack('<H', LAST))
        self.u.mem_write(0x413, struct.pack('<H', 636))
        self.mcb(FIRST, 'M', FIRST+1, 0xF9F)
        self.mcb(0x211F, 'M', 0x2120, 0x50)
        self.mcb(LAST, 'Z', 0, 0x9F00-LAST-1)
        ivt = struct.pack('<I', 0xF000FFF0)*256
        self.u.mem_write(0, ivt)
        self.u.mem_write(symbols['ivt_snapshot'], ivt)
        for number, segment, offset in (
                (0xDA,0x8233,0x1F0), (0xDD,0x3FBA,0x20),
                (0xDC,0x1180,0x20), (0xDE,0x2120,0x20),
                (0xDF,0x2170,0), (0xE0,0x2170,0xF),
                (0xE1,0x2171,0), (0xE2,0x9EFF,0xF),
                (0xE3,0x9F00,0), (0xE4,0xFFFF,0xFFFF),
                (0xE5,0,0), (0xE6,0x2000,0x1710),
                (0xE7,0x3FBA,0x20)):
            pointer = segment << 16 | offset
            self.put_vector(number, pointer)
            self.write(symbols['ivt_snapshot']+number*4, pointer)
        self.put_vector(0xE7,0xF000FFF0)  # live changed before registration

    def mcb(self, segment, kind, owner, size):
        self.u.mem_write(segment*16, struct.pack('<BHH',ord(kind),owner,size))

    def write(self, name, value):
        self.u.mem_write(self.s.get(name,name), struct.pack('<I', value))

    def read(self, name):
        return int.from_bytes(self.u.mem_read(self.s.get(name,name),4),'little')

    def put_vector(self, number, pointer):
        self.write(number*4,pointer)

    def state(self):
        return {name:bytes(self.u.mem_read(self.s[name],256 if name=='ivt_baseline_free' else 4)) for name in STATE}

    def register(self, segment=KERNEL//16, indos=INDOS, first=FIRST):
        frame=bytearray(76)
        struct.pack_into('<III',frame,16,segment,first,indos)
        self.u.mem_write(FRAME,bytes(frame))
        self.u.reg_write(x.UC_X86_REG_EBP,FRAME)
        return self.call('vmm_ivt_baseline_register')

    def call(self, name):
        self.u.mem_write(STACK,struct.pack('<I',STOP))
        self.u.reg_write(x.UC_X86_REG_ESP,STACK)
        self.u.reg_write(x.UC_X86_REG_EFLAGS,0x602)
        self.u.emu_start(self.s[name],STOP,count=100000)
        assert self.u.reg_read(x.UC_X86_REG_ESP)==STACK+4
        flags=self.u.reg_read(x.UC_X86_REG_EFLAGS)
        if name=='vmm_ivt_baseline_register':
            assert flags==0x602
        elif name=='vmm_ivt_baseline_filter':
            assert flags & 0x400  # filter preserves caller DF
        return self.u.reg_read(x.UC_X86_REG_EAX)

    def filtered(self):
        snapshot=bytes(self.u.mem_read(self.s['ivt_snapshot'],1024))
        self.u.mem_write(OUTPUT,snapshot)
        self.u.reg_write(x.UC_X86_REG_EDI,OUTPUT)
        self.call('vmm_ivt_baseline_filter')
        return bytes(self.u.mem_read(OUTPUT,1024))

    def copied_output(self):
        self.u.mem_write(FRAME,bytes(76))
        self.u.reg_write(x.UC_X86_REG_EBP,FRAME)
        assert self.call('test_op_ivt')==0
        frame=bytes(self.u.mem_read(FRAME,76))
        metadata=dict(ready=struct.unpack_from('<H',frame,16)[0],
                      classified=struct.unpack_from('<H',frame,24)[0],
                      filtered=struct.unpack_from('<H',frame,20)[0],
                      first=struct.unpack_from('<H',frame,4)[0])
        return bytes(self.u.mem_read(OUTPUT,1024)), metadata


def qualify(image,symbols):
    cases=[]
    m=Machine(image,symbols)
    raw=bytes(m.u.mem_read(0,1024))
    result=m.register()
    assert result==0, f'early VM0 registration with production vmm_count=1 rejected: {result:X}'
    assert m.read('ivt_baseline_ready')==1
    marked=[i for i,v in enumerate(m.u.mem_read(symbols['ivt_baseline_free'],256)) if v]
    assert marked==[0xDA,0xDD,0xE1,0xE2,0xE6], marked
    result=m.filtered()
    fallback=(KERNEL//16)<<16|IRET
    for i in range(256):
        expected=fallback if i in marked else m.read(symbols['ivt_snapshot']+i*4)
        assert struct.unpack_from('<I',result,i*4)[0]==expected,hex(i)
    assert bytes(m.u.mem_read(0,1024))==raw
    cases.append('free payload and full linear aliases filtered; owned, headers, ceilings, changed entries preserved; live IVT untouched')
    copied,metadata=m.copied_output()
    assert copied==result and metadata==dict(ready=1,classified=5,filtered=5,first=0xDA*4),metadata
    cases.append('actual op_ivt publishes ready/classified/filtered/first through BX/CX/DX/SI client fields')
    before=m.state()
    assert m.register()==0 and m.state()==before
    assert m.register(segment=KERNEL//16+1)!=0 and m.state()==before
    assert m.register(first=FIRST+1)!=0 and m.state()==before
    cases.append('same identity sealed; conflicting kernel/first refused atomically')
    m.put_vector(0xDD,0x21200020)
    result=m.filtered()
    assert struct.unpack_from('<I',result,0xDD*4)[0]==0x3FBA0020
    assert m.read(0xDD*4)==0x21200020
    copied,metadata=m.copied_output()
    assert copied==result and metadata==dict(ready=1,classified=5,filtered=4,first=0xDA*4),metadata
    cases.append('post-registration changed live vector is not replaced by synthesized default')
    failures=(
        ('non-system VM',lambda m:m.write('vmm_current',1),{}),
        ('child already created',lambda m:m.write('vmm_count',2),{}),
        ('wrong InDOS identity',lambda m:None,dict(indos=INDOS+1)),
        ('zero kernel',lambda m:None,dict(segment=0)),
        ('zero first',lambda m:None,dict(first=0)),
        ('kernel overlaps arena',lambda m:None,dict(segment=FIRST)),
        ('not an IRET opcode',lambda m:m.u.mem_write(KERNEL+IRET,b'\x90'),{}),
        ('first beyond terminal',lambda m:None,dict(first=LAST+1)),
        ('BDA above640K',lambda m:m.u.mem_write(0x413,struct.pack('<H',641)),{}),
        ('ceiling below chain',lambda m:m.u.mem_write(0x413,struct.pack('<H',128)),{}),
        ('invalid MCB type',lambda m:m.u.mem_write(FIRST*16,b'X'),{}),
        ('overflow extent',lambda m:m.u.mem_write(FIRST*16+3,b'\xFF\xFF'),{}),
        ('premature terminal',lambda m:m.u.mem_write(FIRST*16,b'Z'),{}),
        ('last declared different',lambda m:m.u.mem_write(KERNEL+LAST_OFF,struct.pack('<H',LAST+1)),{}),
        ('terminal missing',lambda m:m.u.mem_write(LAST*16,b'M'),{}),
    )
    for name,change,args in failures:
        m=Machine(image,symbols);change(m)
        before=m.state(); raw=bytes(m.u.mem_read(0,1024))
        result=m.register(**args)
        assert result!=0 and m.state()==before,(name,result)
        assert bytes(m.u.mem_read(0,1024))==raw,name
        cases.append(name+' refused before publication and without live IVT writes')
    m=Machine(image,symbols)
    raw=bytes(m.u.mem_read(symbols['ivt_snapshot'],1024))
    assert m.filtered()==raw
    copied,metadata=m.copied_output()
    assert copied==raw and metadata==dict(ready=0,classified=0,filtered=0,first=0xFFFF),metadata
    cases.append('unregistered filter preserves raw private snapshot')
    return cases


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    image,symbols=build(args.output)
    cases=qualify(image,symbols)
    report=dict(passed=True,hardware_validation=False,cases=cases,
                production_include_sha256=hashlib.sha256((ROOT/'src/vm/session_ivt_baseline.inc').read_bytes()).hexdigest())
    (args.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
