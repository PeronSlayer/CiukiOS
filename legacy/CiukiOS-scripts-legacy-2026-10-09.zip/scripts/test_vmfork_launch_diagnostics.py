#!/usr/bin/env python3
"""Bounded 16-bit CPU fixture for assembled VMFORK launch diagnostics.

Run with: uv run --with unicorn python scripts/test_vmfork_launch_diagnostics.py
No image build, emulated VM manager, or QEMU session is involved.
"""
import re
import struct
import subprocess
import tempfile
from pathlib import Path

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_INTR, UC_HOOK_CODE
from unicorn import x86_const as x

ROOT = Path(__file__).resolve().parents[1]
REGS = [x.UC_X86_REG_EAX, x.UC_X86_REG_EBX, x.UC_X86_REG_ECX,
        x.UC_X86_REG_EDX, x.UC_X86_REG_ESI, x.UC_X86_REG_EDI,
        x.UC_X86_REG_EBP, x.UC_X86_REG_ESP, x.UC_X86_REG_DS,
        x.UC_X86_REG_ES, x.UC_X86_REG_FS, x.UC_X86_REG_GS,
        x.UC_X86_REG_EFLAGS]


def symbols(listing):
    labels, pending = {}, []
    for line in listing.splitlines():
        text = re.sub(r'^\s*\d+\s+(?:[0-9A-F]{8}\s+\S+\s+)?(?:<\d+>\s*)?', '', line)
        match = re.search(r'\b([A-Za-z_]\w*)(?::|\s+(?:dw|dd|db|times)\b)', line.split(';')[0])
        if match:
            pending.append(match[1])
        address = re.match(r'^\s*\d+\s+([0-9A-F]{8})\s', line)
        if address:
            for name in pending:
                labels[name] = int(address[1], 16) + 0x100
            pending.clear()
    return labels


class Machine:
    def __init__(self, image, labels, segment=0x3000, io_failure=0):
        self.u = Uc(UC_ARCH_X86, UC_MODE_16)
        self.u.mem_map(0, 0x100000)
        self.base, self.segment, self.labels = segment * 16, segment, labels
        self.u.mem_write(self.base + 0x100, image)
        self.files, self.calls, self.io_failure = [], [], io_failure
        self.manager_exit = []
        self.u.hook_add(UC_HOOK_INTR, self.interrupt)
        self.u.hook_add(UC_HOOK_CODE, self.stop)
        self.u.reg_write(x.UC_X86_REG_CS, segment)
        self.u.reg_write(x.UC_X86_REG_SS, segment)
        for i, reg in enumerate(REGS[:7]):
            self.u.reg_write(reg, 0xA5000000 + 0x111 * (i + 1))
        self.u.reg_write(x.UC_X86_REG_ESP, 0xF000)
        for i, reg in enumerate(REGS[8:12]):
            self.u.reg_write(reg, 0x1100 + i * 0x100)
        self.u.reg_write(x.UC_X86_REG_EFLAGS, 0xED7)
        self.word('trace_vm', 2)
        self.word('trace_generation', 7)
        self.word('trace_stage', 6)
        self.u.mem_write(self.base + labels['program'], b'\\VM\\DPMIRUN.COM\0')

    def word(self, name, value):
        self.u.mem_write(self.base + self.labels[name], struct.pack('<H', value))

    def value(self, name):
        return struct.unpack('<H', self.u.mem_read(self.base + self.labels[name], 2))[0]

    def stop(self, uc, address, size, data):
        if address == self.base + 0x80:
            uc.emu_stop()
        elif address == 0x50100:
            self.manager_exit.append((uc.reg_read(x.UC_X86_REG_AX), uc.reg_read(x.UC_X86_REG_BX)))
            uc.emu_stop()

    def interrupt(self, uc, number, data):
        ax = uc.reg_read(x.UC_X86_REG_AX)
        self.calls.append(ax)
        cf, result = 0, ax
        if number == 0x12:
            result = 639
        elif number == 0x21:
            ah = ax >> 8
            if ah == 0x62:
                uc.reg_write(x.UC_X86_REG_BX, self.segment)
            elif ah == 0x52:
                uc.reg_write(x.UC_X86_REG_ES, 0x1000)
                uc.reg_write(x.UC_X86_REG_BX, 0x40)
                uc.mem_write(0x10000 + 0x3e, struct.pack('<H', 0x11ff))
            elif ah == 0x3c:
                ds, dx = uc.reg_read(x.UC_X86_REG_DS), uc.reg_read(x.UC_X86_REG_DX)
                name = bytes(uc.mem_read(ds * 16 + dx, 64)).split(b'\0')[0]
                assert name == b'C:\\SYSTEM\\VMFORK2.BIN', name
                cf, result = ((1, 5) if self.io_failure == 1 else (0, 8))
            elif ah == 0x40:
                ds, dx, cx = (uc.reg_read(r) for r in (x.UC_X86_REG_DS, x.UC_X86_REG_DX, x.UC_X86_REG_CX))
                self.files.append(bytes(uc.mem_read(ds * 16 + dx, cx)))
                cf, result = ((1, 5) if self.io_failure == 2 else (0, cx - (self.io_failure == 3)))
            elif ah == 9:
                pass  # foreground compaction error message
            elif ah == 0x3e:
                cf, result = ((1, 6) if self.io_failure == 4 else (0, 0))
            else:
                raise AssertionError(f'unexpected DOS AX {ax:04x}')
        else:
            raise AssertionError(f'unexpected interrupt {number:02x}')
        uc.reg_write(x.UC_X86_REG_AX, result)
        uc.reg_write(x.UC_X86_REG_EFLAGS, (uc.reg_read(x.UC_X86_REG_EFLAGS) & ~1) | cf)

    def run(self, name):
        before = [self.u.reg_read(r) for r in REGS]
        sp = self.u.reg_read(x.UC_X86_REG_SP) - 2
        self.u.reg_write(x.UC_X86_REG_SP, sp)
        self.u.mem_write(self.base + sp, struct.pack('<H', 0x80))
        self.u.emu_start(self.base + self.labels[name], 0x100000, count=20000)
        assert self.u.reg_read(x.UC_X86_REG_IP) == 0x80, 'routine exceeded fixture instruction bound'
        return before, [self.u.reg_read(r) for r in REGS]


def main():
    with tempfile.TemporaryDirectory(prefix='ciuki-vmfork-') as directory:
        directory = Path(directory)
        # Only these two offsets are used from the generated kernel layout;
        # the fixture models the DOS context explicitly.
        (directory / 'kernel_layout.inc').write_text('KL_EXEC_PSP equ 20h\nKL_CURRENT_PSP equ 22h\n')
        binary, listing = directory / 'VMFORK.COM', directory / 'vmfork.lst'
        subprocess.run(['nasm', '-f', 'bin', '-I', str(directory) + '/',
                        'src/com/vmfork.asm', '-o', str(binary), '-l', str(listing)], cwd=ROOT, check=True)
        image, labels = binary.read_bytes(), symbols(listing.read_text())
        for segment in (0x3000, 0x4000):
            for failure in range(5):
                m = Machine(image, labels, segment, failure)
                m.word('trace_dos_ax', 8)
                m.word('trace_dos_flags', 1)
                before, after = m.run('trace_checkpoint')
                assert before == after, (segment, failure, before, after)
                assert m.value('trace_dos_ax') == 8 and m.value('trace_dos_flags') == 1
                if m.files:
                    record = m.files[-1]
                    assert len(record) == 256 and record[:8] == b'CVFL\x01\x00\x00\x01'
                    assert struct.unpack_from('<HHH', record, 8) == (2, 7, 6)
                    assert struct.unpack_from('<HH', record, 22) == (segment, segment)
                    assert record[64:192].split(b'\0')[0] == b'\\VM\\DPMIRUN.COM'
                assert m.value('trace_io_error') == (0, 5, 5, 0xffff, 6)[failure]
        m = Machine(image, labels)
        before, after = m.run('trace_dos_result')
        assert before == after and m.value('trace_dos_ax') == (before[0] & 0xffff)
        assert m.value('trace_dos_flags') == (before[-1] & 0xffff)
        # Every root-reclaim structural predicate receives a distinct reason.
        cases = [(0x12000, b'\x00\x00', 0x12), (0x12016, b'\x01\x12', 0x13),
                 (0x12080, b'\x01', 0x14), (0x12100, b'\x00\x00', 0x15),
                 (0x12102, b'\x00\x00', 0x16), (0x12104, b'\x00\x00', 0x17),
                 (0x11ff0, b'X', 0x18), (0x11ff1, b'\x01\x12', 0x19),
                 (0x11ff3, b'\x10\x00', 0x1a), (0x11ff3, b'\xff\xff', 0x1b),
                 (0x11ff3, b'\x00\x90', 0x1c)]
        for address, corrupt, reason in cases:
            m = Machine(image, labels)
            m.word('root_psp', 0x1200)
            m.u.mem_write(0x12000, b'\xcd\x20')
            m.u.mem_write(0x12016, b'\x00\x12')
            m.u.mem_write(0x12100, b'\xfa\x8c\xc8\x8e\xd0\xbc')
            m.u.mem_write(0x11ff0, b'Z\x00\x12\x00\x01')
            m.u.mem_write(address, corrupt)
            m.run('validate_root_reclaim')
            assert m.u.reg_read(x.UC_X86_REG_EFLAGS) & 1
            assert m.value('trace_reason') == reason, (address, reason, m.value('trace_reason'))
        # Physical T23 loads an extra INT10 TSR. An unrecognized replacement
        # must fail the existing AUXSTACK layout guard, without any DOS free.
        for paragraphs, signature, reason in ((0x80, b'\xe9\xe3', 0x43),
                                              (0x4f, b'\x00\x00', 0x44)):
            m = Machine(image, labels)
            m.word('vector_slot', 0x10)
            m.u.reg_write(x.UC_X86_REG_DS, m.segment)
            m.u.reg_write(x.UC_X86_REG_BX, 0x10)
            m.u.mem_write(0x42, struct.pack('<H', 0x219d))
            m.u.mem_write(0x219c1, struct.pack('<HH', 0x219d, paragraphs))
            m.u.mem_write(0x21ad0, signature)
            m.run('move_vector_resident')
            assert m.u.reg_read(x.UC_X86_REG_EFLAGS) & 1
            assert m.value('trace_reason') == reason
            assert m.calls == [], 'unknown resident guard must precede all allocation/free calls'
        for name, stage in (('prepare_failed', 10), ('compact_failed', 11),
                            ('cleanup_failed', 12)):
            m = Machine(image, labels)
            m.u.reg_write(x.UC_X86_REG_DS, m.segment)
            m.word('trace_reason', 0x43)
            m.u.mem_write(m.base + labels['entry'], struct.pack('<HH', 0x100, 0x5000))
            m.u.emu_start(m.base + labels[name], 0x100000, count=20000)
            assert m.manager_exit == [(0x42, 0xf043)], (name, m.manager_exit)
            assert m.value('trace_stage') == stage
            assert struct.unpack_from('<H', m.files[-1], 38)[0] == 0xf043
        # A successful LFN relocation leaves reason 46h. A later unsafe IVT
        # reference must identify that predicate rather than report stale F046.
        for pointer, expected, io_failure in (((0x20, 0x1200), 0x3f, 0),
                                              ((0x20, 0x1200), 0x3f, 1),
                                              ((0x20, 0x1400), 0, 0)):
            m = Machine(image, labels, io_failure=io_failure)
            m.u.reg_write(x.UC_X86_REG_DS, m.segment)
            m.word('first_mcb', 0x11ff)
            m.word('ancestors', 0x1200)
            m.word('trace_reason', 0x46)
            m.u.mem_write(0x11ff0, struct.pack('<BHH', ord('M'), 0x1200, 0x100))
            m.u.mem_write(0x13000, struct.pack('<BHH', ord('Z'), 0x1400, 0x100))
            m.u.mem_write(0x22*4, struct.pack('<HH', *pointer))
            before, after = m.run('vectors_clear_ancestor_refs')
            assert before[:-1] == after[:-1]
            assert bool(after[-1] & 1) == bool(expected)
            assert m.calls == []
            if expected:
                assert m.value('trace_reason') == expected
                assert m.value('trace_vector_ref') == 0x22*4
                target = bytes(m.u.mem_read(m.base + labels['trace_vector_target'], 4))
                assert target == struct.pack('<HH', *pointer)
                m.u.mem_write(m.base + labels['entry'], struct.pack('<HH', 0x100, 0x5000))
                m.u.emu_start(m.base + labels['prepare_failed'], 0x100000, count=20000)
                assert m.manager_exit == [(0x42, 0xf122)]
                if io_failure:
                    assert not m.files and m.value('trace_io_error') == 5
                else:
                    assert m.files[-1][58:62] == target
        # Keep actual LFN opcode refusal distinct, and retain the observed byte.
        for prefix, reason, io_failure in ((b'\x80\xfc\x70', 0x46, 0),
                                           (b'\x80\xfc\x70', 0x46, 1),
                                           (b'\x90\xfc\x71', 0x45, 0)):
            m = Machine(image, labels, io_failure=io_failure)
            m.u.reg_write(x.UC_X86_REG_DS, m.segment)
            m.u.reg_write(x.UC_X86_REG_BX, 0x21)
            m.word('vector_slot', 0x21)
            m.u.mem_write(0x21*4, struct.pack('<HH', 0x103, 0x2200))
            m.u.mem_write(0x21ff0, struct.pack('<BHH', ord('M'), 0x2200, 0x400))
            m.u.mem_write(0x22103, prefix)
            m.run('move_vector_resident')
            assert m.u.reg_read(x.UC_X86_REG_EFLAGS) & 1
            assert m.value('trace_reason') == reason
            assert m.value('trace_lfn_immediate') == prefix[2]
            assert m.calls == [], 'unknown LFN must be rejected before allocation/free'
            m.u.mem_write(m.base + labels['entry'], struct.pack('<HH', 0x100, 0x5000))
            m.u.emu_start(m.base + labels['prepare_failed'], 0x100000, count=20000)
            expected = 0xf200 | prefix[2] if reason == 0x46 else 0xf045
            assert m.manager_exit == [(0x42, expected)]
            if io_failure:
                assert not m.files and m.value('trace_io_error') == 5
            else:
                assert struct.unpack_from('<H', m.files[-1], 62)[0] == prefix[2]
        print('VMFORK diagnostics PASS: normal/failed/short I/O preserves registers and FLAGS in two segments; DOS result, 11 root guards, unknown INT10 TSR guards, stale46 ancestor rejection and LFN mismatch, exact manager exit with failed CVFL creation verified')

if __name__ == '__main__':
    main()
