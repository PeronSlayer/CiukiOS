#!/usr/bin/env python3
"""Compile and run the host fixture for CiukiOS audio preference persistence."""
import argparse
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    args.output.mkdir(parents=True, exist_ok=True)
    binary = args.output / 'audio_settings_host'
    subprocess.run([
        'cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
        str(root / 'scripts/fixtures/audio_settings_host.c'), '-o', str(binary),
    ], cwd=root, check=True)
    subprocess.run([str(binary)], cwd=root, check=True)


if __name__ == '__main__':
    main()
