#!/usr/bin/env python3
"""Test production Mach642D contracts, not physical ATI qualification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', type=Path, default=ROOT / 'build/tests/mach64-2d')
a = p.parse_args()
out = a.output.resolve()
out.mkdir(parents=True, exist_ok=True)
sources = ['src/vm/session_gpu_mach64.c', 'src/vm/session_gpu_mach64.h',
           'src/vm/test_session_gpu_mach64.c', 'scripts/test_session_gpu_mach64.py']
exe = out / 'test-mach64'
subprocess.run([os.environ.get('CC', 'cc'), '-std=c99', '-Wall', '-Wextra',
                '-Werror', '-pedantic', '-O1', '-g', '-fsanitize=address,undefined',
                '-fno-omit-frame-pointer', '-DCVMACH64_HOST_TEST',
                '-I' + str(ROOT / 'src/vm'), str(ROOT / sources[0]),
                str(ROOT / sources[2]), '-o', str(exe)], check=True)
r = subprocess.run([str(exe)], text=True, capture_output=True,
                   env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1',
                        'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'})
(out / 'test.log').write_text(r.stdout + r.stderr)
print(r.stdout + r.stderr, end='')
r.check_returncode()
wc = Path(os.environ.get('WATCOM', '/opt/watcom'))
compiler = wc / 'binl64/wcc386'
if not compiler.exists(): compiler = wc / 'binl/wcc386'
subprocess.run([str(compiler), '-zq', '-bt=nt', '-mf', '-3r', '-ecc', '-zl', '-s',
                '-ox', '-ot', '-w4', '-we', '-i=' + str(wc / 'h'),
                '-fo=' + str(out / 'session_gpu_mach64.obj'),
                str(ROOT / sources[0])], check=True)
(out / 'report.json').write_text(json.dumps({
    'passed': True, 'hardware_validated': False,
    'scope': 'production Mach64 driver and independent posted MMIO/stale CPU readback cache fixture',
    'checks': ['exact PCI ID behind AGP bridge', 'read-only automatic probe',
               'nonmutating firmware mode validation', '16/24/32bpp pixel proofs',
               'packed24 DWORD rotation and shifted origins', 'two-row hardware copy',
               'overlap reverse traversal', 'private VRAM restored',
               'no triggering register replay', 'no capabilities before readback proof',
               'bounded FIFO timeout', 'unsafe release retains ownership',
               'ASan/UBSan', 'OpenWatcom target compilation'],
    'sources': {s: hashlib.sha256((ROOT / s).read_bytes()).hexdigest() for s in sources}
}, indent=2) + '\n')
