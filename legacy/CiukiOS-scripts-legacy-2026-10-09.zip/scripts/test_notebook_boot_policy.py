#!/usr/bin/env python3
"""Exercise shipping PCI profile probe and keyboard poll instructions."""
import json
import pathlib
import subprocess
import tempfile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_INSN, UC_HOOK_INTR
from unicorn import x86_const as x

ROOT = pathlib.Path(__file__).resolve().parents[1]
CASES = []

def assemble(source):
    with tempfile.TemporaryDirectory() as directory:
        a = pathlib.Path(directory) / 'probe.asm'
        b = a.with_suffix('.bin')
        a.write_text(source)
        subprocess.run(['nasm', '-f', 'bin', '-I', str(ROOT) + '/', str(a), '-o', str(b)], check=True)
        return b.read_bytes()

def machine(code):
    u = Uc(UC_ARCH_X86, UC_MODE_16)
    u.mem_map(0, 0x100000)
    u.mem_write(0x1000, code)
    u.reg_write(x.UC_X86_REG_SP, 0xF000)
    u.reg_write(x.UC_X86_REG_EFLAGS, 0x202)
    return u

for label, ids, wanted in [
    ('t23', {0x80010000: 0x8C2E5333, 0x8000FD00: 0x24858086}, 1),
    ('armada', {0x80010000: 0x4C4D1002, 0x8000FD00: 0xFFFFFFFF}, 0),
    ('other_savage', {0x80010000: 0x8C2E5333, 0x8000FD00: 0x24158086}, 0),
    ('absent_pci', {}, 0),
]:
    code = assemble('bits 16\norg 0x1000\ncall vm_platform_is_t23\nhlt\n%include "src/com/vm_platform_options.inc"\n')
    u = machine(code)
    latch = [0xDEADBE00]
    reads = []
    def incoming(uc, port, size, data):
        assert size == 4
        if port == 0xCF8: return latch[0]
        assert port == 0xCFC
        reads.append(latch[0])
        return ids.get(latch[0], 0xFFFFFFFF)
    def outgoing(uc, port, size, value, data):
        assert port == 0xCF8 and size == 4
        latch[0] = value
    u.hook_add(UC_HOOK_INSN, incoming, None, 1, 0, x.UC_X86_INS_IN)
    u.hook_add(UC_HOOK_INSN, outgoing, None, 1, 0, x.UC_X86_INS_OUT)
    u.reg_write(x.UC_X86_REG_EBX, 0xBEEF1234)
    u.reg_write(x.UC_X86_REG_EDX, 0xCAFE5678)
    u.emu_start(0x1000, 0x1000 + len(code), count=1000)
    assert u.reg_read(x.UC_X86_REG_EAX) == wanted
    assert u.reg_read(x.UC_X86_REG_EBX) == 0xBEEF1234
    assert u.reg_read(x.UC_X86_REG_EDX) == 0xCAFE5678
    assert u.reg_read(x.UC_X86_REG_SP) == 0xF000
    assert u.reg_read(x.UC_X86_REG_EFLAGS) & 0x200
    assert latch[0] == 0xDEADBE00
    CASES.append({'case': label, 't23': bool(wanted), 'reads': reads, 'pci_latch_restored': True})

# Extract actual shipping poll rather than an equivalent reimplementation.
source = (ROOT / 'src/com/shell_gui_input.inc').read_text()
poll = source[source.index('    mov ah,0x11'):source.index('.key_received:')]
poll = '\n'.join(line for line in poll.splitlines() if not line.startswith('%'))
# Diagnostic code is conditionally assembled out in the ordinary full image.
poll = poll[:poll.index('    cmp byte [boot_log_legacy_seen]')] + '    jmp .key_received\n.enhanced_key:\n    mov ah,0x10\n    int 0x16\n'
for label, enhanced, legacy, expected in [
    ('enhanced_key', True, False, [0x11, 0x10]),
    ('legacy_only', False, True, [0x11, 0x01, 0x00]),
    ('empty', False, False, [0x11, 0x01]),
]:
    code = assemble('bits 16\norg 0x1000\nentry:\n' + poll + '.key_received:\nmov bx,1\nhlt\n.mouse:\nmov bx,0\nhlt\n')
    u = machine(code)
    calls = []
    def interrupt(uc, number, data):
        assert number == 0x16
        command = uc.reg_read(x.UC_X86_REG_AH)
        calls.append(command)
        if command in (0x11, 0x01):
            available = enhanced if command == 0x11 else legacy
            flags = uc.reg_read(x.UC_X86_REG_EFLAGS)
            uc.reg_write(x.UC_X86_REG_EFLAGS, flags & ~0x40 if available else flags | 0x40)
        else:
            assert enhanced if command == 0x10 else legacy
            uc.reg_write(x.UC_X86_REG_AX, 0x1E61)
    u.hook_add(UC_HOOK_INTR, interrupt)
    u.emu_start(0x1000, 0x1000 + len(code), count=1000)
    assert calls == expected, (label, calls)
    assert u.reg_read(x.UC_X86_REG_BX) == int(enhanced or legacy)
    CASES.append({'case': label, 'int16_calls': calls, 'no_empty_blocking_read': True})

out = ROOT / 'build/tests/notebook-boot-policy-r16/report.json'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({'passed': True, 'cases': CASES, 'scope': 'CPU fixtures; no Armada hardware certification'}, indent=2) + '\n')
print(f'{len(CASES)} notebook boot policy cases passed: {out}')
