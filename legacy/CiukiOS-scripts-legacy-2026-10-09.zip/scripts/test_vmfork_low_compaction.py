#!/usr/bin/env python3
"""Execute full-profile VMFORK compaction with the actual DOS allocator.

All UMB claims are refused to exercise the conventional fallback. BIOS memory
reporting and diagnostic writes are modeled; no disk or VM image is used.
Run with: uv run --with unicorn python scripts/test_vmfork_low_compaction.py
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import tempfile

from unicorn import x86_const as x

from test_vmfork_pinned_ancestors import ForkMachine, assemble_vmfork, free_memory
from test_kernel_f149_arena import BASE, CHILD, LIVE, ROOT, SEG, SHELL, assemble

AUX, LFN, ROOT_SIZE, API = 0x2195, 0x21E5, 0xF9A, 0xE0000


class CompactionMachine(ForkMachine):
    def __init__(self, *args, embedded=False):
        self.dynamic_stops = None
        self.umb_claims = []
        super().__init__(*args, embedded=embedded)
        self.psp(SHELL, ROOT_SIZE, SHELL)
        self.u.mem_write(SHELL * 16 + 0x100, bytes.fromhex('fa8cc88ed0bc'))
        entries = [(AUX, 0x4F, AUX, 7), (LFN, 0x451, LFN, 7),
                   (0x3000, 0x400, SHELL, 1),
                   (LIVE, 0x80, SHELL, 1), (0x7000, 0x60, 0x7000, 1)]
        if not embedded:
            entries.append((self.parent, 0x80, self.parent, 1))
        self.put('dos_mem_block_count', len(entries), 1)
        self.u.mem_write(BASE + self.labels['dos_mem_block_table'],
                         b''.join(struct.pack('<4H', *entry) for entry in entries))
        for segment, size, owner, _ in entries:
            self.mcb(segment, size, owner)
        for segment, size in ((AUX, 0x4F), (LFN, 0x451)):
            self.psp(segment, size, SHELL)
        self.u.mem_write(AUX * 16 + 0x100, bytes.fromhex('e9e3'))
        self.u.mem_write(LFN * 16 + 0x103, bytes.fromhex('80fc71'))
        self.call('int21_mem_rebuild_chain')
        self.vector(0x10, AUX, 0x470)
        self.vector(0x21, LFN, 0x103)
        self.word('root_end', SHELL + ROOT_SIZE)
        self.u.mem_write(self.base + self.vm_labels['entry'], struct.pack('<HH', 0, API // 16))
        self.u.mem_write(API, b'\xcb')  # RETF from modeled UMB claim
        self.dos_calls.clear()

    def stop(self, uc, address, size, data):
        if address == API:
            assert uc.reg_read(x.UC_X86_REG_AX) == 0x4B
            self.umb_claims.append(dict(paras=uc.reg_read(x.UC_X86_REG_BX),
                                       root_size=self.chain()[SHELL]['size']))
            uc.reg_write(x.UC_X86_REG_AX, 1)
            uc.reg_write(x.UC_X86_REG_EFLAGS, uc.reg_read(x.UC_X86_REG_EFLAGS) | 1)
        if self.dynamic_stops is not None and uc.reg_read(x.UC_X86_REG_CS) != SEG:
            offset = uc.reg_read(x.UC_X86_REG_IP)
            if offset in self.dynamic_stops:
                self.stopped = self.dynamic_stops[offset]
                uc.emu_stop()
                return
        super().stop(uc, address, size, data)

    def interrupt(self, uc, number, data):
        ax = uc.reg_read(x.UC_X86_REG_AX)
        if number != 0x21 or not (ax >> 8 in (0x48, 0x49, 0x4A, 0x50, 0x58) or ax == 0xF14A):
            return super().interrupt(uc, number, data)
        self.dos_calls.append((ax, uc.reg_read(x.UC_X86_REG_BX), uc.reg_read(x.UC_X86_REG_ES)))
        flags = uc.reg_read(x.UC_X86_REG_EFLAGS)
        cs, ip = uc.reg_read(x.UC_X86_REG_CS), uc.reg_read(x.UC_X86_REG_IP)
        ss, sp = uc.reg_read(x.UC_X86_REG_SS), uc.reg_read(x.UC_X86_REG_SP)
        sp = (sp - 6) & 0xFFFF
        uc.mem_write(ss * 16 + sp, struct.pack('<HHH', ip, cs, flags & 0xFFFF))
        uc.reg_write(x.UC_X86_REG_SP, sp)
        uc.reg_write(x.UC_X86_REG_EFLAGS, flags & ~0x300)
        uc.reg_write(x.UC_X86_REG_CS, SEG)
        uc.reg_write(x.UC_X86_REG_IP, self.labels['int21_handler'])
        self.dispatches += 1

    def relocated_run(self, name, stops=()):
        self.dynamic_stops = {0x80: 'return'}
        self.dynamic_stops.update({self.vm_labels[n]: n for n in stops})
        result = self.run(name, stops=stops)
        self.segment = self.u.reg_read(x.UC_X86_REG_CS)
        self.base = self.segment * 16
        self.dynamic_stops = None
        return result

    def vectors(self):
        return {n: struct.unpack('<HH', self.u.mem_read(n * 4, 4)) for n in (0x10, 0x21)}


def run_cases(make):
    cases = []
    m = make()
    before = free_memory(m.chain())
    vectors = m.vectors()
    resident_images = {p: bytes(m.u.mem_read(p * 16, size * 16))
                       for p, size in ((AUX, 0x4F), (LFN, 0x451))}
    result = m.relocated_run('prepare_compaction')
    assert result['stop'] == 'return' and not result['carry'], (result, m.vm_value('trace_reason'))
    staged = m.segment
    assert staged == CHILD
    assert m.vm_value('compact_ready', 1) == 1
    assert m.vm_value('resident_validate_only', 1) == 0
    assert m.chain()[SHELL] == dict(owner=SHELL, size=0x10)
    assert m.vectors() == vectors and not m.umb_claims
    assert all(bytes(m.u.mem_read(p * 16, len(blob))) == blob for p, blob in resident_images.items())
    assert m.value('current_psp_seg') == m.value('dos_exec_identity_psp') == staged
    result = m.relocated_run('compact_residents', stops=('child.again',))
    assert result['stop'] == 'child.again' and not result['carry'], (result, m.vm_value('trace_reason'))
    assert m.value('current_psp_seg') == m.value('dos_exec_identity_psp') == m.segment
    assert m.segment < staged and m.vm_value('trace_reason') == 0
    assert [c['paras'] for c in m.umb_claims] == [0x4F, 0x451]
    assert all(c['root_size'] == 0x10 for c in m.umb_claims)
    for vector, old, paras, code in ((0x10, AUX, 0x4F, (0x100, b'\xe9\xe3')),
                                     (0x21, LFN, 0x451, (0x103, b'\x80\xfc\x71'))):
        offset, segment = m.vectors()[vector]
        assert offset == vectors[vector][0] and SHELL + 0x10 < segment < old
        assert m.chain()[segment] == dict(owner=segment, size=paras)
        assert bytes(m.u.mem_read(segment * 16 + code[0], len(code[1]))) == code[1]
        assert int.from_bytes(m.u.mem_read(segment * 16 + 2, 2), 'little') == segment + paras
        assert (old, old) in m.free_calls()
    assert m.free_calls().count((CHILD, CHILD)) == 1
    assert m.chain()[SHELL] == dict(owner=SHELL, size=0x10)
    assert m.chain()[m.parent]['owner'] == m.parent
    cases.append(dict(name='umb_unavailable_low_fallback', before=before,
                      after=free_memory(m.chain()), staged=staged, compacted=m.segment,
                      umb_claims=m.umb_claims, vectors=m.vectors()))

    for name, change, expected in (
            ('unknown_lfn_word', lambda m: m.u.mem_write(LFN * 16 + 0x103, b'\x90\x90'), 0x45),
            ('unknown_lfn_immediate', lambda m: m.u.mem_write(LFN * 16 + 0x105, b'\x70'), 0x46),
            ('unknown_aux_signature', lambda m: m.u.mem_write(AUX * 16 + 0x100, b'\x90\x90'), 0x44)):
        m = make()
        change(m)
        vectors = m.vectors()
        result = m.relocated_run('prepare_compaction')
        assert result['carry'] and m.vm_value('trace_reason') == expected, (name, result, m.vm_value('trace_reason'))
        assert m.chain()[SHELL] == dict(owner=SHELL, size=ROOT_SIZE)
        assert not m.umb_claims and m.vectors() == vectors
        assert not any(ax in (0xF14A, 0xF149) for ax, _, _ in m.dos_calls)
        cases.append(dict(name=name, rejected_before_root_resize=True, reason=expected))

    m = make()
    m.vector(0xDA, SHELL + 0x40, 0x100)
    before, vectors = m.chain(), m.vectors()
    result = m.relocated_run('prepare_compaction')
    assert not result['carry'] and m.vm_value('compact_ready', 1) == 0
    assert m.vm_value('trace_reason') == 4
    assert m.chain() == before and m.vectors() == vectors and m.segment == CHILD
    assert not m.umb_claims and not any(ax >> 8 == 0x48 or ax in (0xF14A, 0xF149)
                                      for ax, _, _ in m.dos_calls)
    cases.append(dict(name='unknown_root_vector_pins_before_staging', arena_unchanged=True))
    m = make(True)
    source = m.segment
    result = m.relocated_run('prepare_compaction')
    assert not result['carry'] and m.segment != source
    assert m.segment >= SHELL + ROOT_SIZE and m.vm_value('compact_ready', 1) == 1
    staged = m.segment
    result = m.relocated_run('compact_residents', stops=('child.again', 'child.compact_failed'))
    assert result['stop'] == 'child.again' and m.vm_value('trace_reason') == 0
    assert m.chain()[m.segment]['owner'] == m.segment
    assert (source, source) in m.free_calls() and (staged, staged) in m.free_calls()
    cases.append(dict(name='embedded_psp_keeps_copy_and_rebase', source=source,
                      staged=staged, compacted=m.segment))

    for name, change in (
            ('wrong_owner', lambda m: m.u.mem_write((CHILD - 1) * 16 + 1, struct.pack('<H', SHELL))),
            ('short_extent', lambda m: m.u.mem_write((CHILD - 1) * 16 + 3, struct.pack('<H', 0x10))),
            ('psp_extent_mismatch', lambda m: m.u.mem_write(CHILD * 16 + 2, struct.pack('<H', CHILD + 0x7FF))),
            ('dependent_allocation', lambda m: m.u.mem_write((LIVE - 1) * 16 + 1, struct.pack('<H', CHILD)))):
        m = make()
        m.word('old_psp', CHILD)
        change(m)
        before = bytes(m.u.mem_read(0, 0xA0000))
        result = m.run('use_owned_staging')
        assert result['carry'] and m.vm_value('stage_psp') == 0, name
        # Only the test caller's private stack may have been touched.
        after = bytes(m.u.mem_read(0, 0xA0000))
        start, end = CHILD * 16 + m.vm_labels['stack_top'] - 64, CHILD * 16 + m.vm_labels['stack_top']
        assert before[:start] == after[:start] and before[end:] == after[end:], name
        cases.append(dict(name='owned_staging_rejects_' + name, no_arena_mutation=True))

    m = make()
    need = (m.vm_labels['image_end'] + 15) // 16
    m.parent = SHELL
    m.psp(CHILD, need, SHELL)
    m.word('ancestors', SHELL)
    m.u.mem_write(m.base + m.vm_labels['ancestors'] + 2, b'\0' * 16)
    m.put('dos_mem_psp_mcb_end', CHILD + need)
    entries = [(AUX, 0x4F, AUX, 7), (LFN, 0x451, LFN, 7),
               (0x2637, CHILD - 0x2637 - 1, SHELL, 1),
               (CHILD + 688, 0x9000 - (CHILD + 688) - 1, SHELL, 1),
               (0x9000 + 242, 0x9F00 - (0x9000 + 242), SHELL, 1)]
    m.put('dos_mem_block_count', len(entries), 1)
    m.u.mem_write(BASE + m.labels['dos_mem_block_table'],
                  b''.join(struct.pack('<4H', *e) for e in entries))
    for p, size, owner, _ in entries:
        m.mcb(p, size, owner)
    m.call('int21_mem_rebuild_chain')
    before = free_memory(m.chain())
    assert before['total'] == 1049 - need - 1, (before, need)
    assert before['largest'] < need
    result = m.relocated_run('prepare_compaction')
    assert not result['carry'] and m.segment == CHILD and m.vm_value('compact_ready', 1) == 1
    assert not any(ax >> 8 == 0x48 for ax, _, _ in m.dos_calls)
    result = m.relocated_run('compact_residents', stops=('child.again', 'child.compact_failed'))
    assert result['stop'] == 'child.again' and m.vm_value('trace_reason') == 0
    assert m.value('current_psp_seg') == m.value('dos_exec_identity_psp') == m.segment
    assert m.chain()[m.segment]['owner'] == m.segment
    assert m.chain()[SHELL] == dict(owner=SHELL, size=0x10)
    cases.append(dict(name='captured_low_parent_space_no_duplicate_staging',
                      image_paras=need, before=before, after=free_memory(m.chain())))
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix='ciukios-low-compact-') as tmp:
        directory = Path(tmp)
        kernel, labels = assemble(directory)
        vmfork, vm_labels = assemble_vmfork(directory, labels)
        cases = run_cases(lambda embedded=False: CompactionMachine(kernel, labels, vmfork, vm_labels,
                                                                   embedded=embedded))
        report = dict(status='pass', kernel_sha256=hashlib.sha256(kernel).hexdigest(),
                      vmfork_sha256=hashlib.sha256(vmfork).hexdigest(), cases=cases)
        if args.out_dir:
            args.out_dir.mkdir(parents=True, exist_ok=True)
            (args.out_dir / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
