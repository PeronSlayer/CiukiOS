#!/usr/bin/env python3
"""Verify production codec, PCM timing and guest refill ordering; no T23 emulation claim."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', type=Path, default=ROOT / 'build/tests/session-audio')
a = p.parse_args()
out = a.output.resolve()
out.mkdir(parents=True, exist_ok=True)
exe = out / 'test-session-audio'
flags = ['-std=c99', '-Wall', '-Wextra', '-Werror', '-pedantic', '-O1', '-g',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer']
subprocess.run([os.environ.get('CC', 'cc'), *flags, '-I' + str(ROOT / 'src/vm'),
                str(ROOT / 'src/vm/session_audio.c'),
                str(ROOT / 'src/vm/test_session_audio.c'), '-lm', '-o', str(exe)], check=True)
r = subprocess.run([str(exe)], text=True, capture_output=True,
                   env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1',
                        'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'})
(out / 'test.log').write_text(r.stdout + r.stderr)
print(r.stdout + r.stderr, end='')
r.check_returncode()
scheduler_exe = out / 'test-session-audio-scheduler'
subprocess.run([os.environ.get('CC', 'cc'), *flags, '-Wno-int-to-pointer-cast',
                '-I' + str(ROOT / 'src/vm'),
                str(ROOT / 'src/vm/session_audio.c'),
                str(ROOT / 'src/vm/guest_peripherals.c'),
                str(ROOT / 'src/vm/test_session_audio_scheduler.c'),
                '-o', str(scheduler_exe)], check=True)
scheduler = subprocess.run([str(scheduler_exe)], text=True, capture_output=True,
                          env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1',
                               'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'})
(out / 'scheduler.log').write_text(scheduler.stdout + scheduler.stderr)
print(scheduler.stdout + scheduler.stderr, end='')
scheduler.check_returncode()
wc = Path(os.environ.get('WATCOM', '/opt/watcom'))
compiler = wc / 'binl64/wcc386'
if not compiler.exists(): compiler = wc / 'binl/wcc386'
subprocess.run([str(compiler), '-zq', '-bt=nt', '-mf', '-3r', '-ecc', '-zl', '-s',
                '-ox', '-ot', '-w4', '-we', '-i=' + str(wc / 'h'),
                '-fo=' + str(out / 'session_audio.obj'), str(ROOT / 'src/vm/session_audio.c')], check=True)
subprocess.run([str(compiler), '-zq', '-bt=nt', '-mf', '-3r', '-ecc', '-zl', '-s',
                '-ox', '-ot', '-w4', '-we', '-i=' + str(wc / 'h'),
                '-fo=' + str(out / 'session_devices.obj'), str(ROOT / 'src/vm/session_devices.c')], check=True)
sources = ['src/vm/session_audio.c', 'src/vm/session_audio.h',
           'src/vm/test_session_audio.c', 'src/vm/session_devices.c',
           'src/vm/session_devices.h', 'src/vm/guest_peripherals.c',
           'src/vm/test_session_audio_scheduler.c',
           'scripts/test_session_audio.py']
(out / 'report.json').write_text(json.dumps({
    'passed': True, 'scope': 'production codec, converter and descriptor transport with delayed guest IRQ fixture',
    'hardware_validated': False, 'rates': [8000,11025,16000,22050,32000,44100,48000],
    'duration_seconds_per_rate': 2,
    'checks': ['CAS before every transaction', 'posted VRA and DAC rate completion',
               'bounded busy and absent codec', 'rate-before-VRA restoration',
               'master volume and mute preserved', 'no buffer-dependent pitch or frame drift',
               'stereo and full-scale interpolation', '8-kHz input workspace',
               'short source batches preserve rational interpolation phase',
               '32 fresh guest DMA blocks and 32 acknowledged IRQs',
               'negative control reproduces stale PCM and collapsed IRQs',
               'partial descriptors yield after guest DSP acknowledgement',
               'masked IRQ wait bounded by configured period and actual queue',
               'FIFO error and DMA halt counters', 'CVDV/CVAT 128-byte layouts',
               'ASan/UBSan', 'OpenWatcom target compilation'],
    'sources': {s: hashlib.sha256((ROOT / s).read_bytes()).hexdigest() for s in sources}
}, indent=2) + '\n')
