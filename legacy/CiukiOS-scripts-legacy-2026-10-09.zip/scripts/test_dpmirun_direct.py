#!/usr/bin/env python3
"""Execute assembled DPMIRUN routing/tails; no firmware or hardware claims."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn import x86_const as x
from test_launch_trace_com import Machine, BASE, STOP, compile_com
from test_vmfork_pinned_ancestors import vm_symbols


def return_call(m):
    sp = m.u.reg_read(x.UC_X86_REG_SP)
    ip = struct.unpack('<H', m.u.mem_read(BASE + sp, 2))[0]
    m.u.reg_write(x.UC_X86_REG_SP, sp + 2)
    m.u.reg_write(x.UC_X86_REG_IP, ip)


class BoundaryMachine(Machine):
    def interrupt(self, u, number, data):
        if number == 0x21 and u.reg_read(x.UC_X86_REG_AH) == 0x4d:
            self.exit_observed = True
            u.reg_write(x.UC_X86_REG_AX, getattr(self, 'return_exit', 1))
            u.reg_write(x.UC_X86_REG_EFLAGS, 0x246)
        else:
            super().interrupt(u, number, data)

    def code(self, u, address, size, data):
        if address == self.symbol('exec'):
            self.path = bytes(u.mem_read(BASE + u.reg_read(x.UC_X86_REG_DX), 128)).split(b'\0')[0]
            return_call(self)
            u.reg_write(x.UC_X86_REG_AX, 2 if self.exec_failure else 0)
            self.carry(self.exec_failure)
        elif address == self.symbol('vm_mode.end'):
            self.exec_done = True
            u.emu_stop()
        elif address == 0x50000 and u.reg_read(x.UC_X86_REG_AX) in (0x43, 0x4a):
            u.reg_write(x.UC_X86_REG_CX, 1)
            self.carry(False)
        else:
            super().code(u, address, size, data)


def call(m, name):
    m.exec_done = False
    m.u.reg_write(x.UC_X86_REG_SP, 0xff00)
    m.u.mem_write(BASE + 0xff00, struct.pack('<H', STOP - BASE))
    m.u.emu_start(m.symbol(name), 0, count=1000000)
    assert m.exec_done, name
    return bool(m.u.reg_read(x.UC_X86_REG_EFLAGS) & 1)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--old-binary', type=Path)
    p.add_argument('--old-listing', type=Path)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    image, labels = compile_com(a.output, 'dpmirun')
    rows = []
    cases = [
        (' /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM', True, b''),
        (' /C C:\\APPS\\GAME.EXE -warp 1 1', True, b' -warp 1 1'),
        (' /c \\apps\\game.eXe\t-nomusic', True, b'\t-nomusic'),
        (' /C RUN C:\\APPS\\GAME.COM a=b', True, b' a=b'),
        (' /C C:\\APPS\\GAME.EXE  a  b ', True, b'  a  b '),
        (' /C C:\\APPS\\GAME.BAT a', False, None),
        (' /C C:\\APPS\\GAME', False, None),
        (' /C GAME.EXE', False, None),
        (' /C APPS\\GAME.EXE', False, None),
        (' /C echo hello', False, None),
        (' /W', False, None),
    ]
    for operator in ('<', '>', '|', '&', '"', '%', '^'):
        cases.append((' /C C:\\APPS\\GAME.EXE ' + operator + 'x', False, None))
    cases.append((' /C C:\\GAME.EXE ' + 'a' * 110, True, b' ' + b'a' * 110))
    for tail, expected, arguments in cases:
        m = Machine(image, labels)
        m.mode = 'direct'
        raw = tail.encode('ascii')
        assert len(raw) <= 126
        original = bytes([len(raw)]) + raw + b'\r'
        m.u.mem_write(m.symbol('child_tail'), original)
        absolute = not call(m, 'command_program')
        if absolute:
            call(m, 'vm_direct_command')
        direct = bool(m.u.mem_read(m.symbol('vm_direct'), 1)[0])
        assert direct == expected, (tail, direct)
        assert bytes(m.u.mem_read(m.symbol('child_tail'), len(original))) == original
        if direct:
            length = m.u.mem_read(m.symbol('vm_direct_tail'), 1)[0]
            actual = bytes(m.u.mem_read(m.symbol('vm_direct_tail') + 1, length + 1))
            assert actual == arguments + b'\r', (tail, actual, arguments)
        # Observe the actual VM-mode dispatcher, stopping before DOS EXEC.
        def observe(u, address, size, _):
            if address != m.symbol('exec'):
                return
            name = bytes(u.mem_read(BASE + u.reg_read(x.UC_X86_REG_DX), 128)).split(b'\0')[0]
            expected_name = m.bytestring('program') if direct else b'\\COMMAND.COM'
            assert name == expected_name, (tail, name, expected_name)
            packet = bytes(u.mem_read(m.symbol('params'), 4))
            offset = struct.unpack_from('<H', packet, 2)[0]
            assert offset == labels['vm_direct_tail' if direct else 'child_tail']
            m.exec_done = True
            u.emu_stop()
        from unicorn import UC_HOOK_CODE
        m.u.hook_add(UC_HOOK_CODE, observe)
        call(m, 'vm_mode.exec')
        rows.append(dict(tail=tail, direct=direct, original_tail_preserved=True,
                         actual_dispatch_observed=True))
    boundaries = []
    for failed in (False, True):
        m = BoundaryMachine(image, labels)
        m.mode = 'wait'
        m.exec_failure = failed
        m.exit_observed = False
        m.u.mem_write(m.symbol('entry'), struct.pack('<HH', 0, 0x5000))
        m.u.mem_write(m.symbol('vm_parent_trace'), b'\1')
        call(m, 'vm_mode.exec')
        record = bytes(m.u.mem_read(m.symbol('vm_launch_record'), 256))
        stage, ax, flags = struct.unpack_from('<H', record, 12)[0], *struct.unpack_from('<HH', record, 18)
        assert stage == (76 if failed else 77)
        assert ax == (2 if failed else 1)
        assert bool(flags & 1) == failed
        assert m.exit_observed == (not failed)
        assert m.u.mem_read(m.symbol('exit_code'), 1)[0] == 1
        boundaries.append(dict(exec_failure=failed, stage=stage, ax=ax, flags=flags,
                               carry_preserved=True, exit_observed=m.exit_observed))
    negative = None
    hosts = []
    for failed, exit_ax in ((False, 0x300), (False, 0x301), (False, 0x302), (False, 3), (False, 4), (True, None)):
        m = BoundaryMachine(image, labels)
        m.mode = 'wait'
        m.exec_failure = failed
        m.exit_observed = False
        m.return_exit = exit_ax
        m.u.mem_write(m.symbol('entry'), struct.pack('<HH', 0, 0x5000))
        m.u.mem_write(m.symbol('vm_parent_trace'), b'\1')
        carry = call(m, 'load_host')
        assert carry == (failed or (exit_ax & 0xff) >= 3)
        record = bytes(m.u.mem_read(m.symbol('vm_launch_record'), 256))
        assert record[246:248] == b'DP'
        host_ax, flags, observed_ax = struct.unpack_from('<HHH', record, 248)
        assert host_ax == (2 if failed else 0)
        assert bool(flags & 1) == failed
        assert bool(record[254] & 2) == (not failed)
        assert observed_ax == (0xffff if failed else exit_ax)
        hosts.append(dict(exec_failure=failed, exit_ax=exit_ax, carry=carry,
                          retained_host_ax=host_ax, retained_exit_ax=observed_ax))
    if a.old_binary:
        assert a.old_listing, '--old-listing required'
        old = a.old_binary.read_bytes()
        assert hashlib.sha256(old).hexdigest() == 'dd0f75b57fb2382b414756b93b86a3b6a4bd9a210d1cad7832ce534fb455b63b'
        m = BoundaryMachine(old, vm_symbols(a.old_listing.read_text(), len(old)))
        m.mode = 'wait'
        m.exec_failure = True
        m.exit_observed = False
        call(m, 'vm_mode.exec')
        assert m.path == b'\\COMMAND.COM'
        record = bytes(m.u.mem_read(m.symbol('vm_launch_record'), 256))
        assert struct.unpack_from('<H', record, 18)[0] == 0
        negative = dict(exact_shipped_r12=True, dispatch=m.path.decode(),
                        exec_ax_not_recorded=True)
    r = dict(passed=True, hardware_qualified=False, cases=rows,
             boundaries=boundaries, old_negative_control=negative,
             dpmi_host_status=hosts,
             binary_sha256=hashlib.sha256(image).hexdigest())
    (a.output / 'report.json').write_text(json.dumps(r, indent=2) + '\n')
    print(f'DPMIRUN direct EXEC: {len(rows)} cases PASS')


if __name__ == '__main__':
    main()
