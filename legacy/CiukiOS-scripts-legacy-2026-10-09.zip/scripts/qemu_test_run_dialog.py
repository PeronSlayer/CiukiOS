#!/usr/bin/env python3
"""RUN.APP input/selection/alias gate, using only QEMU keyboard/mouse events.

Run alone in a capped user scope after the full build. The map and RUN.APP must
match the image exactly. Guest RAM is observed to verify text before launch;
screenshots and launch/window markers qualify the visible behavior separately.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import subprocess
import time

from qemu_run_dialog import run_dialog
from qemu_test_installed_hdd import FAT16
from qemu_test_native_utilities import Utilities
from qemu_test_native_windows import WindowVM

ROOT = Path(__file__).resolve().parents[1]


def position_pointer(ui, x, y):
    # Run changes the pointer to an I-beam over its editor. Observe the actual
    # PS/2 hotspot instead of matching the historical arrow's pixel mask.
    # Movement still enters through QEMU; these RAM observations are read-only.
    for _ in range(32):
        ui.refresh()
        px, py = ui.w('ui_mouse_x'), ui.w('ui_mouse_y')
        if abs(px - x) <= 1 and abs(py - y) <= 1:
            ui.until(lambda: ui.b('ui_composing') == 0 and ui.b('ui_pointer_visible') == 1,
                     'Completed pointer presentation', 10)
            return px, py
        speed = max(1, ui.b('app_set_mouse'))
        dx = max(-127, min(127, math.ceil(abs(x - px) / speed) * (1 if x > px else -1))) if x != px else 0
        dy = max(-127, min(127, math.ceil(abs(y - py) / speed) * (1 if y > py else -1))) if y != py else 0
        ui.vm.hmp(f'mouse_move {dx} {dy} 0')
        ui.until(lambda: (ui.w('ui_mouse_x'), ui.w('ui_mouse_y')) != (px, py),
                 'Real PS/2 pointer motion', 8)
    raise AssertionError(f'Pointer did not reach {(x, y)}')


def display_binding(ui):
    ui.refresh()
    values = {name: ui.w(name) for name in
              ('ui_width', 'ui_height', 'vc_mode', 'vc_pitch', 'ui_mode_request')}
    values.update({name: ui.b(name) for name in ('ui_vbe', 'vc_lfb', 'vc_lfb_ok')})
    values['vc_lfb_base'] = struct.unpack_from('<I', ui.ram, ui.offset('vc_lfb_base'))[0]
    return values


def qualification_record(raw):
    assert len(raw) == 400 and raw[:8] == b'CG3D\x00\x01\x10\x00', 'Invalid S3 qualification record'
    result, error = struct.unpack_from('<II', raw, 8)
    assert result == 0x301 and error != 0, 'Unsupported adapter did not stop at the first stage'
    snapshots = []
    for data in (raw[16:208], raw[208:400]):
        assert data[:8] == b'CVGD\x00\x01\xc0\x00', 'Missing resident display readback'
        words = struct.unpack('<48I', data)
        snapshots.append(dict(backend=words[2], ready=words[3], width=words[4], height=words[5],
                              pitch=words[6], depth=words[7], physical=words[11], bytes=words[12],
                              native_caps=words[15] & 7))
    before, after = snapshots
    assert before == after, 'Rejected qualification changed the resident framebuffer/capabilities'
    assert after['backend'] != 3 and after['native_caps'] == 0, 'Unsupported adapter gained S3 capabilities'
    return dict(result=result, error=error, before=before, after=after,
                sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, default=ROOT / 'build/full/ciukios-full.img')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    disk = out / 'disk.img'
    shutil.copyfile(args.image, disk)
    shell, listing = out / 'SHELL.COM', out / 'SHELL.lst'
    subprocess.run(['nasm', '-f', 'bin', '-l', str(listing), '-o', str(shell),
                    'src/com/shell.asm'], cwd=ROOT, check=True)
    fat = FAT16(disk)
    assert fat.read('SYSTEM/SHELL.COM') == shell.read_bytes(), 'SHELL listing does not match image'
    del fat
    report = dict(passed=False, physical_tested=False,
                  shell_sha256=hashlib.sha256(shell.read_bytes()).hexdigest(), checks={})
    vm = WindowVM(disk, out, 'std', memory=512, palette='platinum')
    closed = False
    try:
        vm.ready()
        vm.key('esc')
        ui = Utilities(vm, shell.read_bytes(), listing)
        run = run_dialog(ui)
        run.open()
        run.replace('alpha beta gamma')
        vm.key('ctrl-a')
        selected = run.until(lambda s: sorted((s['anchor'], s['cursor'])) == [0, 16],
                             'Ctrl+A did not select the whole command')
        vm.shot('run-select-all')
        run.type_only('alpha beta gamma')
        run.until(lambda s: s['text'] == 'alpha beta gamma', 'Typing did not replace selection')
        vm.key('home')
        vm.key('ctrl-shift-right')
        word = run.until(lambda s: s['anchor'] != s['cursor'], 'Ctrl+Shift+Right did not select a word')
        a, b = sorted((word['anchor'], word['cursor']))
        assert word['text'][a:b].strip() == 'alpha', word
        run.type_only('z')
        run.until(lambda s: s['text'] == 'z' + word['text'][b:], 'Word replacement lost unselected text')
        run.replace('alpha beta gamma')
        ui.refresh()
        x, y = ui.w('ui_window_x', 1), ui.w('ui_window_y', 1)
        position_pointer(ui, x + 38, y + 85)
        ui.until(lambda: ui.b('ui_cursor_type') == 1, 'Run editor did not expose the I-beam cursor')
        for _ in range(2):
            vm.hmp('mouse_button 1'); time.sleep(.07)
            vm.hmp('mouse_button 0'); time.sleep(.07)
        double = run.until(lambda s: s['text'][min(s['anchor'], s['cursor']):max(s['anchor'], s['cursor'])] == 'alpha',
                           'Double click did not select the first word')
        vm.shot('run-double-click-word')
        report['checks']['selection'] = dict(select_all=selected, keyboard_word=word, double_click=double)
        run.replace('tab focus')
        offset = vm.offset()
        vm.key('tab')
        vm.wait('[DESKTOP] PAINT', offset, 10)
        run.type_only('x')
        time.sleep(.2)
        assert run.state()['text'] == 'tab focus', 'Tab did not leave the command editor'
        vm.key('shift-tab')
        run.type_only('y')
        run.until(lambda s: s['text'] == 'y', 'Shift+Tab did not select and return to the command editor')
        report['checks']['tab_shift_tab'] = True
        run.replace('')
        vm.key('ret')
        run.until(lambda s: s['text'] == '', 'Empty Enter modified the editor')
        ui.until(lambda: ui.b('ui_active_window') == 1, 'Empty Enter closed Run')
        report['checks']['empty_enter_keeps_run'] = True
        vm.key('esc')
        ui.until(lambda: ui.b('ui_window_flags', 1) == 0, 'Run did not close')
        aliases = []
        for command, window, marker in (
                ('  AbOuT  ', 2, '[DESKTOP] WINDOW 02 OPEN'),
                ('ExPlOrEr C:\\SYSTEM', 8, '[FILES] list C:\\SYSTEM')):
            run.open()
            run.replace(command)
            offset = vm.offset()
            vm.key('ret')
            vm.wait('[RUN] launch ' + command.lstrip(), offset, 20)
            vm.wait(marker, offset, 30)
            ui.until(lambda: ui.b('ui_active_window') == window, 'Alias opened the wrong window')
            aliases.append(dict(command=command, window=window, marker=marker))
            vm.shot('run-alias-' + str(window))
            vm.key('alt-f4')
            ui.until(lambda: ui.b('ui_window_flags', window) == 0, 'Alias window did not close')
        report['checks']['aliases'] = aliases
        binding_before = display_binding(ui)
        run.open()
        run.replace('DISPLAY qualify')
        offset = vm.offset()
        vm.key('ret')
        vm.wait('[RUN] launch DISPLAY qualify', offset, 20)
        vm.wait('[DISPLAY] acceleration preparing', offset, 30)
        vm.wait('[DISPLAY] acceleration failed', offset, 30)
        # Complete one real dialog interaction before taking the notice shot.
        paint_offset = vm.offset()
        vm.key('tab')
        vm.wait('[DESKTOP] PAINT', paint_offset, 20)
        vm.shot('display-unsupported-acceleration')
        binding_after = display_binding(ui)
        assert binding_after == binding_before, 'Qualification changed the desktop video binding'
        vm.close()
        closed = True
        raw = FAT16(disk).read('SYSTEM/VIDEO/S3QUAL.LOG')
        (out / 'S3QUAL.LOG').write_bytes(raw)
        report['checks']['display_unsupported_acceleration'] = dict(
            log=qualification_record(raw), binding_before=binding_before, binding_after=binding_after)
        report['passed'] = True
    except Exception as error:
        report['error'] = str(error)
        if not closed:
            vm.shot('failure')
        raise
    finally:
        if not closed:
            vm.close()
        (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
