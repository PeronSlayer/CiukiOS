#!/usr/bin/env python3
"""Execute the assembled kernel runtime initializer and its real RTSV services.

Only INT 12h is modeled (returns 639 KiB). No compatibility claim is made.
"""
import argparse
import json
import struct
from pathlib import Path

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR
from unicorn.x86_const import *

from test_ps2_boot import symbol

ROOT = Path(__file__).resolve().parents[1]
RUNTIME_SEG = 0x0300
BASE = RUNTIME_SEG << 4
STACK_SEG = 0x7000
STOP = 0xFF00


def execute(kernel_path, listing_path, *, mutation=None, expect_success=True, flags=0x202, default_drive=3):
    kernel = bytearray(kernel_path.read_bytes())
    listing = listing_path.read_text()
    service_table = symbol(listing, 'runtime_service_table')
    if mutation:
        offset, value = mutation
        kernel[service_table + offset:service_table + offset + len(value)] = value

    u = Uc(UC_ARCH_X86, UC_MODE_16)
    u.mem_map(0, 0x100000)
    u.mem_write(BASE, bytes(kernel))
    u.reg_write(UC_X86_REG_CS, RUNTIME_SEG)
    u.reg_write(UC_X86_REG_DS, 0x1111)
    u.reg_write(UC_X86_REG_ES, 0x2222)
    u.reg_write(UC_X86_REG_SS, STACK_SEG)
    start_sp = 0xFFF0
    u.reg_write(UC_X86_REG_SP, start_sp - 2)
    u.reg_write(UC_X86_REG_EFLAGS, flags)
    # Supply a meaningful DOS default drive so the actual state-pointer service
    # and default-drive service can be checked after the routine returns.
    u.mem_write(BASE + symbol(listing, 'dos_default_drive'), bytes((default_drive,)))
    u.mem_write((STACK_SEG << 4) + start_sp - 2, struct.pack('<H', STOP))
    service_targets = {BASE + symbol(listing, name): name for name in (
        'kernel_runtime_dos_version_service', 'kernel_runtime_get_state_ptr_service',
        'kernel_runtime_default_drive_service')}
    far_services = []
    def code(uc, address, size, user_data):
        if address in service_targets:
            far_services.append(service_targets[address])
    def interrupt(uc, number, user_data):
        if number != 0x12:
            raise AssertionError(f'unexpected software interrupt {number:02x}')
        uc.reg_write(UC_X86_REG_AX, 639)
    u.hook_add(UC_HOOK_CODE, code)
    u.hook_add(UC_HOOK_INTR, interrupt)
    entry = symbol(listing, 'stage1_runtime_init')
    u.emu_start(BASE + entry, BASE + STOP, count=250000)
    assert u.reg_read(UC_X86_REG_IP) == STOP, 'runtime initializer did not return within budget'

    result = {
        'image_bytes': len(kernel),
        'declared_image_bytes': struct.unpack_from('<H', kernel, 20)[0],
        'carry': bool(u.reg_read(UC_X86_REG_EFLAGS) & 1),
        'stack_restored': u.reg_read(UC_X86_REG_SP) == start_sp,
        'segments_restored': (u.reg_read(UC_X86_REG_DS), u.reg_read(UC_X86_REG_ES)) == (0x1111, 0x2222),
        'if_restored': bool(u.reg_read(UC_X86_REG_EFLAGS) & 0x200) == bool(flags & 0x200),
        'far_service_entries': far_services,
    }
    for key in ('stack_restored', 'segments_restored', 'if_restored'):
        assert result[key], f'{key} failed for {kernel_path}'

    cache = {name: struct.unpack('<H', u.mem_read(BASE + symbol(listing, name), 2))[0]
             for name in ('runtime_status_flags', 'runtime_table_off', 'runtime_table_seg',
                          'runtime_service_off', 'runtime_service_seg',
                          'runtime_state_off', 'runtime_state_seg')}
    result['cache'] = cache
    table_hdr = bytes(u.mem_read(BASE + service_table, 10))
    result['table_header'] = table_hdr.hex()
    if expect_success:
        assert not result['carry'], f'valid RTSV image failed initialization: {result}'
        assert cache['runtime_status_flags'] & 1, 'runtime cache valid bit was not set'
        assert cache['runtime_table_seg'] == RUNTIME_SEG and cache['runtime_table_off'] == service_table, \
            'runtime cache does not point at the live RTSV table'
        assert cache['runtime_state_seg'] == RUNTIME_SEG, 'state pointer segment cache is wrong'
        state_sig = symbol(listing, 'kernel_runtime_state_signature')
        assert cache['runtime_state_off'] == state_sig, 'state pointer cache is wrong'
        state_default = symbol(listing, 'kernel_runtime_state_default_drive')
        assert u.mem_read(BASE + state_default, 1)[0] == default_drive, \
            'default-drive service did not synchronize the live state'
        assert far_services == ['kernel_runtime_dos_version_service',
                                'kernel_runtime_get_state_ptr_service',
                                'kernel_runtime_default_drive_service'], \
            f'expected real version/state/default-drive far calls: {far_services}'
        assert cache['runtime_service_seg'] == RUNTIME_SEG and \
            cache['runtime_service_off'] == symbol(listing, 'kernel_runtime_default_drive_service'), \
            'cached RTSV service pointer is not the live default-drive service'
    else:
        assert result['carry'], f'expected RTSV rejection was accepted: {mutation or kernel_path}'
        assert cache == {name: 0 for name in cache}, f'failure did not clear runtime cache: {cache}'
        assert not far_services, f'malformed header reached a far service call: {far_services}'
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--kernel', type=Path, required=True)
    p.add_argument('--listing', type=Path, required=True)
    p.add_argument('--old-kernel', type=Path, required=True)
    p.add_argument('--old-listing', type=Path, required=True)
    p.add_argument('--padded-kernel', type=Path)
    p.add_argument('--padded-listing', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()

    good = {'normal': execute(a.kernel, a.listing)}
    if a.padded_kernel:
        if not a.padded_listing:
            p.error('--padded-listing is required with --padded-kernel')
        good['padded'] = execute(a.padded_kernel, a.padded_listing)
    elif a.padded_listing:
        p.error('--padded-kernel is required with --padded-listing')

    bad_headers = {
        'magic': (0, b'NOPE'),
        'abi': (4, struct.pack('<H', 3)),
        'service_count': (6, struct.pack('<H', 12)),
        'descriptor_stride': (8, struct.pack('<H', 16)),
    }
    malformed = {name: execute(a.kernel, a.listing, mutation=value, expect_success=False)
                 for name, value in bad_headers.items()}
    old = execute(a.old_kernel, a.old_listing, expect_success=False)
    assert old['carry'], 'frozen preflight kernel unexpectedly accepted its 13-service RTSV table'
    assert old['cache']['runtime_status_flags'] == 0, 'old kernel failure did not clear the cache'

    report = {
        'scope': 'assembled stage1_runtime_init and actual RTSV far services; INT 12h modeled as 639 KiB',
        'corrected_images': good,
        'malformed_headers': malformed,
        'frozen_preflight_old_image': old,
        'old_image_failure': 'CF=1: old validator expected 11 services while image RTSV table declares 13',
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(report, indent=2) + '\n')
    print('PASS corrected runtime init, bounded malformed-header failures, and frozen old-image failure')


if __name__ == '__main__':
    main()
