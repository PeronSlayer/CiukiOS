#!/usr/bin/env python3
"""CPU checks for the read-only Files menu/input observer, not guest execution."""
import json
import struct

from qemu_files_game_launch import files_menu_state, observed_double_click


def menu_fixture():
    data = bytearray(2048)
    titles = []
    at = 0x180
    for title in (b'&File', b'&Edit', b'&View', b'&Go', b'&Help', b'&Details', b'Sort by &Name'):
        titles.append(at)
        data[at:at + len(title) + 1] = title + b'\0'
        at += len(title) + 1
    for i, count in enumerate((11, 6, 12, 14, 3)):
        struct.pack_into('<3H', data, 0x600 + i * 6, titles[i], 0x680, count)
    struct.pack_into('<7H', data, 0x640, 0x600, 5, 317, 234, 774, 2, 1)
    struct.pack_into('<H', data, 0x640 + 14, 1)
    struct.pack_into('<4H', data, 0x680 + 2 * 8, titles[5], 0, 17, 4)
    struct.pack_into('<4H', data, 0x680 + 4 * 8, titles[6], 0, 18, 4)
    return data


class Input:
    def __init__(self, dispatch, shift=0):
        self.time = 0.
        self.button = self.downs = 0
        self.dispatch, self.shift = dispatch, shift
        self.events = []

    def clock(self):
        return self.time

    def sleep(self, seconds):
        self.time += seconds

    def send(self, button):
        self.time += .01
        self.button = button
        self.downs += bool(button)

    def observe(self):
        self.time += .01
        return dict(buttons=self.button, previous=self.button, capture=9 if self.button else 0,
                    active=8, shift=self.shift, ticks=int(self.time * 18), host_ticks=int(self.time * 18))

    def executed(self):
        return self.dispatch and self.downs == 2 and not self.button


def main():
    data = menu_fixture()
    state = files_menu_state(data)
    assert state['active'] == 2 and state['opened'] and state['details'] and state['name']
    struct.pack_into('<3H', data, 0x640 + 10, 0xffff, 0, 0)
    assert files_menu_state(data, state['binding'])['active'] == -1
    for fault in ('pointer', 'range', 'command', 'duplicate_bar', 'duplicate_table'):
        damaged = bytearray(data)
        if fault == 'pointer':
            damaged[0x640] = 1
        elif fault == 'range':
            damaged[0x640 + 10:0x640 + 12] = b'\x06\0'
        elif fault == 'command':
            damaged[0x680 + 4 * 8 + 4] = 19
        elif fault == 'duplicate_bar':
            damaged[0x750:0x750 + 30] = damaged[0x640:0x640 + 30]
        else:
            damaged[0x790:0x790 + 30] = damaged[0x600:0x600 + 30]
        try:
            files_menu_state(damaged)
        except AssertionError:
            pass
        else:
            raise AssertionError(f'Invalid/ambiguous menu accepted: {fault}')
    for dispatch, shift in ((True, 0), (False, 0), (False, 4)):
        source = Input(dispatch, shift)
        try:
            result = observed_double_click(source.send, source.observe, source.executed, timeout=.5,
                                           clock=source.clock, sleep=source.sleep, record=source.events.append)
        except AssertionError:
            assert not dispatch
            assert any('error' in event for event in source.events)
            assert source.downs == (1 if shift else 2), 'Failed pair was blindly replayed'
        else:
            assert dispatch and result['attempts'] == 1
        assert source.button == 0, 'Physical button remained pressed'
    print(json.dumps(dict(status='PASS', menu_cases=7, input_cases=3, hardware_evidence=False)))


if __name__ == '__main__':
    main()
