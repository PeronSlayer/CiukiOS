#!/usr/bin/env python3
"""Apply a real Display preview, then exercise the installed DOOM.COM wrapper.

Use a capped user scope, alone. QEMU covers the BIOS bank path, not S3 silicon.
All guest writes go to a private copy. Verify Run text, game input/frame changes,
menu quit, desktop return and a second opening. Failure retains bounded RAM.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time

import numpy as np
from PIL import Image
from doom_screen import gameplay_screen, menu_skulls, selected_row, statusbar_patterns
from qemu_test_installed_hdd import FAT16
from qemu_test_native_utilities import Utilities
from qemu_test_native_windows import WindowVM
from qemu_observed_pointer import ObservedPointerMixin
from qemu_files_game_launch import launch_testgames_from_files
from inspect_dosvm_snapshot import parse_snapshot
from inspect_vmfork_launch import parse_launch
from inspect_disk_ata import parse_disk_binding, parse_disk_status
from s3_guest_launch_evidence import completed_guest_launch
from qemu_run_dialog import run_dialog


class T23WindowVM(ObservedPointerMixin, WindowVM):
    """Use actual PS/2 feedback once the matching shell listing is bound."""


ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def assemble_shell(output):
    shell = output / 'assembled-SHELL.COM'
    listing = output / 'SHELL.lst'
    subprocess.run([
        'nasm', '-f', 'bin', '-l', str(listing), '-o', str(shell),
        'src/com/shell.asm',
    ], cwd=ROOT, check=True)
    return shell, listing


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--image', type=Path, default=Path('build/full/ciukios-full.img'))
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--vga', choices=('std', 'cirrus'), default='cirrus')
    p.add_argument('--memory', type=int, default=512)
    p.add_argument('--game', default=r'C:\DESKTOP\TestGames\DOOM.COM')
    p.add_argument('--game-args', default='-warp 1 1 -nomusic')
    p.add_argument('--launch-method', choices=('run', 'files'), default='run')
    p.add_argument('--skip-display', action='store_true')
    p.add_argument('--background-display', action='store_true',
                   help='leave Display Properties open behind Files and both DOS launches')
    p.add_argument('--display-only', action='store_true')
    p.add_argument('--game-timeout', type=int, default=60)
    p.add_argument('--require-native-disk', action='store_true',
                   help='require a bound ATA device and native read/write progress in both launches')
    p.add_argument('--s3-resident-fixture', '--force-s3-guest-fixture', action='store_true',
                   help='install benign test-only S3-shaped INT10 TSR on the private image')
    p.add_argument('--s3-stale-parent', action='store_true',
                   help='set only the verified test resident parent to zero after installation')
    a = p.parse_args()
    if a.launch_method == 'files' and a.game_args:
        p.error('--launch-method files requires an empty --game-args value')
    if a.s3_resident_fixture and (a.vga != 'std' or a.launch_method != 'files'
                                   or a.game_args or not a.skip_display or a.display_only):
        p.error('--s3-resident-fixture requires --vga std --launch-method files --game-args '' --skip-display')
    if a.s3_stale_parent and not a.s3_resident_fixture:
        p.error('--s3-stale-parent requires --s3-resident-fixture')
    if a.require_native_disk and a.display_only:
        p.error('--require-native-disk requires the DOS launches')
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    image = a.image.resolve()
    before = digest(image)
    disk = out / 'disk.img'
    shutil.copyfile(image, disk)
    fixture_binary = None
    parent_fixture_binary = None
    if a.s3_resident_fixture:
        fixture_binary = out / 'S3SHIM.COM'
        subprocess.run(['nasm', '-f', 'bin', 'src/probes/vm/s3shim.asm',
                        '-o', str(fixture_binary)], cwd=ROOT, check=True)
        volume = f'{disk}@@{FAT16(disk).start}'
        existing_test = subprocess.run(['mdir', '-i', volume, '::SYSTEM/TEST'],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if existing_test.returncode:
            subprocess.run(['mmd', '-i', volume, '::SYSTEM/TEST'], check=True)
        subprocess.run(['mcopy', '-o', '-i', volume, str(fixture_binary),
                        '::SYSTEM/TEST/S3SHIM.COM'], check=True)
        if a.s3_stale_parent:
            parent_fixture_binary = out / 'S3PARENT.COM'
            subprocess.run(['nasm', '-f', 'bin', 'src/probes/vm/s3parent.asm',
                            '-o', str(parent_fixture_binary)], cwd=ROOT, check=True)
            subprocess.run(['mcopy', '-o', '-i', volume, str(parent_fixture_binary),
                            '::SYSTEM/TEST/S3PARENT.COM'], check=True)
        existing = FAT16(disk)
        names = ['DOSVM.LOG'] + [f'{family}{slot}.BIN'
                                for family in ('VMFORK', 'DOSVM') for slot in range(1, 4)]
        for name in names:
            try:
                existing.read('SYSTEM/' + name)
            except KeyError:
                continue
            subprocess.run(['mdel', '-i', volume, '::SYSTEM/' + name], check=True)
    shell_binary, listing = assemble_shell(out)
    fat = FAT16(disk)
    shipped_shell = fat.read('SYSTEM/SHELL.COM')
    assert shell_binary.read_bytes() == shipped_shell, (
        'freshly assembled SHELL.COM differs from the source image; refusing stale RAM offsets')
    vm = None
    report = dict(passed=False, vga=a.vga, memory_mib=a.memory,
                  game=a.game, game_args=a.game_args, launch_method=a.launch_method,
                  physical_tested=False, s3_resident_fixture=a.s3_resident_fixture,
                  background_display=a.background_display,
                  require_native_disk=a.require_native_disk, native_disk_launches=[],
                  shell_sha256=hashlib.sha256(shipped_shell).hexdigest(),
                  shell_listing=listing.name,
                  shell_listing_sha256=hashlib.sha256(listing.read_bytes()).hexdigest(),
                  requested_commands=[], game_commands=[], events=[])
    ui = None
    s3_fixture = None

    def shot(name):
        path = vm.shot(name)
        with Image.open(path) as im:
            im.save(path.with_suffix('.png'))
            return im.size

    def type_run(command):
        assert len(command) <= 96, 'Run field command exceeds its capacity'
        start = vm.offset()
        run = run_dialog(ui)
        run.open()
        attempts = run.replace(command, delay=.15)
        report['requested_commands'].append(command)
        report['events'].append(dict(name='Run command verified', command=command,
                                     attempts=attempts))
        vm.key('ret')  # submit the focused Run editor; no obsolete shell action ID
        return start

    def read_physical(address, size, name):
        path = out / (name + '.bin')
        vm.hmp(f'pmemsave {address} {size} "{path}"')
        raw = path.read_bytes()
        assert len(raw) == size, (name, len(raw), size)
        return raw

    def install_s3_fixture():
        original = read_physical(0x40, 4, 's3-host-vector-before')
        offset = vm.offset()
        vm.key('f4')
        vm.wait('CiukiOS SHELL C:\\APPS>', offset, 60)
        offset = vm.offset()
        vm.text(r'\SYSTEM\TEST\S3SHIM.COM')
        vm.wait('S3SHIM installed: TEST ONLY, forwarding INT10.', offset, 30)
        vm.wait('CiukiOS SHELL C:\\APPS>', offset, 30)
        vector = read_physical(0x40, 4, 's3-host-vector-installed')
        handler, segment = struct.unpack('<HH', vector)
        assert handler == 0x48 and 0x1200 <= segment < 0xa000, (handler, segment)
        mcb = read_physical((segment - 1) << 4, 16, 's3-host-mcb-installed')
        assert mcb[0] in b'MZ'
        owner, paragraphs = struct.unpack_from('<HH', mcb, 1)
        assert owner == segment and 0x20 <= paragraphs <= 0x500
        resident = read_physical(segment << 4, paragraphs << 4, 's3-host-resident-installed')
        assert resident[0x40:0x44] == b'fK\x60\0'
        assert resident[0x51:0x55] == original
        old_parent = struct.unpack_from('<H', resident, 0x16)[0]
        if a.s3_stale_parent:
            offset = vm.offset()
            vm.text(r'\SYSTEM\TEST\S3PARENT.COM')
            vm.wait('S3PARENT: TEST ONLY, resident parent set to zero.', offset, 30)
            vm.wait('CiukiOS SHELL C:\\APPS>', offset, 30)
            changed = read_physical(segment << 4, paragraphs << 4, 's3-host-resident-stale-parent')
            expected = bytearray(resident)
            expected[0x16:0x18] = bytes(2)
            assert changed == expected, 'S3PARENT changed more than the test resident parent'
            resident = changed
        report['s3_fixture'] = dict(binary_sha256=digest(fixture_binary),
                                   original_vector=original.hex(), host_vector=vector.hex(),
                                   segment=segment, paragraphs=paragraphs,
                                   original_parent=old_parent, stale_parent=a.s3_stale_parent,
                                   parent_fixture_sha256=digest(parent_fixture_binary) if parent_fixture_binary else None,
                                   resident_sha256=hashlib.sha256(resident).hexdigest(), launches=[])
        offset = vm.offset()
        vm.text('exit')
        vm.ready(offset)
        return dict(vector=vector, segment=segment, paragraphs=paragraphs, resident=resident)

    def verify_s3_fixture(label):
        vector = read_physical(0x40, 4, label + '-s3-host-vector')
        resident = read_physical(s3_fixture['segment'] << 4, s3_fixture['paragraphs'] << 4,
                                 label + '-s3-host-resident')
        assert vector == s3_fixture['vector'], 'guest changed system VM INT10 vector'
        assert resident == s3_fixture['resident'], 'guest changed system VM fixture resident'
        deadline = time.monotonic() + 5
        candidates = []
        while time.monotonic() < deadline:
            candidates = []
            fresh = FAT16(disk)
            for slot in range(1, 4):
                try:
                    raw = fresh.read(f'SYSTEM/VMFORK{slot}.BIN')
                except KeyError:
                    continue
                if len(raw) != 256 or raw[:8] != b'CVFL\x01\0\0\x01':
                    continue
                vm_id, generation, stage, reason, progress = struct.unpack_from('<5H', raw, 8)
                if vm_id == slot and progress & 0x400 and stage == 8 and reason == 0:
                    try:
                        manager_raw = fresh.read(f'SYSTEM/DOSVM{slot}.BIN')
                        manager = completed_guest_launch(raw, manager_raw, slot)
                    except (KeyError, ValueError):
                        continue
                    if manager is not None:
                        candidates.append((generation, slot, raw, manager_raw))
            if candidates:
                break
            time.sleep(.1)
        assert candidates, 'no completed launch diagnostic proves S3 guest detachment'
        generation, slot, raw, manager_raw = max(candidates)
        launches = report['s3_fixture']['launches']
        assert not any(item['vm_id'] == slot and item['generation'] == generation for item in launches), \
            'second launch reused a stale diagnostic generation'
        s3_psp, previous_offset, previous_segment, s3_paras = struct.unpack_from('<4H', raw, 50)
        assert s3_psp == s3_fixture['segment'] and s3_paras == s3_fixture['paragraphs']
        assert struct.pack('<HH', previous_offset, previous_segment) == bytes.fromhex(report['s3_fixture']['original_vector'])
        (out / (label + '-VMFORK.BIN')).write_bytes(raw)
        (out / (label + '-DOSVM.BIN')).write_bytes(manager_raw)
        launches.append(dict(label=label, vm_id=slot, generation=generation, stage=stage,
                             progress=progress, host_vector_unchanged=True,
                             host_resident_unchanged=True))

    def window_geometry(owner):
        ui.refresh()
        return (ui.w('ui_window_x', owner), ui.w('ui_window_y', owner),
                ui.w('ui_window_width', owner), ui.w('ui_window_height', owner))

    def game_frame(name):
        path = vm.shot(name)
        with Image.open(path) as frame:
            x, y, width, height = window_geometry(11)
            # DOSVM paints precisely the client from TITLE_H to its 3px frame.
            client = frame.convert('RGB').crop((x + 3, y + 30,
                                                 x + width - 3, y + height - 3))
        assert client.width > 0 and client.height > 0, f'{name}: empty DOOM client {client.size}'
        client = client.resize((640, 400), Image.Resampling.NEAREST)
        client.save(out / (name + '-client.png'))
        return client

    def wait_menu_row(expected, name, timeout=8, position=(97, 64), rows=6):
        deadline = time.monotonic() + timeout
        current = None
        while time.monotonic() < deadline:
            current = selected_row(game_frame(name), sprites, position, rows)
            if current == expected:
                report['events'].append(dict(name='DOOM menu row observed',
                                             screenshot=name, row=expected))
                return
            time.sleep(.25)
        raise AssertionError(f'{name}: DOOM menu row {current}, expected {expected}')

    def game_key(key, hold_ms=150):
        vm.hmp(f'sendkey {key} {hold_ms}')
        # Leave a complete idle interval between menu confirmations. The
        # one-CPU validation scope also schedules framebuffer capture and the
        # desktop; observing a menu frame alone does not prove key-up has been
        # consumed by the guest. Keep every transition assertion below.
        time.sleep(hold_ms / 1000 + 1.0)

    def start_game(label):
        if a.background_display:
            assert ui.b('ui_window_flags', 18) == 1 and ui.w('app_segs', 10), \
                'Display Properties must remain loaded during the launch'
        command = a.game + (' ' + a.game_args if a.game_args else '')
        report['game_commands'].append(command)
        if a.launch_method == 'files':
            assert a.game.upper() == r'C:\DESKTOP\TESTGAMES\DOOM.COM', a.game
            start, evidence = launch_testgames_from_files(vm, ui, disk, 'DOOM.COM')
            report['events'].append(evidence)
        else:
            start = type_run(command)
        vm.wait('[DOSVM] open', start, 30)
        vm.wait('[DOSVM] fork', start, 30)
        ui.until(lambda: ui.b('ui_window_flags', 11) == 1
                 and ui.b('ui_active_window') == 11 and ui.w('app_segs', 8) != 0,
                 'DOOM native DOS window did not become active', 30)
        vm.wait('[DOOM] Using the active DOS session audio devices', start, 30)
        vm.wait('ST_Init: Init status bar.', start, a.game_timeout)
        if '-warp' not in a.game_args.split():
            # The shipping shortcut opens the title sequence, not a level.
            # Wait for graphical pixels before navigating its real menus.
            deadline = time.monotonic() + a.game_timeout
            while True:
                title = np.asarray(game_frame(label + '-title'))
                colours = len(np.unique(title.reshape(-1, 3), axis=0))
                visible = int(np.any(title > 20, axis=2).sum())
                if colours > 32 and visible > 20000:
                    break
                assert time.monotonic() < deadline, 'DOOM title graphics never became visible'
                time.sleep(.25)
            # The title can be presented while the first demo's resources
            # are still loading. An Escape sent during that startup phase
            # may be discarded by the game. Observe the actual menu before
            # continuing; retain every failed attempt in the report.
            for attempt in range(3):
                game_key('esc')
                try:
                    wait_menu_row(0, label + '-title-menu', timeout=30)
                    break
                except AssertionError:
                    report['events'].append(dict(name='title Escape not yet acknowledged',
                                                  attempt=attempt + 1, screenshot=label))
                    if attempt == 2:
                        raise
            game_key('ret')
            wait_menu_row(0, label + '-episode-menu', position=(48, 63), rows=4)
            game_key('ret')
            wait_menu_row(2, label + '-skill-menu', position=(48, 63), rows=5)
            game_key('ret')
        # ST_Init precedes level loading and I_InitGraphics. A black client at
        # that marker is not evidence of a hang, nor a valid gameplay baseline.
        ready_start = time.monotonic()
        deadline = ready_start + a.game_timeout
        while True:
            first = game_frame(label + '-running')
            readiness = gameplay_screen(first, statusbar, sprites)
            # A skill-menu Enter may still be queued. Require the actual WAD
            # statusbar and disappearance of all three menus before input.
            if readiness['matched']:
                break
            assert time.monotonic() < deadline, (
                f'DOOM did not reach gameplay: {readiness}')
            time.sleep(.25)
        report['events'].append(dict(name='DOOM gameplay HUD ready', screenshot=label,
                                    seconds=round(time.monotonic() - ready_start, 3),
                                    evidence=readiness))
        vm.hmp('sendkey right 900')
        time.sleep(.6)
        moved = game_frame(label + '-after-input')
        assert gameplay_screen(moved, statusbar, sprites)['matched'], \
            'DOOM left its gameplay HUD or reopened a menu during the input check'
        a_pixels = np.asarray(first)[:300]
        b_pixels = np.asarray(moved)[:300]
        changed = int(np.any(a_pixels != b_pixels, axis=2).sum())
        report['events'].append(dict(name='DOOM gameplay input changed frame',
                                     screenshot=label, changed_pixels=changed))
        assert changed > 640 * 300 * .01, \
            f'DOOM gameplay did not respond to input: changed {changed} client pixels'
        return start

    def verify_native_disk(label):
        previous = report['native_disk_launches']
        deadline = time.monotonic() + 5
        candidates = []
        while time.monotonic() < deadline:
            fresh = FAT16(disk)
            for slot in range(1, 4):
                try:
                    raw = fresh.read(f'SYSTEM/VMFORK{slot}.BIN')
                    launch = parse_launch(raw)
                except (KeyError, ValueError):
                    continue
                if any((item['vm'], item['generation']) ==
                       (launch['vm'], launch['generation']) for item in previous):
                    continue
                if (launch['stage'] == 8 and launch['reason'] == 0
                        and launch['target_exec_returned'] and launch['exit_code'] == 0):
                    candidates.append((launch, raw))
            if candidates:
                break
            time.sleep(.1)
        assert len(candidates) == 1, 'expected one new successful native-disk launch diagnostic'
        launch, raw = candidates[0]
        native = launch['native_disk']
        assert native and native['state'] == 2 and native['error'] == 0, native
        assert native['control_known'] and native['binding_error'] == 0, native
        old_reads = previous[-1]['native_disk']['read_count'] if previous else 1
        old_writes = previous[-1]['native_disk']['write_count'] if previous else 0
        assert native['read_count'] > old_reads, 'launch has no new native ATA reads'
        assert native['write_count'] > old_writes, 'launch has no new native ATA writes'
        boundary_raw = fresh.read(f"SYSTEM/DPMIRUN{launch['vm']}.BIN")
        boundary = parse_launch(boundary_raw)
        assert boundary['generation'] == launch['generation'], boundary
        assert boundary['stage'] == 77 and boundary['last_dos_ax'] == 0, boundary
        assert not boundary['last_dos_carry'], boundary
        host = boundary['dpmi_host']
        assert host and host['exec_attempted'] and not host['exec_carry'], host
        assert host['exit_observed'] and host['exit_code'] in (0, 1, 2), host
        assert host['direct_command'], 'GUI command retained its intermediate interpreter'
        (out / (label + '-DPMIRUN.BIN')).write_bytes(boundary_raw)
        (out / (label + '-VMFORK.BIN')).write_bytes(raw)
        binding_raw = fresh.read('SYSTEM/DISKBIND.BIN')
        binding_parameters = parse_disk_binding(binding_raw)
        (out / (label + '-DISKBIND.BIN')).write_bytes(binding_raw)
        previous.append(dict(label=label, vm=launch['vm'], generation=launch['generation'],
                             native_disk=native, binding_parameters=binding_parameters,
                             dpmi_launch_boundary=boundary))

    def quit_game(start, label):
        game_key('esc')
        wait_menu_row(0, label + '-menu-new-game')
        for row in range(1, 6):
            game_key('down')
            wait_menu_row(row, label + f'-menu-row-{row}')
        game_key('ret')
        time.sleep(.5)
        confirmation = game_frame(label + '-quit-confirmation')
        assert selected_row(confirmation, sprites, (97, 64), 6) is None, \
            'DOOM did not open its quit confirmation after selecting Quit Game'
        game_key('y')
        vm.wait('[DOOM] DOS session game returned', start, 60)
        vm.wait('[DOSVM] ended', start, 60)
        ui.until(lambda: ui.b('ui_window_flags', 11) == 1
                 and ui.w('app_segs', 8) != 0 and ui.b('ui_active_window') == 11,
                 'finished DOOM window disappeared before the user closed it', 15)
        finished = np.asarray(game_frame(label + '-finished-message'))
        message_pixels = int(np.any(finished > 150, axis=2).sum())
        assert message_pixels > 200, 'finished DOS window remained an empty black client'
        report['events'].append(dict(name='finished DOS window shows status',
                                     screenshot=label + '-finished-message',
                                     message_pixels=message_pixels))
        shot(label + '-finished-window')
        vm.key('alt-f4')
        vm.wait('[DESKTOP] WINDOW 11 CLOSE', start, 20)
        ui.until(lambda: ui.b('ui_window_flags', 11) == 0
                 and ui.w('app_segs', 8) == 0 and ui.b('ui_active_window') != 11,
                 'Alt+F4 did not close/unload the finished DOSVM window', 20)
        report['events'].append(dict(name='DOOM exited, then DOS window closed with Alt+F4',
                                     screenshot=label, app_slot=8, window=11))
        shot(label + '-desktop-return')
        if a.require_native_disk:
            verify_native_disk(label)

    def clean_hmp(command):
        raw = vm.hmp(command).decode(errors='replace')
        return '\n'.join(line for line in raw.splitlines()
                         if '\x1b' not in line and line.strip() != '(qemu)')

    try:
        vm = T23WindowVM(disk, out, a.vga, boot_capture=True, memory=a.memory,
                      palette='platinum')
        report['qemu'] = vm.process.args
        vm.ready()
        shell = shipped_shell
        wad = fat.read('APPS/DOOM/DOOM.WAD')
        sprites = menu_skulls(wad)
        statusbar = statusbar_patterns(wad)
        ui = Utilities(vm, shell, listing)
        vm.bind_pointer_observer(ui)
        report['pointer_observer'] = 'read-only shell hotspot; real PS/2 motion and buttons'
        report['initial_size'] = shot('initial')
        # Dismiss the initial About window using its public keyboard action.
        vm.key('esc')
        if a.s3_resident_fixture:
            s3_fixture = install_s3_fixture()
        if not a.skip_display:
            start = type_run('DISPLAY')
            vm.wait('[DISPLAY] adapter', start, 30)
            vm.wait('[DESKTOP] PAINT', start, 20)
            vm.key('1')
            vm.key('home')
            vm.key('ret')
            vm.wait('[DISPLAY] preview', start, 20)
            deadline = time.monotonic() + 8
            while time.monotonic() < deadline:
                size = shot('preview')
                if size == (640, 480):
                    break
                time.sleep(.2)
            assert size == (640, 480), f'preview remained {size}'
            report['preview_size'] = size
            # Mode switching is deferred; the first 640 frame can precede
            # Display's poll and its confirmation dialog.
            time.sleep(1.5)
            vm.key('ret')
            vm.wait('[DISPLAY] kept', start, 20)
            report['confirmed_size'] = shot('confirmed')
            assert report['confirmed_size'] == (640, 480)
            vm.key('esc')
        if a.background_display:
            start = type_run('DISPLAY')
            vm.wait('[DISPLAY] open', start, 30)
            ui.until(lambda: ui.b('ui_window_flags', 18) == 1 and
                     ui.w('app_segs', 10) != 0,
                     'Display Properties was not loaded', 30)
            report['events'].append(dict(name='Display Properties left open',
                                         window=18, app_slot=10))
        if not a.display_only:
            assert a.game.upper().replace('/', '\\') == r'C:\DESKTOP\TESTGAMES\DOOM.COM', \
                'This gate exercises the shipped TestGames DOOM.COM launcher'
            wrapper = fat.read('APPS/DOOM/DOOM.COM')
            core = fat.read('APPS/DOOM/DOOMCORE.EXE')
            # The independent FAT reader resolves DOS names; TestGames is a
            # VFAT name. mtools resolves its stored alias without assuming it.
            launcher = subprocess.check_output([
                'mtype', '-i', f'{disk}@@{fat.start}',
                '::DESKTOP/TestGames/DOOM.COM'])
            assert wrapper != core, 'APPS/DOOM/DOOM.COM unexpectedly aliases the DOOM core'
            assert b'\\APPS\\DOOM\\DOOM.COM\0' in launcher.upper(), \
                'TestGames DOOM.COM does not EXEC the installed wrapper'
            report['doom_wrapper_sha256'] = hashlib.sha256(wrapper).hexdigest()
            report['testgames_launcher_sha256'] = hashlib.sha256(launcher).hexdigest()
            start = start_game('doom-first')
            report['game_size'] = shot('doom-running')
            quit_game(start, 'doom-first')
            if a.s3_resident_fixture:
                verify_s3_fixture('doom-first')
            start = start_game('doom-second')
            quit_game(start, 'doom-second')
            if a.s3_resident_fixture:
                verify_s3_fixture('doom-second')
            report['doom_com_launches'] = 2
        report['passed'] = True
    except Exception as error:
        report['error'] = repr(error)
        if vm:
            try:
                shot('failure')
                report['registers'] = clean_hmp('info registers')
                report['pic'] = clean_hmp('info pic')
                report['pit'] = clean_hmp('info qtree')
                vm.hmp('stop')
                vm.hmp(f'pmemsave 0 0x1000000 "{out / "failure-16m.bin"}"')
                vm.hmp('cont')
            except Exception as capture_error:
                report['capture_error'] = repr(capture_error)
    finally:
        if vm:
            vm.close()
        fs = FAT16(disk)
        for name in ('DISPLAY.LOG', 'DOSVM.LOG', 'DISKATA.BIN', 'DISKBIND.BIN',
                     *(f'DPMIRUN{slot}.BIN' for slot in range(1, 4)),
                     *(f'VMFORK{slot}.BIN' for slot in range(1, 4))):
            try:
                (out / name).write_bytes(fs.read('SYSTEM/' + name))
            except KeyError:
                pass
        try:
            report['disk_binding_parameters'] = parse_disk_binding(fs.read('SYSTEM/DISKBIND.BIN'))
        except (KeyError, ValueError) as error:
            report['disk_binding_parameters_error'] = str(error)
        try:
            report['native_disk_binding'] = parse_disk_status(fs.read('SYSTEM/DISKATA.BIN'))
            if a.require_native_disk and not report['native_disk_binding']['native_ready']:
                report['passed'] = False
                report.setdefault('error', 'ATA binding did not succeed; BIOS fallback cannot pass this gate')
        except (KeyError, ValueError) as error:
            if a.require_native_disk:
                report['passed'] = False
                report.setdefault('error', f'ATA binding diagnostic unavailable: {error}')
        report['dosvm_snapshots'] = []
        for slot in range(1, 4):
            name = f'DOSVM{slot}.BIN'
            try:
                raw = fs.read('SYSTEM/' + name)
            except KeyError:
                continue
            (out / name).write_bytes(raw)
            try:
                report['dosvm_snapshots'].append(parse_snapshot(raw))
            except ValueError as error:
                report['passed'] = False
                report.setdefault('error', f'{name}: invalid physical diagnostic {error}')
        if not a.display_only:
            try:
                dosvm_log = fs.read('SYSTEM/DOSVM.LOG').decode('cp437', 'replace')
                normalized = dosvm_log.upper()
                expected_log_text = a.game_args.strip().upper() or 'DOOM.COM'
                logged = normalized.count(expected_log_text)
                report['requested_command_log'] = dosvm_log
                report['logged_game_commands'] = logged
                if logged < len(report['game_commands']):
                    report['passed'] = False
                    report.setdefault('error', 'DOSVM.LOG did not record every requested DOOM command')
            except (KeyError, OSError) as log_error:
                report['passed'] = False
                report.setdefault('error', f'DOSVM.LOG unavailable for command verification: {log_error!r}')
        disk.unlink(missing_ok=True)
        report['source_unchanged'] = digest(image) == before
        (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('passed', 'source_unchanged', 'error')
                      if k in report}), flush=True)
    return 0 if report['passed'] and report['source_unchanged'] else 1


if __name__ == '__main__':
    sys.exit(main())
