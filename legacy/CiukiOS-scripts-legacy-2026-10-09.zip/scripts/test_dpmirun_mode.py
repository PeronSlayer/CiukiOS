#!/usr/bin/env python3
"""Execute actual DPMIRUN declaration probe/host branch with bounded DOS I/O.

The file contents and DOS results are fixture inputs; the production parser,
header validation, close-success gate, and host-routing instructions execute.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

from unicorn import x86_const as x
from test_launch_trace_com import Machine, BASE, STOP, ROOT, compile_com
from test_dpmirun_direct import return_call
from inspect_vmfork_launch import parse_launch


class ModeMachine(Machine):
    def __init__(self, image, symbols, payload, failure=None):
        super().__init__(image, symbols)
        self.payload, self.failure = payload, failure
        self.accesses, self.host_calls = [], 0
        self.mode = 'declaration'
        self.u.mem_write(self.symbol('vm_launch_record') + 8, struct.pack('<HH', 1, 2))

    def interrupt(self, u, number, data):
        ax = u.reg_read(x.UC_X86_REG_AX)
        if number != 0x21 or ax >> 8 not in (0x3d, 0x3f, 0x3e):
            return super().interrupt(u, number, data)
        ah = ax >> 8
        self.accesses.append(ah)
        self.carry(False)
        if ah == 0x3d:
            path = bytes(u.mem_read(BASE + u.reg_read(x.UC_X86_REG_DX), 128)).split(b'\0')[0]
            assert path == self.bytestring('program')
            u.reg_write(x.UC_X86_REG_AX, 2 if self.failure == 'open' else 7)
            self.carry(self.failure == 'open')
        elif ah == 0x3f:
            assert u.reg_read(x.UC_X86_REG_BX) == 7
            assert u.reg_read(x.UC_X86_REG_CX) == 16
            data = self.payload[:16]
            u.mem_write(BASE + u.reg_read(x.UC_X86_REG_DX), data)
            u.reg_write(x.UC_X86_REG_AX, 5 if self.failure == 'read' else len(data))
            self.carry(self.failure == 'read')
        else:
            assert u.reg_read(x.UC_X86_REG_BX) == 7
            u.reg_write(x.UC_X86_REG_AX, 5 if self.failure == 'close' else 0)
            self.carry(self.failure == 'close')

    def code(self, u, address, size, data):
        if address == self.symbol('find_session'):
            self.carry(False)
            return_call(self)
        elif address == self.symbol('load_host'):
            self.host_calls += 1
            self.carry(False)
            return_call(self)
        elif address == self.symbol('vm_mode.run'):
            self.exec_done = True
            u.emu_stop()
        else:
            super().code(u, address, size, data)

    def route(self, tail):
        raw = tail.encode('ascii')
        original = bytes([len(raw)]) + raw + b'\r'
        self.u.mem_write(self.symbol('child_tail'), original)
        self.u.reg_write(x.UC_X86_REG_SP, 0xff00)
        self.u.mem_write(BASE + 0xff00, struct.pack('<H', STOP - BASE))
        self.u.emu_start(self.symbol('vm_mode.session'), 0, count=100000)
        assert self.exec_done
        assert bytes(self.u.mem_read(self.symbol('child_tail'), len(original))) == original
        record = bytes(self.u.mem_read(self.symbol('vm_launch_record'), 256))
        decoded = parse_launch(record)['dpmi_host']
        declared = bool(self.u.mem_read(self.symbol('vm_real_mode'), 1)[0])
        assert decoded['real_mode_declared'] == declared
        assert not decoded['exec_attempted'] and not decoded['exit_observed']
        assert self.host_calls == int(not declared)
        assert self.u.mem_read(self.symbol('window_host'), 1)[0] == int(not declared)
        return dict(tail=tail, declared=declared, host_calls=self.host_calls,
                    dos_accesses=self.accesses, original_tail_preserved=True,
                    trace_declaration_preserved=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    image, symbols = compile_com(args.output, 'dpmirun')
    launchers = {}
    for kind in (0, 1, 2):
        target = args.output / f'testgame-{kind}.COM'
        subprocess.run(['nasm', '-f', 'bin', f'-DGAME_KIND={kind}',
                        'src/com/testgame_launch.asm', '-o', str(target)], cwd=ROOT, check=True)
        launchers[kind] = target.read_bytes()
    declaration = b'\xeb\x0eCIUKILCH\x01\x01\x10\x00\x00\x00'
    assert launchers[2][:16] == declaration
    assert all(launchers[k][:16] != declaration for k in (0, 1))
    base = ' /C C:\\DESKTOP\\TESTGA~1\\WOLF3D.COM'
    cases = [(base, launchers[2], None, True),
             (' /c \\apps\\wolf3d\\Wolf3d.cOm\t-nowait', launchers[2], None, True),
             (base, launchers[0], None, False),
             (base, launchers[1], None, False)]
    for i in range(16):
        bad = bytearray(declaration)
        bad[i] ^= 0x80
        cases.append((base, bytes(bad), None, False))
    for count in (0, 1, 2, 8, 15):
        cases.append((base, declaration[:count], None, False))
    for failure in ('open', 'read', 'close'):
        cases.append((base, declaration, failure, False))
    for tail in (' /C C:\\APPS\\GAME.EXE', ' /C C:\\APPS\\GAME.BAT',
                 ' /C C:\\APPS\\GAME.COM >OUT.TXT', ' /C WOLF3D.COM',
                 ' /W', ' /C echo hello'):
        cases.append((tail, declaration, None, False))
    rows = []
    for tail, payload, failure, expected in cases:
        result = ModeMachine(image, symbols, payload, failure).route(tail)
        assert result['declared'] == expected, (failure, result)
        result.update(payload_bytes=len(payload), failure=failure)
        rows.append(result)
    report = dict(passed=True, hardware_qualified=False, cases=rows,
                  binary_sha256=hashlib.sha256(image).hexdigest(),
                  launcher_sha256={k: hashlib.sha256(v).hexdigest() for k, v in launchers.items()},
                  owned_paragraphs=(symbols['image_end'] + 15) // 16,
                  wolf_shortcut_owned_paragraphs=(len(launchers[2]) + 0x100 + 15) // 16)
    (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'DPMIRUN launch declaration: {len(rows)} cases PASS')


if __name__ == '__main__':
    main()
