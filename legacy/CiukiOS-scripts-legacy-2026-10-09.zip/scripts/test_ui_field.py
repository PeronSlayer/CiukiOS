#!/usr/bin/env python3
"""Execute the production single-line selection editor under ASan/UBSan."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def paint_functions():
    source = (ROOT / "src/apps/paint.c").read_text()
    pieces = []
    for name in ("text_extent", "text_position", "text_at", "text_contains", "text_key"):
        start = source.index("static ", source.index("\nstatic ", source.index("#define TEXT_MAX")))
        while not source[start:source.index("\n", start)].split("(")[0].endswith(name):
            start = source.index("\nstatic ", start + 1) + 1
        # These functions contain balanced C braces and no braces in strings.
        at = source.index("{", start)
        depth = 1
        end = at + 1
        while depth:
            depth += (source[end] == "{") - (source[end] == "}")
            end += 1
        pieces.append(source[start:end])
    return "\n\n".join(pieces) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="ciukios-field-") as work:
        exe = Path(work) / "ui_field_host"
        subprocess.run(["gcc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-g",
                        "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                        "-fno-pie", "-no-pie", str(ROOT / "scripts/fixtures/ui_field_host.c"),
                        "-o", str(exe)], check=True)
        report = json.loads(subprocess.check_output([str(exe)], text=True))
        (Path(work) / "paint_text_actual.inc").write_text(paint_functions())
        paint_exe = Path(work) / "paint_text_host"
        subprocess.run(["gcc", "-std=c11", "-Wall", "-Wextra", "-Werror", "-g",
                        "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                        "-fno-pie", "-no-pie", "-I", work,
                        str(ROOT / "scripts/fixtures/paint_text_host.c"),
                        "-o", str(paint_exe)], check=True)
        report["paint"] = json.loads(subprocess.check_output([str(paint_exe)], text=True))
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
