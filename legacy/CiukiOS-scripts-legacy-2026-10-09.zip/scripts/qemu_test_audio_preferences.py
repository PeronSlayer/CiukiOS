#!/usr/bin/env python3
"""Verify master volume defaults and saved mute on two boots of a private HDD copy.

This exercises QEMU's emulated AC'97 device. It is not evidence for physical
ThinkPad audio output.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import time

from PIL import Image

from analyze_audio_wav import pcm_payload
from qemu_test_full_display_profile import VM


class AudioVM(VM):
    auto_enter_dos = False


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def image_volume(disk):
    with disk.open('rb') as stream:
        boot = stream.read(512)
    start = (0 if boot[54:62] == b'FAT16   ' and
             struct.unpack_from('<H', boot, 11)[0] == 512 else
             struct.unpack_from('<I', boot, 454)[0] * 512)
    return f'{disk}@@{start}'


def image_read(disk, path):
    result = subprocess.run(['mtype', '-i', image_volume(disk), '::' + path],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            check=False)
    if result.returncode:
        raise KeyError(path)
    return result.stdout


def image_delete_if_present(disk, path):
    try:
        image_read(disk, path)
    except KeyError:
        return
    subprocess.run(['mdel', '-i', image_volume(disk), '::' + path], check=True)


def image_write(disk, path, data, staging):
    source = staging / Path(path).name
    source.write_bytes(data)
    subprocess.run(['mcopy', '-o', '-i', image_volume(disk), str(source),
                    '::' + path], check=True)
    assert image_read(disk, path) == data, f'{path} did not persist offline'


def records(disk):
    return image_read(disk, 'SYSTEM/AUDIO.LOG').decode('ascii', errors='replace').splitlines()


def verify_audio_log(lines, expected_master):
    init = next((i for i, line in enumerate(lines)
                 if re.search(r'\bevent=I\b', line)), None)
    start = next((i for i, line in enumerate(lines)
                  if re.search(r'\bevent=S\b', line)), None)
    assert init is not None and start is not None and init < start, lines
    assert re.search(r'\bmaster=' + re.escape(expected_master) + r'\b', lines[init]), lines[init]
    return {'init_record': lines[init], 'startup_record': lines[start]}


def pcm_summary(path, expect_silence):
    raw = path.read_bytes()
    if len(raw) == 44 and raw[:8] == b'RIFF\0\0\0\0' and raw[36:] == b'data\0\0\0\0':
        pcm, bits = b'', 16
    else:
        pcm, bits = pcm_payload(raw)
    assert bits == 16
    if expect_silence:
        assert not any(pcm), 'muted master produced nonzero emulated AC97 PCM'
    else:
        assert any(pcm), 'unmuted startup produced no nonzero emulated AC97 PCM'
    return {'wav_bytes': len(raw), 'pcm_bytes': len(pcm),
            'nonzero_pcm_bytes': sum(value != 0 for value in pcm)}


def boot(disk, output, name):
    run_dir = output / name
    run_dir.mkdir()
    audio = run_dir / 'audio.wav'
    vm = AudioVM(disk, run_dir, qemu_args=[
        '-audiodev', f'wav,id=snd,path={audio}', '-device', 'AC97,audiodev=snd'])
    vm.auto_enter_dos = False
    try:
        vm.wait('[DESKTOP] READY', timeout=120)
        label = '5' if name == 'first' else 'muted' if name == 'second' else 'restored'
        shot = vm.shot(f'desktop-volume-{label}')
        png = shot.with_suffix('.png')
        Image.open(shot).convert('RGB').save(png)
        time.sleep(2.0)  # let the queued startup PCM event finish in the guest
    finally:
        vm.close()
    return audio, png


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, required=True,
                        help='full HDD image produced by the upcoming build')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.image.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    source_hash = sha256(source)
    disk = output / 'test.img'
    shutil.copyfile(source, disk)
    staging = output / 'staging'
    staging.mkdir()

    # Make the first boot unambiguously fresh, with startup audio enabled.
    image_delete_if_present(disk, 'SYSTEM/VOLUME.CFG')
    image_delete_if_present(disk, 'SYSTEM/AUDIO.LOG')
    image_write(disk, 'SYSTEM/BOOT.SND', b'1', staging)
    try:
        image_read(disk, 'SYSTEM/VOLUME.CFG')
    except KeyError:
        pass
    else:
        raise AssertionError('first boot image still contains VOLUME.CFG')

    first_audio, first_png = boot(disk, output, 'first')
    try:
        first_config = image_read(disk, 'SYSTEM/VOLUME.CFG')
    except KeyError:
        first_config = None
    assert first_config is None, first_config
    first_audio_log = verify_audio_log(records(disk), '1A1A')
    first_pcm = pcm_summary(first_audio, expect_silence=False)

    # Inject a distinct valid preference offline, then reboot the same private
    # disk. The packed preference byte is level 12 plus the mute bit (0x8C);
    # the AC'97 master register is 0x9313 after applying it.
    image_write(disk, 'SYSTEM/VOLUME.CFG', b'\x8C', staging)
    image_delete_if_present(disk, 'SYSTEM/AUDIO.LOG')
    second_audio, second_png = boot(disk, output, 'second')
    second_config = image_read(disk, 'SYSTEM/VOLUME.CFG')
    assert second_config == b'\x8C', second_config
    second_audio_log = verify_audio_log(records(disk), '9313')
    second_pcm = pcm_summary(second_audio, expect_silence=True)

    assert sha256(source) == source_hash, 'source image changed during test'
    report = {
        'source_image_sha256_unchanged': source_hash,
        'private_image': str(disk),
        'first_boot': {'volume_cfg': None,
                       'audio_log': first_audio_log, 'audio': first_pcm,
                       'desktop_screenshot': str(first_png)},
        'second_boot': {'volume_cfg_hex': second_config.hex().upper(),
                        'audio_log': second_audio_log, 'audio': second_pcm,
                        'desktop_screenshot': str(second_png)},
        'note': 'Emulated QEMU AC97 evidence only; no physical ThinkPad audio claim.',
    }
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print('[audio-preferences] PASS fresh default and saved muted master across two boots')


if __name__ == '__main__':
    main()
