#!/usr/bin/env python3
"""Run actual 16-bit launcher parsing and mailbox wait code in bounded CPU fixtures."""
import argparse
import json
from pathlib import Path
import struct
import subprocess

from unicorn import Uc, UC_ARCH_X86, UC_MODE_16, UC_HOOK_CODE, UC_HOOK_INTR
from unicorn import x86_const as x
from test_vmfork_pinned_ancestors import vm_symbols

ROOT = Path(__file__).resolve().parents[1]
SEG, BASE, API, STOP = 0x3000, 0x30000, 0x50000, 0x3f000


def compile_com(out, name):
    binary, listing = out/(name+'.COM'), out/(name+'.lst')
    subprocess.run(['nasm','-f','bin','-I',str(out)+'/',
                    'src/com/'+name+'.asm','-o',str(binary),'-l',str(listing)],
                   cwd=ROOT,check=True)
    image=binary.read_bytes()
    return image,vm_symbols(listing.read_text(),len(image))


class Machine:
    def __init__(self,image,symbols):
        self.u=Uc(UC_ARCH_X86,UC_MODE_16); self.u.mem_map(0,0x100000)
        self.u.mem_write(BASE+0x100,image); self.u.mem_write(API,b'\xcb')
        for reg in (x.UC_X86_REG_CS,x.UC_X86_REG_DS,x.UC_X86_REG_ES,x.UC_X86_REG_SS):
            self.u.reg_write(reg,SEG)
        self.u.reg_write(x.UC_X86_REG_SP,0xff00)
        self.u.reg_write(x.UC_X86_REG_EFLAGS,0x202)
        self.symbols=symbols; self.create=None; self.checks=[]; self.waits=0
        self.tail=b''; self.path=b''; self.fail=False; self.exec_done=False
        self.mode='parse'; self.publish_refused=False
        self.u.hook_add(UC_HOOK_INTR,self.interrupt)
        self.u.hook_add(UC_HOOK_CODE,self.code)

    def symbol(self,name): return BASE+self.symbols[name]
    def bytestring(self,name,n=128):
        return bytes(self.u.mem_read(self.symbol(name),n)).split(b'\0',1)[0]
    def carry(self,set_):
        f=self.u.reg_read(x.UC_X86_REG_EFLAGS)
        self.u.reg_write(x.UC_X86_REG_EFLAGS,(f | 1) if set_ else (f & ~1))

    def interrupt(self,u,number,_):
        ax=u.reg_read(x.UC_X86_REG_AX)
        self.carry(False)
        if self.mode=='untraced-entry' and number==0x12:
            self.checks.append('int12');u.emu_stop();return
        if number==0x21:
            if ax>>8==0x52:
                u.reg_write(x.UC_X86_REG_ES,0x4000);u.reg_write(x.UC_X86_REG_BX,0x100)
                u.mem_write(0x400fe,struct.pack('<H',0x1180))
            elif ax>>8 in (0x4a,9): pass
            elif ax>>8==0x62 and self.mode=='traced-entry':
                self.checks.append('get-psp');u.reg_write(x.UC_X86_REG_BX,SEG)
            elif ax>>8==0x4c: self.fail=True;u.emu_stop()
            else: raise AssertionError(('unexpected child DOS access',hex(ax)))
        elif number==0x2f:
            if ax==0x1684:
                u.reg_write(x.UC_X86_REG_ES,0x5000);u.reg_write(x.UC_X86_REG_DI,0)
            elif ax==0x1607:
                u.reg_write(x.UC_X86_REG_ES,0x4000);u.reg_write(x.UC_X86_REG_BX,0x200)
            else: raise AssertionError(hex(ax))
        else: raise AssertionError(number)

    def code(self,u,address,size,_):
        if (self.mode=='parse' and 'disk_prepare_parent' in self.symbols
                and address==self.symbol('disk_prepare_parent')):
            # Parsing/mailbox fixture only. Binding uses the separate real
            # BIOS/disk fixtures; do not invent firmware results here.
            sp=u.reg_read(x.UC_X86_REG_SP)
            ip=struct.unpack('<H',u.mem_read(BASE+sp,2))[0]
            u.reg_write(x.UC_X86_REG_SP,sp+2)
            u.reg_write(x.UC_X86_REG_IP,ip)
        elif self.mode=='dpmi-parse' and address==self.symbol('vm_begin'):
            self.create=1;u.emu_stop()
        elif address==API:
            ax=u.reg_read(x.UC_X86_REG_AX);self.carry(False)
            if ax in (0x41,0x51): self.create=ax;u.emu_stop()
            elif ax==0x40: u.reg_write(x.UC_X86_REG_AX,0)
            elif ax==0x4a and self.mode.endswith('-entry'):
                u.reg_write(x.UC_X86_REG_CX,7)
            elif ax==0x52:
                sub=u.reg_read(x.UC_X86_REG_CX)
                if sub==0:
                    self.checks.append('publish')
                    if self.mode=='traced-entry':
                        pointer=u.reg_read(x.UC_X86_REG_ES)*16+u.reg_read(x.UC_X86_REG_DI)
                        assert struct.unpack_from('<H',u.mem_read(pointer,256),12)[0]==15
                        u.emu_stop()
                    self.carry(self.publish_refused)
                elif sub==3:
                    self.waits+=1; self.checks.append('wait')
                    u.reg_write(x.UC_X86_REG_DX,int(self.waits==1))
                else: raise AssertionError(sub)
            elif ax==0x42:
                assert self.publish_refused and u.reg_read(x.UC_X86_REG_BX)==0xf0e1
                self.checks.append('exit');u.emu_stop()
            else: raise AssertionError(hex(ax))
        elif bytes(u.mem_read(address,1))==b'\xf4' and self.mode=='wait':
            self.checks.append('hlt')
            # Model the canonical HLT returning after VM0 persisted/ACKed.
            u.reg_write(x.UC_X86_REG_IP,(address-BASE+1)&65535)
        elif address==STOP: self.exec_done=True;u.emu_stop()

    def parse(self,tail):
        raw=tail.encode('ascii');assert len(raw)<=126
        self.u.mem_write(BASE+0x80,bytes([len(raw)])+raw+b'\r')
        self.u.emu_start(BASE+0x100,0,count=100000)
        self.path=self.bytestring('program')
        length=self.u.mem_read(self.symbol('child_tail'),1)[0]
        self.tail=bytes(self.u.mem_read(self.symbol('child_tail')+1,length+1))

    def wait(self,refused=False):
        self.mode='wait';self.publish_refused=refused
        self.u.mem_write(self.symbol('entry'),struct.pack('<HH',0,0x5000))
        self.u.mem_write(BASE+0xff00,struct.pack('<H',STOP-BASE))
        self.u.reg_write(x.UC_X86_REG_BX,7)
        self.u.emu_start(self.symbol('launch_mailbox_publish'),0,count=100000)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'kernel_layout.inc').write_text('KL_EXEC_PSP equ 1\nKL_CURRENT_PSP equ 3\n')
    image,symbols=compile_com(a.output,'vmfork');cases=[]
    for tail,op,path,args in (
        (' \\VM\\DPMIRUN.COM /V /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM',0x41,
         b'\\VM\\DPMIRUN.COM',b' /V /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM\r'),
        (' /P \\VM\\DPMIRUN.COM /P /V /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM',0x51,
         b'\\VM\\DPMIRUN.COM',b' /P /V /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM\r'),
        (' \\APPS\\MEMCAP.COM',0x41,b'\\APPS\\MEMCAP.COM',b'\r'),
        (' /PROGRAM.COM /V',0x41,b'/PROGRAM.COM',b' /V\r')):
        m=Machine(image,symbols);m.parse(tail)
        assert (m.create,m.path,m.tail)==(op,path,args),(m.create,m.path,m.tail)
        cases.append('actual VMFORK parser '+tail)
    m=Machine(image,symbols);m.parse(' /P ')
    assert m.fail and m.create is None;cases.append('missing traced target fails before fork')
    for traced in (0,1):
        m=Machine(image,symbols)
        m.mode='traced-entry' if traced else 'untraced-entry'
        m.u.mem_write(m.symbol('entry'),struct.pack('<HH',0,0x5000))
        m.u.mem_write(m.symbol('trace_parent'),bytes([traced]))
        m.u.reg_write(x.UC_X86_REG_BX,1)
        m.u.emu_start(m.symbol('child'),0,count=100000)
        assert m.checks==(['get-psp','publish'] if traced else ['int12']),m.checks
        cases.append('traced child publishes before BIOS/memory probe' if traced
                     else 'ordinary child retains original first memory probe')
    for name in ('vmfork','dpmirun'):
        image,symbols=compile_com(a.output,name)
        if name=='dpmirun':
            for prefix,traced in ((' /V ',0),(' /P /V ',1)):
                m=Machine(image,symbols);m.mode='dpmi-parse'
                m.parse(prefix+'/C C:\\DESKTOP\\TESTGA~1\\DOOM.COM')
                assert m.create==1 and m.tail==b' /C C:\\DESKTOP\\TESTGA~1\\DOOM.COM\r'
                assert m.u.mem_read(m.symbol('vm_parent_trace'),1)[0]==traced
                cases.append('actual DPMIRUN prefix parsing '+prefix)
        m=Machine(image,symbols);m.wait()
        assert m.exec_done and m.checks==['publish','wait','hlt','wait'],m.checks
        cases.append(name+' cannot pass pending checkpoint before ACK')
        m=Machine(image,symbols);m.wait(refused=True)
        assert not m.exec_done and m.checks==['publish','exit'],m.checks
        cases.append(name+' publication refusal exits without child filesystem')
    report={'passed':True,'hardware_validation':False,'cases':cases}
    (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
