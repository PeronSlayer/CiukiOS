#!/usr/bin/env python3
"""Decode completed, interrupted and rejected physical S3 qualification logs."""
import struct
import unittest

from inspect_boot_hardware import parse_gpu_log


def snapshot(stage=0, observed=0):
    data = bytearray(192)
    data[:8] = b'CVGD\x00\x01\xc0\x00'
    struct.pack_into('<4I', data, 16, 1024, 768, 4096, 32)
    struct.pack_into('<I', data, 60, 0x80000000)
    struct.pack_into('<I', data, 72, stage)
    struct.pack_into('<2I', data, 104, 4096, 32)
    struct.pack_into('<I', data, 132, observed)
    return data


def record(result, after=None, error=0):
    return (struct.pack('<4sHHII', b'CG3D', 0x100, 16, result, error) +
            snapshot() + (bytes(192) if after is None else after))


class QualificationLog(unittest.TestCase):
    def test_historical_physical_stop(self):
        log = parse_gpu_log(record(0x000f0102))
        self.assertEqual(log['qualification'],
                         dict(phase=2, setup_prefix=15, state='before call'))
        self.assertFalse(log['after']['available'])

    def test_r7_returned_error(self):
        log = parse_gpu_log(record(0x00150302, snapshot(3, 0x07e00000), 8))
        self.assertEqual(log['qualification'],
                         dict(phase=2, setup_prefix=21, state='returned error'))
        self.assertIsNone(log['after']['data']['s3_status']['setup_readback'])
        self.assertEqual(log['error'], 8)

    def test_predicate_survives_serialization(self):
        for check, observed in enumerate(
                (0x300, 0x2220, 0x10000001, 0, 0x21, 0x11223344, 0x305, 0,
                 0x115500, 0x10080400, 0x115500, 0x10080400, 0x400), 1):
            with self.subTest(check=check):
                log = parse_gpu_log(record(0x00150302,
                    snapshot((check << 16) | 3, observed), 8))
                readback = log['after']['data']['s3_status']['setup_readback']
                self.assertEqual(readback['id'], check)
                self.assertEqual(readback['observed'], observed)
                self.assertNotEqual(readback['masked_observed'], readback['expected'])
                if check == 3:
                    self.assertEqual(readback['expected'], 0x10200401)
                if check == 13:
                    self.assertEqual(readback['register'], 'MM8144 32-bit register access')
                    self.assertEqual(readback['mask'], 0x200)
                self.assertFalse(log['after']['data']['s3_engine_qualified'])

    def test_completed_and_legacy_records(self):
        for result in (0, 1, 2, 3, 0x201, 0x204, 0x00150202):
            with self.subTest(result=result):
                log = parse_gpu_log(record(result, snapshot()))
                self.assertEqual(log['result'], result)
                self.assertTrue(log['after']['available'])

    def test_failed_rollback_is_not_a_register_readback(self):
        log = parse_gpu_log(record(0x00150302, snapshot(8, 0x00200020), 8))
        status = log['after']['data']['s3_status']
        self.assertEqual(status['stage'], 8)
        self.assertEqual(status['last_status'], 0x00200020)
        self.assertIsNone(status['setup_readback'])

    def test_fill_predicate_and_cr50_survive_serialization(self):
        for bpp in (16, 32):
            for check in range(1, 7):
                with self.subTest(bpp=bpp, check=check):
                    original, active = 0x1c, 0xfd if bpp == 32 else 0xdd
                    stage = 0xa0000000 | check << 24 | active << 16 | original << 8 | 4
                    expected = (0x600000 if check == 1 else 0x10000400 | bpp << 16
                                if check == 2 else 0x123456 if bpp == 32 else 0x5aa55aa5)
                    observed = expected ^ 1
                    data = snapshot(stage, observed)
                    struct.pack_into('<I', data, 108, bpp)
                    struct.pack_into('<2I', data, 168, observed, expected)
                    decoded = parse_gpu_log(record(0x303, data, 8))['after']['data']
                    status = decoded['s3_status']
                    self.assertEqual(status['stage'], 4)
                    self.assertIsNone(status['preflight'])
                    self.assertIsNone(status['setup_readback'])
                    proof = status['fill_readback']
                    self.assertTrue(proof['pixel_proof_failed'])
                    self.assertEqual((proof['id'], proof['original_cr50'], proof['active_cr50']),
                                     (check, original, active))
                    self.assertEqual((proof['observed'], proof['expected']), (observed, expected))
                    self.assertIsNone(proof['foreground_color'])
                    self.assertIsNone(proof['original_32bit_register_access'])
                    self.assertEqual(proof['mask'], 0xffffff
                                     if bpp == 32 and check >= 3 else 0xffffffff)
                    self.assertFalse(decoded['s3_engine_qualified'])
                    self.assertFalse(decoded['s3_triangles_qualified'])

    def test_new_fill_tag_retains_foreground_and_original_pixel_separately(self):
        for check in range(1, 7):
            with self.subTest(check=check):
                data = snapshot(0xb0000000 | check << 24 | 0xf13004, 0x00123456)
                struct.pack_into('<2I', data, 168, 0x56565656, 0x00123456)
                decoded = parse_gpu_log(record(0x303, data, 8))['after']['data']
                proof = decoded['s3_status']['fill_readback']
                self.assertEqual(proof['foreground_color'], 0x00123456)
                self.assertEqual(proof['observed'], 0x56565656)
                self.assertEqual(proof['masked_observed'],
                                 0x565656 if check >= 3 else 0x56565656)
                self.assertEqual(proof['original_cr50'], 0x30)
                self.assertEqual(proof['active_cr50'], 0xf1)
                self.assertFalse(decoded['s3_engine_qualified'])

    def test_c_fill_tag_retains_original_register_access_width(self):
        for enabled in (False, True):
            for check in range(1, 7):
                with self.subTest(enabled=enabled, check=check):
                    stage = 0xc0000000 | check << 24 | 0xf13004
                    if enabled:
                        stage |= 0x08000000
                    data = snapshot(stage, 0x56565656)
                    struct.pack_into('<2I', data, 168, 0x56565656, 0x00123456)
                    decoded = parse_gpu_log(record(0x303, data, 8))['after']['data']
                    proof = decoded['s3_status']['fill_readback']
                    self.assertEqual(proof['id'], check)
                    self.assertEqual(proof['original_32bit_register_access'], enabled)
                    self.assertEqual(proof['foreground_color'], 0x56565656)
                    self.assertEqual(proof['observed'], 0x56565656)
                    self.assertEqual(proof['original_cr50'], 0x30)
                    self.assertEqual(proof['active_cr50'], 0xf1)
                    self.assertFalse(decoded['s3_engine_qualified'])
                    self.assertFalse(decoded['s3_triangles_qualified'])

    def test_untagged_historical_fill_and_rollback_do_not_decode_cr50(self):
        for stage in (4, 8):
            with self.subTest(stage=stage):
                status = parse_gpu_log(record(0x303, snapshot(stage, 0x7e00000), 8))[
                    'after']['data']['s3_status']
                self.assertIsNone(status['fill_readback'])
                self.assertIsNone(status['release_readback'])

    def test_release_tag_retains_initial_cause_and_actual_expected_restore(self):
        for check, cause in ((1, 0x70003), (2, 3), (3, 0xd0003), (4, 0xc3f13004)):
            with self.subTest(check=check):
                observed = 0xe000 if check == 3 else 0x00200020
                data = snapshot(0xd0000008 | check << 24 | 0xa3f << 12, observed)
                struct.pack_into('<2I', data, 168, cause, 0x30b)
                decoded = parse_gpu_log(record(0x000f0302, data, 8))['after']['data']
                status = decoded['s3_status']
                self.assertEqual(status['stage'], 8)
                self.assertIsNone(status['preflight'])
                self.assertIsNone(status['setup_readback'])
                self.assertIsNone(status['fill_readback'])
                release = status['release_readback']
                self.assertEqual(release['id'], check)
                self.assertEqual(release['expected_misc_payload'], 0xa3f)
                self.assertEqual(release['observed'], observed)
                self.assertEqual(release['original_error_stage'], cause)
                self.assertEqual(release['original_last_status'], 0x30b)
                self.assertEqual(release['masked_observed'], 0 if check == 3 else None)
                self.assertFalse(decoded['s3_engine_qualified'])
                self.assertFalse(decoded['s3_triangles_qualified'])

    def test_release_tag_cannot_qualify_stale_success_fields(self):
        data = snapshot(0xd3000008, 0xe000)
        struct.pack_into('<I', data, 8, 3)
        struct.pack_into('<2I', data, 64, 1, 7)
        for offset in (140, 156, 160, 188):
            struct.pack_into('<I', data, offset, 1)
        struct.pack_into('<2I', data, 168, 0x70003, 0x70003)
        decoded = parse_gpu_log(record(0x000f0302, data, 8))['after']['data']
        self.assertFalse(decoded['s3_engine_qualified'])
        self.assertFalse(decoded['s3_triangles_qualified'])

    def test_persistent_release_tag_excludes_rsf_and_preserves_legacy(self):
        data = snapshot(0xe3210008, 0xe000)
        struct.pack_into('<2I', data, 168, 3, 0x7e00000)
        decoded = parse_gpu_log(record(0x00090302, data, 8))['after']['data']
        release = decoded['s3_status']['release_readback']
        self.assertEqual(release['expected_misc_payload'], 0x210)
        self.assertEqual(release['mask'], 0xbaf)
        self.assertEqual(release['original_error_stage'], 3)
        self.assertFalse(decoded['s3_engine_qualified'])
        final = snapshot(0xe5010008, 0x200020)
        release = parse_gpu_log(record(0x00090302, final, 8))['after']['data']['s3_status']['release_readback']
        self.assertEqual(release['reason'], 'original RSF replay completion')

    def test_packed_pixel_and_timeout_tags_never_prove_triangles(self):
        for reason in range(1, 8):
            with self.subTest(reason=reason):
                data = snapshot(0xf8f13004 | reason << 24, 0x56565656)
                struct.pack_into('<2I', data, 168, 0x56565656, 0x123456)
                decoded = parse_gpu_log(record(0x303, data, 8))['after']['data']
                fill = decoded['s3_status']['fill_readback']
                self.assertEqual(fill['interface'], 'packed_mmio')
                self.assertTrue(fill['original_32bit_register_access'])
                self.assertEqual(fill['pixel_proof_failed'], reason <= 5)
                self.assertEqual(fill['completion_failed'], reason >= 6)
                self.assertFalse(decoded['s3_engine_qualified'])
                self.assertFalse(decoded['s3_triangles_qualified'])

    def test_tagged_fill_cannot_qualify_stale_triangle_fields(self):
        data = snapshot(0xa3f10004, 0x123457)
        # Deliberately inconsistent/stale successful fields cannot make the
        # failed fill diagnostic into an engine or native triangle proof.
        struct.pack_into('<I', data, 8, 3)
        struct.pack_into('<2I', data, 64, 1, 7)
        for offset in (140, 156, 160, 188):
            struct.pack_into('<I', data, offset, 1)
        struct.pack_into('<2I', data, 168, 0x123457, 0x123457)
        decoded = parse_gpu_log(record(0x303, data, 8))['after']['data']
        self.assertFalse(decoded['s3_engine_qualified'])
        self.assertFalse(decoded['s3_triangles_qualified'])

    def test_malformed_records(self):
        for result in (4, 0x106, 0x402, 0x00010201, 0x00160102, 0xffffffff):
            with self.subTest(result=result), self.assertRaises(ValueError):
                parse_gpu_log(record(result, snapshot()))
        with self.assertRaises(ValueError):
            parse_gpu_log(record(0))  # completed result needs both snapshots

    def test_distinct_packed_2d_phase(self):
        for code, state in ((0x105, 'before call'), (0x205, 'returned success'),
                            (0x305, 'returned error')):
            decoded = parse_gpu_log(record(code, snapshot()))
            self.assertEqual(decoded['qualification'],
                             dict(phase=5, setup_prefix=0, state=state))


if __name__ == '__main__':
    unittest.main()
