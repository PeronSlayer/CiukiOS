"""Drive RUN.APP through real input; read its bound CAPP fields to verify it.

The Watcom map and binary must be from the image being tested. No guest memory
is written and no shell legacy DOS-helper buffer is mistaken for Run's editor.
"""
from pathlib import Path
import re
import struct
import time

from qemu_test_installed_hdd import FAT16

ROOT = Path(__file__).resolve().parents[1]
RUN_SLOT = 14
RUN_WINDOW = 1
KEYS = {' ': 'spc', '.': 'dot', '\\': 'backslash', '-': 'minus',
        '/': 'slash', ':': 'shift-semicolon', '_': 'shift-minus'}


def map_address(text, name):
    found = re.findall(r'^\s*([0-9a-fA-F]{8})[+*]?\s+_' + re.escape(name) + r'\s*$',
                       text, re.MULTILINE)
    assert len(found) == 1, f'RUN.APP map has no unique {name}: {found}'
    return int(found[0], 16)


def decode_state(data, command, field):
    pointer, capacity, length, cursor, selected, scroll, anchor, drag = struct.unpack_from('<8H', data, field)
    assert pointer == command and capacity == 97, 'RUN.APP editor layout differs from the matching map'
    assert length < capacity and cursor <= length and anchor <= length, 'inconsistent Run editor snapshot'
    assert data[command + length] == 0, 'Run text is not terminated at its editor length'
    return dict(text=data[command:command + length].decode('cp437'), length=length,
                cursor=cursor, anchor=anchor, selected=selected, scroll=scroll, drag=drag)


class RunDialog:
    def __init__(self, ui, app_dir=None):
        self.ui = ui
        self.vm = ui.vm
        app_dir = Path(app_dir or ROOT / 'build/full/obj/apps')
        self.binary = (app_dir / 'RUN.APP').read_bytes()
        symbols = (app_dir / 'run.map').read_text()
        self.command = map_address(symbols, 'run_command')
        self.field = map_address(symbols, 'run_input')
        assert self.binary[:4] == b'CAPP'
        self.memory_size = struct.unpack_from('<H', self.binary, 6)[0] * 16
        assert 0x108 <= self.memory_size <= 65536, 'Invalid RUN.APP allocation size'
        assert self.command + 97 <= self.memory_size and self.field + 16 <= self.memory_size
        drive = next((arg for arg in self.vm.process.args
                      if isinstance(arg, str) and arg.startswith('file=') and ',if=ide' in arg), None)
        assert drive, 'Cannot bind Run observation to the QEMU IDE image'
        image = Path(drive.split(',format=', 1)[0][5:])
        assert FAT16(image).read('SYSTEM/APPS/RUN.APP') == self.binary, (
            'RUN.APP in the image differs from the build map/binary; rebuild before using RAM symbols')

    def state(self):
        self.ui.refresh()
        segment = self.ui.w('app_segs', RUN_SLOT)
        assert segment, 'RUN.APP is not loaded'
        path = self.vm.output / 'run-observed.bin'
        # CAPP modules can live in Jemm's paged UMBs. The segment identifies
        # SysVM0 linear memory, not its physical backing. Keep header validation
        # so a snapshot from another VM context can never be accepted as Run.
        path.unlink(missing_ok=True)
        reply = self.vm.hmp(f'memsave {segment * 16} {self.memory_size} "{path}"')
        assert path.exists(), f'RUN.APP virtual memory read failed: {reply!r}'
        data = path.read_bytes()
        assert len(data) == self.memory_size, 'RUN.APP virtual memory read was incomplete'
        assert data[0x100:0x108] == self.binary[:8], 'RUN.APP CAPP header mismatch'
        result = decode_state(data, self.command, self.field)
        result['segment'] = segment
        return result

    def until(self, predicate, description, timeout=10):
        deadline = time.monotonic() + timeout
        current = None
        while time.monotonic() < deadline:
            try:
                current = self.state()
            except AssertionError as error:
                if str(error) not in ('inconsistent Run editor snapshot',
                                      'Run text is not terminated at its editor length'):
                    raise
            else:
                if predicate(current):
                    return current
            time.sleep(.08)
        raise AssertionError(f'{description}: {current}')

    def open(self):
        self.vm.key('f3')
        self.ui.until(lambda: self.ui.b('ui_active_window') == RUN_WINDOW
                      and self.ui.w('app_segs', RUN_SLOT) != 0,
                      'Run CAPP window did not open', 20)

    def type_only(self, text, delay=.06):
        for char in text:
            self.vm.key('shift-' + char.lower() if char.isupper() else KEYS.get(char, char))
            if delay:
                time.sleep(delay)

    def replace(self, command, attempts=3, delay=.06):
        assert len(command.encode('ascii')) <= 96, 'Run field command exceeds its capacity'
        for attempt in range(1, attempts + 1):
            self.vm.key('ctrl-a')
            self.vm.key('delete')
            self.until(lambda s: s['text'] == '', 'Run Ctrl+A/Delete did not clear the text')
            self.type_only(command, delay)
            try:
                self.until(lambda s: s['text'] == command, 'Run did not accept the exact command', 5)
                return attempt
            except AssertionError:
                if attempt == attempts:
                    raise


def run_dialog(ui):
    if not hasattr(ui, '_run_dialog'):
        ui._run_dialog = RunDialog(ui)
    return ui._run_dialog
