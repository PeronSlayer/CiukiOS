# R14 original Wolfenstein startup and explicit real-mode launch

The R14 T23 logs show original Wolfenstein returning 1 normally, with native
ATA healthy, no pinned ancestor blocks and 34,558 paragraphs available in one
block before the game launch chain. This is not a protected-mode fault: the
physical `DESKTOP/TestGames/WOLF3D.COM` targets `APPS/WOLF3D/WOLF3D.EXE`, the
original 16-bit executable. It does not target `WOLF4GW.EXE` or the separate
protected audio wrapper.

The final virtual BIOS mode is 89h, with 253 OPL writes and two DSP commands.
The original binary has an `InitGame` check at file offsets 83B0h/83B9h for
`mminfo.mainmem < 235000`. Its failure path caches ERRORSCREEN 89h, shuts down
the managers and exits 1. These physical counters match that path; the physical
capture does not directly record `mminfo`.

## Primary sources and decision

[id Software's WL_MAIN.C](https://github.com/id-Software/wolf3d/blob/master/WOLFSRC/WL_MAIN.C)
initializes the memory, video, input, page, sound, cache and user managers before
checking the conventional heap. The check is separate from total free DOS
memory. [ID_MM.C](https://github.com/id-Software/wolf3d/blob/master/WOLFSRC/ID_MM.C)
calculates that heap using Turbo C `coreleft`/`farcoreleft` and obtains it with
`malloc`/`farmalloc`.

The [Microsoft DOS reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
defines EXEC/SETBLOCK and the conventional memory arena. A DPMI host provides
protected-mode services described by the
[DPMI specification](https://docs.pcjs.org/specs/dpmi/1991_03_12-DPMI_Spec_v10.pdf);
this original real-mode game does not enter a DPMI client. Loading a resident
32-bit host for it needlessly reduces its conventional heap.

The Wolf TestGames launcher now explicitly declares that its target is real
mode. DPMIRUN reads and validates that declaration before installing HDPMI.
Unknown programs, malformed declarations, EXE files, batch commands and shell
operators retain the existing host path. DOOM retains its existing protected
path. No commercial executable or memory threshold is patched by this fix.

The COM declaration is exactly 16 bytes: `EB 0E`, `CIUKILCH`, version 1,
flags 1 (real mode only), 16-bit size 16 and 16-bit reserved zero. DOS execution
jumps over the declaration. DPMIRUN accepts it only on a validated direct
absolute COM command, after a complete read and successful close. The existing
CVFL `DP` flags byte 254 bit 2 records `real_mode_declared`; record size and
version remain unchanged. The virtual video/device session and stage 75–77
launch checkpoints still execute.

## Bounded original-binary proof

Run without a full build, QEMU or hardware port access:

```sh
uv run --with unicorn python scripts/test_dpmirun_mode.py --output build/tests/dpmirun-mode-r15
uv run --with unicorn python scripts/test_wolf_realmode_memory.py --wolf-exe /run/media/peronslayer/CIUKIOSFULL/APPS/WOLF3D/WOLF3D.EXE --output build/tests/wolf-realmode-memory-r15
```

The Wolf test executes the unchanged original MZ entry, Turbo C initialization,
`MM_Startup`, heap routines and `InitGame` memory-check instructions. Its DOS
allocation, resize, vector and IOCTL calls execute the real full-profile
kernel. Only file loading and BIOS equipment/video/clock are boundaries.

| Controlled launch case | Original `mainmem` | Actual memory-check branch |
| --- | ---: | --- |
| No retained launch/host reservations | 249,690 bytes | Continue |
| R14 retained launcher/HDPMI reservations | 231,786 bytes | Insufficient memory |
| Current declared launcher; resident HDPMI omitted | 242,362 bytes | Continue |

The current assembled DPMIRUN retains 385 paragraphs; the declared shortcut
retains 71. The original game's first resize retains 18,472 paragraphs in all
cases. The R14 reservations use DPMIRUN 340, HDPMI GROUP16 160, permanent TLB
512, client workspace 32 and shortcut 70, each with its real allocator MCB.
The positive control uses current assembled launcher sizes, not those old
constants.

34 declaration cases pass: all 16 individual header-byte corruptions, short
reads, open/read/close errors and shell/direct-command routing controls.
The existing 19 direct-EXEC cases, six host-status cases, exit/EXEC checkpoint
boundaries and 13 launch/mailbox cases also pass.

Original Wolf SHA-256:
`50d3e0a424279b6a1ea8a184f695cc226afcf1fb0a9409040cf0261ec4c56c31`.
Unchanged full kernel SHA-256:
`64ab65017f16d612c3b2753ba5fea4f680173dcfd9cad8b43f9f58c2564839d8`.

The physical FREE/MAX is reproduced in a controlled hole; complete hardware
MCB topology and the full HDPMI EXEC lifecycle are not replayed. Later game
managers and gameplay are not emulated. This proves the specific original
heap failure and the declaration's capacity improvement, not T23 gameplay.
The ordinary direct launch of the undeclared original EXE still uses the
generic host path; the targeted TestGames shortcut declares its requirement.
