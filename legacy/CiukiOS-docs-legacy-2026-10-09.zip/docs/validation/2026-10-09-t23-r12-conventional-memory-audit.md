# T23 R12 conventional-memory audit

This is a read-only diagnosis of the captured R12 normal exit code `1`, before
protected-mode video traffic. It does not claim that the physical game failure
has been reproduced or that QEMU represents a T23.

## Physical facts and limits

The physical CVFL record contains `FREE=17086`, `MAX=6606` paragraphs after
compaction: 273,376 bytes in total, with a largest free block of 105,696 bytes.
There are 12 pinned blocks. The first has MCB segment `31CE`, owner PSP `1180`,
and size `1000` paragraphs. The record does not contain the complete MCB chain,
so the other hole sizes and nested EXEC placements cannot be reconstructed.

The immutable image is
`build/full/t23-next/ciukios-t23-diskseq33-r12.img`, SHA-256
`db294f38015388f1230c637b431eb970fad053afd85d247840e6b2c8ff3ff61a`.
Its shipped DOOMCORE.EXE is 709,905 bytes, SHA-256
`799a20c759567cebb530b7d8b1e7765b13734be5af7f97367f6aa81d87b636da`.

## Exact shipped footprints

These figures derive from the actual image headers, pinned host source and
linker map. They are conventional-memory footprints, not total file sizes.

| Component | Paragraphs | Bytes | Basis |
| --- | ---: | ---: | --- |
| DPMIRUN.COM retained PSP and image | 340 | 5,440 | 5,178-byte file, including its 512-byte stack; PSP and paragraph rounding |
| COMMAND.COM retained PSP, image and stack | 891 | 14,256 | 12,271-byte file; aligned image/PSP end 12,528; runtime `.bss` stack 1,728 |
| HDPMI GROUP16 resident PSP and code/data | 160 | 2,560 | `curGDT=0900h`, `getendpara()` plus PSP |
| HDPMI permanent translation buffer | 512 | 8,192 | `?DYNTLBALLOC=1`, `?TLBSIZE=2000h`; low-memory placement if UMB allocation fails |
| HDPMI temporary GROUP32 load buffer | 3,611 | 57,776 | Final PX section RVA `F000h`, virtual size `01A4h`, rounded end minus `1000h` |
| HDPMI default DPMI client workspace | 32 | 512 | INT 2Fh AX=1687h returns `?RMSTKSIZE/16` |
| HDPMI second/subsequent client workspace with `-a` | 176 | 2,816 | Default workspace plus `curGDT/16=144` clone paragraphs |
| Original DOOM MZ selection requirement | 3,921 | 62,736 | Kernel compatibility copy extent plus header/prefix, PSP and `e_minalloc` |
| Original DOOM minimum child PSP block | 3,889 | 62,224 | Compatibility extent minus MZ header plus PSP and `e_minalloc` |

HDPMI's temporary GROUP32 buffer is freed before it returns resident. It is
therefore a startup peak, not an additional allocation still held while DOOM
executes. Extra startup page-manager buffers and temporary host stack are not
included in this table; successful host startup would already have passed them.

DOOMCORE's original MZ header has `e_cp=122`, `e_cblp=164`, `e_cparhdr=32`,
`e_minalloc=1`, and `e_maxalloc=FFFFh`. Strict MZ EOF is 62,116 bytes; the
existing kernel compatibility loader copies the rounded page extent 62,464
bytes. The appended DOS/4G payload starts with a `BW` container at strict MZ EOF;
the extender loads it separately. The kernel does not initially copy the entire
709,905-byte file into conventional memory.

The one-paragraph MZ minimum is not proof that DOS/4G needs only 62 KiB throughout
startup. Its later DOS transfer buffers, DPMI allocations and runtime requirements
must be measured. The original audit did not establish a specific extra
allocation from R12. The [R13 original-binary follow-up](2026-10-09-t23-r13-original-doom-vinit.md)
now independently confirms a 256,000-byte DOS-memory allocation in this exact
DOOMCORE, without relying on the different DoomVanilla executable.

HDPMI's [protected-mode DOS file API](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/INT21API.ASM)
tries an optional 65,024-byte dynamic buffer for reads/writes larger than 8 KiB.
Allocation failure falls back to repeated chunks through the permanent 8 KiB
buffer. An additional 64 KiB hole is therefore not a hard HDPMI file-I/O
requirement. The [dynamic allocator](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HELPERS.ASM)
edits the DOS MCB chain directly instead of calling AH=48h. Synchronization with
CiukiDOS's allocation table is a possible follow-up only if this path is reached;
R12 does not prove that it caused the earlier client exit.

## Why `-a` is not a memory fix

The exact [pinned HDPMI documentation](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HDPMI.TXT)
describes `-a` as separate address contexts. The DOS address range remains shared.
The [pinned host implementation](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HDPMI.ASM)
has `getclonesize()` return zero without `ENVF_VM`; with `-a`, later clients need
the additional real-mode host clone described above. DPMIRUN's current host tail
is `-cSSSS:OOOO -r` (plus `-v` for VCPI), so it does not itself request these
clones. `HDPMI=32` in an inherited environment would also enable them; the R12
capture does not include that environment.

The [Open Watcom DOS/4GW configuration guide](https://github.com/open-watcom/open-watcom-v2/blob/master/bld/redist/dos4gw/dos4gw.doc)
distinguishes DPMI-managed extended-memory allocation from conventional-memory
pressure. Its DOS16M address/range options are not a way to enlarge a fragmented
DOS arena. No kernel, arena, pinned-block or host-memory limit is changed by
this audit.

## Bounded CPU fixture

Run:

```sh
uv run --with unicorn python build/tests/t23-r12-conventional-audit/fixture.py
```

The fixture runs the full-profile kernel's actual MZ selection, load, relocation,
PSP allocation and entry logic against the shipped original DOOMCORE header and
bytes. It creates three explicitly synthetic free holes (4,173 + 6,606 + 6,307
paragraphs), reproducing the physical total and maximum, and preserves the
captured first pinned 4,096-paragraph heap. Other occupied blocks are aggregates,
not a claim to reproduce the unrecorded 12 physical pins.

Both direct and interpreter scenarios reach the original executable's entry
point. With a synthetic COMMAND PSP in the largest hole, removal saves exactly
892 free paragraphs (14,272 bytes including its MCB). In this chosen topology,
the largest block before DOOM increases by only 299 paragraphs because the next
hole was already large. Child blocks are respectively 6,275 and 6,574 paragraphs.
The pinned heap remains byte-for-byte intact in both cases. Execution stops at
game entry: this verifies the loader and arithmetic, not DPMI host startup or
the game runtime.

The result is stored in `build/tests/t23-r12-conventional-audit/fixture.json`.
Bypassing COMMAND for an explicitly selected COM/EXE removes a real 14 KiB
interpreter allocation. It can reduce pressure, but this fixture does not prove
that it alone resolves the physical exit. Subtracting every component from the
single 6,606-paragraph maximum is only a hypothetical placement scenario;
COM first-fit, MZ largest-fit and suspended parent arenas make the actual result
depend on the unrecorded MCB topology.

## Direct MCB mutation follow-up

The independent fixture `scripts/test_kernel_external_mcb.py` assembles the full
kernel into a private temporary directory. Its kernel SHA-256
`64ab65017f16d612c3b2753ba5fea4f680173dcfd9cad8b43f9f58c2564839d8`
matches the immutable R12 image's `SYSTEM/CIUKIDOS.SYS` byte-for-byte.

It confirms a generic allocator limitation: a valid, owned MCB block created
directly in a free gap is retained by `int21_mem_refresh_owners`, but disappears
when `int21_mem_rebuild_chain` rewrites the gap from its allocation table.
With a deliberately persistent external carve, actual AH=31h triggers this
rebuild through `int21_resize`; its owner becomes zero. After actual resident
merge and the parent allocator-frame restoration, the next AH=48h allocation
overlaps that formerly owned block. Both a 65,024-byte direct carve and a
synthetic 8,192-byte direct carve reproduce this limitation.

That scenario is **not the normal HDPMI buffer lifetime**. The pinned
`intr213F` and `intr2140` call `_FreeDosMemory` before returning, including their
error paths. The permanent 8 KiB TLB uses AH=48h instead of this direct carve.
The tracked AH=48h 8 KiB control survives actual AH=31h, resident merge and
parent-frame restoration with its header/data preserved and no subsequent
allocation overlap.

For the actual temporary-buffer lifetime, the fixture executes the real kernel
INT21 dispatcher, AH=3Fh/AH=40h loops, copy logic and SFT synchronization while
a 65,024-byte owned carve is live. Separate 16,384-byte read/write transfers
preserve its ownership header and untouched data/tail. Instrumented calls to
the DOS allocator, owner refresh and chain rebuild are all zero. The modeled
boundaries are filesystem extent resolution, sector I/O and directory-size
persistence; this is not a full HDPMI or physical-hardware test.

Results: `build/tests/external-mcb-r12-regression/evidence.json`.

```sh
uv run --with unicorn python scripts/test_kernel_external_mcb.py \
  --output build/tests/external-mcb-r12-regression --expect-regression
```

The generic persistent-carve limitation remains a separate compatibility issue.
These findings do not link it to the R12 original DOOM exit, and do not justify
an allocator or memory-limit change in R13.
