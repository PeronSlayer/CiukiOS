# Run CAPP observation and input gates

Run is now application slot 14/window 1. The shell's retained `ui_run_text`
and `ui_run_len` belong to the legacy DOS-helper path and are not the editable
Run field. Tests must not treat those fields as evidence of accepted input.

[Microsoft edit-control text operations](https://learn.microsoft.com/en-us/windows/win32/controls/edit-controls-text-operations)
describes selection using keyboard/mouse, bounded selection endpoints and
replacement of the selected range. The shared CiukiOS field implements this
behavior. Harnesses now use actual Ctrl+A/Delete and printable events, then
read `run_command`/`run_input` through the matching Watcom map before launch.
`qemu_run_dialog.py` binds that map/binary to the actual image's RUN.APP and
checks the loaded CAPP header. Every guest observation is read-only. A `[RUN]`
launch marker identifies dispatch but cannot alone establish prior input or
application success; callers retain their independent game/window checks.

The T23, BIOS DOS-window, VGA-window and protected-mode graphics gates share
this observer. The historical UI handoff gate reads CAPP state and excludes
only the one blinking-caret pixel column from its empty-field comparison.
The historical COM `ui_redraw_input` batching cases are superseded by
`scripts/test_ui_field.py`, which compiles the production C editor and Run
source; its evidence is explicitly identified as host C rather than COM
instruction execution.

`scripts/qemu_test_run_dialog.py` adds real-input checks for Ctrl+A replacement,
keyboard word selection, mouse double-click word selection, empty Enter, and
case-insensitive About/Explorer aliases including a directory argument. It
captures selection and target-window screenshots and waits for both launch
and target markers. It must run sequentially in the capped full-image scope.
Python/static harness validation does not establish a QEMU pass or physical
T23 behavior.

## Reading relocated application memory

The 2026-10-08 Run gate found slot 14 at segment `DC2Ch` while the window
was visibly correct. Its physical `DC2C0h` dump contained zero bytes at the
CAPP header. Jemm maps upper-memory allocations through paging; multiplying
the segment by 16 gives a linear address, not necessarily the physical backing.
[QEMU's monitor reference](https://www.qemu.org/docs/master/system/monitor)
distinguishes `memsave` (virtual memory) from `pmemsave` (physical memory).
Read the active system-VM mapping with `memsave`, bounded to the allocation
size in the matching CAPP header. Retain the exact header, symbol, capacity,
length and termination checks. This change fixes observation; it does not
change the guest or bypass a failed editor assertion.

The Run gate positions its mouse using the observed `ui_mouse_x/y` hotspot
and configured PS/2 movement scale, injecting only real `mouse_move` events.
Its earlier pixel matcher required the old arrow even while Run correctly
requested an I-beam over the editor. The gate now waits for completed
composition, visible pointer and the editor's I-beam before double-clicking;
the selected word is still verified in the actual Run field. This is local to
the Run gate and does not change the other harnesses' cursor checks.

The T23 DOS runtime gate opts into `ObservedPointerMixin` after binding
`Utilities` to the exact loaded shell/listing. This covers the complete Files
launch call chain: control clicks, movement between address editor and file
rows, and the final pointer wait inside `WindowVM.completed_control_click`.
Its prior arrow-only matcher stopped at Files' correctly visible I-beam.
Before binding, normal WindowVM behavior remains available; unrelated gates
are unchanged. Files address, real button-edge acknowledgement, double-click
timing, EXEC and game-output assertions remain independent checks.

The traced R5c Files run demonstrated an additional harness race: the old
300 ms menu delay returned before the third Alt+V had opened View and before
the subsequent N had closed it. The gate now discovers the unique menubar
through its five exact titles and the `app.h` near-pointer ABI, then waits
for View open, command close, the Details/Name checked flags, released BIOS
modifiers and completed composition. No guest field is written. A flushed
JSONL input journal, four module dumps and screenshots survive failures.
The mouse observer requires an actual Files execution marker after a timely
double-click; it never retries a timely pair that failed to dispatch.

`scripts/test_files_launch_observer.py` checks seven menu binding/state cases
and three input cases, including ambiguous pointers, failed dispatch and
held modifiers. The decoder was also checked against all eight real R5c menu
dumps and 24 corrupted variants. R5c itself passed both DOOM launches with
real menu/gameplay input and unchanged S3 resident state, but predates the
explicit menu acknowledgement and is not its runtime validation.

The final `qemu-six-fixes-doom-stale-r5d-20261008/report.json` passes with the
explicit acknowledgement enabled against the immutable image that was
written to the physical disk. Both real Files launches reach gameplay,
respond to input, quit and return to the desktop; source integrity and the
host resident are preserved. This closes the harness regression without any
production keyboard/menu change.
