# T23 R13 vector provenance and conventional-memory reclamation

The R13 first retained block is MCB `31CEh`, owner PSP `1180h`, size `1000h`
paragraphs. INT DD (IVT byte offset `0374h`) contains `3FBA:0020`, which aliases
its payload. `pin_observations=12` counts repeated observations, not distinct
blocks; `record_pinned_block` stores only the first block's tuple.

## What the source establishes

The exact pinned [JLOAD32 initializer](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Tools/JLOAD/JLOAD32.ASM)
explicitly selects flat DS and ES before calling DLL_PROCESS_ATTACH. CiukiOS's
`DllMain` calls `vmm_snapshot_ivt`; that routine copies 256 dwords from linear
address zero with DF cleared. `op_ivt` copies the immutable snapshot into a
validated private-guest destination. No incorrect segment or shifted source
was found in this path.

`vmm_create` separately copies the first megabyte as it exists when the GUI
launches the session. Thus the child inherits current allocations and vectors,
while the restoration baseline predates GUI heap allocation. The existing
`restore_vectors` rejects any baseline replacement whose address now falls
inside an ancestor-owned allocation. It does not know who owned that address
when the baseline was captured.

No direct DA/DD installation was found in CiukiOS's exact source searches.
This does not prove that firmware or external code never uses those entries.
The kernel's fixed `int_default_iret` is a single IRET and is already used for
its default user-vector initialization. The R13 physical capture does not
record the original IVT snapshot or its load-time MCB ownership, so the stale
free-address hypothesis remains to be classified by the new early INIT path.

## Ownership-based decision

The primary [MS-DOS Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
defines an unowned MCB area as available for allocation; owned resident code
requires its allocated memory to remain live. The relevant distinction is
allocation provenance rather than interrupt number.

A conservative private baseline can classify entries only after validating
the entire conventional MCB chain, while the early VMSTART/JLOAD initialization
has returned and before GUI allocations begin. A raw baseline target that is
unchanged in the live IVT and lies inside an owner-zero MCB is not a live
resident allocation. Its private fallback may use the existing fixed kernel
IRET. An allocated resident target, a changed live vector, an out-of-range
target or a malformed chain must retain conservative behavior.

Classifying after JLOAD's return avoids mistaking its transient EXEC allocation
for resident ownership. Publication must be atomic after validation; repeated
same-kernel INIT must keep the sealed classification. VM0's IVT and allocations
must remain untouched. These conditions do not amount to a DA/DD exemption or
license to discard arbitrary referenced resident memory.

## Actual CPU fixture

```sh
uv run --with unicorn python build/tests/t23-r13-ivt-provenance/fixture.py
```

The first fixture uses the exact physical pin tuple with controlled baselines:
an unchanged raw address alias retains the 64 KiB block; a ROM or allocated
resident default restores the vector and releases that GUI-owned block through
the actual full-kernel F149 allocator. Two pin observations in the first case
refer to the same retained block.

The extended fixture now assembles and executes the production
`session_ivt_baseline.inc` classifier/filter and actual `op_ivt`. It supplies a
controlled pre-GUI MCB chain in which the future GUI heap addresses are free,
while the root and recognized resident services remain owned. The resulting
private output and BX/CX/DX/SI metadata feed actual VMFORK vector restoration,
root compaction, resident relocation and cleanup. INT10 and INT21 continue
pointing into owned resident blocks in all cases.

The test then reserves measured retained footprints through real AH48:
DPMIRUN 340 paragraphs, HDPMI GROUP16 160, permanent TLB 512, DPMI client
workspace 32 and game shortcut 69, plus their MCBs. These are controlled
retained allocations, not a complete HDPMI EXEC replay. It executes the actual
original DOOM MZ loader and relocated entry instructions through the **first
real AH4A** at original file offset `4170h`. That shrink retains 3,868
paragraphs, independent of the synthetic hole placement. Only then does it
execute the [original V_Init allocation](2026-10-09-t23-r13-original-doom-vinit.md).

| Controlled baseline | Largest after real cleanup, paragraphs | Largest after host reservations, original MZ entry and first AH4A | Original V_Init |
| --- | ---: | ---: | --- |
| Unregistered, DD alias | 11,935 | 11,935 | AH48 rejects 16,000; original error path reached |
| Registered, DD alias | 22,445 | 17,426 | AH48 succeeds; all 256,000 bytes clear and four screen pointers install |
| Unregistered, DD plus physical DA span | 11,823 | 11,823 | AH48 rejects 16,000; original error path reached |
| Registered, both aliases | 22,445 | 17,426 | AH48 succeeds; all 256,000 bytes clear and four screen pointers install |

The additional DA case models the independently captured MCB `7518h`, owner
`1180h`, size `0FFAh`, containing `8233:01F0`. Its measured span is included
without claiming the full physical topology. Classification covers all 256
vectors; neither DA nor DD is privileged by number.

Actual `op_ivt` and VMFORK trace metadata match in all cases: unregistered
outputs report ready/count/filtered/first `0/0/0/FFFF`; the registered DD case
reports `1/1/1/0374`; the registered two-span case reports `1/2/2/0368`.

Evidence is `build/tests/t23-r13-ivt-provenance/evidence.json`. The kernel hash
matches the immutable R13 kernel. Other MCB locations and retained-host
placements are synthetic. Later DOS/4G startup between its first shrink and
V_Init is not executed, and the physical T23's unrecorded initial MCB topology
is not reconstructed. This is a causal controlled test of address-alias
pinning, not a claim of hardware resolution.

The independent primitive test runs 20 checks against the production include:

```sh
uv run --with unicorn python scripts/test_session_ivt_baseline.py \
  --output build/tests/ivt-baseline-r14
```

It verifies whole-chain rejection and atomic publication, real owned targets,
free payload boundaries and segment aliases, header exclusion, changed live
vectors, sealed repeat registrations, conflicting identities, raw fallback
when unregistered, actual `op_ivt` metadata and unchanged VM0 IVT bytes.
Both tests passed against include SHA-256
`0e5a357ccf1899253ee8c33ec539452dfd86b46d8b0329e0b81fe4618378b534`.
