# T23 S3 launch and adaptive wallpaper validation

Status: **the image that passed the recorded QEMU gates failed a physical T23
cold boot after the splash. That image is retired. A strict BAR2 candidate is
pending a fresh full build and cold-boot validation.** This record combines the
read-only diskseq60 and diskseq61 captures with focused CPU/host fixtures and
emulated integration evidence. Do not treat the stale diskseq60 DPMIRUN log as
evidence that the photographed physical DOOM attempt entered DPMIRUN.

## Physical T23 capture

The connected `CIUKIOSFULL` volume was mounted read-only. The collector recorded
22 files at 2026-10-08 15:19:20 UTC, with `source_writes: false`. The complete
manifest, including source modification times, decoded snapshots, missing-file
list and mount details, is
[`physical-logs-20261008-diskseq60-final/manifest.json`](../../build/full/t23-next/physical-logs-20261008-diskseq60-final/manifest.json).
The capture contains nine missing optional files, including all three
`VMFORK*.BIN` launch checkpoints and `VIDEO/CACHE.LOG`; those records cannot be
used to establish the corresponding launch checkpoints or cache measurements.

The captured `SYSTEM/MEMMAP.BIN` decodes as complete CMAP v1/E820 with ten
firmware ranges, 636 KiB conventional memory, EBDA segment `9F00h`, and
510.375 MiB usable above 1 MiB. Its record format stores E820 base, length,
type and attributes only. It is not an MCB/PSP ownership map and cannot confirm
the owner, type or size of resident blocks at segments `2505h` and `219Dh`.
See the raw file above and the decoder [`read_memory_map.py`](../../scripts/read_memory_map.py).

`SYSTEM/DPMIRUN.LOG` is 106 bytes, SHA256
`8470e140cc21f5fadb8d5102abdf708e2965bd6882b9a40567c107b226e8c7f4`, and its
source timestamp is 2026-10-08 10:57:26 UTC. The artifact comparison shows it
is byte-identical to the log in the previously flashed image and sets
`stale_dpmirun_log: true` and `physical_dpmirun_started_proven: false`.
Therefore it is a stale QEMU trace, not a fresh record of the T23 run.
[`artifact-comparison.json`](../../build/full/t23-next/physical-logs-20261008-diskseq60-final/artifact-comparison.json)
also confirms the installed DOOM/Wolf3D launchers, DOOM core/WAD, VMFORK and
DPMIRUN binaries match that flashed image.

The fresh `LOADDRV.LOG` reports `S3VBEFIX OK PCI5333:8C2E IRQ0B` and an INT10
hook from `219D:0470` to `2505:0048`. `DISPLAY.LOG` records 1024×768×32 VESA,
4096-byte pitch, active LFB and successful VBE readback. The EDID header is
invalid, so the capture does not establish a preferred native mode. `GPU.LOG`
identifies PCI 5333:8C2E (SuperSavage), BAR0 `C0200000`, framebuffer BAR1
`E8000000`, and BAR2 raw value `00000008`; preflight stopped at the unassigned
BAR2 aperture before any engine qualification. This is separate from evidence
that the display driver is loaded and the full-color VBE mode is active.

`DOSVM.LOG` says a `DOOM.COM` request was made, but that alone does not prove
the child program began. `DOSVM1.BIN` reports generation 1, FREE/exit 0 and no
video session activity. With the launch trace absent and the DPMIRUN log stale,
the captured exit code is not proof that DOOM reached gameplay or exited
normally. This matches the diagnostic gap described in
[`vmfork-launch-diagnostics.md`](../design/vmfork-launch-diagnostics.md).

### diskseq61: cold-boot regression after the splash

The next connected-disk capture is
[`physical-logs-20261008-diskseq61/manifest.json`](../../build/full/t23-next/physical-logs-20261008-diskseq61/manifest.json).
It was acquired read-only at 2026-10-08 18:03:27 UTC from `/dev/sdc`; the
collector made no source writes. The machine showed the splash and then stayed
on a black screen. The manifest lists source file timestamps later than the
capture time, so those timestamps are not reliable boot chronology.

The captured binaries match the immutable image SHA256
`7e04efad18b4df3f5ed97b4236a5a66088f2ed5ec23a162fee2d457c5fdde599` recorded
below: SHELL.COM (`d34d0f5b…af24d`), CVSESS.DLL (`e5884075…e79f8`),
DPMIRUN.COM (`f0b59a5c…f3256`), VMFORK.COM (`2c0991a0…d402`) and SFX.DRV
(`e0e257b9…7a7e1`) all match the artifact inventory. The captured settings
are `STARTUP.CFG=LIVE`, `VIDEO/DISPLAY.CFG=AUTO` and `UI/WALL.CFG=04 00`.
LOADDRV.LOG still reports `S3VBEFIX OK PCI 5333:8C2E` hooking INT10 from
`219D:0470` to `2505:0048`.

The 233-byte AUDIO.LOG contains only event `I`, stage 7, result 0, for the
native ICH AC97 device. That is successful audio-device initialization. There
is no event `S` (startup PCM queued) or `E` (playback completed), unlike the
earlier working capture. Thus startup audio did not reach its recorded start
or completion. BOOT.LOG is empty, but the immutable image also seeds it empty,
so that file does not locate the stop. DISPLAY.LOG, VIDEO/DISPLAY.LOG,
GPU.LOG, GPU3D.LOG, VBE.TRC, CACHE.LOG, DOSVM.LOG and all VMFORK checkpoints
are absent. The traced GPU log is written after a completed paint; its absence
is consistent with no first completed desktop paint, or a trace/file-write
failure. These gaps do not prove a GPU bind failure or identify the exact
instruction where boot stopped. No DOS launch is recorded.

This is a cold-boot regression in the `7e04…` image despite its passing
emulated gates; those earlier QEMU results do not qualify this physical boot.

## S3 guest handling and BAR2 regression

The captured INT10 chain exposes the launch rejection: the physical S3VBEFIX
is topmost, while the previous VMFORK relocation check recognizes only the
AUXSTACK resident. The implementation design records the source evidence,
guest-only detach conditions, and limits in
[`vmfork-s3-guest.md`](../design/vmfork-s3-guest.md). It recognizes only the
pinned S3VBEFIX layout in a private child conventional-memory copy, validates
its MCB and predecessor, checks for other IVT references, redirects that
child's INT10 and releases only the validated guest allocation. It does not
call the physical driver's INT10 handler or touch hardware ports/MMIO.

The independent assembled-CPU fixture passed 21 cases, including the captured
`2505:0048 -> 219D:0470` chain, ownership/extent checks, refusal paths,
register/FLAGS preservation and unchanged system memory. See
[`vmfork-s3-guest-fixtures.md`](../design/vmfork-s3-guest-fixtures.md) and
`scripts/test_vmfork_s3_guest.py`. The first forced guest-TSR run reached DOOM
gameplay, accepted input and quit normally, and left host INT10/TSR memory
unchanged, but its harness incorrectly expected `dead` instead of the normal
natural-exit state `FREE`. The corrected retry passes the complete gate:
[`report.json`](../../build/full/t23-next/qemu-doom-s3-resident-retry-20261008/report.json).
It launches the original `TestGames/DOOM.COM` twice via Files with no
arguments; both CVFL captures report VM 1, generations 1 and 2, stage 8,
progress `057Fh` and exit 0. The records are
[`doom-first-VMFORK.BIN`](../../build/full/t23-next/qemu-doom-s3-resident-retry-20261008/doom-first-VMFORK.BIN)
and
[`doom-second-VMFORK.BIN`](../../build/full/t23-next/qemu-doom-s3-resident-retry-20261008/doom-second-VMFORK.BIN).
The report confirms host vector and full resident fixture bytes stayed
unchanged for both launches, and the source image was unchanged. This is a
512 MiB standard-VGA QEMU fixture test, not physical S3 hardware validation.
Physical T23 retest remains pending.

The earlier optional-BAR2 change let the existing BAR0/BAR1 PIO path proceed
when BAR2 was absent or invalid. That behavior was covered by
[`savage-optional-aperture-20261008/report.json`](../../build/tests/savage-optional-aperture-20261008/report.json),
but the resulting `7e04…` image is now retired because of the diskseq61
cold-boot regression. Do not treat optional BAR2 handling as the active
implementation. The current working tree restores strict BAR2 requirements;
its tree SHA is `a761d665`. The focused regression report records 50/50 host
model cases and 50/50 ASan/UBSan cases:
[`report.json`](../../build/tests/savage-bar2-regression-20261008/report.json).
This is host-side validation only; no replacement full image has yet passed a
physical T23 cold boot. Actual acceleration and lag improvement remain
unverified. See [`native-supersavage-bci.md`](../design/native-supersavage-bci.md).

## Adaptive wallpapers

Three adaptive masters were added under `misc/ciukios_bg/adaptive/`, preserving
each wallpaper's composition while extending the landscape for aspect-preserving
Fill on common 4:3, 16:10 and 16:9 displays. The originals remain the source
assets; the generated siblings are new artwork variants, not pixel-identical
outpainted copies. Default selection, bounded CWP2 dimensions and format
validation are described in [`wallpaper-adaptive.md`](../design/wallpaper-adaptive.md).
That design records passing import/loader CPU and host fixtures, the first
QEMU run's legacy CWP1 comparison failure, and the corrected readiness wait.
After the wait correction, the HDD photo gate reports `pass` at 800×600 and
1024×768 in the retry directory and at 1280×800 in the final directory. Each
checks all three adaptive photos in Fill, default Ciuk1, cold restart, malformed
entry retention and legacy CWP1 behavior. The reports share candidate image
SHA256 `143f2e6528e3ef716bde20fbca0eddd843a5531d24ed625210502f933f4f1508`:
[`800`](../../build/full/t23-next/qemu-adaptive-photos-retry-20261008/800/result.json),
[`1024`](../../build/full/t23-next/qemu-adaptive-photos-retry-20261008/1024/result.json),
and
[`1280`](../../build/full/t23-next/qemu-adaptive-photos-final-20261008/1280/result.json).
The 1920×1080 gate also passes in the final directory:
[`1920`](../../build/full/t23-next/qemu-adaptive-photos-final-20261008/1920/result.json).
Across 800×600, 1024×768, 1280×800 and 1920×1080, the default Ciuk1 cold
restart is checked independently and all three adaptive photos are compared
against Fill source coordinates. The Properties gate passes 32 recorded
checks at 800×600 with five style previews (Fill, Fit, Stretch, Center, Tile)
and zero source-pixel delta; it explicitly marks each of the five style cold
restart checks `skipped` (`--skip-style-restarts`). It also checks a 640×480
mode preview and confirms rollback to 800×600. See
[`800-std/result.json`](../../build/full/t23-next/qemu-adaptive-properties-20261008/800-std/result.json).
Thus these runs establish preview/style rendering and default cold-restart
behavior, not persistence across a restart for every style. The full CD boot
also passes its default Ciuk1 Fill comparison with a read-only ISO and no HDD:
[`qemu-adaptive-cd-20261008/report.json`](../../build/full/t23-next/qemu-adaptive-cd-20261008/report.json).
Square and ultrawide safe-area composition is not qualified here.

The original Wolf3D launcher also passes a separate standard-VGA QEMU run via
Files double-click with no arguments, gameplay/input and F10 quit:
[`report.json`](../../build/full/t23-next/qemu-wolf-adaptive-s3-20261008/report.json).
This Wolf3D run does not install the forced S3 resident fixture; only the DOOM
gate above tests that guest-detachment path. Neither QEMU run qualifies
physical S3 hardware.

## Retired artifact history

The capped HDD/CD builds and emulated gates recorded above succeeded for the
following artifact, but the physical cold-boot regression retires it. Preserve
its hashes as historical proof; do not flash or release it as the corrected
candidate. The immutable pristine HDD image was
`build/full/t23-next/ciukios-t23-s3-adaptive.img`, 134,217,728 bytes, SHA256
`7e04efad18b4df3f5ed97b4236a5a66088f2ed5ec23a162fee2d457c5fdde599`.
Its shipped default was Ciuk1/Fill (`04 00`). It contains no run-specific
DOSVM, VMFORK, DPMIRUN or ACTIVE.CFG diagnostics. The strict-BAR2 working tree
at `a761d665` is the replacement source; its candidate image and release
artifacts are recorded in the replacement validation below.

The public Windows portable ZIP is 153,655,348 bytes, SHA256
`444db26ddaea792da4e3df4c20d6bd41b6ba14988245777e32da472676a9d1a9`.
CRC checks pass for all 3,331 members; all eight private game directories and
shortcuts are absent and all 24,176 free FAT16 clusters are zero. HDD, CD and
the packaged Windows image contain the tested runtime components and artwork.
The only permitted rebuilt DLL difference is its COFF timestamp at bytes
128–131; every other byte matches the tested candidate. The ZIP records the
existing HEAD and `source_dirty: true` for these uncommitted changes.
Windows runtime was not tested. These integrity checks are historical and do
not override the physical boot failure. Replacement public and private bundles
are recorded below with the strict-BAR2 candidate. See
[`final-adaptive-artifacts-20261008.json`](../../build/full/t23-next/final-adaptive-artifacts-20261008.json).

The separately requested private Windows bundle with the original local games
is also refreshed: `build/releases/CiukiOS-0.8.3-Windows-local-games.zip`,
179,801,863 bytes, SHA256
`1d303308e883d67cf4354f3768bccfb115403e08e45c347a5deb59c787afb84e`.
All 3,331 ZIP members pass CRC checks; its image is exactly the pristine HDD
above and its other 3,328 unchanged members match the public bundle. It is
ignored by Git, marked private/local-only and was not uploaded. Its presence,
contents and integrity were checked; Windows runtime was not tested. See
[`CiukiOS-0.8.3-Windows-local-games.validation.json`](../../build/releases/CiukiOS-0.8.3-Windows-local-games.validation.json).

## Physical qualification still required

A replacement image must first complete a physical T23 cold boot through its
first desktop paint. Then a new capture must contain fresh matching
VMFORK/CVFL and DOSVM generations and a newly written DPMIRUN trace before
claiming the S3 launch fix works on hardware. Capture `VIDEO/CACHE.LOG` as well
when reporting cache or lag metrics. Native engine qualification and lag
improvement are unverified on the T23; the host protocol model and standard-VGA
QEMU tests cannot establish those hardware results.

## Strict-BAR2 replacement validation

The replacement candidate is `ciukios-bar2-bootfix-candidate.img`, SHA256
`0e962a8b88ba173ee883452f7cae01ec32c25b07998f6eb87e22b85cab2b60e4`.
Its complete CVSESS.DLL matches the last physically working `c86065d` image
except the COFF link timestamp at bytes 128–131. Every other inventoried
runtime component matches the retired adaptive candidate, including the
guest-only S3 detach fix and all three wallpapers. Ciuk1/Fill remains default.
See [baseline comparison](../../build/full/t23-next/bar2-bootfix-baseline-comparison-20261008.json).

The fresh 512 MiB standard-VGA QEMU gate passes pristine AUTO boot at
1024×768×32, exact initial and returned Ciuk1 pixels, complete native startup
PCM playback, keyboard/system-shell use and return to the desktop. It also
exercises HELP and the explicit unsupported SAV3D path. See
[boot report](../../build/full/t23-next/qemu-bar2-bootfix-hardware-20261008/report.json).

The fresh forced-S3 resident fixture gate passes two Files double-click
launches of the original DOOM shortcut without arguments, actual gameplay
and input, normal menu exit, and closing the finished DOS window. The host
INT10 vector and complete resident fixture remain intact. See
[DOOM report](../../build/full/t23-next/qemu-bar2-bootfix-doom-s3-20261008/report.json).
These tests use private image copies; they do not establish that the physical
T23 now boots or that its native acceleration works.

The final capped HDD/CD builds also pass. The immutable replacement image is
`build/full/t23-next/ciukios-t23-bar2-bootfix.img`, 134,217,728 bytes, SHA256
`aa9b1136417b3cc74dce2a09537531b68a15e348e24fa75ed3da05c1aa8709a3`. HDD, CD and public Windows image match the tested
candidate's runtime components; only the DLL COFF link timestamp differs.
The image contains no stale VMFORK/DOSVM/DPMIRUN or ACTIVE.CFG run diagnostics.

The public Windows ZIP has 3,331 valid CRC members, SHA256
`fc67ecbcd7c7b31ec1ecea3a8be9cfc0f5f56c8a476cfbea7693cfd2a44aa3f4`; its eight excluded private paths are absent and
all 24,176 free FAT16 clusters are zero. See
[artifact report](../../build/full/t23-next/final-bar2-bootfix-artifacts-20261008.json).
The private local-games ZIP is 179,801,897 bytes, SHA256
`bb94cbcf920cd4e5eeabc33ed92923894b872151e193658aaee77f9cb4a536e8`; its image matches the replacement HDD, all
3,331 members pass CRC, and the unchanged bundle files match the public ZIP.
It remains ignored by Git and was not uploaded. Windows runtime was not tested.

The replacement was written to serial <disk-serial> / diskseq61 after backing
up the original 128 MiB prefix. Direct-I/O readback matches the source SHA256
exactly. The backup SHA256 is
`ce0d3772278d83ea30476a947e02f359b755d464f8e0cd7588a247e4c5109d6f`.
See [physical write report](../../build/full/t23-next/physical-write-20261008-bar2-bootfix/report.json).
UDisks power-off succeeded and the target by-id device disappeared; the disk
is ready for safe removal. Physical T23 cold boot and gameplay remain
unqualified until the next real test.
