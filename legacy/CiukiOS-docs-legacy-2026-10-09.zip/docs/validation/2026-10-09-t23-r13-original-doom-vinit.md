# T23 R13 original DOOM screen allocation

The original DOOM executable requests **one contiguous 256,000-byte DOS-memory
block** immediately after its `V_Init: allocate screens` startup banner. This
is proved from the shipped binary and an actual-instruction CPU fixture. It is
not a protected `malloc` request and cannot be fulfilled from extended memory
by changing the HDPMI transfer-buffer size.

## Scope of the physical evidence

The capture is `build/full/t23-next/physical-logs-20261009-diskseq35-r13/`.
`DOSVM.LOG` records DOOM as generation 1 with successful VM creation and no
observed exit. The subsequent WOLF3D launch is generation 2. WOLF3D exited
normally with code 1 and overwrote `DOSVM1.BIN`, `VMFORK1.BIN` and
`DPMIRUN1.BIN`. Its zero protected-mode video counters cannot be assigned to
the earlier DOOM hang. Its native ATA counters cannot establish DOOM's disk-I/O
state either.

Before these launches, the physical parent log reports 4,245 free paragraphs
(67,920 bytes), with a largest block of 3,883 paragraphs (62,128 bytes). That
is the parent arena, not the final child arena. The earlier post-compaction
capture measured 17,086 free paragraphs (273,376 bytes), with a largest block
of 6,606 paragraphs (105,696 bytes). Both maxima are below the game's request.
The exact free block at the first-generation DOOM `INT31 AX=0100h` call is not
captured; extender startup can change its PSP allocation.

## Original binary proof

Both immutable images `ciukios-t23-diskseq33-r12.img` and
`ciukios-t23-diskseq34-r13.img` ship identical `APPS/DOOM/DOOMCORE.EXE`:
709,905 bytes, SHA-256
`799a20c759567cebb530b7d8b1e7765b13734be5af7f97367f6aa81d87b636da`.
Their full kernels also match byte-for-byte: 43,261 bytes, SHA-256
`64ab65017f16d612c3b2753ba5fea4f680173dcfd9cad8b43f9f58c2564839d8`.
The first appended extender container has signature `BW` at file offset 62,116;
the MZ relocation entry at offset `3Ch` is not an LE header pointer.

These are **file offsets**, not captured runtime CS:EIP values:

| Routine | File offset | Verified behavior |
| --- | ---: | --- |
| `V_Init` | `7B554h` | Passes `3E800h` bytes to `I_AllocLow`; installs four screen pointers, 64,000 bytes apart |
| `I_AllocLow` | `5CF54h` | Rounds byte count to paragraphs; stores `0100h` and 16,000 paragraphs in the Watcom register packet; calls INT31 |
| Watcom `int386` wrapper | `825D3h` | Uses the supplied interrupt number and register packet |
| `I_Error` | `5CB24h` | Receives the requested length and largest block after allocation failure |

The static packet is at original data operand `29110h`: its AX word receives
`0100h`, its BX word at `29114h` receives 16,000, and the carry field at
`29128h` controls the error branch. On success, `I_AllocLow` converts returned
AX to a linear address by shifting it left four bits and clears all 256,000
bytes. The loop writes screen indices 0 through 3; the declaration of five
screen slots does not mean this initialization allocates five screens.

The primary [id Software engine source](https://github.com/id-Software/DOOM/blob/master/linuxdoom-1.10/v_video.c)
corroborates the four-screen count and the intent to use low DOS memory on PCs.
Its Linux `I_AllocLow` uses a different platform implementation. The
[original source-release README](https://github.com/id-Software/DOOM/blob/master/README.TXT)
explains that the DOS platform source was omitted because of the sound library;
the Linux allocator must not be substituted for this original DOS executable's
machine-code evidence.

The [DPMI specification, function 0100h](https://docs.pcjs.org/specs/dpmi/1991_03_12-DPMI_Spec_v10.pdf#page=73)
requires a DOS-memory allocation through INT21 AH=48h and reports the largest
available block in BX on failure. The exact
[pinned HDPMI implementation](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/I31DOS.ASM)
does that: it calls `rmdos` with AH=48h and propagates DOS AX/BX and carry.
It allocates a selector only after the DOS allocation succeeds. HDPMI's optional
65,024-byte file-I/O buffer is a separate mechanism.

## Why the error may remain invisible

Before its first formatted output, the actual `I_Error` executes six cleanup
calls, at file offsets `61774h`, `5C124h`, `5D844h`, `5D1B4h`, `5C504h`, and
`5C414h`. Its first formatting call is at `82FE5h`. The low-memory failure
message therefore need not appear before these routines finish.

An allocation failure followed by a cleanup hang is consistent with the last
visible `V_Init` banner. This is an inference, not proof that any particular
cleanup routine hangs on the T23. A first-generation 0100h request/result
checkpoint would distinguish this from a stuck allocator or unrelated fault.

## Bounded CPU fixture

Run the private test artifact:

```sh
uv run --with unicorn python build/tests/t23-r13-doom-vinit-audit/fixture.py
```

It runs original `V_Init`, `I_AllocLow`, segment-read, memset and pointer-loop
instructions. The Watcom INT31 wrapper is the modeling boundary: its actual
AX/BX packet goes to the unchanged full kernel's real AH=48h allocator. The
fixture does not emulate DOS/4G, all of HDPMI, hardware or the physical MCB
topology. It stops the failure case at `I_Error` entry and does not execute
the cleanup routines.

| Controlled case | Free / maximum before request, paragraphs | Actual AH48 outcome |
| --- | ---: | --- |
| Earlier physical totals, synthetic hole locations | 17,086 / 6,606 | CF set, AX=8, BX=6,606; original code reaches `I_Error` with 256,000 requested and 105,696 available |
| Same layout after actual original MZ entry | 10,511 / 6,307 | CF set, AX=8, BX=6,307; original code reaches `I_Error` |
| Isolated contiguous positive control | 32,127 / 32,127 | Allocation succeeds; all 256,000 bytes clear and four 64,000-spaced screen pointers install |

Result: `build/tests/t23-r13-doom-vinit-audit/evidence.json`. The fixture completes
in about half a second. Its kernel assembly matches both immutable images.
No kernel, memory limit, game executable or production source was changed by
this audit.

The established requirement is a 16,000-paragraph contiguous DOS block in the
private game's arena. Retaining every GUI ancestor's conventional allocation
can prevent that even when total free memory approaches the request. Any
subsequent arena change must preserve genuinely inherited resident services
and prove their vector dependencies; this audit does not authorize discarding
those blocks or remapping a DOS allocation into extended memory.
