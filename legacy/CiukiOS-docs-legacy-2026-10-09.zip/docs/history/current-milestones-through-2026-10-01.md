# Archived milestone ledger

This keeps dated kernel sizes, workload results and investigation notes from the original ledger. The active summary is [current milestones](../current-milestones.md).

<details>
<summary>Expand the original ledger</summary>

# Current Milestones

Updated 2026-10-01 for `CiukiOS pre-Alpha v0.8.0` development. M1–M3 passed
their QEMU gates. M4 paints DOOM in a forked VM with Files open, gives each
DOS window independent focus and close, and passes the complete **26/26**
VM-window profile on the 0.8.0 image
([evidence](../validation/2026-09-30-m4/README.md)). M5 remains open.
On 2026-10-01, CiukPaint received immediate damage presentation during a
held stroke, DOS VM video damage was narrowed to changed horizontal bands,
CiukWeb replaced the preinstalled MicroWeb browser, and the first TinyGL
software OpenGL subset drew a triangle in an M4 window. On this newer image,
the 26 VM-window gates each passed across serial recovery runs after a host
reboot; the automated profile did not finish in one invocation. See the
[current status](../project-status-2026-10-01.md) and
[combined evidence](../validation/2026-10-01-native-app-gl/README.md).
Post-M4 work adds a desktop TestGames folder and a persistent CiukiOS
Settings Registry. The [post-M4 evidence](../validation/2026-09-30-post-m4/README.md)
is separate from the 26/26 baseline. Windows 95/98 PE applications and
installers remain unsupported; the
[compatibility plan](../windows-compatibility-and-layout-2026-09-30.md)
identifies free tests and the runtime work still required.
The September 26 desktop increment documented below and the older cross-phase
qualification records have separate evidence scopes.
Dated investigation notes and files under `handoff/` remain historical evidence;
when they disagree with this ledger, `Roadmap.md` and the current compatibility
matrix govern.

## Selected desktop increment

Image: `build/full/native-desktop-2026-09-26/final/ciukios-native-desktop.img`.
SHA-256: `08bc6df6510e55e3f501d49f9414e2d0f0a2006eccdda5dbf8f78bdc1e244bd6`.
The image is a personal 128 MiB development disk, not a public redistribution
or a newly burned ISO. Eleven focused QEMU Pentium III/128 MiB reports pass;
[archived reports and manifests](../validation/2026-09-26/validation.json) preserve
their scope. [The implementation record](../native-desktop-2026-09-26.md) describes
the source/image identity and failure evidence.

| Area | September 26 result | Explicit limit |
| --- | --- | --- |
| Native Files/media | CD, floppy and BIOS-exposed disk navigation, text preview, import and graphical errors pass. | Removable sources are read-only; USB needs BIOS exposure before boot, with no native hot-plug stack. |
| Wallpaper | 99 tiles, conversion/import/Refresh, persistent selection, damaged-file protection and pixel checks pass. | Indexed tiles up to 256×256; full-size Fit/Fill is not implemented. Windows-origin wallpaper assets remain personal-build-only. |
| System sounds | Kenney CC0 events, ICH AC97/SB PCM, mute, missing-device/file and DOS ownership handoff pass. | Supported controllers only; QEMU playback does not qualify T23/E500 hardware. |
| Windowed DOS | Restricted foreground BIOS-text execution; separately, cooperative Doom preview Ctrl/Space/chords/releases pass. | The games are source ports. Original DOS graphics/DPMI/audio virtualization remains unimplemented. |
| Hardware | No new physical qualification. | T23/E500 input/audio, native hardware acceleration and physical frame rate remain open. |

## September 26 monitor foundation

The experimental kernel and external session module are a separate increment;
they do not change the selected desktop image above or enable Jemm in normal
boot. The final QEMU Pentium III/128 MiB monitor gate passes with the explicitly
adapted, source-built Jemm/JLOAD binaries. Its ordinary DOS child uses private
A000/B800 memory, BIOS video, ports and file I/O while the physical text buffer
remains unchanged. The gate compares all 32 VGA PTEs before and after the session,
checks a 4,096-byte copy into the physical 800×600×24 VBE framebuffer, rejects
invalid copy bounds and proves module/monitor unload and native desktop return.
A fresh packaged HDPMI host starts after the shadow mapping. Its protected-mode
probe writes A000/B800 and the JLM reads back those private bytes; 218 actual
I/O traps, register/frame checks and host unload before session end pass. This
is bounded integrated DPMI video evidence, not a general protected-mode VM.

The separate freestanding VGA model supports text, planar graphics, mode 13h and
Mode X, with CPU-side host assertions, sanitizers and an OpenWatcom target build.
The monitor still needs to route every guest memory and port operation through
it; directly mapped shadow RAM cannot supply planar VGA latch semantics.

The kernel now supports extended XMS query/allocation without truncating EDX and
preserves registered devices and live CDS/SFT storage across repeated AH=52h
calls. CPU instruction tests pass on the new kernel and fail on the old binary
for the corresponding defects. The separate Windows 3.1 regression completes
two launches, resize/repaint and objectively measured WAV/MIDI playback.
Classic Doom also passes its independent fullscreen gate: actual menu/skill
selection, gameplay/movement, AC97 output (Doom-only PCM RMS 992.76), native
exit, subsequent COM execution and desktop mouse/console return. The monitor
is absent from that regression VM.

This is a monitor and transfer foundation, not a completed desktop DOS VM.
Original games in windows, complete guest video/peripheral virtualization,
focused input, virtual audio and physical T23/E500 operation remain open. Procedures and
exact evidence are in [the session record](../vm-session-foundation-2026-09-26.md)
and [the Jemm/HDPMI contract](../vm-dpmi-contract-2026-09-26.md). The
[archived monitor report](../validation/2026-09-26-vm/monitor-final.json) preserves
the qualified binary hashes; the session record links the independent Windows,
Doom and device-model results.

### September 27 integration correction

V86 and HDPMI VGA memory/port accesses now reach the software model. The
[video-track record](../vm-video-session-2026-09-27.md) qualifies five native-QEMU
pixel comparisons and the unchanged DOS Navigator FIRE executable in a
fixed-size desktop window, including focus, cover/uncover and minimize/restore.
It records approximately 18 window repaint/s on the host machine; this is not
a physical Pentium III measurement. At that point its keyboard path was BIOS
INT 16h only, with no guest mouse; see the evening follow-up below. The separate DPMI lifetime workload uses the unchanged
packaged doom-vanille DOS engine; it does not qualify that game in a native
window or with audio. The original September 26 selected image remains unchanged.

The peripheral API now uses `cvgp_` / `CVGP_`, resolving its actual compile/link
collision with the presenter's `cvp_` / `CVP_`. The combined video, presenter
and peripheral sources pass host execution under ASan/UBSan and a freestanding
OpenWatcom link; all 912 renamed peripheral-model assertions also pass. The
[archived before/after evidence](../validation/2026-09-27-integration/README.md)
includes the real pre-fix compiler failure. This qualifies API coexistence and
the isolated model, not Jemm/HDPMI device wiring, guest audio or native GUI input.
The [integration audit](../vm-integration-audit-2026-09-27.md) distinguishes the
earlier combined lifetime run from the completion runs. The rebuilt HDPMI, with
its manifest, the virtual-IF adapter and the corrected scheduler, passes the
combined lifetime gate under ordinary Jemm and three times under the opt-in V86
IF profile. VGA acceptance, the native DOS window and the earlier session gates
also pass with the final module. Seven defects found on the way are archived
with their fixes. There is no hardware qualification.

### September 27 evening: devices, negotiation, resize

The V86 IF profile is negotiated at runtime through Jemm's
`Host_Scheduler_Profile` service; one Jemm build serves both uses. The
peripheral model is attached to real-mode DOS programs: raw keyboard with focus,
virtual INT 33h mouse, ISA DMA/SB16 and DBOPL OPL streamed to the AC'97. The
VGA-session DOS window is resizable and rescales the guest. All gates in
[the device archive](../validation/2026-09-27-devices/README.md) pass in QEMU.
Protected-mode (HDPMI) clients are not attached to the device model yet.

## Phase Status

The following phase table retains the bounded September 1 application matrix;
it is not a claim that every workflow was rerun on the selected desktop image.

| Phase | Status | Reached milestone | Still required |
|---|---|---|---|
| 3 — DOS graphics/runtime | CLOSED | Stable shell-first graphics/runtime baseline. | Regression maintenance only. |
| 3.5 — Setup | CLOSED for functional `full` MVP | Packaged `SETUP.COM` and accepted installer flow. | Per-row B6 keyboard evidence and post-MVP media work remain backlog. |
| 4 — DOOM gameplay | CLOSED for its accepted 2026-05-04 scope | Original DOOM reached the recorded playable visual milestone on `full`; the current aggregate also verifies a healthy gameplay frame. | SB16/DMX remains outside the Phase 4 closure. |
| 5 — Runtime ownership | CLOSED | Loader-only Stage1 plus wholesale ABI2 CIUKIDOS owner on `full` and `full-cd`. | No placement tranche remains; behavioral compatibility continues in Phase 6. |
| 6 — DOS applications | ACTIVE | Bounded Costa and CuteMouse PASS workflows; stronger DOSNavigator, WOLF3D, doom-vanille, shell, process, editor, mouse, and driver evidence. | Ten-program `full` corpus, five-category `full-cd` corpus, complete JFT/SFT behavior, and removal/productization of title-specific hooks. |
| 7 — Legacy audio | NOT CLOSED | Objective OPL2, real-mode and DOS/4GW SB16 WAV gates, controlled WAD playback, original Doom OPL2/PC-speaker gameplay, and doom-vanille combined OPL2/SB16 gameplay pass. | Original Doom SB16/DMX, clean return from another external workload, full-CD, and real-hardware evidence. |
| 8 — Networking | ACTIVE; first bounded milestone complete | Configurable IPv4, resident ARP/ICMP independent of FTP, outbound Internet ping, host ping over TAP, and bidirectional FTP on `full`. | DHCP-server evidence, more NICs, encrypted/common protocols beyond FTP, full-CD, and physical hardware. |
| 9 — Windows pre-NT | Windows 3.1 removed 2026-09-28 (history below); DOS windows follow docs/roadmap-dos-vm-desktop-2026-09-28.md | Optional local Windows 3.1 reaches 386 Enhanced Mode twice with one linear pointer, native SB startup WAV audio, real AdLib MIDI playback, generic DOS-VM enter/exit, unprofiled DOS/4GW Doom with automatic EMS/XMS, task `Alt+F4`, clean shell return, and relaunch. | Wider Windows 3.1 multimedia/application coverage, full-CD, printing/devices, real hardware, Windows 95, and Windows 98. |
| 10 — Build/release | ACTIVE | Canonical full/full-CD build, focused aggregate, negative ABI, installer, application, networking, and Windows gates. | Broader CI/release automation and real-hardware matrix. |

## Canonical Runtime Boundary

- Stage0 loads 8 sectors from the 72-sector reserved Stage1 slot.
- Loader-only Stage1: 1,588 bytes at segment `0x0800` in the selected September 26 build.
- `CIUKIDOS.SYS`: 43,169 bytes in the selected desktop image; 43,217 bytes in the subsequent monitor experiment. Hard ceiling: `0xA900` (43,264 bytes).
- The loader validates the kernel at temporary segment `0x0900`, then relocates it to resident segment `0x0300`. Persistent SYSVARS occupies `0x0D90:0000` through `0x0D90:06FF`.
- ABI: version 2, 11 descriptors, 8 bytes per descriptor, capability mask `0x003F`, `CHAIN=0`.
- Eleven EXEC-state frames occupy paragraphs `0x0E00-0x0EF1`; the boot-only Stage2 window at `0x0E80` is reused after handoff returns.
- The baseline kernel has 95 bytes below its ceiling; the experimental kernel has 47. New monitor/device code lives in explicit external modules without expanding the build-gated kernel window.

## Current Compatibility Decisions

1. Mouse support is one shared DOS/BIOS path, not an executable-name policy. Costa and DOSNavigator use the resident `INT 33h` service; Windows 3.1 uses the IBM PS/2 `INT 15h/AH=C2h` callback path. BIOS PS/2 clients exclusively own their cursor rendering, preventing the former double pointer.
2. COM/MZ placement is title-independent first-fit allocation. Doom-vanille's 256 KiB request and DOSNavigator's COM-to-MZ chain are regression workloads, not kernel name checks.
3. A COM process that launches another program must release unused paragraphs with DOS `INT 21h/AH=4Ah` before nested `AH=4Bh`. `SHELL`, `NETSTART`, `DRVLOAD`, `PMIRQSB`, `DOOMSFX`, `DOOMVAN`, `DOOMSB`, and `NETCFG` relocate their live stack and follow this standard contract; the kernel contains no program-name exception.
4. Canonical interactive QEMU runs use SDL through a verified X11/XWayland transport, explicit i8042, 256 MiB VM RAM, approximately 63 MiB XMS-visible memory, one Pentium III vCPU, and KVM for the widest stable application set. The opt-in `vga-fast` TCG JIT profile is measurably faster for verified-safe planar-VGA workloads, but QEMU 11.1 TCG crashes during original Doom gameplay; `auto`, `tcg`, and `tcg-safe` remain explicit diagnostic choices.
5. Windows 3.1 media, Doom, WOLF3D, DOSNavigator, and other non-redistributable payloads remain local and ignored. Their tests must SKIP or report missing payload honestly when absent.
6. A historical or narrow PASS never overrides a newer direct result. Doom-vanille's allocation, texture-integrity, DMX/SB16 selection, and non-silent PCM gates are green on the current checkout.
7. The external shell owns its display after a normal child returns. It restores BIOS mode 03h, font/page/cursor/intensity state, title bar, and prompt generically; applications are not required to know CiukiOS shell internals.
8. Windows DOS profiles request all available conventional/EMS/XMS memory instead of fixed per-program limits. DOSMGR-selected synthetic PSPs receive an automatic conventional arena, and each Win16/DOS-VM EXEC frame above the Windows startup baseline is released independently on termination; no Doom-specific PIF or executable-name exception is used.

## Validated Bounded Workflows

These are the historical application results summarized on September 1. The
newer desktop report does not convert their open limits into PASS results.

| Workload | Current result | Exact boundary |
|---|---|---|
| Costa v1.8.0 | PASS on `full` | Desktop, one moving cursor, Calculator nested EXEC, stable observation. |
| DOSNavigator | PARTIAL | The upstream `DN.COM` is packaged unchanged and passes dual-pane startup, one-row arrows, mouse, Colors/XMS, native `Alt+X` exit, shell return, and same-boot runtime/mouse/video cleanup; wider file/editor and full-CD workflows remain open. |
| WOLF3D | PARTIAL | Menus and correctly rendered first level on `full`; injected page-flip patch, clean exit, full-CD, and audio remain open. |
| Original DOOM | PASS on `full` for bounded visual/audio workflow | Real gameplay plus objective non-silent AdLib music/PC-speaker SFX WAV pass; SB16/DMX, clean exit, full-CD, and real hardware are not proven. |
| doom-vanille | PARTIAL | Automatic 256 KiB low-DOS allocation, combined DMX OPL2/SB16 initialization, real gameplay, HUD/wall integrity, objective mixed output, and 350-gametic performance in 172 realtics pass after restoring the required Watcom ABI; audio-enabled clean exit and full-CD remain open. |
| Windows 3.1 | Removed 2026-09-28; was PASS on `full` for the bounded Phase 9 workflow | Enhanced Mode start/restart, one linear 1:1 pointer, native SB startup WAV, objective non-silent `CANYON.MID` AdLib playback, generic `COMMAND.COM` DOS-VM return, unprofiled DOS/4GW Doom dynamic-memory launch/exit, Calculator `Alt+F4`, Program Manager survival, and clean DOS return. |
| mTCP/Crynwr | PASS on `full` for bounded Phase 8 workflow | Config persistence, resident ICMP, Internet Echo, authenticated FTP upload/download and persistence. |

## Release Gates

The release-facing validation set is:

```bash
bash scripts/build_full.sh
bash scripts/verify_phase5_runtime_ownership.sh --no-build
make qemu-test-all
make qemu-test-full-costa
make qemu-test-full-network-ftp
make qemu-test-full-network-icmp
make qemu-test-full-windows31
```

The aggregate includes every locally available bundled game and Windows workflow. Networking and the long installer gates remain separate; use the affected focused lane whenever shared DOS, memory, disk, input, video, audio, network, or setup code changes.

## Current Operational Order

1. Broaden M5 qualification for simultaneous protected-mode DPMI workloads;
   M4 already covers a protected-mode probe and DOOM in separate desktop VMs.
2. Expand the licensed driver catalog and test additional era hardware. The
   current QEMU NIC set does not establish support for most physical PCs.
3. Preserve the passing 26/26 M4 profile while expanding the Phase 6 corpus
   and full-CD workflows. Keep original Doom SB16/DMX and physical
   compatibility gaps explicit.
4. Qualify physical T23/E500 input, audio and storage separately from QEMU.

</details>
