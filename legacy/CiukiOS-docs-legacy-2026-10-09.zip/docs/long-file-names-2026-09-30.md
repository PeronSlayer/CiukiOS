# Long file names in CiukiOS — 30 September 2026

The FAT16 kernel keeps its existing 8.3 interface. A resident `LFN.COM`
hooks INT 21h after the kernel loads and implements the Windows 95 `71xxh`
long-name calls, including search handles and VFAT directory entries. It is
loaded once per DOS VM: a VM fork has its own kernel instance and interrupt
table. Applications use the wrappers in `src/apps/rt.c`; without the
extension they fall back to 8.3 calls. `src/apps/sys.c` uses those wrappers
for tree operations, clipboard and versioned Recycle Bin records.

The desktop and Files accept names up to 255 characters, reject DOS and
Windows reserved punctuation and trailing dot/space, and keep complete names
for display and file operations. A short alias still exists on the FAT volume
for older DOS applications. Files keeps its names and navigation history in
separate DOS blocks so its 16-bit DGROUP remains below 64 KiB. Its list cap is
currently 172 entries. The Files tree sidebar navigates stable short aliases
even when the current folder path is long.

The original September layout limited `CIUKIDOS.SYS` to `0xA900` bytes.
The 9 October layout expands the allowed core while reserving its actual
assembled size. The LFN parser remains an independent resident module, and
now binds a [validated public RTSV/CLFN API](design/lfn-runtime-api.md) rather
than private addresses extracted from a kernel listing. The kernel changes
for the original LFN implementation were correct truncate-on-create and
attribute behavior, plus writing directory timestamps. File creation reads
RTC registers directly: calling BIOS INT 1Ah recursively inside INT 21h
caused the V86 session to fail its file I/O probe.

The QEMU gate `scripts/qemu_test_long_names.py` creates and renames long
desktop and Files names, copies and moves files into long folders, recycles
and restores them, then checks VFAT entries and contents independently and
runs `fsck.fat -n`. Physical hardware has not been tested.
