# Files edit-control footprint

The 2026-10-08 integration map placed Files' stack end at `0x10090`, 144 bytes
beyond its 16-bit module arena. The 4096-byte stack and 64 KiB module bound
remain required. Open Watcom's [C language reference, small data model](https://open-watcom.github.io/open-watcom-v2-wikidocs/clr.html#The_Small_and_Big_Data_Models)
describes the near data addressing assumption used by these modules.

Inspection found two copies of the newly added inline-rename pointer geometry
in `on_mouse` and `files_hover`: Details, Icons and List each transform the item
rectangle identically. Share that geometry and pointer hit calculation in one
function. Hover still returns I-beam only inside the editable field; held
selection continues through move/release outside its rectangle. This removes
duplicated code without shrinking file lists, field buffers or the stack.

The 172 cached icon-label widths have a fixed 80-pixel layout bound (`CELL_W`
92 minus 12) but occupied 16 bits each. Store these pixel counts in `u8`, as
the existing cached line counts already do. Label measurement, wrapping and
filename contents remain unchanged. This recovers 172 bytes of module BSS.

Desktop independently exceeded its arena by 80 bytes. Its 48 caption widths
are bounded to 78 pixels. Place each `u8` width in the existing padding byte
after `dicon.sys/attr/sel`, before the aligned size field. Record size remains
unchanged and the separate 96-byte width array disappears. The icon records
are internal runtime data; desktop persistence writes individual fields.

Browser's integration map independently placed its stack end at `0x10AF0`,
2800 bytes beyond the same bound. Its 48 by 128-byte link URL table consumed
6144 bytes in DGROUP, although it is only accessed when adding or following
a link. Move that table to a separate range at the end of the existing page
node XMS block. Preserve all 6144 nodes, 47 usable links, 24 fields and the
4096-byte stack; the page allocation grows by 6144 bytes while near data falls
by 6144 bytes. The existing node handle already has error checking and is
freed by Browser teardown. No guest memory limit changes.

The original [XMS 3.0 specification, function 0Bh](https://files.mpoli.fi/unpacked/software/programm/general/gcgpe10.zip/xms30.txt)
requires an even transfer length and uses 32-bit byte offsets within a handle.
The fixed 128-byte records satisfy that rule. The new range starts at
`NODE_MAX * sizeof(struct node)` using 32-bit arithmetic; node reads/writes
retain their old offsets. One bounded near buffer resolves/stages a URL during
parsing or clicking, and failed writes do not publish a new link index.
