# Private DOS VMs and boot disk I/O

The diskseq67 capture establishes that VMFORK reaches target EXEC with a valid
arena, then receives DOS error 2 for the existing `\VM\DPMIRUN.COM`. It does
not establish whether the T23 BIOS uses DMA, SMM, or stale firmware state.
The real-kernel CPU fixture resolves and loads that exact file from R9 sectors
after compaction, including the two known pinned allocations. It is not a
complete physical RAM dump or a model of the T23 firmware.

Research before implementation:

* [Phoenix EDD 1.1, sections 2.4 and 3.2.8](https://wiki.sensi.org/download/doc/ata_edd_11.pdf)
  defines the AH48 DPTE pointer, exact ATA ports/device/IRQ, checksum and
  version. Copy the temporary DPTE before another BIOS call. Its LBA flag
  states that extended BIOS requests address the same device LBAs directly.
* [T13 ATA/ATAPI-4 draft, hosted by Seagate](https://www.seagate.com/support/disc/manuals/ata/d1153r17.pdf)
  and [ATA/ATAPI-6 draft](https://www.read.seas.harvard.edu/~kohler/class/04f-aos/ref/hardware/ATA-d1410r3a.pdf)
  define IDENTIFY, 512-byte sectors, PIO data-in/data-out, status/DRQ and nIEN.
  Device Control is write-only; Alternate Status is not its saved value.
* [Jemm upstream](https://github.com/Baron-von-Riedesel/Jemm), pinned source
  e96bb6bb80cbdc3e6585544db79a6b133a5566dd, implements VDS translation in
  `src/VDS.ASM` and ISA DMA translation in `src/VDMA.ASM`. Those mechanisms
  do not prove that arbitrary firmware bus-master/SMM transfers follow our
  per-VM PTEs. `src/JEMM32.ASM` implements the interrupt-chain callback and
  synchronous Begin_Nest_Exec/Exec_Int/End_Nest_Exec used for serialization.
* [Intel 8259A](https://www.pcjs.org/documents/datasheets/intel/INTEL_8259A_PIC.pdf)
  distinguishes masking from IRR acknowledgement. Masking an IRQ alone does
  not remove a pending request; never clear a BIOS request as if it were ours.

The selected change gives the bound legacy ATA boot device a CPU PIO path.
This removes the private-page/firmware-transfer dependency, without claiming
that a particular undocumented T23 firmware mechanism has been proved.
It does not change conventional-memory ceilings or clone semantics.

Binding occurs in the system VM. Require a valid DPTE naming the exact legacy
channel/device, ATA/LBA/nonremovable flags, 512-byte sectors and matching
capacity. A reference BIOS sector read must match the native read. Disk
contents alone never select a device. Observe actual V86 writes to the bound
Device Control port before saving its value; refuse qualification if the
value is unknown. A BIOS disk reset may be used once in the system VM to
establish the firmware's control state, followed by a fresh reference read.

The INT13 hook handles bound EDD and CHS transfers through the native engine.
This also covers the kernel's existing EDD-to-CHS retries without silently
re-entering firmware after a native command. Unsupported/unbound devices keep
their existing BIOS path. Synchronous BIOS chaining holds a firmware-active
guard so neither the scheduler nor the native engine overlaps a BIOS request.
No DOS filesystem call is made by the driver.

Each native sector operation checks device idle and pending/in-service disk
IRQs, suppresses its own device interrupt with nIEN, performs bounded PIO,
acknowledges status and restores the observed control value only after idle.
An uncertain timeout retains ownership and interrupt suppression; it is an
error, not permission to run the firmware fallback. No per-sector IDENTIFY,
reset or cache flush is added. Trace fields report binding/refusal and native
read/write counters so integration cannot pass by silently using BIOS.

## Module integration (2026-10-09)

`session_disk.inc` supplies the Jemm adapter and a private 8 KiB ring-0 C
stack; `session_disk_ata.c` supplies the native task-file engine. Both link
into CVSESSION in extended memory. The DOS kernel source and its fixed
43264-byte envelope are unchanged by this integration. The generated layout
adds the existing `boot_drive` address so VMFORK does not assume drive 80h.

`vmfork_disk.inc` executes binding before cloning. It obtains the exact DPTE
and copies all 16 bytes immediately, obtains translated AH08 geometry, then
prepares the native engine. The BIOS reference read runs after the selected
Device Control port is trapped. If its control value remains unknown, one
BIOS reset followed by another reference read is allowed. A temporary DOS
allocation provides a 4 KiB firmware stack and is freed before cloning;
VMFORK's normal 512-byte resident stack is not used for firmware execution.

VM operations 53h/54h/55h expose status/prepare/bind. Every firmware INT13
execution uses Jemm's synchronous nested-execution contract while
`disk_firmware_active` prevents VMM switching. Native C execution has its
own guard and physical interrupts disabled. Bound EDD reads/writes and CHS
reads/writes validate the entire conventional-memory buffer before the first
sector and retain partial-sector counts on error. Unsupported write-and-verify
flags are rejected before issue. A bound AH00 reset reports native readiness
without re-entering firmware. An uncertain owned command blocks firmware
access until reboot; no successful state is invented after a timeout.

`SYSTEM\DISKATA.BIN` records the 80-byte CDS1 status after parent binding.
CVFL keeps the existing PLOG marker at 214 and adds an ATA1 extension at 242:
state/error at 218/220, command/control ports at 222/224, completed reads/writes
at 226/230, last LBA at 234, Device Control byte/known flag at 238/239 and parent
binding error/phase at 240/241. The parent phases are 1 query, 2 AH41, 3 AH48,
4 DPTE pointer validation, 5 AH08, 6 native prepare, 7 reference read, 8 native
bind, 9 optional reset/re-read, 10 temporary firmware-stack allocation.
VMFORK target EXEC errors return E000h OR (DOS AX AND 0FFFh); the complete
AX remains in CVFL and ordinary application exit codes 0..255 remain distinct.

Focused validation executes the actual production assembly instructions:

* `test_session_disk_adapter.py`: 34 cases cover EDD and CHS translation,
  low kernel buffers, invalid packets/ranges/pages, partial completion,
  quarantine, native-error finality and recursive firmware serialization.
* `test_vmfork_disk_binding.py`: 13 cases cover immediate DPTE capture before
  firmware changes the temporary table, translated geometry, firmware segment
  clobbers, transient stack allocation/free, optional reset with fresh DAP
  count/reference data, binding reuse and each refusal phase.
* Existing VMFORK diagnostics and launch-mailbox validation also pass.
* `test_session_disk_unload.py`: 11 cases execute production DllMain and
  verify that an installed disk callback, trapped port, native call or nested
  firmware request refuses module unloading before any cleanup changes other
  ownership. The disk hooks remain installed until reboot; orderly detach
  remains available only when none of those resources exists.

These CPU fixtures use Unicorn 2.1.4 and mocked ATA/Jemm service boundaries.
Their reports explicitly mark hardware validation false. A successfully
compiled module and these contracts do not prove the T23 BIOS exposes a valid
DPTE or that hardware has passed binding; the persisted counters distinguish
native I/O from a serialized but unbound firmware path.

The first runtime with batched PIO exposed another distinction between a
bounded loop and a device timeout: 65536 status reads do not represent a
known amount of time. The elapsed deadline uses the existing full 64-bit
`cvclock_now` timestamp and `vmm_tsc_measured` rate, calibrated against PIT2
in DllMain before disk binding. Native binding requires a known rate. A
30-second command allowance is CiukiOS policy, consistent with the long
response times allowed for standby media access in ATA/ATAPI-6 section 6.3.2;
it is not a claim that every ATA operation has that exact normative timeout.
Upstream Linux's [`ata_sff_wait_ready`](https://github.com/torvalds/linux/blob/v6.2/drivers/ata/libata-sff.c)
likewise passes a time deadline to its readiness wait.

This calibration is independent of interrupt delivery, so it advances while
PIO runs with interrupts disabled. It is not a guaranteed wall clock on the
T23: Intel's [SDM description of P6 TSC](https://www.intel.com/content/dam/support/us/en/documents/processors/pentium4/sb/253669.pdf)
states that the counter follows internal processor cycles; firmware power
state/frequency changes can alter its rate after calibration. CiukiOS has no
P-state transition implementation here. This limitation must remain explicit
until an invariant platform timer or frequency-change notification is used.

### Bulk data phases and module lifetime

The first integrated generic KVM run bound the native controller successfully,
but the per-word C I/O loop made loading abnormally slow: the captured status
showed 27,288 completed native reads and 164 writes, with no ATA error. A longer
observation reached DOOM's `ST_Init`; it was stopped before gameplay validation
after the throughput issue was identified. These runs are not passes.

Each 512-byte data phase now calls a fixed-length `REP INSW`/`REP OUTSW` helper,
instead of 256 C calls and individual I/O instructions. Both the
[SeaBIOS PIO implementation](https://github.com/coreboot/seabios/blob/master/src/hw/ata.c)
and [Linux libata SFF](https://github.com/torvalds/linux/blob/v6.2/drivers/ata/libata-sff.c)
use repeated word transfers for this operation. Command issue, DRQ, bounded
completion, IRQ acknowledgement and Device Control restoration are unchanged.
The helpers preserve cdecl nonvolatile registers, FLAGS/DF and data selectors,
and explicitly use the flat ring-0 selector. Eight actual-assembly cases check
both legacy ports, both DF states, nonflat caller data selectors, exact data,
word counts and buffer canaries.

CVSESSION refuses unload while the INT13 hook, trapped control port, native
call or firmware call remains active. Eleven actual-DllMain cases verify
refusal before any resource cleanup and the existing clean detach path.

## Module boundary and transaction cleanup

The ATA protocol lives in `src/vm/session_disk_ata.c`, with its protected-mode
adapter in a separate CVSESSION module. The conventional-memory kernel keeps
its existing INT13 calls and does not grow. This matters because the R9 kernel
uses 43261 of its 43264 available bytes, but is also the intended architecture:
hardware protocols belong in driver modules rather than the core DOS image.

The initial C draft was incomplete: it replaced the observed firmware Device
Control shadow with the temporary nIEN value and lacked a restoration path.
The integrated implementation separates the saved firmware value from native
ownership and routes every post-suppression exit through transaction cleanup.
Successful or completed-error commands acknowledge normal Status and restore
the exact control byte. An unresolved issued command retains suppression and
quarantine; another prepare request cannot erase that ownership. Selection
failure before a command restores control without acknowledging an unrelated
device request. A stale ERR from the previous command does not prevent the
next command, and an absent previously selected slave is distinguished from
an absent DPTE-selected boot disk.

The parent identification and INT13 adapter must serialize calls and keep
physical interrupts disabled for each bounded native transfer. Native OUTs
run in ring 0 and do not pass through the V86 firmware-control observer. The
observer tracks subsequent firmware changes; it never infers Device Control
from a read of Alternate Status.

## R10e physical refusal and DPTE-independent mapping (2026-10-09)

The newly attached <disk-serial> disk (diskseq32) was mounted read-only.
The capture is `build/full/t23-next/physical-logs-20261009-diskseq32-r10e/`.
CVFL generation1 stops at phase4, native state0, zero reads/writes, then
EXEC reports DOS AX0002 for the existing DPMIRUN.COM. AH48 succeeded and
reported at least30 bytes; its configuration pointer validation rejected it.
The raw pointer and AH41 capability flags were not recorded, so the exact
refusal predicate is unknown. This is a failed physical R10e launch.

Research before changing the fallback: Phoenix EDD1.1 section3.2.8 specifies
the configuration pointer as optional (AH41 CX bit2) and FFFF:FFFF as invalid.
https://www.singlix.com/trdos/archive/pdf_archive/ATA_EDD_11.PDF
ATA/ATAPI-6 task-file registers define device selection, LBA, sector count,
READ SECTORS, READ MULTIPLE and READ DMA; Device Control is write-only.
https://www.read.seas.harvard.edu/~kohler/class/04f-aos/ref/hardware/ATA-d1410r3a.pdf
SeaBIOS demonstrates programming these registers during a BIOS disk read.
https://raw.githubusercontent.com/coreboot/seabios/master/src/hw/ata.c

Decision: preserve valid DPTE binding, but allow independent mapping from
actual firmware OUT instructions during a serialized VM0 BIOS reset and
single-sector LBA0 read. Observe both legacy ATA register sets passively;
forward each original instruction once. Require a unique complete LBA28
read command, selected device, count1, LBA0 and an observed safe control byte.
Do not select a disk by its contents or guessed ports. The existing native
IDENTIFY/capacity/sector-comparison gate remains mandatory after mapping.
Reject unavailable/ambiguous observations (including SMM I/O that cannot
be observed), and never issue speculative native commands. Discovery
callbacks live in CVSESSION, outside the conventional kernel.

The fallback is implemented by VM operations56h/57h in CVSESSION. BEGIN
installs14 passive byte-output observers; only VM0 inside guarded firmware
execution contributes evidence. END removes all observers and installs the
exact selected control observer. CX0 aborts after a firmware error. A failed
callback removal retains its ownership count and blocks module unload.
Pre-read initialization C6/91/EF/EC/08 contributes no disk identity; fresh
count/LBA/device writes are required afterward. READ20/C4/C8 mapping is
accepted only with count1, LBA0 and exactE0/F0 device selection. SMM-only
I/O that bypasses these callbacks cannot qualify a device.

AH41 bit2 is now honored; 26-byte EDD responses remain useful without a
configuration pointer. Valid far pointers are normalized before copying
16 bytes so a segment-offset boundary does not falsely reject contiguous
physical memory. `SYSTEM/DISKBIND.BIN` (CDB1/version1/80bytes) records AH41
CX at8, parent result at10, discovery-selected flag at12, and the64-byte
ADP1 packet at16, preserving the original EDD response/pointer.

Validation:627 ASan/UBSan C checks,82 actual assembly adapter checks,
15 actual unload checks and20 parent-binder checks pass. The production
OpenWatcom module compiles; the kernel remains byte-identical to R10e/R9.
The generic runtime test uses a private image with only the optional-pointer
capability test forced false; production has no such override. It therefore
executes actual firmware discovery and native binding, then completes two
DOOM game/menu/input/quit/reopen cycles with a background Display window.
CVFL generations1/2 finish stage8/exit0: native reads120336/241197 and
writes184/405, state2/error0/control-known1. The captured device model has
160 audio underruns; no audio-timing qualification is inferred.
Evidence:`build/full/t23-next/qemu-dos-diskseq32-r11-observed/report.json`.
This is a software integration check, not emulation of the IBM firmware.

## R11 physical record: valid low-memory DPTE rejected (2026-10-09)

Diskseq33 capture matches all seven R11 production binaries. CDB1 reports
AH41 CX0005, AH48 length30/flags0001 and pointer0040:00C6 (linear000004C6).
The earlier arbitrary minimum00001000 rejects that firmware buffer and
sends the T23 through passive discovery; that returns unsupported at
phase13/error3, so native counters remain zero and target EXEC AX0002.
The EDD1.1 section3.2.8 configuration-pointer definition places no4KiB
minimum on its address. The reference is a temporary BIOS-owned buffer.
https://www.singlix.com/trdos/archive/pdf_archive/ATA_EDD_11.PDF

Decision: remove the invented4KiB lower bound from the read-only DPTE copy.
Reject null/unrepresentable ranges, normalize the far pointer and bound the
entire16-byte read below1MiB. Keep checksum, version, exactports/device/IRQ,
EDDparameters, nativeIDENTIFY and sectorcomparison requirements unchanged.
Test the exact physical0040:00C6 spelling as well as high-ROM and alias
spellings, immediate copy before reuse, and the existing optional-pointer
fallback. The old implementation must fail the same low-memory test.
