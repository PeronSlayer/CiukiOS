# Native ATI Rage Mobility-P/M 2D engine

Research and implementation decision, 2026-10-09. The physical Armada E500
reports PCI `1002:4c4d` and firmware LFB 1024x768, packed24bpp, pitch3072 at
`0x40000000`. It must use a Mach64 engine path rather than the existing
Radeon/Rage128 scanout-offset backend. Detection alone never publishes an
acceleration capability.

The primary reference is ATI's [RAGE Pro and Derivatives Programmer's Guide,
Rev1.0](https://oummg.com/manual/imgs/ATI3DRageII/PRG-215R3-00-10_RAGE_PRO_and_Derivatives_Programmers_Guide_Rev_1.0_200003.pdf),
sections5.2.1 (FIFO and idle),6.4.1 (packed24bpp) and6.4.2 (coordinate and
scissor limits). The pinned [X.Org Mach64 sources](https://github.com/X11Libre/xf86-video-mach64/tree/a6aefafdb998cd4abc2e8f8572f71d68b871f8d5)
corroborate BAR2+0x400 as Block0 MMIO (`atipreinit.c`), chip4c4d as Mach64
Mobility (`atichip.c`), hardware VRAM decoding (`atipreinit.c`), FIFOed register
reads only after idle (`atimach64io.h`), and readback-cache invalidation before
CPU framebuffer access (`atimach64accel.c`). The sources and manual are pinned
in `gpu-vendor-support-research.md`; downloaded copies remain in ignored build
research directories. CiukiOS code is independently written from the register
contract; no GPL Linux acceleration code is copied.

The firmware owns mode timings, PLLs, panel, PCI decode and scanout. This
module touches engine context only. A read-only automatic probe verifies exact
PCI ID, class, enabled memory decode, BAR0/LFB match, valid32-bit BAR2, hardware
chip ID, active CRTC dimensions/depth/pitch and VRAM extent. It never sizes
BARs destructively and never broadens another family's whitelist. An explicit
four-step qualification separates probe, setup/restore, private pixel proof/
restore, and retained qualified ownership. Scratch lies beyond all framebuffer
pages owned by the caller and below a64KiB guard in firmware usable VRAM.

Packed24bpp is handled as an8bpp engine: byte-scaled X coordinates, widths,
pitch; rotation `((starting_byte_x /4) %6)`; DST24 rotation enabled; and full
24-bit colour/write-mask payload. This preserves complete pixels and does not
stretch or reinterpret the firmware image. Screen copies use source and
destination byte coordinates and reverse traversal for overlapping ranges.
Every command is bounded by FIFO availability and engine idle; every CPU VRAM
handoff invalidates the readback cache. The private proof saves/restores its
4KiB region and checks distinct colour channels, shifted X origins and a
two-row hardware copy. Capabilities remain zero until proof succeeds.

Engine registers are saved only while idle. Release restores non-triggering
registers, individual scissor fields (the packed write aliases are not assumed
readable), individual source/destination X and Y, and destination width but
never destination height/height-width, whose writes would launch a draw. The
trajectory position and size are scratch engine context; restoring height is
unsafe and deliberately omitted. GEN_TEST_CNTL GUI enable is preserved without
resetting clocks, PCI, mode, or unrelated firmware state. A timeout after
ownership is acquired prevents CPU framebuffer use until safe release.

This is hardware fill/copy acceleration. It does not advertise triangle or3D
capabilities. Host register fixtures and target compilation validate command
contracts and fail-safe ownership; they cannot establish physical ATI success.
