# DOS VM baseline vector ownership

Research and decision: 2026-10-09, before implementation.

The R13 T23 capture retains MCB31CEh (owner1180h, 1000h paragraphs) because
INTDD points to 3FBA:0020. Its twelve pin observations are repeated observations,
not twelve distinct allocations. DOOM's original V_Init requires a contiguous
16,000-paragraph DOS allocation; the captured later Wolf session has a maximum
of only6,606 paragraphs. See the original-binary audit in
`docs/validation/2026-10-09-t23-r13-original-doom-vinit.md`.

The [MS-DOS Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
defines owner-zero MCBs as free allocations. The
[Microsoft DOS allocator](https://github.com/microsoft/MS-DOS/blob/main/v4.0/src/DOS/ALLOC.ASM)
uses that ownership when granting conventional memory. A service cannot retain
a valid DOS allocation lifetime through an owner-zero block which DOS can
grant to any subsequent program. This is an allocation ownership rule, not a
claim that particular interrupt numbers are unused.

The [pinned JLOAD implementation](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Tools/JLOAD/JLOAD32.ASM)
installs flat DS and ES before invoking DllMain. CiukiOS snapshots the actual
1024-byte IVT then. Shell startup loads drivers and LFN before VMSTART, and
enters the desktop after VMSTART. The current restoration records pointer
values but no load-time memory ownership. Thus an unchanged pointer originally
inside free memory may later alias a GUI allocation and pin that unrelated
allocation. The physical capture cannot prove the load-time ownership of DD;
the repair must measure it rather than assume it.

Add a bounded JLM module for baseline ownership registration. VMSTART registers
the actual kernel segment/InDOS identity and first MCB immediately after JLOAD
returns, before the GUI allocates its application heaps. Validate the complete
conventional arena against the kernel's last MCB and BIOS conventional ceiling
before publishing any classification. Retain the raw IVT snapshot permanently.
Classify only snapshot targets which still equal the live vector and lie in
the payload of an owner-zero block. Preserve allocated/resident targets,
MCB headers, outside-arena targets, and changed vectors without exceptions.

VMM_IVT may replace a classified pointer in its output with the kernel's
existing fixed IRET entry only if the requesting VM's live pointer still
equals that raw snapshot. It never changes VM0's IVT. The IRET offset comes
from the exact build listing and its opcode/storage are verified at
registration; no firmware address or new dummy handler is guessed. Missing
registration preserves the original behavior. A conflicting registration or
invalid chain must fail without publishing a partial classification.

VMFORK then follows its existing restoration and owner-qualified reclamation.
Genuinely resident and subsequently changed pointers retain their existing
lifetime guards. No pin exemption, memory ceiling increase, game binary
patch, or kernel allocator change is authorized by this design.

Validation must execute the new assembly and the actual kernel/VMFORK:
owner-zero versus resident provenance, equal versus changed pointers, aliases,
headers, malformed chains, duplicate registration and kernel identity; then
the original DOOM V_Init must satisfy its actual256,000-byte request after
safe reclamation in a measured fragmented fixture. QEMU is a separate generic
integration check and does not emulate the T23 GPU or establish hardware
qualification.
