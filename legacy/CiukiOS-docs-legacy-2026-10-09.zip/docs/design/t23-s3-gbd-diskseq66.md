# T23 diskseq66: GBD setup through the command interface

The R8c physical capture identifies setup predicate3: MM816C reads zero
instead of `10200401`. The engine-control predicate passes. This is evidence
of the direct-MMIO descriptor path failing its readback, not evidence that
the register is write-only or that native rendering works.

Before changing the implementation, the upstream
[Linux v6.2 Savage framebuffer driver](https://github.com/torvalds/linux/blob/v6.2/drivers/video/fbdev/savage/savagefb_driver.c#L283)
was checked: `SavageSetup2DEngine` includes SuperSavage, programs GBD through
BCI SETREG indices E0/E1, and submits both words twice. Its repeated-write
comment describes a SavageIX workaround; that comment alone does not prove
the T23 cause. The
[S3 Savage4 register manual](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
documents GBD1/2 at MM8168/MM816C and BCI E0/E1 as read/write. This manual
is for Savage4; the shared SuperSavage layout and descriptor fields are
corroborated by `SavageSetGBD_PM` in the
[X.Org 2.4.1 source archive](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz).
The X.Org warning about an early MM816C write applies explicitly to Savage4,
so it is not treated as a confirmed SuperSavage diagnosis.

Decision: use the documented BCI path for the final descriptor, keeping the
SuperSavage descriptor bits already derived from X.Org. Submit E0/E1 twice,
wait for bounded idle, and require the same exact MMIO readback predicates.
Do not weaken the check, change scanout/timings or enable shadow DMA. Setup
prefix19 now submits the descriptor, prefix20 waits for it, and prefix21
validates it. Earlier restored prefixes are unchanged.

Once BCI descriptor submission begins, rollback must restore both saved
words through BCI while the interface remains enabled, wait for idle and
verify both readbacks before disabling BCI and restoring the other state.
If submission, idle or restoration cannot be proved, retain ownership and
the mappings for recovery. Setup phases issue no drawing commands. Private
2D and triangle rendering must still pass their separate pixel tests before
being advertised. CPU protocol tests do not establish physical success.

The updated host model passed 95 scenarios under AddressSanitizer and
UndefinedBehaviorSanitizer, including all 21 setup prefixes, exact register
restoration, no drawing during setup, rejected BCI submission, FIFO/idle
timeouts and retained ownership on failed rollback. Results and tested source
hashes are in `build/tests/s3-diskseq66/report.json`. The model implements
the documented E0/E1 register mapping; it does not emulate a T23 GPU.
