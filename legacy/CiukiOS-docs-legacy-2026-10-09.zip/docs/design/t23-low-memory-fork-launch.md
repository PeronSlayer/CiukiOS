# Fork launch with Display and Files still open

Diskseq66's physical capture identifies a failure before any VM exists:
`EXEC failed \\VM\\VMFORK.COM code=0008`. The parent has1049 paragraphs free,
largest687, root1180/0F9A. Thus missing child CVFL/DOSVM snapshots are expected
here. The previous diskseq65 launch had4259 free; the difference3210 equals
DISPLAY.APP's3209-paragraph allocation plus its MCB. This accounts for the
additional memory used while Display remains open. DOSVM.APP on the disk is
byte-identical to R8c (SHA256 `ee549a9b910881ab12100194302aba8799f4981e439c5522129b5e2b8a69aaa0`).

Before implementation, Microsoft's
[MS-DOS Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
was checked for COM allocation/stack and MZ CS/SS, IP/SP and min/max allocation
semantics, together with its original
[EXEC implementation](https://github.com/microsoft/MS-DOS/blob/main/v4.0/src/DOS/EXEC.ASM).
CiukiDOS's COM selector reserves the file plus PSP and an additional0200
paragraphs for an unspecified COM stack. For the captured6624-byte VMFORK,
that requires942 paragraphs, exceeding the measured687. VMFORK already
includes and initializes a512-byte stack in its payload. Its own explicit
MZ requirement avoids reserving an additional8KiB without changing the
generic COM policy or the game's eventual memory allowance.

The full build keeps VMFORK.COM for existing command-line/probe callers and
also creates VMFORK.EXE from the identical payload. A32-byte standard MZ
header declares CS=SS=FFF0 relative to the load-image segment, IP0100, and SP
at the included stack's end; the16-bit segment addition selects the PSP.
MINALLOC=MAXALLOC=1 provides one extra paragraph and avoids the special
both-zero load-high layout. The wrapper needs no relocation or new startup
stub. DOSVM now explicitly executes the EXE. The HDD build/profile check
and physical-log capture include it; capture also includes DOSVM.APP.

Compaction also avoids a redundant second allocation when VMFORK already
owns a separate conventional PSP. Reuse requires CS=current PSP, SS=CS,
a valid self-owned MCB, enough image/stack space, a consistent initial PSP
ceiling, a full
extent above the root tail, and no other allocation owned by this PSP.
Otherwise the established copy/rebase path remains, including embedded PSP
callers. Existing root/vector pin checks still run before this decision.
The final compacted PSP takes ownership of its block and publishes its exact
size with AH4A before retiring the old PSP. This rebuild is needed because
an ordinary EXEC PSP has no heap-table entry for F149 to remove. This also
keeps the active PSP extent cache consistent. PSP:2 may exceed the current
MCB end because DOS retains its initial ceiling after AH4A shrinks a block;
the reuse check accepts that bounded initial ceiling instead of requiring
equality. No live desktop module is
unloaded and neither kernel nor VM-manager memory limits change.

DOSVM retains the actual DOS EXEC error in its failure window and parent log.
For this case it displays `Unable to run the DOS session.` and
`DOS error code: 0008`, rather than the ambiguous FFFF session result.

Focused validation on2026-10-09:

* `test_vmfork_mz_memory.py` executes the actual full-profile kernel's COM
  selector and MZ selector/load/run using a synthetic parent with exactly
  FREE1049/MAX687. Only file reads supply the in-memory assembled binary.
  Updated COM requires956 paragraphs and returns0008; EXE requires447,
  allocates445 to PSP8002, and transfers with CS=SS=DS=ES=8002, IP0100,
  SP7090. Its code and all parent allocations are preserved. Free memory
  afterward is602 paragraphs, largest362. The only modified payload bytes
  before entry are the normal PUSH/POP FLAGS at the private stack top.
  The actual AH4A then shrinks the block to444 paragraphs, preserves PSP:2,
  and the assembled reuse predicate accepts that valid resized PSP.
* `test_vmfork_low_compaction.py` passes11 actual-kernel cases. After loading
  the444-paragraph payload into a synthetic687-paragraph launch interval,
  FREE604/MAX242 cannot hold another copy. Preparation nevertheless reuses
  the owned PSP, releases the validated root tail, and compacts correctly.
  It also tests embedded copy/rebase, UMB refusal, unknown resident signatures,
  root vector pins, and rejection of invalid ownership/extent/dependencies.
* Thirty retained-allocation tests still pass with the actual allocator.
  OpenWatcom compiles DOSVM with the normal warnings-as-errors flags.

Reports are in `build/tests/vmfork-mz-diskseq66/`,
`build/tests/vmfork-low-diskseq66-final/`, and `build/tests/vmfork-pins-diskseq66-final/`.
These fixtures isolate the measured launch-memory failure. They do not
establish that later T23 game execution or S3 acceleration is now working;
that needs the next hardware run and its parent-persisted checkpoints.
