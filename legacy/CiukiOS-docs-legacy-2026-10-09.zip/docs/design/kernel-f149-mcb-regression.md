# F149 free and the conventional arena root

Investigation, 2026-10-08. The T23 reports VMFORK return `F011` after the
private S3 resident is released. The suspected interaction is the F149
dispatcher temporarily replacing `dos_exec_identity_psp` with the released
block's owner: ownership validation and the active EXEC ancestry then share
one identity even though they have different purposes.

[RBIL INT 21h/AH=52h](https://fd.lod.bz/rbil/interrup/dos_kernel/2152.html)
defines ES:BX as the list of lists and the word at offset -2 as the first
MCB segment. Freeing a TSR must preserve that arena root and all unrelated
live allocations. Repository inspection shows `int21_free` calling
`int21_mem_rebuild_chain`, whose root comes from
`int21_mem_lowest_psp` following PSP:16h parents. A resident can retain the
PSP of an already exited loader as its parent; that chain cannot replace the
running SHELL/VMFORK ancestry.

The CPU regression assembles the actual full-profile CiukiDOS kernel and
executes its dispatcher, free implementation, allocation table update and
MCB rebuild in Unicorn. Only initial process/MCB state is supplied by the
fixture. No allocator routine is mocked. Cases vary the resident's parent
and requested owner, retaining checks on the original first MCB, the live
root/child allocation and the private block being released.

The pre-fix kernel reproduces the failure: a correct-owner F149 returns
AX=0/CF=0 yet changes the first MCB published by AH=52h from `117F` to
`2504` when the resident's parent is no longer a PSP. Even when the resident
still names a live parent, it is inserted back into the chain with 11259
paragraphs instead of 80. This second corruption occurs because
`int21_mem_psp_end` treats the temporary owner as the active PSP and reuses
the real child's cached end (`5100`), covering that child's `5000` PSP.
Ordinary AH=49 free/ownership checks and active-child AH=4A/F14A resize are
controls and pass on the same baseline.

Reproduction:

```sh
uv run --with unicorn python scripts/test_kernel_f149_arena.py \
  --expect-regression --report build/tests/kernel-f149-before.json
```

After the production fix, omit `--expect-regression`. A preserved kernel
binary and matching NASM listing can be supplied using `--kernel` and
`--listing`; the JSON records the exact binary SHA-256. The preserved
pre-fix binary used in this session hashes to
`56f242f4560d011a6313fee2eee939cf04e028d77de6435308de178de361c2c6`.
The fixture's RAM layout is constructed to exercise these relationships;
it is not presented as a byte-exact capture of the T23's process arena.

The correction keeps the true EXEC PSP throughout the free. F149 supplies an
explicit owner on the allocator's stack; ordinary AH=49 supplies zero and keeps
its previous ownership behavior. The explicit owner is checked before the
resident exception, and zero/wrong owners are rejected with DOS error 9. There
is no new allocator-state global or enlarged snapshot/memory ceiling.

All 13 cases pass on the corrected `src/runtime/ciukidos.asm` full-profile
kernel, SHA-256
`64ab65017f16d612c3b2753ba5fea4f680173dcfd9cad8b43f9f58c2564839d8`.
These include stale/zero/live parent chains, resident/nonresident correct and
wrong ownership, zero-owner refusal, ordinary AH=49 controls, actual AH=52h
publication and both AH=4A/F14A active-child resizes. Reports are retained in
`build/tests/kernel-f149-20261008/{before-extended-report,after-report}.json`.
This is CPU regression evidence; full launch and physical T23 qualification
remain separate validation steps.
