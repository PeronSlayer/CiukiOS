# S3 guest detachment fixtures

The independent CPU fixture executes the assembled `detach_s3_guest` routine.
It now uses diskseq63's captured T23 chain `24FD:0048 -> 2195:0470`, and the
resident produced by executing the pinned project S3VBEFIX.COM installer
(4123 bytes, SHA256
4072e46a340ae7d2c0f22d556857a74734b77e46134853d089af30a798d08f3f).
The arena contains both self-owned resident blocks as actual bounded MCB
members. The F149h stub enforces ES=BX=24FDh and allows exactly one free, so a
plausible header cannot authorize freeing a different allocation.

The actual pinned installer subroutine at COM:B6Bh runs its resident copy,
INT10 and optional INT6D installation, and environment free. Both default and
`/I` paths must make the expected DOS calls and reproduce the entire copied
resident byte range. DOS calls are modeled; this subroutine fixture excludes
the hardware setup and final INT27 termination in the full program.

Run this lightweight check with:

```bash
uv run --with unicorn python scripts/test_vmfork_s3_guest.py
```

Cases cover successful detachment, system-VM and unknown-handler skips,
near-ceiling IVT safety, malformed pinned prefix, active internal call,
MCB type/owner/size, predecessor identity/owner/size, missing arena membership,
other IVT aliases into both the MCB header and resident allocation, and DOS free
failure. All general registers including their upper 32-bit halves, segment
registers, and FLAGS/EFLAGS except returned CF must survive. Hardware interrupts,
port IN/OUT and MMIO/ROM access fail the fixture. Independent system and guest
memory instances verify that only the guest's IVT and validated MCB change.
This models the private-copy contract; repository VMM page-allocation inspection
and runtime qualification provide the evidence for real private mappings.

The independent review exposed and helped fix an owner-register mismatch:
F149h requires BX to name the validated MCB owner. The guard also needs an early
conventional-memory bound before reading a candidate header near A0000h.

`src/probes/vm/s3shim.asm` builds a benign test-only TSR for QEMU's standard VGA
profile. It accepts only the known AUXSTACK predecessor, installs the pinned
header/version/prefix layout at PSP:0040h/0048h, and keeps 20h paragraphs. Both
conditional handler paths tail-jump to the existing AUXSTACK handler. It neither
implements S3 behavior nor invokes device hardware. Its installation and both
forwarding branches are also executed by the CPU fixture.

Before implementing this TSR fixture, Microsoft's original
[MS-DOS 4.0 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
was checked for AH=35h/25h vector discovery/installation and AH=31h residency.
The pinned upstream S3VBEFIX ends through INT27 with DX naming the first byte
after its resident extent. LOADDRV's `q_int27` rounds that extent to paragraphs
and jumps to AH31 in the current INT21 chain. The later console fixture uses
this normalized AH31 path, and now also frees the environment as S3VBEFIX does.
The reference's INT27 contract restores vectors 22h/23h/24h from the PSP.
The actual header and handler
contract is grounded in the
[pinned S3VBEFIX source](https://github.com/wbcbz7/S3VBEFIX/blob/5d2a891a8a80e6ef4e6c99cb2f9afe9d39477884/src/S3VBEFIX.ASM)
and the supplied binary. The test TSR is installed only into a private image
copy and is not added to the canonical full image or release.

The existing original-DOOM gate now accepts `--s3-resident-fixture` under this
specific profile:

```bash
systemd-run --user --scope -p MemoryMax=3G -p MemorySwapMax=1G -- \
  python scripts/qemu_test_t23_runtime.py \
  --image build/full/ciukios-full.img \
  --output build/validation/s3-guest-doom \
  --vga std --memory 512 --launch-method files --game-args '' \
  --skip-display --s3-resident-fixture
```

Run this alone after checking host memory. The gate assembles the fixture,
injects it into SYSTEM/TEST on its private HDD copy, removes old VM diagnostics
from that copy, and installs it through the real text console before the first
game. It then uses real Files navigation/double-click and the unchanged installed
TestGames DOOM.COM launcher with no arguments. Existing title/menu/gameplay/input,
menu quit, finished-window close and second-launch checks still run.

After each game, read-only RAM captures must show the system VM's INT10 and
entire retained fixture allocation unchanged. A complete CVFL record must show
S3-detachment progress 0400h and target return, with the fixture PSP/predecessor
and allocation size. Its VM id, generation and exit code must match the
DOSVM snapshot with natural `observed_exit` reason and `free` state. The second launch requires fresh generation evidence. Both
per-launch records and host-memory captures are retained in the output. The
source image's SHA256 must remain unchanged.

The optional gate has been prepared and syntax-checked; its heavy QEMU runtime
is owned by the main integration. Neither the CPU fixture nor this standard-VGA
QEMU profile qualifies physical S3 hardware or the Windows launcher.

The T23 F011 investigation adds `--s3-stale-parent` (requiring the resident
fixture). It installs `S3PARENT.COM` only on the private test image. After the
TSR installer has returned, this utility checks the exclusive harmless-shim
token, pinned forwarding prefix and exact self-owned 20h-paragraph MCB, then
sets the resident's PSP:16h parent to zero. Delaying this until after TSR return
preserves the installer's real termination path. The utility refuses the
production S3VBEFIX, which has no test token. Five CPU cases execute its actual
binary and verify only those two bytes change; bad token, owner, size and IVT
offset are refused. The QEMU gate snapshots and compares the entire resident
before/after the change and retains the parent/fixture hashes. All subsequent
host immutability and two-launch assertions remain in effect.

The old F149 fixture above intentionally stubs the DOS call and therefore
cannot validate the kernel's allocator. The new
`scripts/test_kernel_f149_arena.py` complements it by executing the complete
actual CiukiDOS dispatcher and MCB allocator; see
[the allocator regression](kernel-f149-mcb-regression.md). It reproduces the
old first-MCB/cached-PSP-end corruption and passes all 13 cases after the fix.

The first forced-S3 runtime on 2026-10-08 reached original DOOM gameplay,
changed frames with real input, and quit normally; the host vector and fixture
allocation matched their pre-game captures. The gate then rejected the evidence
because it incorrectly required `dead`. Repository `vmm_exit` marks DEAD, but
`vmm_switch` releases the private pages and marks FREE before the system-VM
observer sees natural termination. Generation and exit code are retained.
The captured CDVS is VM1/generation1/observed_exit/FREE/exit0. The failure dump
also contains a complete matching CVFL at 001BA000h and 001BB5BAh with stage8,
progress057Fh, exit0 and I/O error0. Absence of an exported VMFORK file was caused
by the failing candidate predicate and incomplete failure export, not evidence
that trace writes failed.

`python scripts/test_s3_guest_launch_evidence.py` uses those exact captured
CVFL/CDVS records as small checked-in fixtures. It accepts the natural FREE exit
and rejects mismatched generations, VM ids and exits, missing detachment/EXEC/
return milestones, running/DEAD states and timeout/user-close reasons. The gate
now retains raw VMFORK files on failure too. Two complete launches still require
a fresh successful runtime gate; the first partial result alone does not pass it.
