# Editable text selection

Research and implementation decision, 2026-10-08.

Microsoft's [Edit Control Text Operations](https://learn.microsoft.com/en-us/windows/win32/controls/edit-controls-text-operations) defines selection as a half-open character range and replacement as deletion of that range followed by insertion at its start. Its [custom edit control sample](https://learn.microsoft.com/en-us/samples/microsoft/windows-universal-samples/customeditcontrol/) uses Shift with arrow keys to extend the range. [WM_LBUTTONDBLCLK](https://learn.microsoft.com/en-us/windows/win32/inputdev/wm-lbuttondblclk) documents press/release/press detection within the configured double-click interval and delivery to a captured window.

Repository inspection found two existing models: CiukNote's document has separate anchor and caret positions, while `ui.c` fields had only an all-or-nothing `sel` flag. Browser address/form controls implemented separate append-only editing. All C application dialog fields, Files address and inline rename, Desktop inline rename, and Browser editable fields will share the range model. CiukNote retains its existing multiline model and uses the configured double-click interval.

The single-line model stores anchor/caret positions, paints only the selected visible glyphs, and retains a bounded horizontal viewport. Mouse dragging, Shift+click, double-click word selection, Ctrl+A, Shift+arrows/Home/End, Ctrl+arrows, and selected-range Backspace/Delete/replacement use the same indexes. A left/right arrow without Shift collapses the selection to its corresponding edge. Double-click selects the word under the pointer without trailing space; continuing to drag extends by complete words. Password fields measure and render masked glyphs without exposing their text in highlights. ASCII letters, digits, underscore and extended code-page bytes form words; punctuation and whitespace have separate runs. This is a byte-oriented code-page editor, not a Unicode grapheme editor.

Mouse selection begins only inside an editable control and consumes subsequent move/release events until release. Window resize capture remains owned by the shell and precedes application client events. Disabled fields never begin selection. Tab and dialog mnemonics keep existing select-all-on-focus behavior.

The native shell Run field was separate assembly code (`shell_gui_input.inc` / `shell_gui_dialogs.inc`) and was not covered merely by changing the C toolkit. It moves into `RUN.APP`, keeping window ID 1 and the existing builtin aliases with their complete argument tails. Ordinary commands open a DOS window; the explicit Full screen action retains the existing command service. This also frees space in SHELL.COM, which was within three bytes of its size ceiling.

CiukPaint's pending canvas text also uses the shared anchor/caret range. Its installed font and zoom determine hit positions; selected glyphs are overlaid only during UI painting, so the highlight cannot become image pixels when the text is committed. Enter inserts a line break, arrows and Shift extend the range, and clicking outside the pending text commits it. CiukNote keeps its multiline document editor; both editors select whole words on a double click and extend that selection during dragging.

Host validation compiles the same `ui_field.inc` used by the application toolkit with bounded drawing and proportional-glyph stubs. It checks range edits, key navigation, reversed selections, pointer capture, double-click timing/wrap, masked drawing, clipped highlighting and viewport scrolling. Full-image runtime validation remains the integrating agent's responsibility.

`python3 scripts/test_ui_field.py` passes 70 shared-editor/actual-Run assertions
plus 26 checks of the actual Paint text geometry and keyboard functions under
AddressSanitizer and UndefinedBehaviorSanitizer. The affected production C
sources also compile with the normal Open Watcom warning-as-error flags.
The host test explicitly covers bounded extended code-page bytes; it does not
claim Unicode grapheme editing. Run's `_run_command` and `_run_input` map
symbols allow runtime harnesses to verify characters accepted by the real
CAPP, replacing inspection of the removed native shell field.

The additional canvas editor exposed Paint's flat CAPP segment limit at link
time. Following the [Open Watcom mixed-memory guidance](https://open-watcom.github.io/open-watcom-v2-wikidocs/cguide.html)
and [DOS AH=48 paragraph allocation contract](https://fd.lod.bz/rbil/interrup/dos_kernel/2148.html),
the existing 3072-byte BMP/XMS scratch row moves from DGROUP to the end of the
already owned DOS undo-index block: offsets 0..4799 retain the two 1200-word
index arrays, offsets 4800..7871 hold scratch. DOS I/O uses the existing far
read/write functions and XMS moves use that segment/offset directly. The
same `tabs` lifetime releases both regions. Dimensions, directory capacity,
scratch capacity and 4096-byte stack remain unchanged; no extra handle or MCB
is needed. Allocation remains one checked operation before any canvas I/O.

`uv run --with unicorn python scripts/test_paint_scratch.py --report
build/tests/paint-scratch-20261008/report.json` executes Open Watcom's actual
16-bit Paint BMP loader/saver, runtime and far-pointer accesses in Unicorn.
Six round trips pass: 1280/2048-pixel 24-bit images, 2048-pixel 32/8-bit images,
1281-pixel 4-bit and 2047-pixel 1-bit images. Palette-representable pixels
round-trip exactly, including nonrepeating patterns across 3072-byte chunk
boundaries and padded scanlines. The fixture verifies far transfers at offset
4800, canaries covering the 4800-byte undo-index region and allocation ends,
and release of every allocated block. DOS filesystem/allocation and external
shell-service boundaries are emulated; this is not a T23 hardware claim.
Paint's production individual link ends at 64736 bytes including its unchanged
4096-byte stack, leaving 800 bytes below the CAPP segment ceiling. The file
dialog's near filename/directory storage is not aliased with scratch.
