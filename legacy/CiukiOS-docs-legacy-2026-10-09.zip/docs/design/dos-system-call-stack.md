# DOS system-call stack ownership

Decision before implementation, 9 October 2026. The R17 marker-only OEM mouse
boot exposed corruption, not a slow BIOS C2 operation. The original injected
CuteMouse MZ body is 5,863 bytes and starts at physical `225E0`; its PSP is
`224E`. Initial SS:SP is `224E:18E7`, only 256 bytes above its image end
`17E7`. After the complete AH02 banner, RAM at offsets `17CF..17E6` no longer
matches the original option table: return frames overwrite the table. The
GDB trace calls the corrupted W-option handler at PSP offset `0046`, then
leaves the code segment. Saved INT33 was correctly `0300:0353`; the error
occurs before any PS/2 C205 request. Evidence is preserved in
`build/full/t23-next/bios-input-control-r17-b2/` and `bios-input-stall-r17-b2/`.

[FreeDOS entry.asm](https://github.com/FDOS/kernel/blob/master/kernel/entry.asm)
switches to its DOS-owned API stack in `int21_normalentry` before calling
the dispatcher. The [FreeDOS service dispatcher](https://github.com/FDOS/kernel/blob/master/kernel/inthndlr.c)
keeps console output and file operations separate; the owner of a service
must provide its execution storage. CiukiDOS currently runs its complete
INT21 dispatcher, BIOS output and metadata mirror on the interrupted program's
stack. A valid DOS program with a small stack must not have to reserve space
for those kernel internals.

The full core will own twelve 512-byte interrupt stack slots: one per active
DOS interrupt, covering the eleven supported nested EXEC frames plus its
outer call. Entry uses only 42 bytes of caller storage, including the CPU's
six-byte interrupt frame, to snapshot all 32-bit general registers and DS/ES.
It copies that frame into a dedicated slot before dispatch. Exit copies the
returned registers and modified IRET frame back to the original SS:SP and
restores the caller stack before IRET. Each nested entry uses another slot,
so launching a child cannot overwrite the parent syscall's inactive frame.
Full-depth rejection returns error 8/carry without corrupting an existing
slot. IF remains disabled during copying; the caller's IRET flags preserve
the original IF/DF plus the service's carry/zero results.

The slots and their context records belong to the actual resident core extent
published by CMLY. Their approximately 6 KiB RAM cost is explicit, bounded and
required by the reproduced corruption; no unused kernel growth ceiling is
reserved. Conventional-memory and Wolf regressions must be rechecked after
this change. This does not turn the DOS dispatcher into a reentrant DOS API:
the existing InDOS contract still applies to asynchronous TSR clients.

Required validation includes small odd caller stacks, 32-bit register and
segment results, IF/DF/CF/ZF, nested calls and overflow, real EXEC/termination
and CuteMouse startup with its original unmodified binary. A generic BIOS
mouse run is compatibility evidence, not proof of the physical Compaq firmware.
