# Physical T23: phase-2 freeze, diskseq 63

The 2026-10-08 capture in
`build/full/t23-next/physical-logs-20261008-diskseq63` was copied from the
read-only mounted TS64GMSA230S, serial <disk-serial>. No source files were changed.
`S3QUAL.LOG` contains `CG3D` result `00000102`: the checkpoint immediately
before phase 2, with no after snapshot. Phase 1 returned. The last observed
alternate status was `07e00000`, MMIO BAR0 `c0100000`, framebuffer `e8000000`,
unassigned BAR2 raw `00000008`, 16 MiB VRAM, 1024 by 768 by 32, pitch 4096.
The saved status satisfies the current idle predicate. This is evidence of
where the call stopped returning, not evidence identifying a particular MMIO
instruction. A polling iteration limit cannot recover a single hung bus access.

## Source comparison and implementation decision

Before changing the backend, compare the pinned
[X.Org Savage 2.4.1 source](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz),
especially `SavageInitialize2DEngine`, `SavageSetGBD_SUPER`, and the no-COB
threshold setup in `savage_driver.c`, with
[Linux 6.2 Savage BCI](https://raw.githubusercontent.com/torvalds/linux/v6.2/drivers/gpu/drm/savage/savage_bci.c)
and its [register definitions](https://raw.githubusercontent.com/torvalds/linux/v6.2/drivers/gpu/drm/savage/savage_drv.h).
The local vendor Savage4 manual and Mesa 7.11.2 register declarations inform
register meanings, but do not establish that all Savage4 register readback
behavior applies to SuperSavage.

The old phase 2 mapped a private framebuffer page and read/restored fourteen
3D registers without submitting any 2D or 3D commands. Remove that unnecessary
hardware access. Snapshot only the eight setup registers used by this phase;
restore only registers actually modified. The 2D proof additionally preserves
the PBD/SBD registers changed by BCI commands. Snapshot 3D state only after
the copy proof has passed and a triangle will actually be submitted.

Match upstream's bus widths and order: two 16-bit mix accesses at 8134/8136,
plane masks/mix before BCI enable, no-COB command thresholds, temporary
BD64/block-write-disabled descriptor, CR50 selection, then final GBD address
and format. With upstream no-COB high=32 and low=0, the packed threshold is
`((low & 1fffe0h) << 11) | ((high & 1fffe0h) >> 5) = 1`, not `10001h`.
Continue to disable shadow DMA and the overflow buffer. Do not change PCI
resources, clocks, firmware timings, display base, or the strict startup gate.
These are source-backed corrections; the old physical log does not prove
which one caused the freeze.

## Durable setup prefixes

Display calls restored setup prefixes `0101h..0115h` after phase 1 and before
the existing phase 2. Each call starts from the firmware state, executes a
successively longer prefix, restores every modified register, and unmaps its
resources before returning. No commands are submitted and no partial ownership
is left between GUI polls. Cancelling or a failed checkpoint write stops the
remaining calls. The original four-phase utility ABI remains accepted.

| Prefix | Last newly included operation |
| --- | --- |
| 1..8 | Snapshot 8128, 812c, 8134/8136, 8168, 816c, 48c0c, 48c10, 48c18 |
| 9 | CR31 address mode |
| 10..12 | Write/read plane masks and the two mix registers |
| 13 | Disable BCI |
| 14 | Set no-COB thresholds |
| 15 | Disable shadow status |
| 16 | Enable PIO without COB/DMA |
| 17 | Temporary GBD high |
| 18 | CR50 GBD selection |
| 19..20 | Final GBD low/high |
| 21 | Readback of control, descriptors, CR50, CR31, write mask |

The `CG3D` result keeps its original phase/status low word and stores the
prefix index in its high word. A freeze during prefix N narrows the failure
to the newly added operation or its restoration; prefix 21 groups six
readbacks. It does not by itself prove a single instruction is responsible.

The CPU fixture exercises the production C code with the captured PCI tuple,
nonzero saved register values, exact restoration of each prefix, access
widths, no phase-2 BAR1/3D accesses, ownership and failure paths. It models
register behavior; it cannot certify bus transactions or T23 acceleration.
QEMU is likewise a software regression gate, not a T23/SuperSavage emulator.
Physical confirmation of the resulting image remains required.
