# Window border resizing

Research and implementation decision, 2026-10-08.

Microsoft's [WM_NCHITTEST specification](https://learn.microsoft.com/en-us/windows/win32/inputdev/wm-nchittest)
distinguishes left, right, top and bottom sizing borders, four corner zones,
ordinary client content and fixed borders. Its [cursor documentation](https://learn.microsoft.com/en-us/windows/win32/menurc/about-cursors)
defines horizontal, vertical and both diagonal resize cursors.
[SetCapture](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setcapture)
keeps a held-button operation attached to its starting window until release;
[WM_GETMINMAXINFO](https://learn.microsoft.com/en-us/windows/win32/winmsg/wm-getminmaxinfo)
allows window-specific minimum and maximum tracking dimensions.

The existing CiukiOS window manager uses a bottom-right resize grip only.
`shell_gui_input.inc` duplicates geometry updates for Programs and C APP
windows. `shell_gui.inc` recovers a missed grip from window geometry because
compositor bands can rebuild an incomplete hit list. The compositor already
invalidates both the old and new dragged-window footprints, and C applications
receive updated `HOST.w`/`HOST.h` during painting. `WS_DIALOG` windows explicitly
request a close-only fixed frame and include message boxes and property dialogs.

Keep the existing fixed-dialog criterion. All normal C APP windows, including
DOSVM, and Programs receive eight sizing zones. A window that is maximized does
not expose active sizing borders until restored. Hit-test the topmost visible
window from current z-order and geometry rather than trusting a band's hit
records; covered lower borders cannot steal the pointer. The active edge or
corner stays captured during resizing, preserves the opposite edge, and is
clamped to the work area and minimum dimensions. Preserve ordinary C APP client
mouse capture so edit selections and other client drags continue to work.

Keep 320 by 200 pixels for ordinary C APP windows and 510 by 370 for Programs.
The three dynamic windows with fixed control groups use larger minima:
Tasks 600 by 400, Control Panel 442 by 390, and Player 500 by 270. Tasks needs
its Performance rows through y366 above the status bar; Control needs four
columns and four icon rows through y364; Player needs separate transport and
volume controls plus the timeline. The 640 by 480 desktop has a 628 by 411
sizing work area. Clamp minima to the space available while retaining the
opposite edge; Escape restores the exact saved geometry even if it predates
these bounds. Tasks also opens at 600 by 400 on that screen instead of the old
580 by 380. Reserve the desktop top bar, taskbar and window-shadow footprint.

[Microsoft's window-management guidance](https://learn.microsoft.com/en-us/windows/win32/uxguide/win-window-mgt)
recommends resizing for dynamic content and allows fixed windows for fixed
content that fits the work area. Run, About and Display Properties therefore
use the existing close-only dialog style. About has fixed text rows; Display
Properties has six fixed-width tabs and fixed settings controls. Dynamic
lists, documents, images and the player remain resizable.

Extend the cursor resource with deterministic monochrome masks for horizontal,
vertical and both diagonal resize directions. These are functional cursor
shapes, not changes to the Tango system icon family or the approved Ciuki
portrait. Existing Arrow, I-beam and Forbidden masks remain unchanged. The
512-byte existing cursor workspace holds seven 66-byte cursor records; the
new resource uses a distinct version so old three-record resources cannot be
misread using the new stride.

The old pointer clamp stopped 24 pixels before the right edge and 16 pixels
before the bottom edge, preventing access to some sizing borders. Pointer
coordinates now reach the final screen pixel. Microsoft's
[hotspot definition](https://learn.microsoft.com/en-us/windows/win32/menurc/about-cursors#the-hot-spot)
ties input coordinates to the cursor's hotspot, independently of the bitmap
extent. The [VESA VBE 2.0 standard](https://www.phatcode.net/res/221/files/vbe20.pdf),
ModeInfoBlock, distinguishes visible X/Y resolution from BytesPerScanLine.
Use those fields to bound each packed framebuffer row to visible pixels and
each transfer to visible rows; framebuffer padding is not cursor space.

Packed cursor save/restore keeps the clipped row width, height, pitch and RAM
stride with each of the two saved backgrounds. The saved RAM source identifies
the geometry: compositor page catch-up sometimes restores the front cursor's
background onto the opposite page. Looking up by destination page would use
the wrong rectangle. VGA saves only the remaining one to three bytes of each
visible plane row and restores the same captured byte/row counts. Drawing
clips the centered cursors' masks at the top and left edges as well; the
hotspot stays at the actual input coordinate.

`ui_hit_find` resets stale sizing state, resolves current z-order, then calls
`ui_resize_hit`. A fixed/maximized topmost window blocks sizing of covered
windows. A mouse-held resize owns its initial edge mask; Escape restores its
original geometry and damages the old and restored rectangles. Ordinary APP
capture still receives selection drag/release events. Cursor loading stages
the versioned header and complete 462-byte theme in existing renderer scratch,
validates all seven hotspots, and only then replaces the 512-byte resource
workspace. A malformed resource keeps the previous theme or built-in arrow.
The loaded flag belongs to the asset block: clear it before new assets are
allocated on desktop entry, then let settings load the table. Video
initialization and mode switches retain both the existing block and its flag.
The first QEMU integration run caught a reset in video initialization that
discarded this flag after loading a valid resource; the gate retains its
explicit loaded-resource check, and the CPU fixture now executes the actual
entry and video reset blocks to guard this lifecycle.

Focused validation: `uv run --with unicorn python scripts/test_window_resize.py`.
The fixture assembles the production hit-test, sizing, resource loader and
pointer routines, executes them in a bounded 16-bit CPU, and models only DOS
file calls/framebuffer row transfers/VGA planes. It checks all eight edges and
captured directions, Escape, minimum/work-area clamping, Programs, fixed and
maximized exclusion, overlays, z-order and stale hit records; all 21 themed
cursors and five malformed resources; 24 packed depth/position combinations,
six VGA positions, both saved display pages, source-to-opposite-page restore,
and 16 exact silhouettes of centered cursors clipped at screen corners.
Framebuffer padding and guard boundaries remain untouched, and restoring
the cursor reproduces the original pixels.
The policy fixture additionally runs all eight edges for the three specific
minima at 640 by 480 and 800 by 600 (48 cases), checks the actual three fixed
styles from the shell table, and restores an older below-minimum window
exactly on Escape.

The separate integration driver is `scripts/qemu_test_window_resize.py`.
It verifies that the image's SHELL exactly matches its assembled listing,
boots a copied image, and drives Files/Programs/Run with real keyboard and
relative mouse events. Read-only shell observations locate geometry and
confirm cursor resources, capture, eight edges, Escape, minimum/work-area
limits, maximized and fixed frames, and topmost ownership. Screenshots capture
the actual resized windows and compare restored desktop pixels, excluding
status bars and the parked cursor. The active scenario has a 90-second budget
after boot. A generated script or syntax check is not a passed runtime test;
the integrating build must run it and retain `result.json`.

Validation must exercise all eight border directions, stationary opposite
edges, minimum and work-area clamping, fixed/maximized exclusion and topmost
window ownership. CPU fixtures do not establish display damage correctness or
performance on the ThinkPad; the full-image QEMU test and the physical retest
remain separate integration evidence.
