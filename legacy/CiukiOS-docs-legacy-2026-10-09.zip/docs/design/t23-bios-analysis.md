# IBM T23 firmware analysis

On 2026-10-09 the owner proposed reverse engineering the original BIOS to
understand repeated physical DOS launch failures. Downloaded from Lenovo:
https://download.lenovo.com/ibmdl/pub/pc/pccbbs/mobiles/1auj20us.exe

The package SHA256 is
4fbf4263fe4d0ec40c6c7982a7b9bb9cf41e420fc731143763f1a4de9b2abf7d.
7-Zip extracted its cabinet/FAT12 contents without executing the updater.
`$017E000.FL1` has SHA256
063b4c4bac732a791f9e77822dd9242e7e96e40127d054996416a66fccf2dc04.

The upstream coreboot extraction tools were downloaded and compiled locally:
https://github.com/coreboot/bios_extract
The upstream README describes `bcpvpd` for IBM BCPVPD/$IBMCOMP wrappers.
`bcpvpd` and `bios_extract` ran in a separate 256MiB/64MiB capped user scope.
The unwrapped image SHA256 is
a980d90958418f1e6c5ed96daa8e9f6aeafa8f8d9363a1dd1990356164ee4434.
The extractor identifies PhoenixBIOS 4.0 Release 6.0 for IBM ThinkPad,
1AET64WW, dated2006-10-18. It extracted BIOS code, option ROM, ACPI and
other modules under ignored `build/research/t23-bios/modules/`.

A bounded static disassembly found a candidate AH41/AH42 dispatcher but
did not establish the active INT13 route or AH48 pointer return behavior.
It is not evidence that AH48 is absent: the physical log shows it succeeded.
Installed firmware version is unknown because current captures lack SMBIOS
version information. Updating or flashing the T23 firmware was not required
for this analysis. The original updater was never executed.

The R10e capture at diskseq32 matches all seven captured production binaries
against the immutable R10e manifest. DOS failure and S3 qualification failure
therefore occurred on the newly written code, rather than an older image.

## AH48 and embedded ATA templates located (R11 failure follow-up)

The R11 physical CDB1 log now records AH41CX0005, AH48size30/flags0001
and DPTEpointer0040:00C6. In extracted `bioscode_2.rom`, fileoffsets
D3BC..D3D3 compare callerlength against1Eh and write0040h to[SI+1Ch]
and00C6h to[SI+1Ah]. This establishes that the downloadable BIOS
intentionally returns the same low-memory location seen on the T23.
It exposes the erroneous CiukiOS4KiB pointer minimum. The runtime
DPTEcopy can safely read the whole16byte buffer in the BIOS data area.

Four checksum-valid16byte templates occur in `bioscode_0.rom` at
602D/603D/604D/605D: primary/secondary, master/slave, exact01F0/03F6
or0170/0376 ports and14/15 IRQs. They carry revision10h, not11h, with
initial optionwordzero/headA0orB0. These are initialization templates;
they are not proof of the liveDPTEhead/LBAoptions.

The AH48 code atD350 initially writesflags0003; D39E testsDXbit0010
from the live[BDA:D0]optionword and D3B0 clearsflagsbit1 on its LBA
capacity route. The physicalflags0001 are consistent with that route.
This is an inference from downloaded firmware plus physicalrecords,
not a claim that installed firmwareversion or live16bytes are known.

Revision10/11 compatibility is now supported with all checksum/channel/
IRQ/ATA/liveLBA/EDD/IDENTIFY/sectorcomparison checks retained. The raw
ROMtemplates still fail the liveLBA requirement in focused tests.
The actualreturnedDPTE is recorded in CDB1 after copying and before
subsequentBIOS calls can reuse the temporary buffer.
