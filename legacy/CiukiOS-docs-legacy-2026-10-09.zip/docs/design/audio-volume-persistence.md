# System master volume

CiukiOS uses the AC'97 master-volume codec register for the desktop volume
control. The Intel AC'97 Component Specification defines register 02h as a
master mute bit plus six-bit left and right attenuation fields. Its reset
value is `8000h`, which is muted; the desktop's existing volume scale maps
levels 0–31 to inverse attenuation (`31 - level`). The register definition
and reset value are in the [Intel AC'97 Component Specification, Revision
2.2](https://www.alsa-project.org/files/pub/datasheets/intel/ac97r22.pdf).
QEMU's [AC'97 device implementation](https://github.com/qemu/qemu/blob/master/hw/audio/ac97.c)
models this same master register.

In normal startup, the shell initializes its AC'97 sound driver before the
desktop opens. The driver applies the saved master preference before queuing
the startup melody; if the preference is absent or invalid, it applies level
5, unmuted. The driver retains the existing SAFE, MUTE and HARD startup gates,
so those quiet profiles do not have their mixer changed. No preference file
is needed until the user changes a setting. The taskbar slider saves after a
completed adjustment; the Sound control panel saves its master level and mute
state when the user presses OK. `\SYSTEM\VOLUME.CFG` stores a packed byte:
bits 0–4 hold the level and bit 7 holds mute, so level 5 unmuted is `05` and
level 12 muted is `8C`. Invalid preferences do not overwrite the caller's
fallback values.
`BOOT.SND` remains the separate startup-chime enable setting.

The sound driver is the only startup authority. The desktop reads the live
mixer rather than applying the preference a second time. Its completed slider
and arrow-key adjustments call the shell service's reserved `0100h..013Fh`
save range; the service packs mute into bit 7 and writes the same one-byte
format as the Sound panel. This keeps DOS file handling outside the desktop
module, which is already close to the 64 KiB CAPP memory ceiling. Equivalent
volume-key handling and a table for the seven gear-icon rectangles recover
code space without reducing any stack or buffer. The final Desktop occupies
65,520 bytes including runtime memory; all 19 apps compile successfully.

The host preference fixture checks valid levels/mute, malformed input and
I/O failures. The integrated R9 image passed two isolated QEMU AC'97 boots:
without a preference, the init record preceding startup playback reports
master `1A1A` (level 5), with nonzero recorded PCM. A saved `8C` preference
survives reboot unchanged and produces master `9313` and silent PCM.
Artifacts: `build/full/t23-next/qemu-audio-diskseq66-r9/report.json`.
These checks establish software behavior on the emulated codec, not physical
ThinkPad output.

`qemu_test_audio_slider.py` also passed an actual user-input sequence on a
fresh private copy: click the volume HUD, press Right (5 to 6), then reboot.
The shell wrote byte `06`; the reboot retained that byte and initialized the
master to `1919` before playback. This exercises the new desktop-to-shell
save service, rather than relying only on an offline-injected preference.
Report: `build/full/t23-next/qemu-audio-slider-diskseq66-r9/report.json`.
