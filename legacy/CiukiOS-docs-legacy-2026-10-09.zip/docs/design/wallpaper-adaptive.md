# Adaptive Ciuki wallpaper masters

The three original `misc/ciukios_bg/Ciuk1.png`, `Ciuk2.png` and `Ciuk3.png`
remain source assets. Their adaptive siblings under `misc/ciukios_bg/adaptive/`
extend the surrounding scene so that centered Fill can crop the added scenery
on 4:3, 16:10 and 16:9 desktops while retaining the original subjects, text
and proportions. They retain the same three catalog names. Square and
ultrawide layouts need a separate artwork safe-area review before qualification.

## Research and implementation decision

[W3C CSS Images, cover and contain sizing](https://www.w3.org/TR/css-images-3/#cover-contain)
defines aspect-preserving cover as filling both target dimensions and contain
as fitting inside them. [Microsoft desktop wallpaper positions](https://learn.microsoft.com/en-us/windows/win32/api/shobjidl_core/ne-shobjidl_core-desktop_wallpaper_position)
defines the equivalent Fill and Fit choices, with Stretch, Center and Tile as
separate explicit positions. The existing `wallp.c` geometry already implements
these choices against the desktop work area (screen height minus 61 pixels).
Keep that geometry; use Fill for the adaptive set and retain Fit for the
original-only fallback. Explicit user positions keep their existing meanings.

[Microsoft bitmap storage](https://learn.microsoft.com/en-us/windows/win32/gdi/bitmap-storage)
describes dimensions, RGB ordering and row orientation as format contracts.
CWP2 is CiukiOS's own top-down RGB888 format, rather than a BMP container.
Conversion keeps every decoded RGB pixel and records source/output hashes;
it does not stretch, crop or resample artwork. Rows have even byte stride for
the existing [XMS 3.0 move requirement](https://www.phatcode.net/res/219/files/xms30.txt).
An odd-width RGB row receives one zero padding byte.

Repository inspection found strict 1672×941 checks in both `wallp.c` and the
shell's CWP2 validator. Generalize these to positive width up to 2048 and height
up to 1536, require stride `(width * 3 + 1) & ~1`, RGB format 1, flags 0,
payload size `stride * height`, and exact file length `16 + payload size`.
The maximum row is 6144 bytes, within the existing 6146-byte shared scratch;
the maximum payload is 9,437,184 bytes, below `webstore_alloc`'s existing 16 MiB
per-block limit. Products use 32-bit arithmetic. No allocator, hardware memory
reservation or display-mode limit changes are required.

The builder selects the adaptive directory only when all three siblings are
present. A partial set fails clearly, avoiding mixed original/adaptive catalog
semantics. If none are present, originals and their Fit default remain valid.
The manifest identifies adaptive inputs and the corresponding originals with
hashes so release validation can establish which artwork was packaged.

## Validation

`python3 scripts/test_wallpaper_import.py` passes seven groups, including
complete/partial/missing adaptive-set selection, the retained three names,
original/adaptive hashes, Fill/Fit defaults, maximum dimensions, and exact RGB
reconstruction with odd-width padding.

`python3 scripts/test_wallp_cache.py --output /tmp/ciuki-adaptive-cache` passes
383 production cache/paint cases, including both 2048×1536 and 1536×1152
sources, all five styles, native packing and band canaries. Its production
CWP2 loader also accepts five bounded dimension cases and rejects twelve
malformed headers/files before allocating a replacement.

`uv run --with unicorn python scripts/test_wallpaper_pixels.py --output
/tmp/ciuki-adaptive-shell` passes the existing five native pixel-format cases
and executes the production shell CWP2 loader against five accepted and eleven
rejected fixtures. A failed validation retains the previously selected kind.
The DOS services in that check are stubs; it is CPU instruction evidence.

Fresh NASM assembly produces a 60,925-byte `SHELL.COM`, within the existing
60,928-byte ceiling. The CWP1/CWP2 successful commit tail is shared and two
wallpaper hints shortened to accommodate bounded checks without changing the
ceiling or stack allocation. Full image and QEMU validation belong to the main
integration task; host fixtures do not establish DOS or display-device behavior.

The existing HDD photo and CD screenshot gates now decode bounded CWP2
dimensions/stride and identify the exact packaged original/adaptive PNG by RGB
comparison. They validate fresh `WALL.CFG` against that packaged artwork:
adaptive uses Fill and originals use Fit. The HDD gate offers 800×600,
1024×768, 1280×800 and 1920×1080, including the existing two-mode option.
Fill samples use the exact renderer source coordinates, allow only native RGB
quantization, and include exposed work-area edges to reject accidental bands;
Fit retains its complete-image and uniform-margin checks. Desktop icon masks,
cold restart, malformed-input retention and CWP1 compatibility checks remain.
The separate Properties gate retains explicit position tests.

Python compilation and command help checks pass. An independent existing
`cover_frame` fixture produces zero pixel deltas at 640×480, 800×600,
1024×768, 1280×800 and 1920×1080; injected top-edge bands are rejected at every
mode. This exercises the shared HDD/CD metrics without starting QEMU. Actual
image boot and screenshot results remain an integration requirement.

The first adaptive HDD run at 800×600 passed all three photos, cold restart and
malformed-input retention, then failed its CWP1 comparison. Inspection of
`build/full/t23-next/qemu-adaptive-photos-20261008/800/restart/serial.log`
found `loaded WALL01.CWP` without `ready WALL01.CWP`; its legacy screenshot
matched the retained Ciuk3 screenshot exactly over all 431,200 work-area pixels.
The CWP1 branch captured before asynchronous preparation completed. The photo
and CD gates now wait for the selected file's ready marker followed by a
completed desktop paint, including the previously missing CWP1 wait. Pixel
thresholds and the legacy check remain unchanged. Mocked serial sequences verify
that an earlier paint or ready without a later paint cannot satisfy the wait.
The corrected gate passes all three photos, default cold restart, malformed
selection retention and CWP1 compatibility at 800×600 and 1024×768. The
1280×800 run also exposed a separate observation race: the saved shell snapshot
had `ui_composing=1`, window 10 visible and active, and only the six HUD hits;
the later screenshot showed the completed dialog and its Next button. The
gate now waits for an idle compositor and retries only lookup errors occurring
before any input is sent. It never repeats an action after input or changes
pixel thresholds. The repeated 1280×800 and new 1920×1080 cases pass.

The HDD evidence is under
`build/full/t23-next/qemu-adaptive-photos-retry-20261008/{800,1024}/result.json`
and `qemu-adaptive-photos-final-20261008/{1280,1920}/result.json`. All use the
same immutable candidate, SHA256
`143f2e6528e3ef716bde20fbca0eddd843a5531d24ed625210502f933f4f1508`.
Each of the three scene comparisons has zero RGB sample error at every mode.
Visual review of the 800×600 and 1920×1080 captures retains the complete dog
and both text lines. Square and ultrawide composition remains unqualified.

The Properties gate at 800×600 passes all five explicit positions with zero
source sample error, plus malformed-file retention, Cancel, theme restoration,
drag and display-mode preview/rollback/Keep. Its five individual style cold
restarts were explicitly skipped; the HDD photo gates independently test the
default cold restart at all four modes. Evidence:
`build/full/t23-next/qemu-adaptive-properties-20261008/800-std/result.json`.
