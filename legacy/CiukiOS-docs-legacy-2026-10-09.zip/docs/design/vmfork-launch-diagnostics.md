# VMFORK launch checkpoints

A physical T23 capture showed a newly created VM followed by FREE/exit 0,
without fresh CVVS activity. Its DPMIRUN.LOG matched the stale QEMU log in the
flashed image byte for byte. That does not establish that DPMIRUN was started.
VMFORK previously reported zero after a preparation/compaction failure, so the
manager's exit code also could not distinguish that failure from success.

Before implementation, the launch path was checked against Microsoft's
[MS-DOS 4.0 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
and the original [MS-DOS EXEC implementation](https://github.com/microsoft/MS-DOS/blob/main/v4.0/src/DOS/EXEC.ASM).
INT 21h/4B00h returns CF set and AX holding the DOS error if EXEC fails. A
successful EXEC returns after the target terminates, and AH=4Dh retrieves that
child's termination code. AH=40h can return a short byte count with CF clear;
checking CF alone would wrongly accept incomplete diagnostics. AH=3Eh closes
its handle. The reference's allocation and resize contracts were also checked:
this diagnostic uses a read-only MCB walk rather than an allocator probe, so
measurement does not alter the arena or allocation strategy.

The local code shrinks its COM block, forks, restores private interrupt vectors,
stages itself into a new PSP, prepares the root reclaim, moves recognized TSRs,
then relocates its own image again before cleaning ancestor allocations and
executing the target. The second relocation jumps directly to `child.again`.
Consequently all trace code/data remains within `image_end`, and checkpoints are
placed in the surviving foreground launch path, outside PSP mutations, IRQs and
paint callbacks. Both copies carry the trace and the updated COM paragraph size.
No memory ceiling or MCB/PSP/vector ownership check is relaxed.

Each child uses `C:\SYSTEM\VMFORK1.BIN`, `VMFORK2.BIN` or `VMFORK3.BIN`, selected
from its VM id. It queries VMM_EXIT_CODE for the slot's generation. A checkpoint
creates/truncates, writes exactly 256 bytes, checks the byte count and closes the
file; no handle survives into relocation or EXEC. A newer launch overwrites the
old record. VM id plus generation must be matched to the manager record; a
missing/old file is not evidence of a launch. I/O is best effort and cannot
change the launch result. A power loss or failed write can leave a short file;
collectors must validate magic, version and exact length before interpreting it.

All fields are little endian. This is CVFL version 1:

| Offset | Type | Meaning |
| --- | --- | --- |
| 0 | char[4] | `CVFL` |
| 4 / 6 | u16 / u16 | version 1 / size 256 |
| 8 / 10 | u16 / u16 | VM id / generation |
| 12 / 14 | u16 / u16 | latest stage / rejection reason |
| 16 | u16 | reached-stage bitmask |
| 18 / 20 | u16 / u16 | last meaningful DOS AX / FLAGS (CF is bit 0) |
| 22 / 24 / 26 | u16 | live CS / current DOS PSP / root PSP |
| 28 | u16 | ancestor count |
| 30 | u16 | pre-mutation INT12 conventional memory, KiB |
| 32 / 34 | u16 / u16 | largest pre-mutation free MCB, paragraphs / complete bounded walk valid=1 |
| 36 / 38 | u16 / u16 | planned vector number / VM exit code |
| 40 | u32 | checkpoint sequence |
| 44 | u16 | sticky previous diagnostic I/O error; FFFFh means short write |
| 46 | u16 | retained ancestor-free refusal reason |
| 48 | u16 | offending IVT byte offset on ancestor-vector rejection |
| 50 / 52 / 56 | u16 / far pointer / u16 | detached S3 PSP / predecessor INT10 / resident paragraphs |
| 58 | far pointer | inspected resident target, or rejected ancestor-vector target |
| 62 | u16 | observed LFN immediate byte at PSP:105h; upper byte zero |
| 64 | char[128] | target ASCIIZ pathname |
| 192 / 194 / 196 / 198 | u16 | pin observations / first pinned MCB / its owner / its data paragraphs |
| 200 / 202 | u16 / far pointer | first pinned IVT byte offset / exact pointer target |
| 206 | u16 | initial total free paragraphs, valid when offset34=1 |
| 208 / 210 / 212 | u16 | post-cleanup free paragraphs / largest block / complete walk valid=1 |
| 214 / 218 | char[4] / byte[38] | `PLOG` for manager-held parent persistence / reserved |

The memory walker accepts only M/Z chains, checks addition/end bounds and stops
after 64 MCBs. A partial/invalid walk leaves validity zero, making its observed
largest free block non-authoritative. DOS result fields are captured immediately
after relevant calls using CS-relative stores that preserve registers and FLAGS;
diagnostic create/write/close calls never replace them. Allocation-strategy
cleanup also does not overwrite the operation that failed.

| Stage | Meaning | Progress bit |
| --- | --- | --- |
| 1 | pre-preparation launch context | 0001h |
| 2 | preparation returned successfully (possibly skipped) | 0002h |
| 3 | compaction attempt | 0004h |
| 4 | compaction returned / ancestor cleanup entered | 0008h, 0010h |
| 5 | ancestor cleanup completed | 0020h |
| 6 | target EXEC about to be called | 0040h |
| 7 | target EXEC returned CF set | 0080h |
| 8 | target returned and AH=4Dh exit obtained | 0100h |
| 9 | ancestor free refused when compaction was skipped; existing fallback retained | 0200h |
| 10 / 11 / 12 | preparation / compaction / mandatory ancestor cleanup failed | no success bit |

Failure stages report `BX = F000h | reason` to the manager, except reason 3Fh
reports `F100h | interrupt_number`, and reason 46h reports `F200h | observed_byte`.
These details survive in the parent's DOSVM.LOG and CDVS even if no CVFL file
can be written. This preserves the 16-bit exit-code ABI. EXEC failures retain
the existing FFFFh result; normal
child exits retain the target's 8-bit return code. The root reclaim's deliberate
skip conditions are 01h no ancestors, 02h kernel EXEC PSP mismatch and 03h kernel
current PSP mismatch. Reason 04h skips root compaction before staging when its
tail has an IVT reference, or when that tail contains the owner PSP of another
referenced allocation. Progress 0800h records that retained root, and 1000h
records at least one retained allocation. Cleanup keeps all ancestor PSPs and extra allocations
with IVT references, including references to MCB headers. Pin observations may
count a block more than once because successful frees restart the arena walk.

Preparation failures retain their helper's exact reason:

| Reason | Predicate |
| --- | --- |
| 08h | root PSP shrink DOS call failed |
| 10h / 11h | list-of-lists failed / root differs from first MCB data segment |
| 12h / 13h / 14h | root PSP magic / self-parent / empty command tail |
| 15h / 16h / 17h | SHELL root signature words at 100h / 102h / 104h |
| 18h / 19h / 1Ah | root MCB type / owner / minimum size |
| 1Bh / 1Ch / 1Eh | root end overflow / conventional bound / ancestor PSP magic |
| 24h / 25h / 26h / 27h / 28h | MCB type / size-add overflow / end wraps to zero / conventional bound / 64-block bound |
| 30h | staging PSP allocation failed |
| 3Fh | IVT entry still references an ancestor-owned block |
| 40h / 41h / 42h | resident MCB owner / below minimum size / above maximum size |
| 43h / 44h | INT10 AUXSTACK size / entry signature |
| 45h / 46h | INT21 LFN signature word / opcode byte |
| 47h / 48h | low resident allocation failed / destination is not below old resident |
| 50h / 51h / 54h / 56h | query strategy / set first fit / compacted PSP allocation / restore strategy failed |
| 60h / 61h / 62h / 63h / 64h / 65h | retired PSP verification: list-of-lists / MCB type / arena already beyond PSP / owner not free / terminal block before PSP / 64-block bound |
| 70h | ancestor-owned allocation free failed |

The physical machine loads S3VBEFIX and replaces INT10 with an additional TSR.
The original mover recognizes only AUXSTACK's 4Fh paragraphs and E9E3h entry
word at PSP+100h. A replacement INT10 TSR therefore can reject preparation at
43h or 44h. The diagnostic preserves those guards; any guest-specific detachment
requires independent source and ownership validation. Bits 0400h and reasons
80h..9Fh are available to that integration.

Validation: NASM assembled the changed COM with the existing generated kernel
layout. `uv run --with unicorn python scripts/test_vmfork_launch_diagnostics.py`
executes the actual assembled trace routines in a bounded 16-bit CPU fixture.
It verifies every saved general/segment register and FLAGS after normal,
create-failed, write-failed, short-write and close-failed logging in two COM
segments; the DOS AX/CF snapshot; eleven independent root-reclaim rejection
predicates; and unrecognized INT10 resident size/signature rejection before
allocation/free; and all three failure dispatches reaching the manager with
BX=F043h. It also verifies that an ancestor-vector rejection replaces a stale
46h reason with 3Fh and retains the exact vector target; the tested INT22
reference reaches the manager as F122h. Malformed LFN bytes retain distinct
45h/46h reasons, and an immediate of 70h reaches the manager as F270h.
The fixture uses synthetic kernel offsets only for its mock
context. The standalone NASM check uses the actual generated layout. Full-image
build and runtime QEMU validation belong to the main integration; this focused
check does not claim physical or Windows runtime coverage.
