# Bounded pending PIT edge in DOS sessions

## Evidence and decision, 2026-10-09

R10d's second DOOM launch reached gameplay and then stopped advancing its
menu. The retained RAM contains the exact Down make/break bytes `E0 50 E0 D0`
in the focused guest's queue, with no dropped keys or device errors. The
client resume address is in DOOM's `TryRunTics` wait; the virtual PIC has
IRQ0 in service and IRQ1/IRQ7 waiting. This is not evidence of a missing
physical keyboard event.

The per-VM PIT contains **1,492 pending expirations** at divisor 8522 (about
140 Hz). The earlier R10c capture contains **13,485** at the same divisor.
`session_clock.c` passed the peripheral model's complete expiry count to the
PIC delivery loop, which consumes one after each accepted request. Because
IRQ0 has highest priority, servicing elapsed-time debt could keep admitting
timer handlers before the keyboard, audio and the main loop for seconds.

A private trace image, derived from R10d with only Jemm memory instrumentation,
also reached gameplay and quit confirmation. Its final trace shows successful
virtual IRQ0 acknowledgements alternating with EOIs; it does **not** establish
a lost EOI. It timed out returning from DOOM, and is not a passing runtime.
The trace lives under `build/tests/irq-eoi-trace` and is not shipped.

Primary sources checked before the change:

* [Intel 8259A datasheet, IRR/ISR and fully nested mode, pp. 3 and 14](https://www.pcjs.org/documents/datasheets/intel/INTEL_8259A_PIC.pdf):
  one request bit and one in-service bit per line; IRQ0 outranks other master
  lines. Multiple elapsed PIT periods are not an arbitrarily long IRQ queue.
* [Linux v6.2 KVM i8259 implementation](https://raw.githubusercontent.com/torvalds/linux/v6.2/arch/x86/kvm/i8259.c):
  `pic_set_irq1` sets the request bit and `pic_intack` clears the pending edge
  while setting the in-service bit. This corroborates the register semantics,
  rather than serving as a T23 hardware model.

Decision: retain complete elapsed-time advancement and exact PIT counter phase,
but coalesce the session clock's undelivered expirations into one pending edge.
Once that edge is transferred to the authoritative virtual PIC, a subsequent
elapsed period may create another. Keep masks, priority, EOI ownership and
physical PIC programming unchanged. The general peripheral model can retain
its expiry accounting; the session-to-PIC adapter defines delivery semantics.
Do not raise kernel memory limits or add this logic to the DOS kernel.

Validation must cover long gaps, a high-rate PIT, one-shot consumption, exact
counter phase, VM isolation and full-width TSC arithmetic. The same interactive
game gate must pass twice, without weakening its keyboard/menu/exit assertions.
These checks do not qualify the physical SuperSavage or the T23 firmware.

The focused ASan/UBSan fixture passes 35 checks. The same fixture against the
prior clock implementation fails 19 checks, including repeated delivery of
5,972 queued events after one long gap. Counter-phase checks pass independently
of delivery coalescing. Evidence: `build/tests/session-clock-coalesce.json`.
The original RAM, SHA-256 and decoded counts are retained as `clock-debt.json`
in each failure directory; `decode-r10-clock-evidence.py` records the exact
module layout used to obtain those counts.

The R10e integration gate passes two complete DOOM sessions with native ATA
and a background Display window, including all keyboard/menu/quit/return
assertions. This supports the delivery change without an EOI-policy change.
Report: `build/full/t23-next/qemu-dos-diskseq67-r10e-native/report.json`.
