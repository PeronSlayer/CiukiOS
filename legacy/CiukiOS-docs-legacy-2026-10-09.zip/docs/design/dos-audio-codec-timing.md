# DOS audio transport on the T23

The R14 physical test confirms original DOOM gameplay, but its sound is distorted, sometimes slow and sometimes accelerated, with changing pitch. The final device snapshot belongs to the later Wolf3D run; its zero underrun counter does not establish anything about DOOM's audio.

## Sources and decision (9 October 2026)

[Intel ICH3 datasheet, sections 5.18.1 and 13.2.10](https://www.intel.cn/content/dam/doc/datasheet/82801ca-io-controller-hub-3-datasheet.pdf) specifies posted codec writes and only one outstanding AC-link transaction. Before every codec read or write the driver must acquire CAS at NABM+34h. Reading an available CAS acquires it; hardware releases it when the following codec transaction finishes. A CPU OUT alone does not establish completion. The PCM descriptor queue uses CIV and LVI (sections 13.2.2–4); it is separate from the codec semaphore.

[Cirrus CS4299 datasheet](https://www.mouser.com/datasheet/2/76/CS4299_F1-611188.pdf) describes the actual T23 codec: register 2Ch reports the accepted DAC rate, and VRA in register 2Ah must be enabled before changing it. Supported rates include 44.1 and 48 kHz. Thus rate negotiation must complete before reading its result or starting DMA.

The existing boot driver in `src/com/ac97init.asm` already acquires CAS for every transaction. `src/vm/session_devices.c` instead uses consecutive unguarded NAM accesses, including enabling VRA, writing 44100 and immediately reading the rate. Replace these accesses with a separate bounded codec module; abort sound initialization on timeout instead of accepting FFFFh as capabilities or a rate. Restore the old rate while VRA remains enabled, then restore the old extended control. Preserve the desktop master volume, including mute and changes during the game.

The existing software fallback restarts its 44.1-to-48-kHz phase at every 256-frame buffer and consumes 236 source frames each time: 44,250 source frames per second rather than 44,100. At low accepted codec rates its fixed input workspace also truncates the required input. Use a persistent rational phase and stereo interpolation across descriptor boundaries, with an input workspace sized for the supported 8–48-kHz output range. This fixes a proved rate error; it does not by itself prove the explanation of every physical symptom.

Validate posted codec transactions, bounded timeout and rollback, exact source consumption across many descriptors, stereo independence and stable signal pitch with host fixtures using the production modules. Hardware sound quality still requires the physical driver path; a generic QEMU audio device does not reproduce the T23 codec's transaction latency.
