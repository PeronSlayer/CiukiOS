# Display Properties: staged S3 qualification

Decision, 2026-10-08: run the explicit S3 checks from Display Properties in
the system VM while the existing desktop framebuffer remains bound. A DOS
console utility cannot establish lasting desktop acceleration: returning from
that utility may rebind the video console and restore the normal strict BAR2
policy. No firmware mode change belongs in this operation.

The hardware sequence follows the independently audited upstream
[X.Org SuperSavage implementation](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz),
[Linux Savage register definitions](https://github.com/torvalds/linux/blob/v6.2/drivers/gpu/drm/savage/savage_drv.h)
and [Mesa 7.11.2 source](https://archive.mesa3d.org/older-versions/7.x/7.11.2/MesaLib-7.11.2.tar.bz2).
The register findings and limits are recorded in
[the S3 audit](t23-s3-init-audit-20261008.md). Display is only the caller of
the resident operation; it never programs the adapter or relaxes its gates.

The Advanced page offers **Enable acceleration** only for the detected native
SuperSavage. An explicit `DISPLAY qualify` argument also allows an unsupported
adapter through the caller, so a runtime negative test can exercise the actual
resident rejection. Neither path runs automatically at startup.

After showing the pending status, the caller performs at most one ordered
`VM_OP_GPU_QUALIFY | NO_SWITCH` (`AX=0118h`) operation per poll.
The sequence is `BX=1`, then the 21 restored setup-prefix probes
`BX=0101h..0115h`, then the complete phases `BX=2,3,4`. The prefix probes
belong to logical phase two and submit no drawing commands. The caller keeps
the ordinary four-phase progress text throughout these implementation steps.
The shell continues processing input and redraws between phases. A durable
400-byte `CG3D` version-0100 record at `\SYSTEM\VIDEO\S3QUAL.LOG` is written
and closed before each operation. Its result is `0100h | stage` before the
call, `0200h | stage` after success, or `0300h | stage` after failure; the
error word and before/after 192-byte CVGD snapshots use the SAV3D format.
For a prefix probe, the result's high word holds its index 1..21; its low word
keeps the logical phase-two code. For example, 00030102h means the closed
checkpoint immediately before `BX=0103h`. Ordinary phases have high word zero.
This extension is decided before implementation and preserves the existing
record size/version. It follows the backend's source-grounded, restored-prefix
contract; the caller never touches device registers itself.
The individual register prefixes are specified in
[the diskseq63 phase-two audit](t23-s3-phase2-diskseq63.md).
Any short write or failed close stops subsequent hardware operations.
The persistence gate follows the write-count and close-result contracts in
Microsoft's [MS-DOS Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/).
Every prefix yields to input after its closed result, so cancellation prevents
the next submission. The caller rechecks the active DOS count, LFB availability
and original framebuffer geometry/address before each submission.

Closing or suspending Display cancels work that has not been submitted. The
first three phases restore their own hardware state; phase four retains the
qualified desktop engine. Failure stops the sequence. The resident monitor
continues owning any potentially active engine after a timeout, so this caller
must never try to reset it or force a CPU fallback. Mode changes and Apply/OK
are deferred while qualification is pending. Normal startup remains strict;
success here applies to the current framebuffer binding only.

Host fixtures verify caller sequencing and the durable checkpoint boundary.
They do not prove MMIO, real command execution, or physical T23 stability.

Validation: `scripts/test_display_qualify.py` executes the production caller
under ASan/UBSan, with 250 passing cases. These cover the exact 25-call order,
all 50 before/after checkpoint positions for create/write/close faults,
API-return and saved-CF failures at every token, cancellation and reentry
between every call, changed modes/bindings or live DOS windows, and all three
required final native-readback fields. Report:
`build/tests/display-qualify-prefix-20261008/report.json`. This focused test
does not build an image or qualify physical T23 behavior.

## R16: independent S3 2D retention and ATI qualification

The R15 physical T23 record failed during setup-prefix nine rollback, before
any drawing command. The selector-restoration and packed-MMIO decisions are
source-grounded in [the native SuperSavage design](native-supersavage-bci.md).
They are independent of the 3D proof: a successful fill/copy engine must not
be advertised as a successful triangle engine.

If phase four fails only the triangle proof and safely restores the complete
original state, the backend may preserve its packed-2D diagnostic hint only.
The caller accepts this case only for exact SuperSavage, stage nine, no engine
ownership, and completed private fill/copy proofs. It then checkpoints a
separate `BX=5` operation. This operation reruns the private packed fill/copy
proofs and retains only those capabilities. The final native snapshot must
report backend three, ready one, and public capabilities five (fill/copy).
Its success message explicitly says that 3D verification did not pass. Any
timeout, failed restoration, missing copy/fill proof or failed durable
checkpoint forbids this retry. The old four-phase 3D API remains strict.

Exact ATI Mobility-P `1002:4c4d` uses the independent
[Mach64 backend](native-mach64-2d.md), with the same four durable checkpoints
at `ATIQUAL.LOG` but without S3 setup prefixes. Its final snapshot must show
backend four, ready one and fill/copy capabilities five. Its fourth-phase
progress text refers to graphics state rather than 3D.

The R16 production caller fixture passes 270 cases, including 2D retention,
rejection of retained ownership/missing proofs, and all create/write/close
failures around the fifth-phase checkpoints. Report:
`build/tests/display-qualify-r16/report.json`. Physical operation remains a
separate qualification requirement.
