# T23 diskseq 64: preserve the firmware shadow-status address

The read-only capture `physical-logs-20261008-diskseq64` contains the exact R6b
VMFORK, CVSESSION, Display and shell binaries. `S3QUAL.LOG` result `000f0102`
is the durable checkpoint before setup prefix 15, with no after snapshot.
The first fourteen restored prefixes returned successfully. In this build,
prefix 15 adds a zero write to MM48C0C and the corresponding saved-value
writeback during release. The previous status was `07e00000`, and no drawing
commands have been submitted. The record cannot distinguish the zero store
from its restoration or later accesses in that call.

Research before implementation: the explicit SuperSavage branches in
[X.Org Savage 2.4.1](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz)
(`SavageInitialize2DEngine`) and
[Linux Savage fbdev](https://raw.githubusercontent.com/torvalds/linux/v6.2/drivers/video/fbdev/savage/savagefb_driver.c)
(`SavageSetup2DEngine`) write MM48C0C=0 in the no-shadow path, so the register
is not simply absent or unsupported. The original
[S3 Savage4 register manual](https://old.vgamuseum.info/images/stories/doc/s3/savage4_registers.pdf)
defines MM48C18 bit 1 as the command-status update enable and requires the
MM48C0C bit 0 enable as well. The explicit upstream SuperSavage branch enables
PIO without shadow updates using MM48C18 low control bits `8`, versus `a`
with shadow updates. The [upstream manual](https://xorg.freedesktop.org/archive/X11R7.5/doc/man/man4/savage.4.html)
also documents possible bus locks from polling engine status on some Savage
chips. This warning does not prove that status polling caused this capture.

Decision: this backend does not use a DMA shadow-status buffer, so disable
updates using the control bit and leave the firmware's shadow address word
untouched. Do not clear or replay MM48C0C. This reduces hardware mutation while
retaining the documented no-shadow/no-COB control state. Prefix 15 now verifies
that BCI, COB and shadow status are disabled in MM48C18; prefix 16 enables only
PIO. The register snapshot and total prefix count remain compatible with
existing diagnostics. This is an inferred safe alternative from the enable
semantics, not a claim that the physical capture proved a defective register.

Also mark only the PBD/SBD descriptor registers dirty before 2D commands;
marking the entire saved 2D set would inadvertently replay the untouched shadow
word during release. Preserve it across every success, failure and cleanup.
Host tests reject any MM48C0C store and cover nonzero enabled firmware shadow
state, exact control/address restoration, all setup prefixes and 2D/3D paths.
Those tests verify our access protocol, not execution on the T23. Physical
confirmation remains necessary.
