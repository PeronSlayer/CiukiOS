# T23 VMFORK `F011` audit

Audit date: 2026-10-08. This source/capture audit led to the F149 correction described below. No DOS
reclaim predicate is relaxed.

## What the physical record proves

The diskseq62 capture has no `SYSTEM/VMFORK1.BIN`, but its manager-written
`SYSTEM/DOSVM1.BIN` reports VM 1, generation 1, state FREE, and exit code
`0xF011`. In `src/com/vmfork.asm:285-305`, the preparation-failure path forms
the VM exit code as `0xF000 | trace_reason`. Reason `0x11` is assigned only
immediately before the failed comparison of `first_mcb + 1` with `root_psp`
(`src/com/vmfork.asm:501-511`). The physical launch therefore reached that
predicate and found that the root SHELL PSP does not immediately follow the
first MCB. It did not fail the AH=52 carry check (reason `0x10`).

This is a layout mismatch, not evidence that the MCB chain is corrupt. The
current validation intentionally requires the SHELL.COM root to be the first
user allocation before VMFORK resizes or moves any ancestor memory. Removing
the equality check without identifying the intervening allocation would make
the existing compaction assumptions unproven.

## ABI and DOS source audit

The VM number gate in CVFL is consistent with the VM manager. `VMM_CREATE`
returns the parent answer with `CX=0` and slot in `BX`; it initializes the
child return frame with `CX=1` and its own slot in `BX`
(`src/vm/session_abi.inc:115-118`, `src/vm/session_vmm.inc:455-489`).
VMFORK stores that child `BX` into `trace_vm` before calling
`VMM_EXIT_CODE` (`src/com/vmfork.asm:114-118`). The VM exit-code query then
returns slot state in `BX`, generation in `CX`, and exit code in `DX`; it cannot
retroactively change the already saved `trace_vm`.

The actual full-image DOS kernel is CiukiDOS, assembled from
`src/runtime/ciukidos.asm` and shared `src/boot/floppy_stage1.asm`. The tracked
FreeDOS tree is a comparison source, not the executing kernel. The earlier
FreeDOS-based conclusion that freeing the TSR cannot change `first_mcb` was
incorrect for this implementation.

CiukiDOS's AH=52 publishes `dos_list_of_lists` at ES:[BX-2], matching the
[documented SYSVARS layout](https://fd.lod.bz/rbil/interrup/dos_kernel/2152.html).
Its `int21_mem_rebuild_chain` explicitly recomputes that variable from
`int21_mem_lowest_psp`, following the active EXEC identity and its PSP:16h
parent chain. The [PSP specification](https://www.delorie.com/djgpp/doc/rbinter/it/78/13.html)
describes that parent field; a retained resident's parent can have exited.

Before this correction, the F149 extension swapped `dos_exec_identity_psp` to the block owner
before calling `int21_free`. That changes both authorization and ancestry:
`int21_free` refreshes ownership and rebuilds the visible MCB chain while the
TSR is the active identity. A resident whose loader has exited can therefore
replace the arena root and omit the real executing PSP and suspended shell.
The identity is restored only after the rebuild, leaving its published first
MCB stale. Executing the production kernel with a stale resident-parent
fixture reproduced this failure: the first MCB moved from 117F to 2504 and
the resident allocation expanded over live memory. The correction passes
the explicit owner without changing EXEC identity. All 13 allocator cases
pass; see [the kernel regression](kernel-f149-mcb-regression.md).

The full-image QEMU regression also installs the test S3 resident, lets its
installer return, and gives it the same stale parent condition. Two DOOM
launches from Files reach gameplay, respond to input, exit normally, and
return to the desktop while preserving the host resident. This supports the
identified mechanism; it does not replace testing the actual T23 BIOS hook.
Evidence: `build/full/t23-next/qemu-six-fixes-doom-stale-20261008/report.json`.

Decision: separate the explicit F149 owner authorization from the active
EXEC identity. Rebuild and owner refresh must retain the actual executing
ancestry. Standard AH=49 and exact-owner F149 authorization must be tested
separately, including wrong-owner rejection. Keep VMFORK's root/chain safety
predicates and measured conventional/extended-memory limits unchanged.

## Why the physical CVFL file is absent

`trace_checkpoint` is called at stage 1 and again on stage-10 failure. It
best-effort creates `C:\SYSTEM\VMFORK1.BIN`, writes 256 bytes, checks for a
short write, and closes the file (`src/com/vmfork_trace.inc:62-124`). Its
create/write/close errors are recorded only inside that file. If create fails,
there is no independent record of the failure. The manager's existing
`DOSVM1.BIN` is written by the system-VM DOSVM application and records the VM
state and exit status, not VMFORK's local trace fields (`src/apps/dosvm.c:204-226`).

So the missing CVFL record does not identify whether child-side DOS file create,
write, close, or persistence failed. It is separate from the proven `F011`
reclaim result. The existing capture confirms the VM slot/generation and
failure reason through the manager exit code, but it cannot say why the child
checkpoint file did not materialize.

## Bounded manager-side evidence

If child DOS file writes remain unavailable on the T23, add a small VMFORK-only
exit diagnostic through the VM manager. Before `vmm_exit` marks the slot dead,
copy a fixed record from the client's register arguments into the `VMREC`:
failure stage/reason, saved `first_mcb`, `root_psp`, last DOS `AX/CF`, and raw
AH=52 `ES:BX`. At the same point, the manager can inspect a bounded MCB summary
from the child's private first-megabyte mapping: at most 64 M/Z records from
`vmm_first_mcb`, recording each segment, type, owner, size, and whether its data
segment matches `root_psp`. Keep only that compact summary with the dead slot,
then let the existing system-VM snapshot writer persist it after exit. This
avoids relying on the child's FAT write path and does not mutate the arena.

The telemetry must report which memory image it read and whether the 64-block
walk reached a valid Z terminator below `0xA000`. It should show the first
allocation before any attempt to change the reclaim policy. Only then can the
project decide whether a preceding block is a valid owner allocation that the
compactor can safely account for, or whether root reclaim must remain disabled
on this physical profile.

## References

- [FreeDOS kernel source](https://github.com/FDOS/kernel), including INT 21h
  for comparison only; it is not the full-image CiukiDOS implementation.
- [Ralf Brown's Interrupt List, INT 21h/AH=52h](https://fd.lod.bz/rbil/interrup/dos_kernel/2152.html).
- The source ranges listed above are in the pinned repository tree and identify
  the tested CiukiOS ABI and exact F011 reason encoding.
