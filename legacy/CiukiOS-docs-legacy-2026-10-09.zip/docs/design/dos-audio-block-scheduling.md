# DOS audio DMA block scheduling

## Physical evidence, 9 October 2026

`build/full/t23-next/physical-logs-20261009-diskseq37-r15/manifest.json`
retains three different T23 generations. DOSR11 is DOOM (15,823 output
buffers; 5,251 delivered SB block requests), DOSR12 is Wolf3D (16,760 buffers;
47 SB requests), and DOSR13 is original DOOM (7,229 buffers; 569 SB requests).
All report an accepted 44,100-Hz DAC rate, zero DMA-halting underruns, and six
or seven queued descriptors. These snapshots establish neither an absence of
FIFO errors nor timely guest mixer refill: the old counter counts DCH only,
FIFO status is cleared each service, and SB rate/block size and scheduling
cost are not in CVDV. The later Compaq boot is a separate machine; its boot
logs cannot be used as T23 game telemetry.

## Sources and implementation decision

The pinned [VSBHDA sound interrupt source, commit 75fa4bb](https://github.com/Baron-von-Riedesel/VSBHDA/blob/75fa4bbfea70cbcc0c40d1212f04952ff8abbf16/src/SNDISR.C)
limits a DMA copy by the remaining Sound Blaster block (`SB_BuffSpace`,
lines 329 and 406–413). It invokes the guest interrupt at that boundary before
copying the next block (lines 510–517). Its [Intel AC97 transport](https://github.com/Baron-von-Riedesel/VSBHDA/blob/75fa4bbfea70cbcc0c40d1212f04952ff8abbf16/src/hw/SC_ICH.C)
uses physical CIV/PICB progress to determine output space; guest DMA block
boundaries and hardware period boundaries are separate quantities.

[Intel's ICH3 datasheet, sections 13.2.2–5](https://www.intel.cn/content/dam/doc/datasheet/82801ca-io-controller-hub-3-datasheet.pdf)
defines CIV, LVI, DCH and the separate FIFOE indication. Count FIFO errors
before clearing their status rather than treating a running DMA engine as a
proof of uninterrupted audio.

CiukiOS previously rendered every missing 256-frame hardware descriptor
(up to eight, about 46 ms at 44.1 kHz) before scheduling any guest SB request.
`cvgp_render_audio` reloads the next auto-init block immediately; both the
DSP status and modeled PIC store one pending bit. Consequently a service
can consume multiple guest blocks before their refill interrupt runs.

A host reproduction using the unchanged production peripheral model and a
64-unit auto-init double buffer consumed 32 SB blocks in one 2,048-frame
batch but exposed only one deliverable interrupt. Its PCM repeated the two
initial stale halves. Rendering to each boundary, acknowledging the request
and letting the guest refill consumed the same 2,048 samples while delivering
32 interrupts and producing 32 fresh sequential PCM blocks. This proves a
scheduling defect; it does not identify its contribution to every physical
R15 symptom because those logs omit the guest block sizes.

Keep the eight-descriptor transport lead and negotiated codec rate. Build
hardware descriptors incrementally. Stop source generation at each SB block
boundary, schedule its guest request, and return to the guest before reading
the following block. Resume after DSP acknowledgement. If an application
holds its interrupt longer than its own configured SB block duration, allow
the same continuing DMA behavior as physical hardware and count the late
acknowledgement; never wait forever or change the programmed sample rate.
A separate incremental rate converter must accept a short source batch so
codec fallback cannot prefetch across a boundary. Preserve CVDV's 128-byte
layout; an optional CVAT timing packet records actual guest rate/block size,
service gaps, rendering cycles, boundary yields, late acknowledgements,
FIFO errors and hardware halts. Host tests cover stale data, interrupt counts,
partial descriptors, continued phase, masked-interrupt progress and register
status clearing. Physical sound quality requires a subsequent machine run.

## Validation and timing packet

`python3 scripts/test_session_audio.py` passes both production-module fixtures
with AddressSanitizer and UndefinedBehaviorSanitizer. OpenWatcom compiles
`session_audio.c` and `session_devices.c` with warnings as errors. The
production transport fixture proves 32 distinct fresh 64-unit blocks and
32 guest requests, verifies the 11,025-Hz SB path without changing its rate,
and checks 8- and 48-kHz codec fallback boundaries. Artificially pausing a
source batch preserves bit-for-bit PCM against the continuous reference at
8,000, 11,025, 16,000, 22,050, 32,000, 44,100 and 48,000 Hz. Existing codec
transaction, volume/mute and rollback tests remain covered. The machine
sound and the Windows launcher have not been validated by these host tests.

`cvdev_report_audio(cvdev_audio_report *out)` writes exactly 128 bytes without
physical I/O. The optional DEV_AUDIO_STATE query is opcode 59h. The CVAT
header is magic `CVAT`, ABI 0100h, length 128. Generation is at offset 8. The
30 following little-endian dwords are, in order: generation, active, DAC rate,
source rate, SB rate, SB block units, SB units left, SB format, services,
rendered buffers, SB boundaries, boundary yields, late acknowledgements,
wait polls, DMA halts, FIFO errors, last/max service gap in microseconds,
last/max rendering cycles, total rendering cycles low/high, source/output
frames, queued descriptors, partial descriptor frames, DSP IRQ status,
guest DMA address, guest DMA count, flags. SB format records sample bits in
bits 0–7, stereo in bit 8, auto-init in bit 9 and active in bit 10. Flags
record wait phase in bits 0–7, hardware stream running in bit 8 and stream
ownership in bit 9. Gaps and rendering costs include only the selected
owner's physical stream service; source/output frame counts exclude muted
background sessions. The driver retains the existing CVDV and CDVS layouts.
