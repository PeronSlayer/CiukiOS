# Native SuperSavage BCI backend

Research and implementation: 2026-10-07. Hardware allowlist: PCI `5333:8C2E`
only, SuperSavage IX/C SDR. `session_gpu_savage.c` is a freestanding integer C
implementation of the documented PIO command protocol. It changes engine
state while preserving the firmware's display timing and scanout state. It is
not an OpenGL implementation: its first 3D interface rasterizes an untextured,
Gouraud shaded, screen-space triangle with depth, texture, fog, blending,
stencil and culling disabled. The GPU performs rasterization and transfers.

## Research basis and decisions

Sources were consulted before implementing the backend. The pinned source
archives, hashes and licensing are recorded in
[the upstream research](savage-upstream-research.md).

- [X.Org xf86-video-savage 2.4.1](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz):
  `src/savage_driver.c:2931` (`SavageMapMem`) selects BAR0 MMIO, BAR1 VRAM and
  BAR2 tiled apertures on SuperSavage; `src/savage_regs.h` gives a 512 KiB MMIO
  extent. `savage_driver.c:1834–1870` reads CR36 and the mobile RAM table.
  `src/savage_accel.c:1051–1117` uses the PM/SuperSavage descriptor convention,
  destination tiling value 1 and the 64-bit descriptor bit 0. The no-overflow
  PIO initialization at lines 158–190 enables BCI control bit 3 while keeping
  shadow-status DMA and the command overflow buffer disabled. `src/savage_xaa.c:450–590`
  supplies the descriptor order for native copy and fill commands.
- [Linux v6.2 Savage DRM](https://github.com/torvalds/linux/tree/v6.2/drivers/gpu/drm/savage):
  `savage_drv.h:233–246` defines the 32-dword on-chip FIFO, BCI window at
  `0x10000`, alternate status at `0x48C60` and non-Savage3D used-entry mask
  `0x001FFFFF`. `savage_bci.c:97–110` waits for enough FIFO space. The DRM
  dispatch and UAPI define triangle list command `0x80000000`, count in bits
  23–16 and skip mask `0xFA` for X,Y,Z,ARGB vertices. SuperSavage does not use
  command or vertex DMA; this backend submits PIO dwords only.
- [Mesa 7.11.2](https://archive.mesa3d.org/older-versions/7.x/7.11.2/MesaLib-7.11.2.tar.bz2):
  `savage_3d_reg.h` defines packed DrawLocalCtrl, DrawCtrl0/1, DestCtrl and
  destination write flush fields. `savagestate.c:1430–1505` establishes a
  nontextured pass-through color state. Destination control stores width in
  128-byte tiles and a 2 KiB aligned offset; it has no linear-destination
  choice. Therefore a BIOS linear framebuffer must not be presented as a
  tiled 3D surface.
- [Original S3 Savage4 register reference](https://old.vgamuseum.info/images/stories/doc/s3/savage4_registers.pdf),
  used only alongside the SuperSavage-specific upstream implementation:
  DrawLocalCtrl is MMIO `0x48584`, DestCtrl `0x485DC`, DrawCtrl0/1
  `0x485E0/4`, and destination write watermarks `0x485EC`. The BCI indices map
  to these registers as `0x4850C + index * 4`. The document describes RGB565
  and XRGB8888 destinations, 128-byte by 16-row tiles and 2 KiB offsets.

These protocol facts are implemented independently in CiukiOS. Original
upstream source and license notices remain in the downloaded research trees;
the production backend does not embed a Linux kernel driver or assume its
runtime, IRQ, DRM, AGP or memory services exist in DOS.

## Ownership and usable memory

### Optional CPU tiled aperture proposal (2026-10-08, diskseq60; withdrawn)

The next T23 capture identifies the previous stage-1 rejection precisely:
BAR0 is `0xC0200000`, BAR1 is `0xE8000000` and BAR2 reads `0x00000008`
(prefetchable memory with no assigned base). The BIOS LFB still reads back as
1024x768x32, pitch4096. The driver submitted no commands and owned no engine.

The primary [Linux v6.2 SuperSavage resource selection](https://github.com/torvalds/linux/blob/v6.2/drivers/gpu/drm/savage/savage_bci.c#L1000-L1036)
and X.Org `SavageMapMem` distinguish BAR1 linear VRAM from BAR2 CPU tiled
apertures. The current CiukiOS backend maps only BAR0 MMIO and a private
linear readback page in BAR1. Its 3D destination is addressed by GPU offsets,
then copied by BCI into linear VRAM; it never maps or dereferences BAR2.
The proposal therefore made BAR2 optional for these existing operations. An absent or
unsupported BAR2 is reported as aperture address zero; no address is invented
or substituted and no PCI resource is reprogrammed. CPU tiled-aperture access
remains unavailable. Required BAR0/BAR1, decode, class, LFB match, extent and
ownership checks remain unchanged. Native capabilities still require actual
private fill/copy/triangle readback proofs before publication. This decision
does not establish that acceleration works on the physical T23.

This follows the [PCI resource ownership and access guidance](https://docs.kernel.org/6.4/PCI/pci.html):
only resources actually used by a driver are prerequisites to those accesses;
BAR sizing and resource assignment are outside this existing backend.

### Physical cold-boot regression and strict preflight restoration

The diskseq61 physical capture on 2026-10-08 follows the owner's report of
splash followed by a permanent black screen. Its installed binaries match
the flashed immutable image, SHA256
`7e04efad18b4df3f5ed97b4236a5a66088f2ed5ec23a162fee2d457c5fdde599`.
AC97 initialization reports success, but startup playback and the first
logged desktop paint are absent. The empty BOOT.LOG is a factory seed and
does not identify the instruction at which boot stopped. Evidence is in
[`diskseq61/manifest.json`](../../build/full/t23-next/physical-logs-20261008-diskseq61/manifest.json).

Repository review shows framebuffer bind synchronously enters native S3
initialization before returning to the shell. Removing the BAR2 gate exposes
CR/MMIO writes and private engine probes on this T23 for the first time.
The primary [Linux Savage BCI source](https://github.com/torvalds/linux/blob/v6.2/drivers/gpu/drm/savage/savage_bci.c#L69-L106)
uses bounded status polling and reports busy on timeout; that protocol does
not establish that CiukiOS's register setup or recovery works on this machine.
CiukiOS also bounds its polls, but neither those bounds nor a passing host
model qualify a physical initialization sequence.

Decision: withdraw the optional-BAR2 change and restore the exact earlier
strict resource preflight. The observed raw BAR2 `00000008` must reject at
stage 1 before any VGA access, MMIO mapping, ownership or engine submission.
The previously working BIOS VBE/CPU framebuffer remains available. This is
a targeted rollback of the leading regression suspect, not proof of the
exact fault instruction. Guest-only S3 TSR handling and adaptive wallpapers
remain independent changes. Native acceleration on the physical T23 remains
unqualified; do not re-enable this boot path based solely on model tests.

### Preflight diagnostics (2026-10-08)

The T23 diskseq59 capture reaches the protected 1024x768x32 CPU framebuffer,
but the native driver reports stage 1 without any MMIO command or engine
ownership. Stage 1 previously combined geometry and PCI-resource predicates,
so that capture does not identify which predicate failed. A single visible
frame is sufficient for this gate: private scratch and its readback mapping
are separately bounded by usable VRAM after resource validation.

The read-only PCI checks follow the primary
[Linux v6.2 PCI register definitions](https://github.com/torvalds/linux/blob/v6.2/include/uapi/linux/pci_regs.h):
command bit 1 enables memory decode, class is bits 31:16 of offset 08h,
BAR bits 2:1 identify the memory-address type, bit 3 is prefetchability and
bits 31:4 are the base. Prefetchable 32-bit BARs remain accepted. The pinned
X.Org `SavageMapMem` selects BAR0 for SuperSavage MMIO, BAR1 for the linear
framebuffer and BAR2 for its tiled apertures. Diagnostic changes retain all
these predicates and perform no BAR sizing, PCI-command write or engine
command before they pass.

The fixed 128-byte status ABI retains stage in `error_stage & 0xff`.
For stage 1, reason bits above the low byte distinguish format, dimensions,
pitch, extent, missing PCI identity, class, memory decode, BAR0/1/2,
framebuffer mismatch and MMIO overflow. Input width/height/pitch/bpp are
recorded before validation. Discovered BAR bases are recorded before engine
ownership. `last_status` is a preflight detail while these reason bits are
present, rather than an alternate-status MMIO sample: it contains the mapped
byte length for format/geometry/pitch/extent failures, raw class/command/BAR value for
those failures, or requested physical base for a mismatch/missing device.
Successful engine status and completion counters retain their meanings.

The twelve reason flags occupy `0x000fff00`; their individual values are in
`session_gpu_savage.h`. The production backend passed 45 host protocol
scenarios, also under AddressSanitizer and UndefinedBehaviorSanitizer, and
compiled with the canonical OpenWatcom flags. These include the captured
1024x768, pitch4096, 3 MiB single-frame extent and 237x64 KiB usable-VRAM
limit with T23-shaped 32-bit BARs (prefetchable framebuffer/aperture). The
model qualifies all three native primitives without requiring a second front
page. It does not qualify physical T23 acceleration. Evidence is in
`build/tests/savage-preflight-20261008/report.json`.

CVSESSION must establish and verify a real BIOS LFB mode first. A banked mode,
including an unproven physical BAR alias, is never sufficient. Native bind
accepts the mapped front-buffer extent and a separate firmware-reported usable
VRAM limit, supplied from the VBE controller TotalMemory field. Old clients
which lack this limit retain the protected CPU transport.

The RAM amount decoded from CR36 is a physical limit, not proof of free VRAM.
The T23's recorded VBE controller exposes 237 × 64 KiB = 14.8125 MiB while
the device's CR36 encoding may describe 16 MiB. Native scratch is bounded by
the smaller firmware-usable amount, leaves an additional 64 KiB guard, starts
after all front-buffer pages owned by CVSESSION, and stays below the usable
extent. No scratch allocation enters the remaining BIOS-owned memory. BAR1
must exactly match the active BIOS physical LFB and PCI memory decode must
already be enabled. BAR0/1/2 are read without destructive BAR-size probes or
PCI command changes.

The backend maps only BAR0 MMIO and one private readback page. The private
tiled surface occupies VRAM after the owned front-buffer pages. Its row width
is rounded to 128 bytes and its height to 16 rows. BAR2 aperture registers,
stream registers, clocks, timings and scanout addresses are untouched.

Initialization saves every altered CRTC, descriptor and engine-state register.
Xorg's `SavageEnableMMIO` (`savage_driver.c:4175–4201`) establishes CR40 bit 0
before MMIO reads. The backend follows that order with temporary CRTC ownership
and restores the bit and locks on every failure before engine ownership begins.
The 64-bit descriptor is enabled with the PM/SuperSavage bit convention, all
write planes are enabled, and PIO is enabled with overflow and shadow DMA off.
Unsupported chips and invalid geometry are rejected before MMIO writes.

## Actual hardware proofs before capabilities

Native fill capability is advertised only after a private-VRAM BCI solid fill
has completed, the mapped readback pixels match the requested color and the
original readback data has been restored. RGB8888 checks its meaningful RGB
channels; RGB565 checks every pixel bit.

Native triangle capability additionally requires a separate hardware test:
the GPU fills a private tile with a background color, rasterizes a known red
triangle through `DRAW_PRIM`, and copies the tile through the 2D engine into
the private linear readback page. The backend verifies an interior red pixel
and an exterior background pixel. It restores that page only after proving
that both engines and the FIFO are idle. A cleanly drained triangle mismatch
keeps native fill available and leaves triangle capability absent. A timeout
removes both capabilities and retains ownership.

The 128-byte status snapshot separates completed user operations from probe
results: fill selftests, triangle selftests, triangle probe failures, expected
and observed probe pixels, submitted dwords, completed fills/blits/triangles,
FIFO and idle timeouts, PCI identity and discovered resources. It records real
readback evidence rather than inferring use from a loaded filename.

Native copy capability (driver capability bit 2, value 4) has an independent
qualification. Before it is advertised, the backend fills two private linear
source rows with different CPU patterns, submits a native BCI copy through
explicit source/destination descriptors, verifies the copied pixels and
restores the private readback page after idle. A failed copy probe retains
fill capability but removes copy and triangle capabilities. Triangle operation
depends on working transfers and is not attempted with a failed copy probe.

## Bounded submission and CPU synchronization

Each BCI packet fits the 32-dword hardware FIFO and polls for sufficient space
before the first dword. MMIO is uncached and volatile, preserving x86 ordered
PIO writes. Alternate status polling is bounded at 65,536 reads per wait.
No engine reset is attempted on an uncertain timeout.

Native fill accepts one visible scanline up to the existing 16 KiB CVFF limit;
other valid layouts use the protected CPU fill service. Fill never overwrites
pitch padding or extends into another scanline. Successful return means the
GPU fill and its idle command completed. CPU row reads/writes, pointer save
and restore, presentation and page copies must synchronize with the native
engine first.

`cvsavage_page_copy(source,dest,rowbytes,rows,pitch)` accelerates the existing
page-copy service using the same PBD/SBD BCI transfer. It requires native copy
qualification, matching bound pitch and pixel format, aligned byte offsets,
equal source/destination X positions, visible row widths, disjoint full pitched
spans and extents inside all framebuffer pages owned by CVSESSION. It refuses
crossing a page's visible height, more than 64 rows or more than 16 KiB of
pixel data. Explicit descriptor bases allow copying between the first and
second front-buffer page. Unsupported geometry returns 1 without commands;
the monitor must synchronize before its CPU fallback. A hardware failure
returns 2 and retains ownership. Completed GPU copy increments the native
blit counter only after its idle command finishes.

`CVT3` is exactly 64 bytes: four 32-bit header fields (`CVT3`, size 64, zero
flags, zero reserved), followed by three X/Y/Z IEEE754 bit patterns and ARGB8888
colors. Packet contents are copied into the monitor's private storage before
validation. Coordinates must be finite, nonnegative and inside the active
viewport, Z must be in [0,1], and the containing rectangle is limited to 65,536
pixels. Validation uses integer bit decoding; ring 0 never changes x87 state.

For a triangle, the GPU copies the containing rectangle from the linear front
buffer into the tiled scratch surface, draws the triangle, then copies the
same rectangle back. The surrounding pixels remain intact, and the display
remains a BIOS linear surface. The full triangle operation synchronizes both
engines before returning success.

Bind returns 0 for unsupported or safely restored hardware, 1 after successful
native setup, and 2 when a failed operation retains hardware ownership. Fill
and triangle return 0 for completed native work, 1 for validation rejection or
an unavailable feature, and 2 for hardware failure. A retained failure forbids
CPU fallback and module unload until idle is proven. Release then restores all
saved registers and unmaps its private mappings; it never frees them while
the GPU could still be using them.

## Validation limits

The production source compiles with the same freestanding OpenWatcom flags as
CVSESSION. `test_session_gpu_savage.c` compiles the actual backend against a
bounded model of documented PCI/MMIO/BCI commands. It checks private probes,
RGB565/RGB8888 commands, tile/linear transfers, visible pixel preservation,
invalid commands and limits, no-S3 rejection, failed readback, bounded waits,
retained ownership and exact state restoration. This is a protocol test;
QEMU has no SuperSavage model and cannot certify the physical rasterizer.
Physical capability and operation counters must be collected on the T23.

## Read-only panel ceiling before framebuffer bind

`cvsavage_panel_probe()` provides internal LCD dimensions before selecting a
video mode. Its source and decisions are recorded in
[the panel research](t23-panel-detection-research.md). It permits only the exact
SuperSavage PCI identity, VGA display class, enabled PCI I/O decode and a valid
BAR0 resource. It caches the PCI identity, revalidates that identity, and reads
fresh register snapshots each time. It does not cache dimensions across mode
changes.

### Absent-device discovery cost (2026-10-09)

The R10c input regression captured the CPU in the panel probe's exhaustive
PCI scan, reached through the frequently polled `DISPLAY_INFO` service. The
saved stack in
`build/full/t23-next/qemu-dos-diskseq67-r10c-input/native-disk-and-panel-stack.json`
contains the return into `cvsavage_panel_probe+0x75`, querying bus 228,
device 6, function 0. ATA was ready, with error zero and both native/firmware
ownership guards clear. The emulator has no SuperSavage: positive discovery
was cached, but absence was not, causing a fresh scan of all 256 buses on
every metadata query. Such queries run on the serialized device stack with
interrupts disabled. This is a demonstrated source of repeated UI/device
service latency, not proof that it explains every pending guest interrupt.

The primary [Linux v6.2 PCI discovery implementation](https://github.com/torvalds/linux/blob/v6.2/drivers/pci/probe.c)
separates retained device objects (`pci_scan_single_device` first checks
`pci_get_slot`) from explicit topology rescans (`pci_rescan_bus`). Following
that separation, this fixed legacy-GPU module now remembers a completed
negative enumeration for its lifetime. A repeated negative panel query
clears panel dimensions and returns without PCI, VGA or MMIO I/O. A known
positive identity remains checked on each query; if it disappears, one fresh
scan is allowed before retaining the negative result. Invalid LCD registers,
disabled decoding and mode changes do not become cached device absence.
The existing Display Detect action refreshes mode/monitor information; it
does not implement PCI GPU hotplug. Discovery starts fresh on a module load.

The bounded host model now passes 107 scenarios with ASan/UBSan, including
five discovery cases: repeated empty and unsupported topologies, live
positive-panel dimensions, loss of a positive device and recovery from
temporarily unreadable LCD registers. An empty initial topology costs 8,193
PCI reads and 8,193 selector writes; 100 subsequent status calls cost zero
I/O. A positive repeat uses five PCI reads and five selector writes while
preserving the live panel checks. Evidence is in
`build/tests/s3-panel-discovery/{run.log,report.json}`. This model is a protocol
regression; the T23's present SuperSavage follows the positive path, so this
change alone makes no claim of fixing its acceleration or DOS launch.

The probe reads CR6B and SR61/SR66/SR69/SR6E through standard indexed VGA ports;
it requires active LCD bit 1, two identical snapshots and plausible dimensions.
It uses X.Org's exact mobile decode equations. It preserves the CRTC and
sequencer index selectors and the PCI configuration selector. It performs no
register-data, MMIO, extended lock, clock or timing writes. Locked/unavailable,
all-FF, unstable, inactive and implausible reports produce unknown dimensions.

Status dwords at offsets 112/116/120 contain panel width, height and flags
(bit 0 means valid). DISPLAY_INFO exposes these at offsets 176/180/184. Offset
124 (DISPLAY_INFO 188) counts successful independent native copy readbacks.
The panel report is a selection ceiling for the active internal LCD, not a new
timing or a claim about an external monitor's maximum mode. BIOS VBE mode
validation and active access-path readback remain mandatory.

## System-shell diagnostic client

`SAV3D.COM` is a small native 3D demonstration and evidence collector. Run
`sav3d` from the F4 system shell while the shell retains its verified LFB
mapping. The shell must treat this installed diagnostic as a trusted system-VM
client instead of creating an independent DOS VM or ending its owned display
before EXEC. The client itself never changes the BIOS mode or binds/unbinds
the framebuffer.

The client discovers CVSESSION through INT 2Fh/1684h and validates QUERY's
magic, ABI version, active-session state, framebuffer ownership and native
triangle capability. It independently validates DISPLAY_INFO's backend 3,
ready state, exact S3 device identity and successful private fill/triangle
probe counts. Unsupported GPUs receive the explicit message
`Native S3 triangle unsupported on this active display.` No software fallback
is reported as a GPU result.

One hardware triangle uses the screen-space vertices (32,64), (192,64) and
(32,224), with red, green and blue vertex colors. The client requires a
completed triangle counter increment of exactly one, at least two completed
hardware transfers and actual submitted PIO words before reporting completion.
It waits for a key and returns to the shell for its ordinary repaint. A native
hardware error writes only the disk log and returns; it avoids DOS console
output while the owning shell must drain/release an uncertain engine.

`SYSTEM/VIDEO/GPU3D.LOG` is exactly 400 bytes:

| Offset | Contents |
| --- | --- |
| 0 | `CG3D` magic |
| 4 | 16-bit version `0x0100` |
| 6 | 16-bit header size 16 |
| 8 | 32-bit result: 0 completed, 1 unsupported, 2 session validation failed, 3 native operation/counter verification failed |
| 12 | 32-bit service error; AX is stored in its low 16 bits |
| 16 | 192-byte DISPLAY_INFO before submission |
| 208 | 192-byte DISPLAY_INFO after submission/error |

Unavailable snapshots remain zero. The client verifies complete log writes
and file close; it returns DOS errorlevel 0 on a completed logged demonstration,
1 when unsupported, 2 on session/hardware failure and 3 on a log failure.

`scripts/test_sav3d_client.py` assembles the real COM and executes its actual
instructions in Unicorn with mocked monitor/DOS services. Fourteen scenarios
verify preconditions, exact float/color packet bytes, completed counter proof,
400-byte evidence, rejection of stale/malformed metadata, missing native probe,
hardware failures, unavailable monitors and short/failed disk writes. Hardware
failure paths are checked to produce no framebuffer console output. This test
does not claim to emulate or qualify a physical SuperSavage.

## R10e physical stage-4 failure and solid-source ROP (2026-10-09)

The read-only diskseq32 capture in
`build/full/t23-next/physical-logs-20261009-diskseq32-r10e/` reports a different
failure from the earlier descriptor readback: the phase-3 fill/copy proof now
reaches stage 4. The setup predicates passed, the engine reported idle
(`07E00000`), and there were no FIFO or idle timeouts. The attempt submitted
23 words (cumulative count 64 to 87): 8 descriptor setup, 6 solid fill, 1 wait,
and 8 descriptor restoration. Its fill proof count remained zero and engine
ownership was restored. These facts locate the rejection at private fill
pixel comparison, before copy or triangle qualification.

Source review found a concrete command defect. The pinned
[X.Org Savage 2.4.1 source](https://xorg.freedesktop.org/archive/individual/driver/xf86-video-savage-2.4.1.tar.xz)
uses `SavageHelpSolidROP` to translate a solid `GXcopy` through the copy ROP
table. Its `savage_xaa.c:365-436` explains that Savage non-stippled solid
colour is the source operand. The maintained
[X.Org source in NetBSD xsrc](https://raw.githubusercontent.com/NetBSD/xsrc/trunk/external/mit/xf86-video-savage/dist/src/savage_xaa.c)
preserves that explanation and solid-fill command format; its
[SavageGetCopyROP table](https://raw.githubusercontent.com/NetBSD/xsrc/trunk/external/mit/xf86-video-savage/dist/src/savage_accel.c)
maps `GXcopy` to `CC` (source copy). CiukiOS instead submitted `F0` (pattern
copy), despite `SRC_SOLID`/`PAT_NONE` and sending the desired source colour.
Decision: change only the fill command ROP from `4BF08C00` to `4BCC8C00`.
Descriptor order, command length, addressing, memory bounds and all private
readback requirements remain intact. The same helper also clears the private
triangle surface, so that clear receives the corrected source copy as well.

The earlier host fixture duplicated the wrong literal and wrote the supplied
colour regardless of its ROP. It therefore hid this defect. The corrected
fixture decodes the eight-bit ternary truth table independently, using
pattern/source/destination bit indices and a distinct pattern poison value;
that poison tests operand selection without asserting an undocumented
hardware pattern reset value. Independent checks exercise source copy,
pattern copy, destination preservation and source/destination XOR.

Validation in `build/tests/s3-source-rop/`:

- The saved, exact R10e production source against the corrected decoder
  reproduces stage 4, 23 words, zero timeouts and restored private VRAM.
  The same old source fails the updated successful phase-3 fixture.
- The corrected source passes 112 AddressSanitizer/UndefinedBehaviorSanitizer
  scenarios. The captured 1024x768x32 profile with unassigned BAR2 now
  completes independent fill and copy proofs in the model, submits 32 words
  and restores original private VRAM, CR and MMIO state.
- Qualification still requires actual private fill, copy and triangle
  readbacks on the physical T23 before publishing their capabilities.
  This correction and the improved negative control establish a source
  defect and its modeled reproduction; they do not yet qualify physical 3D.

The source hashes, commands and test outputs are recorded in
`build/tests/s3-source-rop/report.json`. No full image, ZIP, emulator run or
physical disk write was performed by this focused S3 check.

## R11 counterevidence, full SuperSavage setup audit and retained fill diagnostics

The real diskseq33 R11 capture on 2026-10-09 still returns phase 3/error 8,
stage 4, with 23 additional command words and no FIFO or idle timeouts.
`S3QUAL.LOG` has SHA-256
`02db5c23b131f13654119fd0dba54f954729765c67f247352c3640826e6ad4f4`, identical
to diskseq32. The updated resident binary was present on the tested disk.
The source-copy ROP correction above therefore did **not** resolve the physical
failure. The existing record did not retain the original execution format,
the inline destination descriptor or the mismatching private pixel; zero
triangle-probe fields are not measurements of this failed fill.

The second audit compared the entire mobile SuperSavage setup rather than
only generic Savage4 drawing commands. Sources are the pinned X.Org 2.4.1
archive above; the maintained
[full X.Org mode initialization](https://raw.githubusercontent.com/NetBSD/xsrc/trunk/external/mit/xf86-video-savage/dist/src/savage_driver.c)
and [SuperSavage `SavageSetGBD_PM` implementation](https://raw.githubusercontent.com/NetBSD/xsrc/trunk/external/mit/xf86-video-savage/dist/src/savage_accel.c);
the [upstream Linux v6.2 clear packet](https://github.com/torvalds/linux/blob/v6.2/drivers/gpu/drm/savage/savage_state.c#L811-L860);
and the S3
[RE046-B register specification](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
paired with the SuperSavage-specific source. The resulting comparison is:

| Contract | Upstream and CiukiOS comparison | Decision |
| --- | --- | --- |
| MMIO and FIFO | SuperSavage maps BAR0, 512 KiB, BCI window `+10000`; BAR1 is linear framebuffer. Production uses those addresses and disables CPU caching in `_PageCommitPhys`. | Retain mappings. Unassigned BAR2 does not supply the private linear fill destination. |
| Inline destination packet | X.Org `savage_xaa.c:582-590` and Linux clear use command, destination byte offset, descriptor, colour, XY, WH. Production has that exact order. | Retain order; do not change it from an inferred parser assumption. |
| Descriptor format | Mobile setup uses temporary GBD `10000001`, then final GBD with bit 0 set; PBD/SBD omit that GBD-only bit. Linear offsets are bytes and stride is pixels. Production matches. | Retain descriptor construction and restore protocol. |
| Execution depth | Full mode initialization (`savage_driver.c:3931-3952` in the pinned source) selects CR50 bits 5:4 as `10` for 16-bit or `30` for 32-bit before the mobile GBD helper selects width bits `C1`. Production only ORed `C1` into the inherited CR50. The register manual defines depth separately for enhanced command execution. | Set the negotiated depth explicitly, check mask `F1` against `D1`/`F1`, preserve unrelated bits, restore the exact original CR50. |
| Firmware scanout/context | X.Org also reprograms stream addresses, stride and CR67/CR65 and resets the engine during full modesetting. CiukiOS has an already active VBE desktop and promises to restore firmware context. The captured engine is idle, with no reset timeout evidence. | Do not copy a modeset/reset sequence into this private proof without evidence. Preserve firmware scanout and shadow pointer. |
| Private proof | A successful command submission or idle status is insufficient. | Retain GPU pixel readback before any capability publication; add the failed predicate to the persisted status. |

The CR50 change closes a concrete missing programming contract. It is **not
the established cause of the T23's R11 mismatch**: the old physical record
does not contain the inherited CR50 value, and the VBE firmware may already
have selected the correct depth. No modeled pass establishes that hardware
cause or qualifies the T23.

For a completed idle fill, only comparison of the four actual private DWORDs
decides success. After a pixel mismatch, the backend additionally reads the
inline PBD at MM8170/MM8174 using two 16-bit accesses. The generic register
manual labels these registers readable, and upstream mobile setup programs
them; a SuperSavage-specific guarantee that inline NEW is reflected by CPU
readback was not established. PBD readback therefore supplies failure
diagnostics and can never reject an otherwise successful pixel proof. The
existing 128-byte status retains:

- `error_stage` top nibble `A`, low-byte stage 4; bits 27:24 identify PBD low
  (1), PBD high (2), or private pixel DWORD 0..3 (3..6). Every reason already
  implies that the actual private pixel proof failed.
- Original CR50 in bits 15:8 and active CR50 in bits 23:16, captured before
  rollback restores the firmware registers.
- Actual and expected predicate values in the existing probe pair and the
  actual value in `last_status`; 32-bit pixel comparisons mask the unused
  XRGB byte while retaining the raw observed DWORD.

The private DWORDs and engine context are still restored after an idle proof,
even on mismatch. The failure values survive successful rollback and the
qualification client snapshot. A failed rollback retains the existing stage-8
ownership failure instead of falsely claiming restored hardware. The decoder
recognizes only tagged stage-4 records, leaves historical stage 4 and stage 8
untagged, and cannot treat a tagged fill predicate as native triangle proof.

Focused validation is recorded in `build/tests/s3-engine-format-r11/report.json`:
139 ASan/UBSan scenarios pass, including all four inherited depths at both
16/32-bit, ignored execution-depth writes, each of the six failed readback
predicates, successful pixels despite mismatching PBD readback, exact
CR/MMIO/private-VRAM restoration and unused XRGB handling.
The exact saved R11 production source fails the added execution-depth contract
before drawing against the independent fixture; that negative control establishes
the omitted initialization, not the physical result of an incorrect CR50.
The previous R10e ROP negative control still reproduces its isolated failure
with firmware depth set correctly. Nine qualification-log and eleven display
decoder tests pass; the production backend compiles with Watcom warnings as
errors. No full build, QEMU run, ZIP or physical disk write was part of this
focused validation.

The uncached-private-read contract was also checked against the actual R11
cache record and the monitor implementation, rather than only the caller's
flag. `src/vm/session_gpu.inc:126` supplies `PC_CACHEDIS` to `_PageCommitPhys`
for both mappings and reloads CR3 after commitment. The pinned
[JLOAD implementation at commit e96bb6bb](https://raw.githubusercontent.com/Baron-von-Riedesel/Jemm/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Tools/JLOAD/VMM.ASM)
supports this flag: `_PageReserve` creates PTEs without cache/PAT bits, and
`_PageCommitPhys` shifts `PC_CACHEDIS=00100000` to PTE bit 4 (PCD), retaining
PWT=0 and PAT=0. The local built source is
`build/external/jemm-monitor/work-m3l4wken/jemm/Jemm-e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Tools/JLOAD/VMM.ASM:1786-1851`.

The diskseq33 artifact `SYSTEM/VIDEO/CACHE.LOG`, decoded in the capture's
`manifest.json`, contains PAT `0007040600070406` (entry 2 is UC-minus),
MTRR default type `00000C00` (enabled, default UC), and only one enabled
variable range: base `0000000000000006`, mask `0000000FE0000800`, type WB.
That range does not cover MMIO `C0100000`, linear framebuffer `E8000000`,
or the private phase-3 probe `E8600000`. Applying the
[Intel SDM Volume 3A memory-type combination table](https://cdrdv2-public.intel.com/835781/325462-sdm-vol-1-2abcd-3abcd-4.pdf)
to this captured profile and the actual JLOAD page flags gives effective UC
for the private mapping, not a cached or write-combining alias. This is a
source-plus-capture derivation; the existing cache artifact reports the
visible framebuffer PTE rather than measuring the private PTE directly.
The production private reads are volatile loads, issued after submitting
`WAIT_2D` and observing the idle predicate. No CPU cache flush is substituted
for the independent GPU pixel proof.

## R12 byte-replicated colour and initial PBD/SBD state (2026-10-09)

The real diskseq34 R12 qualification capture changes the diagnosis:
`SYSTEM/VIDEO/S3QUAL.LOG` SHA-256
`4547cfe0f5a671c51004c441fe9c3f6d69bbbb339d049addc3806ca279e58bba`
reports tagged stage 4, private DWORD 0, actual `56565656`, expected
`00123456`, masked actual `00565656`. Original CR50 was `30`, active CR50
was `F1`, and both inline PBD readbacks matched. The attempt again submits
23 words with no FIFO/idle timeout and restores ownership. The GPU therefore
changed the private destination; this is not an unchanged-VRAM failure.
The submitted colour's low byte is replicated across the observed DWORD.
R12 also establishes that inherited CR50 already selected 32-bit pixels,
so the explicit depth fix was not the cause of this physical mismatch.

The Watcom disassembly in
`build/tests/s3-engine-format-r11/savage_r12.asm` shows `123456` loaded and
pushed as a DWORD by `selftest`, copied as a DWORD into rectangle packet
word 3, and submitted by DWORD stores to the FIFO. The packet flags,
descriptor and word order still match the primary X.Org/Linux implementations.
The S3 manual defines independent enhanced-length and register-width controls,
but neither it nor the checked upstream source establishes a silicon rule
that explains this exact byte replication. No speculative MM850C or MM8144
change is made on that basis.

The full SuperSavage initialization contains an additional concrete contract:
after setting GBD, `SavageSetGBD_PM` in the pinned X.Org source
(`savage_accel.c:1107-1114`) sets PBD low/high and SBD low/high to the same
initial surface address and format. The
[maintained SuperSavage initialization](https://raw.githubusercontent.com/NetBSD/xsrc/trunk/external/mit/xf86-video-savage/dist/src/savage_accel.c)
preserves that sequence. The production backend previously set only GBD and
relied on the first inline `PBD_NEW` packet to initialize PBD. Decision:
initialize PBD and SBD explicitly, in upstream order, to address zero and the
negotiated linear descriptor without the GBD-only bit 0. Read back those
explicit writes before any drawing packet; rejected writes retain distinct
setup predicates 9..12. Save and restore their complete original values,
including inherited different offsets/depths. The added saves and four-write
group use the existing 21-checkpoint protocol without changing its ABI.

A plausible explanation is that colour acceptance uses an inherited bitmap
format before the inline NEW descriptor is applied; an inherited 8-bit format
would account for byte replication followed by matching 32-bit PBD readback.
This remains **a hypothesis**, not a verified SuperSavage parser specification
or the established hardware root cause. The change closes an independently
identified omission from full upstream initialization. Physical pixel proof
remains mandatory, with no CPU fill substitute and no capability publication
based on descriptor readback alone.

`SEND_COLOR` also changes the foreground colour register at MM8124 (BCI D6,
S3 RE046-B p140). The backend now saves and restores that register with the
2D context; later 3D state saving cannot overwrite its original snapshot.
New failed-fill records use top-nibble tag `B`: the existing actual/expected
probe DWORDs and both CR50 bytes retain their meanings, while the previously
duplicated `last_status` field records the foreground register before
rollback. This distinguishes a replicated colour latch from correct colour
with an incorrect pixel result. Legacy tag `A` still decodes with no known
foreground readback. These reads supply diagnostics only after a pixel
mismatch and never reject a successful private pixel proof.

Focused checks in `build/tests/s3-descriptor-seed-r12/report.json` include:

- An independent assertion that all four explicit descriptor seeds precede
  the first drawing packet. The exact saved R12 production source fails this
  initialization contract before the pixel model can hide its omission.
- An explicitly enabled hypothesis model reproduces the real `56565656`
  result with inherited 8-bit colour parsing. It is marked hypothesis-only,
  rather than being presented as documented silicon or physical qualification.
- The new source passes 153 ASan/UBSan scenarios: inherited PBD/SBD formats
  0/8/16/32 and differing offsets, both supported depths, each rejected seed
  write, normal proof, raw replicated-colour diagnostics, unchanged capability
  gates, full original descriptor/foreground/private-VRAM rollback, and the
  existing timeout/ownership/retrace coverage.
- Ten qualification-log and eleven display decoder tests pass, including
  distinct failed-pixel and foreground values in the new tag and compatibility
  with historical logs. Watcom compiles the production source with warnings
  as errors. No full build, emulator, ZIP or disk write is part of this check.

## R13 foreground replication and 2D register access width (2026-10-09)

The diskseq35 physical R13 capture matches the installed module SHA-256
`d081dab2e32ad177c7f332cf2996409cd3b58b3ef421035c29f42f094a7b02c7`.
Its `S3QUAL.LOG` SHA-256 is
`4211b3b002595933048c34b295bf2665c61f2b416db6cba8742a5fde38f6e466`.
The tagged failure is `B3F13004`: original CR50 `30`, active CR50 `F1`,
private pixel `56565656`, expected `00123456`, and foreground register
`56565656`. The attempt passed the explicit initial PBD/SBD readbacks,
submitted 23 words, had no FIFO/idle timeout, and released ownership. The
initial-descriptor parsing hypothesis above therefore did not explain or
resolve this physical failure. Replication already exists in the foreground
register, rather than appearing only when the pixel is stored.

An independent primary driver identifies a further omitted initialization
contract. [9front's Savage driver](https://raw.githubusercontent.com/9front/9front/front/sys/src/9/pc/vgasavage.c)
includes PCI device `8C2E` and explicitly sets `MM8144` bit 9 before DWORD
colour, plane-mask and descriptor writes. Its `savageinit` writes the control
as a **16-bit** value, so enabling DWORD access does not itself depend on
DWORD access. The downloaded source SHA-256 is
`6326be0eb9c7c6b1dfee001022ab844b86146384499e51c95672ed48c2e8002d`;
the local audit copy is `build/external/savage-research/plan9/vgasavage.c`.
This driver uses packed MMIO drawing rather than BCI and explicitly notes
the limits of the BCI documentation; its sequence is evidence for the
register-access contract, not proof of a particular BCI colour-parser rule.

The [S3 register manual](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
p146 defines `MM8144_9` as the 16/32-bit 2D register-access selector, requires
software initialization, and gives an undefined initial value. This control
is independent of the CR50 execution pixel length. Although the individual
legacy index description calls the register write-only, p142 explicitly
states that those indices are directly readable through packed new MMIO;
the non-packed BEE8 read-selector and pipelined-update procedure does not
apply to packed accesses. Reading `MM8144` uses **one 16-bit access** and
must not accidentally read the adjacent `MM8146` read-selector register.

Decision: save packed `MM8144` with a 16-bit read; retain every control bit
and set only bit 9 with a 16-bit write before any DWORD 2D register writes;
check that bit before proceeding. During rollback restore masks,
descriptors and foreground while DWORD access remains enabled, then restore
the original misc control with a 16-bit write. The legacy index nibble is
retained as `E` on writes. Do not copy the independent driver's engine reset,
clipping-disable, scanout or clock changes. Keep the existing 21 setup
checkpoints, status ABI, historical failure diagnostics and private pixel proof.
This addresses a specified missing initialization; whether it causes the
observed BCI replication remains unqualified until physical evidence shows
the correct private pixels.

New failed-fill snapshots use additive tag `C`. They retain both CR50 bytes,
the failed pixel/expected pair and foreground register. Reason 1..6 occupies
bits 26..24; spare bit 27 records whether the saved original `MM8144_9` was
already enabled. This uses saved state and adds no hardware access. A future
physical mismatch can therefore distinguish missing initial access width
from a failure despite firmware already enabling it. Historical tags `A`
and `B` continue to decode with unknown original register-access width.
The flag is diagnostic only and cannot publish acceleration capability.

Focused validation is recorded in
`build/tests/s3-register-width-r13/report.json`:

- The exact saved R13 source/header fails an independent assertion on its
  first DWORD 2D write with 32B disabled, before any BCI pixel model runs.
  This establishes the omitted initialization, not the physical cause of
  foreground-byte replication.
- The updated source passes 168 ASan/UBSan scenarios, including both pixel
  depths, differing inherited comparison/clipping/base controls, an adjacent
  read-selector sentinel, every existing setup prefix, and full restoration
  of masks/descriptors/foreground while DWORD access remains enabled.
- A rejected enable is reported as setup predicate 13 before any DWORD
  state write or BCI command. A rejected original misc restoration retains
  ownership; a later successful retry replays only misc/control and releases
  ownership without submitting BCI through the disabled interface.
- Tag C preserves original enabled/disabled state through rollback; legacy
  A/B diagnostics remain readable. Eleven qualification-log tests and eleven
  display decoder tests pass, including refusal to qualify tagged failures.
- Watcom warnings-as-errors compilation passes. The resulting disassembly
  (`savage_r14.asm` in that directory) contains word reads/writes at `8144`,
  an OR of bit 9 before the first plane-mask write, and DWORD BCI stores.

These checks run in small capped user scopes. No full image, emulator, ZIP
or disk write was performed for this focused validation. The captured R13
result remains a failed physical qualification.

## R14 misc-control synchronization and rollback evidence (2026-10-09)

The physical diskseq36 R14 capture stops before a drawing command. Its
`S3QUAL.LOG` SHA-256 is
`c26993e6bf10e69f1f849d468db4b332d77411eecbaae2b368b48102d4c0a07a`;
the installed `CVSESS.DLL` SHA-256 is
`f5c94cf10b2c2734a7ced3bd7d37eac3e30fb5d471862a303ce66ea89dd93cde`.
Setup prefixes 1..14 return successfully; prefix 15 returns error 8 with
ownership retained, zero command words, zero FIFO/idle timeouts and raw
`last_status=0000E000`. Prefix 15 checks disabled BCI CONTROL; the retained
stage 8 is the subsequent misc-control rollback failure. R14 does not retain
the saved misc payload or the original failed predicate, so this capture
cannot distinguish a CONTROL check failure from a successful check followed
by a misc restore failure. It is not another failed private-pixel result.

Rechecking the primary sources identifies two concrete omissions in R14:

- [9front's SuperSavage initialization](https://raw.githubusercontent.com/9front/9front/front/sys/src/9/pc/vgasavage.c)
  waits for engine idle after disabling BCI, after the 16-bit misc-control
  write, and after masks/descriptors. R14 reads the misc control immediately
  after writing it and clears DWORD access during rollback immediately after
  DWORD state writes, without completing those register transitions.
- The [vendor register manual](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
  p146 reserves misc bits 6 and 10. The documented writable payload mask is
  `0BBF`, not `0FFF`; reserved bits cannot be a restore correctness predicate.

Decision before implementation: retain the 16-bit packed misc access and
all ownership checks; complete the enable write before reading it or making
DWORD state writes, complete BCI disable before checking CONTROL, and drain
restored DWORD state before restoring access width. Complete the final misc
word write before checking its documented payload. Do not write or compare
reserved misc bits. Every wait is bounded; a failed completion or documented
payload mismatch still retains engine ownership. Add a distinct rollback
diagnostic which retains the original cause and the rollback observation.

The register-read limitation remains explicit: p142 says packed new-MMIO
index reads avoid the legacy pipeline, but p146 calls MM8144 write-only and
references legacy pipelined readback. The legacy selector for index E is
**6**, not E, and MM8146 is a separate write-only selector. No inspected
X.Org, Linux or 9front path reads MM8144 to save firmware state; 9front only
writes it. Neither its driver nor Savage4's generic wording establishes a
physical 8C2E readback guarantee. We therefore do not invent a selector
rewrite or discard the restore check. Synchronization and the reserved-bit
mask address source-contract gaps; they are not a proven explanation of
R14's exact E000 observation or R13's foreground replication. The previous
host model's immediate-register behavior did not cover asynchronous MMIO.

The implementation completes both CONTROL transitions before checking them,
completes PBD/SBD seeding before its readbacks, and completes the original
CONTROL write before dropping ownership. It preserves the 21-prefix ABI.
Misc writes mask out reserved bits 6/10; their observed values are excluded
from restore comparison. All documented misc controls are restored rather
than forcing 32B to remain enabled. No legacy selector write, clipping toggle,
reset, timing change or capability bypass is introduced.

Additive rollback tag `D` retains low-byte stage 8. Bits 27..24 identify the
failed operation: 1 completes the preceding DWORD restores, 2 completes the
misc word write, 3 compares its documented payload, and 4 completes original
CONTROL restoration. Bits 23..12 retain the expected misc payload; raw
`last_status` retains the rollback observation. The existing probe pair
retains the **original full error stage and original last status**, so a
CONTROL predicate and a misc restoration failure remain distinguishable.
Repeated failed retries retain that initial cause. Tags A/B/C and untagged
historical records remain readable. D-tag records cannot qualify the engine
or triangles, even if other fields contain stale successful counters.

Focused evidence is recorded in `build/tests/s3-misc-sync-r14/report.json`:

- The exact pre-change R14 source/header are retained in its `baseline/`
  directory. With the independent timing fixture, width initially disabled
  fails prefix 9; width already enabled can falsely release with pending
  writes. The negative controls fail before normal drawing. These are
  synchronization contract failures, not reproductions or proof of R14's
  exact physical prefix-15 read value.
- The timing fixture delays accepted engine-register updates until a status
  completion poll and preserves their order. It runs two complete successive
  21-prefix rounds without resetting hardware state between prefixes, at both
  supported depths and both inherited access widths. It checks no pending
  work at ownership release, exact firmware register restoration, no drawing
  and no 3D access. This is an adversarial timing fixture; it does not claim
  that packed-read ambiguity or this precise delay models the 8C2E silicon.
- The complete ASan/UBSan fixture passes 342 scenarios. New cases include
  changing reserved-bit observations, each of the four rollback failures,
  retained ownership, preserved original cause, and retry without DWORD
  engine-state replay or BCI submission through a disabled interface.
- Thirteen qualification-log and twelve display decoder tests pass.
  Watcom compiles production code with warnings as errors; disassembly is
  saved as `savage_r15.asm` in the report directory.

The R14 physical result remains failed qualification. The source-backed
synchronization changes do not establish that S3 acceleration works on the
T23 or that bit 9 explains R13's replicated foreground. No full build, QEMU,
ZIP or disk write is part of this focused validation.
# R15 physical rollback and independent packed-MMIO decision

## R16: mandatory Drawing Command bit0

Physical diskseq38 `S3QUAL.LOG` SHA256
`23fc6435f73caf01f34f2f0cb89b728e79cbc1bcf2b52306bba6c9edc4bb2e26`
passes all setup prefixes, then fails phase3 with `F1F13004`. Foreground readback
is now `00123456`, so the former low-byte colour replication is absent in this
snapshot. Packed drawing leaves private DWORD0 at its `A55AA55A` sentinel,
expected `00123456`; no idle/FIFO timeout occurs, and rollback releases ownership.

[S3 Savage4 Registers, Drawing Command MM8118, pp137–139](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
requires bit0 to be programmed to1. R16 emits fill `000440B0` and copy `0009C0B0`,
both violating that requirement. The original packed-MMIO model checked draw and
direction fields, but omitted this mandatory command bit. The 9front reference
also omits it and cannot override the vendor contract; its implementation comment
expressly limits the source's hardware testing. Correct only that bit in the
existing commands (`...B1`). An independent field-decoded fixture rejects an
invalid drawing command without modifying private pixels; the exact R16 source
then reproduces the unchanged-sentinel failure, while the corrected source must
pass fill/copy proofs at16/32bpp with posted writes and restore all borrowed state.
This establishes a concrete invalid-command defect, not proof that it is the only
remaining physical cause. Do not infer extra enable/clock/descriptor changes or
advertise physical 3D before its independent hardware proof passes.

The diskseq37 R15 `S3QUAL.LOG` (`1da75298409f9df7f10f9cc61622152769489475828d62283afd17940b05f9e0`)
fails qualification phase2 prefix9 with tag `D3010008`: the original setup
stage is 3, its status is `07E00000`, and rollback reads `E000` while expecting
misc payload `0010`. No commands ran. Thus the access-width enable succeeded;
the failure is the rollback predicate for RSF, not a failed fill or 3D command.
The latest GPU.LOG instead describes a 24-bpp unsupported adapter; it must not
be used to reinterpret the T23's earlier qualification snapshot.

[S3 Savage4 Registers, pp142,146](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf)
defines RSF as a lower/upper-half access selector and marks MISC write-only.
[S3 Vision868, p19](https://www.bitsavers.org/components/s3/DB015-A_Vision868_Multimedia_Accellerator_Apr1995.pdf)
describes automatic selector toggling for doubleword accesses in 16-bit register
mode. That earlier-chip rule is not evidence that independent SuperSavage word
reads toggle RSF. The physical result establishes that RSF cannot be treated as
a stable readback predicate in our existing sequence; it does not identify which
access changed it. Save MISC before other engine accesses, normalize RSF while
owned, verify persistent controls excluding RSF, and replay the original selector
after the final status reads. Idle completion and persistent-width restoration
remain required before ownership is released. Legacy D diagnostics retain their
original meaning; new E diagnostics describe this revised persistent-bit check.

[9front's Savage driver](https://raw.githubusercontent.com/9front/9front/front/sys/src/9/pc/vgasavage.c)
and [the exact8C2E dispatch](https://raw.githubusercontent.com/9front/9front/front/sys/src/9/pc/vgas3.c)
provide a packed-MMIO fill/copy implementation independent of BCI drawing packets.
After an idle BCI private-pixel mismatch, qualify that path with separate private
VRAM pixels and two-row copies. Preserve BG colour, source/destination XY and
width/height in addition to the existing state. Drawing COMMAND is write-only and
triggers work: never save/replay it as configuration. The documented descriptor
selector bits permit private PBD/SBD destinations without changing scanout or
using the visible front buffer for a proof. Native capability requires its actual
pixel/copy proof; timeouts retain ownership. BCI triangles retain their separate
hardware proof, and a 2D result cannot advertise 3D. No CPU rasterizer supplies
proof pixels. These changes correct the source contract; physical acceleration
remains unqualified until an actual T23 capture passes.

The public phase contract now includes action5: retain re-proven packed 2D
fill+copy without submitting triangles. A safely released phase4 failure at
stage9 may retain only the informational packed-path status bit8; ready and
operation capability bits remain zero. The caller may offer a separate 2D-only
result under that exact condition. Action5 reruns both private proofs and only
then publishes ready/ownership, low capability bits5 and packed-path hint8.
Failed rollback, fill/copy mismatch, or a timeout cannot authorize that action.
The 192-byte CVGD header exports only its known capability bits1/2/4; the 128-byte
S3 status additionally records the path hint. 3D still requires its actual tiled
triangle proof, including the BCI tiled clear/transfer work; no unsupported packed
tiled command is inferred from a successful linear packed fill.

Validation is recorded in `build/tests/s3-r15-rsf-packed/report.json`: 688 bounded
ASan/UBSan scenarios, 27 decoder tests and OpenWatcom warnings-as-errors compile.
The adversarial RSF fixture explicitly models an unstable write-only selector,
not undocumented SuperSavage silicon: it exercises save-before-other-accesses,
two repeated21-prefix rounds at16/32bpp and original access-width/RSF values0,
10,200,210. The exact R15 baseline fails the isolated prefix9 rollback with
`D3010008`, original stage3, read `E000`; the corrected source releases correctly.
A separate field-decoded MMIO model proves private fill/copy, restores every
borrowed register, and covers corrupted pixels, copy mismatch, engine timeout,
public fills/copies, invalid requests and safe phase4-to-phase5 transition.
The R15 baseline also fails that independent packed-path fixture. These are
protocol/ownership negative controls; they do not establish physical acceleration.

Exact OEM packages were retrieved from the [official T23 driver catalog](https://download.lenovo.com/lenovo/content/ddfm/T23.html)
under ignored `build/research/s3-r15-vendor/`: IBM SuperSavage12.32.26 W9x,
12.90.90 NT5, and NT4. The W9x INF explicitly matches5333:8C2E/subsystem01FC1014.
Archive and extracted relevant binary hashes are pinned in
`build/research/s3-r15-vendor/manifest.json`. Bounded executable scans did not
locate direct MM8144 access constants; this is a limit of those literal scans,
not evidence the OEM driver omits or cannot compute that register access.
