# Parent-persisted DOS launch checkpoints

Diskseq65 (2026-10-08) contains R7 binaries and two attempted launches, DOOM
and WOLF3D. Both reach `VM ready`, but neither leaves a child CVFL or DPMIRUN
log. The user reports a whole-system freeze. The earlier diskseq64 launch
already returned F1DA without a CVFL file, so absence of that file cannot
identify the current hang. This change makes progress evidence independent
of child filesystem access; it does not claim to fix or identify the hang.

Before implementation, the Microsoft [MS-DOS 4.0 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
was checked for AH=40h's exact byte-count result and AH=3Eh's close contract.
The local full-profile `int21_write` writes sectors, flushes the FAT cache,
and updates a growing file's directory entry before reporting success.
`int21_close` only releases a handle here; AH=68h also only validates one.
Accordingly the parent requires a complete successful write AND successful
close. This is DOS-level persistence, not a guarantee against a drive losing
its own volatile cache on physical power removal.

Intel's [80386 manual, section 15.3](https://www.scs.stanford.edu/05au-cs240c/lab/i386/s15_03.htm)
places virtual-8086 task/interrupt management in the monitor. Inspection of
CiukiOS confirms that its canonical Jemm callback and HLT path already switch
V86 frames while preserving the InDOS/FAT gates. The new mailbox requests
VM0 through that path; it does not switch a frame from inside an interrupt,
perform disk I/O in ring 0, or change interrupt routing. A possible physical
IDE interrupt ownership race remains a hypothesis, not an implemented fix.

`VMFORK /P` uses dedicated operation 51h (`VMM_CREATE_TRACE`). Ordinary 41h
forks never enable the feature, irrespective of unspecified register values.
Only the desktop supplies /P; its DPMIRUN target also receives /P. Existing
command-line callers keep their old child-file diagnostics and never wait for
a desktop logger. The explicit traced create uses plain 51h, without the
optional NO_SWITCH bit.

Each traced VM owns a 256-byte mailbox in ring-0 memory. Operation 52h:

* CX=0 publishes the current child CVFL, ES:DI=buffer and BX=generation. It
  validates the complete conventional/UMB range and writable user pages,
  magic/version/size, VM and generation, ready state, trace opt-in and an
  empty mailbox. InDOS, dirty FAT, or a cleared saved IF refuses publication. The manager assigns
  a nonzero 32-bit sequence and sets pending only after copying all bytes.
  It stamps `PLOG` at bytes214..217, allowing captures to prove that this
  parent-persisted transport ran rather than the old child logger.
* CX=1 reads from VM0 only: BX=slot, DX=generation, ES:DI=destination.
  CX returns 0 for empty or 1 for a copied checkpoint. Reading does not ACK.
* CX=2 ACKs from VM0 only: BX=slot, DX=generation, CX high word plus SI low
  word form the exact 32-bit sequence. Wrong owner, slot, state, generation,
  sequence, or duplicate ACK is refused without clearing pending.
* CX=3 is the child's wait query: BX=generation, DX returns pending.

Pending children remain READY in the public lifecycle, but the scheduler
skips them. The child also waits in a bounded-state query/HLT loop, so an IRQ
that wakes it before a parent switch cannot pass the checkpoint. Publication
refusal terminates the child with F0E1; it never falls back to child disk I/O.
Creation, release and forced kill reset the mailbox state. No record from a
previous slot generation can release a new launch.
Generations restart at boot. A CVFL file left on disk by an earlier boot is
not evidence of progress in the current boot, even if its VM/generation pair
matches. Correlate the launch with the parent log and deployed image, and
archive or remove earlier diagnostics before a dedicated hardware run. The
R8c test image starts without old CVFL files.

DOSVM's foreground poll writes the CVFL to `SYSTEM/VMFORKn.BIN`. Before the
first ACK it also writes `SYSTEM/DOSVMn.BIN` with reason4 `launch_held`, so a
freeze before virtual video begins still leaves manager evidence. Any short
write, create/write/close error, malformed record or ACK error causes a
parent log entry and attempts to kill the held child. No failed persistence
is acknowledged; even if kill fails it stays held. Further polls do not
repeatedly write or ACK that failed launch.
A read-API error for a still-ready matching generation also stops the held
launch; an error after exit or slot reuse is ignored without touching files.

The traced child first publishes stage15 immediately after retrieving its
generation and restoring DS/ES, before BIOS INT12, AH52, or the PSP-chain
walk. The checkpoint's own AH62 query remains before publication; a missing
first record therefore still cannot prove that the child ever resumed.
VMFORK records restored-vector and detached-S3 boundaries as stages13/14.
DPMIRUN stages64..76 bracket firmware font reads, video configuration and
begin, device begin, virtual mode3, HDPMI EXEC, and command/game EXEC. The
initial DPMIRUN resize is bracketed by VMFORK's stage6. DPMIRUN /P bypasses
its child filesystem logger; serial logging remains bounded. The manager
sequence spans VMFORK and DPMIRUN even though each has its own CVFL buffer.
Only the latest closed checkpoint is required on disk. DPMIRUN's record has
its own stage and name; unused VMFORK-specific fields remain zero.

Validation is deliberately focused: the assembled production mailbox and
guest-range validator run in bounded 32-bit CPU fixtures, including stale
ACKs, pointer/page rejection, owner checks, pending protection and sequence
carry/wrap. A host fixture includes the actual parent persistence helper and
injects file/close/ACK failures, asserting ordering and no ACK on failure.
COM assembly and OpenWatcom DOSVM compilation use the project toolchains.
The full-image software regression and subsequent physical capture are
separate integration steps; none of these fixtures emulates the T23 hardware.

Completed focused checks on 2026-10-08: 22 assembled mailbox cases and thirteen
actual COM parser/wait/refusal cases pass in `build/tests/vmm-launch-diskseq65/`
and `build/tests/launch-com-diskseq65-r8b/`. All thirty retained-allocation cases
still pass against the actual DOS kernel's F149 allocator. The parent launch
and DA-memory host fixtures pass. NASM assembles both COMs, and OpenWatcom
compiles DOSVM with the production warnings-as-errors flags.

The R8b full-image software test exposed a separate F048 compaction-order
failure before DPMIRUN; see [the measured correction](vmfork-low-resident-compaction.md).
After that correction, R8c launches DOOM twice through Files with gameplay,
input, quit and reopening. Its final CVFL is parent-stamped PLOG, generation2,
sequence23, stage8, progress017F, with 34862 paragraphs both total and largest
free. The captured DOSVM snapshot has exit0, no fatal flag and no model errors.
This verifies the mailbox in the real image; it does not establish T23
hardware compatibility or identify the physical diskseq65 freeze.
