# GPU vendor support research

Research recorded 2026-10-09 before any GPU architecture change. The aim is to
prioritize the already-supported S3 Savage path on the ThinkPad T23, then add
separate ATI and NVIDIA paths for appropriate legacy hardware. This is a source
review, not a claim that an untested physical adapter works.

## Armada E500 target

Compaq's Armada E500/V300 Technical Reference Guide (part 11QY-0200A-WWEN,
March 2000) describes the Intel 440BX host bridge, PIIX4M southbridge on PIII
models (PIIX4E on PII models), AGP ATI RAGE Mobility-P, ESS Maestro 2E, and
PS/2 TouchPad. The E500 is specified with 8 MB local video SDRAM; the V300 has
4 MB. The Maintenance and Service Guide lists the E500's ATI RAGE LT Pro with
4 MB SGRAM in its general product feature table, which does not match every
E500 configuration. Treat the exact installed machine's PCI IDs and VBE
information as authoritative at runtime rather than relying on a SKU-level
name or memory-size assumption.

An Oracle hardware certification record for a specific Armada E500 reports
`8086:7190` 440BX host bridge, `8086:7191` AGP bridge, `8086:7110` PIIX4 ISA,
`1002:4c4d` ATI Rage Mobility P/M AGP 2x (subsystem `0e11:b160`), and
`125d:1978` ESS Maestro 2E (subsystem `0e11:b112`). The PCI ID is also named
`ATI 215 LM` in the Linux PCI ID header. This is the most concrete ID to use
when qualifying the reported E500. It belongs to the ATI Mach64/Rage family;
it is not a Rage 128 M3/M4 part.

The internal TouchPad is described as PS/2 in Compaq's system reference
material. The external PS/2 connector is available through the port replicator
or docking configuration. These are hardware identification facts only; this
note does not diagnose the reported dead keyboard or mouse.

## What CiukiOS currently does

`src/vm/session_gpu_legacy.c` is explicit that its ATI/NVIDIA backend only
changes the framebuffer start address for panning. Firmware chooses the VBE
mode; the CPU draws into the existing framebuffer. Its `cvlegacy_present()`
updates `ATI_CRTC_OFFSET` (`0x224`) or NVIDIA `PCRTC+0x800`, after checking the
active mode and restoring the prior scanout offset on release. This is not
2D or 3D acceleration.

The ATI PCI whitelist omits the E500's `1002:4c4d`. It currently includes
several Rage 128/Rage 128 Mobility IDs, plus selected ATI ID ranges. The ATI
register path is based on Radeon/Rage 128-style CRTC registers. Do not simply
add `4c4d` to that list: the E500's Rage Mobility-P is a Mach64-era device and
needs a separately qualified Mach64 register/backend path. The NVIDIA list
accepts these exact IDs: `10de:0020`, `0100-0101`, `0110-0113`, `0150-0153`,
`0170-0173`, `0181-0183`, `0200-0203`, and `0250-0253`. They cover RIVA TNT
(NV04), GeForce/GeForce2 (NV10), GeForce3 (NV20), and GeForce4 families; the
present implementation still only pans the scanout for them.

CiukiOS also has a separate S3 Savage engine driver and a VirtIO GPU 2D path.
Savage advertises fill, blit, and triangle operations only after engine checks
and readback/self-tests; its diagnostics count completed engine operations.
VirtIO uses the 2D resource protocol. Neither fact means every desktop drawing
operation is GPU-accelerated: ordinary desktop composition and pixel drawing
remain CPU-side unless routed through one of those explicit operation APIs.
For a “proper acceleration” goal, report capabilities per operation and keep
the CPU renderer as the correctness path for operations a backend does not
implement.

## Register/source evidence and licensing

* Compaq, [Armada E500 and V300 Technical Reference Guide, part
  11QY-0200A-WWEN](https://usersmanualguide.com/compaq/laptop/armada-e500-series/user-manual/2motp)
  (original vendor manual, mirrored online): system architecture, video
  controller, audio, and pointing-device descriptions. A second searchable
  mirror is [Manualzz](https://manualzz.com/doc/48555918/compaq-armada-v300-series-reference-manual).
* Compaq, [Armada E500 and V300 Maintenance and Service Guide, PDF
  mirror](https://www.macdat.net/files/pdf/compaq/service_manuals/armada_e500_v300.pdf):
  SKU feature list, service procedures, and configuration variation.
* Oracle, [Armada E500 hardware certification record](https://www.oracle.com/ocom/groups/public/%40otn/documents/webcontent/373933.html):
  observed PCI vendor/device and subsystem IDs for one configured E500.
* Linux upstream, [`pci_ids.h`](https://github.com/torvalds/linux/blob/af32da41b0327b9c6a37856ba82b6760d6c8d10e/include/linux/pci_ids.h):
  names `1002:4c4d` as ATI 215 LM and enumerates the Rage 128 / NVIDIA legacy
  PCI families. Linux is GPL-2.0-only for the downloaded fbdev implementation
  sources; do not copy code into CiukiOS without an explicit license review.
* X.Org, [xf86-video-mach64 upstream source](https://github.com/X11Libre/xf86-video-mach64/tree/a6aefafdb998cd4abc2e8f8572f71d68b871f8d5):
  Mach64 mode, register, and 2D engine handling; `COPYING` is a permissive
  MIT-style license with attribution conditions. It is a useful 2D reference,
  not a CiukiOS driver or a physical-hardware test.
* ATI, [RAGE Pro and Derivatives Programmer's Guide, Rev. 1.0
  (2000)](https://oummg.com/manual/imgs/ATI3DRageII/PRG-215R3-00-10_RAGE_PRO_and_Derivatives_Programmers_Guide_Rev_1.0_200003.pdf):
  original register/programming material for the Rage Pro/LT Pro line and
  device IDs. Use the register guide as the hardware reference; respect its
  copyright rather than copying its text/code.
* ATI, [Mach64 Register Reference Guide for ATI-264VT and 3D RAGE
  (1996)](https://bitsavers.computerhistory.org/components/ati/RRG-G02700_mach64_Register_Reference_Guide_ATI-264VT_and_3D_RAGE_1996.pdf):
  primary register descriptions for the Mach64 generation. This is a better
  register reference for the E500 Mobility-P family than Radeon register
  offsets.
* Linux upstream, [`mach64_accel.c`](https://github.com/torvalds/linux/blob/af32da41b0327b9c6a37856ba82b6760d6c8d10e/drivers/video/fbdev/aty/mach64_accel.c):
  GPL-2.0 Mach64 engine examples for fills, copies, and command sequencing.
* Linux upstream, [`nv_hw.c`](https://github.com/torvalds/linux/blob/af32da41b0327b9c6a37856ba82b6760d6c8d10e/drivers/video/fbdev/nvidia/nv_hw.c)
  and [`nvidia.c`](https://github.com/torvalds/linux/blob/af32da41b0327b9c6a37856ba82b6760d6c8d10e/drivers/video/fbdev/nvidia/nvidia.c):
  GPL-2.0 framebuffer mode and engine setup examples for NV04 through later
  families. `NVSetStartAddress()` confirms the PCRTC `+0x800` start register
  used by the existing narrow panning path.
* NVIDIA, [nouveau hardware documentation on MMIO](https://envytools.readthedocs.io/en/latest/hw/mmio.html):
  documents the NV04:NV11 PCRTC mapping at BAR0 + `0x600000`; this supports
  the existing NVIDIA MMIO offset calculation.
* X.Org, [ATI driver manual](https://xorg.freedesktop.org/archive/X11R7.5/doc/man/man4/ati.4.html):
  distinguishes the Mach64, Rage 128, and Radeon driver families.
* Historical DRI project, [Mach64 status](https://dri.freedesktop.org/wiki/ATIMach64/):
  records that the old Mach64 3D DRM module was dropped and did not reach the
  mainstream kernel. This is a significant maturity warning for a native 3D
  target; it is not evidence that the silicon lacks a 3D engine.

## Decision for implementation planning

Keep the existing legacy panning backend narrowly named and scoped. Add ATI
Mach64/Rage Mobility-P as an independent backend after explicit ID, VBE mode,
BAR/aperture, and safety checks; the exact first physical qualification target
is `1002:4c4d`, with subsystem `0e11:b160` as corroborating evidence rather
than a hard-coded requirement. Begin with a separately qualified 2D fill/copy
engine path based on the Compaq/ATI register documentation and X.Org's
permissively licensed Mach64 code. Keep CPU drawing as fallback and gate
hardware claims on engine idle/readback checks. Treat Mach64 3D as a separate,
later research effort because the historical DRM/DRI path is incomplete and
dropped; no evidence here supports promising native 3D for the E500.

For NVIDIA, retain the existing whitelist only for the currently qualified
scanout panning behavior. Any future 2D backend should be a distinct NV04/NV10
module with per-family engine initialization, FIFO/idle handling, restoration,
and readback qualification. NVIDIA is not a target on the E500. The broad
existing ID list spans multiple architecture generations; a shared `+0x600000`
PCRTC mapping is not evidence that a single engine setup works across all of
them. Prefer NV04/NV10-era boards for Pentium III systems and qualify each
exact board/device ID before enabling engine operations. NVIDIA 3D is out of
scope for an initial implementation.

This suggests independent hardware backend modules behind a small operations
interface (bind/probe, supported 2D ops, optional 3D ops, present, release),
with the UI compositor and CPU renderer owning fallback decisions. Keep the
existing Savage T23 path first in hardware selection, then try a qualified ATI
backend, then a qualified NVIDIA backend. Adapter detection alone must not
advertise acceleration.

## NVIDIA legacy hardware and driver references (2026-10-09 update)

NVIDIA's own archived Linux supported-chip table separates the requested IDs
across these legacy branches:

| Era/family | PCI ID (`10de:`) | NVIDIA product name | Official legacy branch |
|---|---:|---|---|
| NV04 / TNT2 | `0028` | RIVA TNT2/TNT2 Pro | 71.86.xx |
| NV04 / TNT2 M64 | `002d` | RIVA TNT2 Model 64/Model 64 Pro | 71.86.xx |
| NV11 / GeForce2 MX | `0110` | GeForce2 MX/MX 400 | 96.43.xx |
| NV11 / GeForce2 MX | `0111` | GeForce2 MX 100/200 | 96.43.xx |
| NV17 / GeForce4 MX | `0171` | GeForce4 MX 440 | 96.43.xx |
| NV17 / GeForce4 MX | `0172` | GeForce4 MX 420 | 96.43.xx |

This table is from NVIDIA's [official Linux supported-products list for the
96.43 and 71.86 branches](https://download.nvidia.com/XFree86/Linux-x86_64/304.43/README/supportedchips.html).
The PCI IDs are also named in NVIDIA's archived [device ID list PDF](https://download.nvidia.com/developer/SDK/Individual_Samples/DEMOS/common/src/VenderDeviceIDsExample/docs/Device_IDs.pdf)
and in the downloaded X.Org `pci_ids.h`. These are source-backed product
families, not a sales or popularity ranking.

This hardware generation is a reasonable period match for Pentium III-era
systems: NVIDIA published 32-bit x86 packages for both 71.86.15 and 96.43.23,
and a separate x86_64 96.43.23 package. NVIDIA's archived ForceWare 81.98
release notes list Windows 98/Me support and include GeForce2 MX and GeForce4
MX products. That establishes historical driver coverage, not physical
compatibility with an arbitrary PIII motherboard. Check the actual card's
connector and AGP keying/voltage (or PCI interface), bracket/clearance, power
needs, and device ID. Do not infer connector compatibility from the GPU name.

The X.Org upstream [`xf86-video-nv` source at commit
8234bcee52a357c69f2122e5df516966882543c7](https://gitlab.freedesktop.org/xorg/driver/xf86-video-nv/-/tree/8234bcee52a357c69f2122e5df516966882543c7)
is permissively MIT-licensed (`COPYING`). This revision has `riva_hw.c` and
`riva_xaa.c` for the older RIVA family, and `nv_hw.c` and `nv_xaa.c` for the
NV-era path. The XAA code is the source-backed 2D implementation family:
solid fills, screen-to-screen copies, and lines. The upstream filename is
`nv_xaa.c`, rather than `nv_accel.c`; it is the matching 2D source for this
version. The tree has no 3D API/backend. NVIDIA's closed-source legacy driver
provided the historical 3D path, but is reference material only and cannot be
ported as permissively licensed source. Do not claim that X.Org `nv` supplies
3D acceleration.

The X.Org chip-generation setup classifies the RIVA generation under
`NV_ARCH_04`; GeForce2 MX/NV11 and GeForce4 MX/NV17 use the `NV_ARCH_10`
register family. `nv_hw.c` contains architecture-specific setup and scanout
programming, and the XAA files implement separate accelerated drawing
operations. This supports distinct NV04 and NV10 modules, not merging them
into the present scanout-only path.

The official package split is useful for matching offline driver references:
71.86 is the branch for the two TNT2 IDs; 96.43 is the branch for the four
GeForce2/4 MX IDs above. CiukiOS currently only changes NVIDIA scanout base;
it does not have NVIDIA 2D or 3D rendering. A possible first native step is to
port only a narrowly scoped XAA solid-fill/copy subset into an independent
backend and keep software rendering for unsupported operations. No NVIDIA
board, register path, 2D engine, or 3D engine has been physically tested or
qualified here. The downloaded Linux packages target historical kernel/X
server combinations; their online availability does not make them compatible
with CiukiOS or current Linux distributions.

The downloaded originals are NVIDIA's [71.86.15 x86 package](https://download.nvidia.com/XFree86/Linux-x86/71.86.15/NVIDIA-Linux-x86-71.86.15-pkg0.run),
[96.43.23 x86 package](https://download.nvidia.com/XFree86/Linux-x86/96.43.23/NVIDIA-Linux-x86-96.43.23-pkg0.run),
and [96.43.23 x86_64 package](https://download.nvidia.com/XFree86/Linux-x86_64/96.43.23/NVIDIA-Linux-x86_64-96.43.23-pkg0.run).
The matching [ForceWare 81.98 release notes](https://download.nvidia.com/Windows/81.98/81.98_ForceWare_Release_Notes.pdf)
document Windows 98/Me, the requested GeForce2/4 MX products, and Direct3D /
OpenGL driver support. NVIDIA's driver notes are not evidence of CiukiOS
acceleration.

## Downloaded reference inventory

Files are stored under ignored `build/research/gpu-vendors/`; they are research
copies and are not release payloads. SHA-256 values pin the exact fetched
contents, including sources fetched from upstream `master` on 2026-10-09.

| File | Origin / license note | SHA-256 |
|---|---|---|
| `Compaq-Armada-E500-Maintenance-Service-Guide.pdf` | Compaq manual mirror; vendor document | `ac197efbd6a64a920a03cf55c202f6a70d15708f2f253676dae40128ec6b4da2` |
| `ATI-RAGE-Pro-Derivatives-Programmers-Guide.pdf` | ATI programmer guide mirror; ATI copyright | `bcb063e6e27f531b1022e8612f05b95ebaea2c69b87669000e481ac0b57a90dc` |
| `xf86-video-mach64-master.tar.gz` | X11Libre/X.Org Mach64 driver snapshot; permissive `COPYING` | `cabf2f868f4c96f8676c8e98c134e202c3b7669cc947f95fab857bbf20e570c2` |
| `linux-mach64-accel.c` | Linux upstream fbdev Mach64 acceleration; GPL-2.0 | `6bd4cae42cbada11c4536040b7dd910252b0698525455a2693c95fb18bda72c6` |
| `linux-nvidia-nv_hw.c` | Linux upstream NVIDIA fbdev hardware setup; GPL-2.0 | `c20e471bb65ce723eaeb34e79e50865409f62299f1b498f30cb041fe49e4543a` |
| `linux-nvidia-nvidia.c` | Linux upstream NVIDIA fbdev; GPL-2.0 | `3ab10b4c2fc0a3d740dcae09c8acdabbde68f5916c3f79857465250383ed0c16` |
| `linux-pci_ids.h` | Linux upstream PCI names/IDs; GPL-2.0 | `020fac001871c0f8441c1294f787231fb6cfbf2c55915ca8f918262e2db4487c` |
| `NVIDIA-Linux-x86-71.86.15-pkg0.run` | Official NVIDIA legacy binary for RIVA TNT/TNT2; proprietary; official MD5 matched | `c4acf9a6e0069b42e984bf6d445f4f7dabfcf2d7ca5c8530c2b638a1fec2fc2e` |
| `NVIDIA-Linux-x86-96.43.23-pkg0.run` | Official NVIDIA legacy binary for GeForce2 MX/GeForce4 MX; proprietary; official MD5 matched | `51e6adf4ba73071622045fc37169f80db3ae3e784dff53b29d35146a04042142` |
| `NVIDIA-Linux-x86_64-96.43.23-pkg0.run` | Official NVIDIA legacy binary; proprietary; official MD5 matched | `f7cf537a0104ce98a301f0a097e26d938d829e9318d420e9bc5d674014b47e27` |
| `NVIDIA-ForceWare-81.98-Windows-Release-Notes.pdf` | Official NVIDIA release notes; documents Win98/Me and GeForce2/4 MX support | `56db1723a65d396e432da16c71c34dc0ebc22438acae2ff703578384eefc3f6a` |
| `xf86-video-nv-8234bcee.tar.gz` | X.Org upstream snapshot at commit `8234bcee52a357c69f2122e5df516966882543c7`; MIT | `9803deb5d09e690c195eefa09c898ee49dd8786e21f144913f5e1f06b51a3696` |
| `xf86-nv-COPYING` | Extracted X.Org license notice | `10d10e1ec37594d481c3de8dda22a40b731ebd43be7ccd462baaa7394738a9f3` |
| `xf86-riva_hw.c` | X.Org RIVA/NV04 hardware setup | `c3d90d9148f62d09386fd442718e38a742ba642055a5f886e84aa128aab62ceb` |
| `xf86-riva_xaa.c` | X.Org RIVA/NV04 XAA 2D acceleration | `cf953941699e7905d61a771e2b631551285b0ee5eb1081f2313ce96e07e7a75b` |
| `xf86-nv_hw.c` | X.Org NV10 hardware setup | `adda43f513140a588e7e7fbe11d990c8a822dae8934ae892c7c5a01a228ff3d6` |
| `xf86-nv_xaa.c` | X.Org NV10 XAA 2D acceleration | `0f1a1b52fab909fb8025db341d1f08602259f6ad18fea94e9f97ca6a4e913105` |

The three NVIDIA binary packages were downloaded from NVIDIA's official
archive and their MD5 values matched the adjacent NVIDIA-published `.md5`
files. They were not executed or installed and are not release payloads. No
kernel tree was cloned and no source was compiled. The Compaq Technical
Reference Guide and ATI Mach64 register reference are linked above; their
download attempts were not retained locally (the Compaq guide mirror failed
TLS hostname validation, and the Mach64 PDF host did not complete within the
bounded request). This does not affect the recorded vendor manual citations.
