# Physical T23 F046 launch audit

Research and decision: 2026-10-08, before implementation.

The `physical-logs-20261008-diskseq63` capture records VM1 generation1,
`observed_exit`, state FREE and exit F046h. No guest video session attached and
no `SYSTEM/VMFORK1.BIN` checkpoint file was found. LOADDRV records the real
S3VBEFIX chain `24FD:0048 -> 2195:0470` on PCI 5333:8C2E. This is physical
evidence of a failed launch, not evidence of DOOM gameplay or a QEMU result.

The [pinned S3VBEFIX source](https://github.com/wbcbz7/S3VBEFIX/blob/5d2a891a8a80e6ef4e6c99cb2f9afe9d39477884/src/S3VBEFIX.ASM)
places the resident header at 40h, handler at 48h and previous INT10 pointer
at 51h. Its installer copies the resident over the upper PSP, sets INT10,
optionally sets INT6D, frees its environment, and terminates resident. The
[author's documentation](https://github.com/wbcbz7/S3VBEFIX/blob/master/README.TXT)
defines the inactive-call flag and last-in-chain requirement. The Microsoft
[MS-DOS 4.0 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
documents the PSP's saved termination/break/error vectors and Keep Process.
These sources support checking exact bytes and vector ownership; they do not
authorize discarding an unknown hook or treating an emulator as the T23.

Repository inspection finds two paths that can report F046h in the captured
VMFORK binary. `move_vector_resident` explicitly sets 46h before testing the
LFN handler's `cmp ah,71h` immediate at PSP:105h. The current LFN binary has
the expected `80 FC 71` instruction. A successful UMB relocation also leaves
46h in `trace_reason`. `vectors_clear_ancestor_refs` can subsequently reject
an IVT pointer into an ancestor-owned allocation without replacing that old
reason. Its documented 3Fh reason is missing from the implementation. Therefore
the physical exit alone cannot identify a corrupt LFN byte.

Decision: restore the specific 3Fh reason on ancestor-vector rejection, keep
the ownership rejection intact, and retain the observed vector target and LFN
immediate in the existing CVFL record's reserved header words. Execute the
actual assembled routine in a CPU fixture with a stale 46h and an IVT reference
into an ancestor allocation, plus an unrelated safe reference. Also exercise
the actual LFN byte rejection. This fixes an independently reproducible
diagnostic defect; it does not establish the underlying physical launch cause.

Because the physical capture has no CVFL file, the manager's existing 16-bit
exit code must also carry the decisive detail. Reserve F100h..F1FFh for reason
3Fh, with the low byte equal to the offending interrupt number; reserve
F200h..F2FFh for reason 46h, with the low byte equal to the observed LFN immediate.
Other preparation failures retain F000h | reason. The parent already persists
this exit value in DOSVM.LOG and CDVS; no new manager API or child file is
required. The detailed CVFL reason and far pointer remain available when its
best-effort file succeeds.

The S3 CPU fixture will also execute the pinned binary's installer subroutine
at COM offset B6Bh, identified by its exact bytes and the pinned source's
`install` routine. This runs the actual resident copy and INT10/optional INT6D
installation, with DOS vector and environment-free calls modeled explicitly.
It does not execute VGA setup or claim S3 hardware behavior. The default
installed resident from that execution feeds guest-detachment checks, using
the latest captured segment tuple 24FD:0048 -> 2195:0470.

Validation: `test_vmfork_launch_diagnostics.py` executes the actual assembled
scan, LFN guard and failure dispatcher. An unsafe INT22 target now returns F122h
with CVFL reason3Fh; a wrong LFN immediate70h returns F270h with reason46h.
Both manager exits are checked again with DOS create forced to fail and no
CVFL bytes written. A target outside ancestor ownership passes. Existing
trace register/FLAGS and unrelated failure-reason checks pass.

`test_vmfork_s3_guest.py` passes the two pinned installer branches, 21
detachment/guard cases, the test shim's environment-free/AH31 lifecycle,
both harmless forwarding branches, and five stale-parent utility cases.
`test_s3_guest_launch_evidence.py` also passes. No full image build, QEMU run,
disk write or T23 retest was performed by this focused audit. The captured
physical F046 remains ambiguous until the detailed failure exit is observed
or another source-grounded reproduction identifies its underlying predicate.

The kernel audit traced the real S3VBEFIX INT27 through LOADDRV's `q_int27`,
which rounds DX to paragraphs and far-jumps to AX=3100h in the current INT21
chain. Its DOS lifecycle therefore reaches the same AH31 path as the console
fixture. There is no evidenced INT27 compatibility gap in this startup path.
