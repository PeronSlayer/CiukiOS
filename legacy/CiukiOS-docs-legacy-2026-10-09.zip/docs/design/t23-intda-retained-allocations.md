# Retain live ancestor allocations in a DOS fork

Research and decision: 2026-10-08, before implementation.

The diskseq64 physical capture reports exit F1DAh: the child found an INTDA
far pointer inside an ancestor-owned DOS allocation before compaction. Its
5974-byte VMFORK matches R6b exactly (SHA256
`6ca57ad35ec73ade0f30fb271493f964cf4cc78d1e41a2a02b6813df70b856fd`).
The S3 chain is still 24FD:0048 -> 2195:0470. No child CVFL file was captured,
so the pointer's exact target and owner are not known from this capture.

The Microsoft [MS-DOS Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
documents far interrupt vectors and the allocation lifetime of resident code.
Microsoft's [MS-DOS 4.0 allocator source](https://github.com/microsoft/MS-DOS/blob/main/v4.0/src/DOS/ALLOC.ASM)
provides the upstream allocation/owner/MCB model used for the lifetime audit.
The vendor [Phoenix System BIOS reference](https://bitsavers.org/pdf/ibm/pc/ps2/bios/System_BIOS_for_IBM_PC_XT_AT_Computers_and_Compatibles_198908.pdf)
describes the vector table and its assignments. Neither supports treating an
arbitrary INTDA target as disposable on the T23. The exact
[Jemm upstream](https://github.com/Baron-von-Riedesel/Jemm/tree/e96bb6bb80cbdc3e6585544db79a6b133a5566dd)
also gives no basis to exempt this vector. The physical slot is 0368h; its
stored segment:offset target is a separate address.

Inspection confirms that `segment + (offset >> 4)` correctly identifies the
target paragraph for conventional memory, including noncanonical segment
aliases. A 16-bit carry can only wrap into paragraphs below 1000h, below the
supported first DOS allocation, and cannot explain this ancestor match.
The existing policy instead makes every such match fatal even when leaving
the referenced memory allocated is possible. The repair retains that memory;
it does not classify INTDA as unused or rewrite its vector.

After read-only root/arena validation, scan the root's proposed reclaimed tail
`[root PSP + 10h, root end)`. A reference skips root compaction before the
staging allocation, copy, resize or PSP rebase. The original VMFORK CS/SS and
kernel current/EXEC PSP therefore remain valid. Keep every ancestor PSP as
before. Also retain the root if a referenced extra allocation belongs to an
ancestor PSP embedded in that tail: the owner PSP is part of the retained
allocation's live context, even without a separate self-owned MCB. For each
extra ancestor-owned allocation considered by cleanup, scan
all 256 IVT far pointers against the complete MCB-header-plus-data interval;
retain that block if any pointer aliases it, and free only unreferenced blocks
through the existing owner-qualified F149h service. Revalidate the bounded
arena before each cleanup sweep. Also validate before the earlier inherited
vector-restoration walk, so malformed arenas fail before that walk mutates any
vector. Refusal of the optional VMM vector snapshot remains a successful skip.
The unreferenced-root compaction path retains
its guard against a newly introduced root-tail reference before shrinking.

This reduces reclamation without increasing any memory limit. Initial total
and largest free paragraphs are measured before preparation; remaining totals
are measured after cleanup. CVFL records the first retained block, owner,
extent, vector and exact target plus retention flags. These are best-effort
child diagnostics, and their presence on a later physical disk is not assumed.
No new VM-manager API is introduced. The system VM's memory is untouched.

The guarantee is the allocation and PSP lifetime of the retained vector
target. This does not identify the T23 handler, prove what it does, or prove
that a game has enough remaining conventional memory; actual EXEC and the
subsequent physical run remain decisive.

Validation: `uv run --with unicorn python scripts/test_vmfork_pinned_ancestors.py
--report build/tests/vmfork-pins-20261008/report.json` passes 30 bounded CPU
cases against the assembled full-profile DOS dispatcher and actual F149 free
implementation, with no allocator mock. Direct and segment-alias references
preserve the root before staging; references to payloads or MCB headers preserve
extra blocks. Indirect references retain an embedded owner PSP and its root.
Mixed cleanup executes the actual free implementation twice, preserves every
pinned block, IVT and PSP context, and reaches the target-launch boundary.
Unrelated BIOS/UMB pointers and a root-owned extra with a surviving root PSP
do not prevent the normal staging entry. Invalid chains fail before vector
restoration or allocation mutation; diagnostic walks leave validity zero and
preserve the original measurements. An optional VMM snapshot refusal returns
success with no DOS calls or state mutation.

Measured fixture free paragraphs, with no ceiling change:

| CPU fixture | Initial total | Remaining total | Initial largest | Remaining largest |
| --- | ---: | ---: | ---: | ---: |
| Separate launcher, mixed pins/free | 31,295 | 31,555 | 11,935 | 11,935 |
| Embedded launcher, mixed pins/free | 33,475 | 33,735 | 11,935 | 12,158 |
| Embedded owner, indirect pin | 33,475 | 33,751 | 11,935 | 11,935 |

These are controlled CPU-fixture measurements, not T23 free-memory values.
The diagnostics, actual pinned S3 installer/guest-detachment, and S3 launch
evidence suites also pass. Physical DOOM execution remains unqualified until
the new image is run and captured on the T23.
