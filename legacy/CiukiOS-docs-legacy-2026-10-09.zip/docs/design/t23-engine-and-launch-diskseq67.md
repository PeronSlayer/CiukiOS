# R9 physical failures: diskseq67

The read-only capture in `build/full/t23-next/physical-logs-20261009-diskseq67/`
matches the installed R9 binaries. The DOS launcher now creates VM1; CVFL
generation1 reaches stage7, target EXEC of `\VM\DPMIRUN.COM`, returning
AX0002/CF1. The file is present with the correct hash. Free memory after
compaction is17182 paragraphs, largest6702. This is a filesystem/EXEC failure
inside the child, not the former launcher allocation failure. Its cause is
being traced before choosing a fix.

S3 setup still stops at predicate3 with a zero 32-bit GBD-high read. R9 sent
the BCI descriptor packets, so changing the write transport did not remove
this result. The previous inference that the write failed to latch was too
strong: the read itself must comply with the register access specification.

## Register access and engine lifecycle

Primary sources checked before implementation:

* [S3 Savage4 register specification, Section7 p129 and pp132–133,148–149](https://bitsavers.org/components/s3/Savage4/RE046-B_Savage4_Registers_199904.pdf):
  the 2D register block requires 16-bit reads, including two adjacent reads
  for a 32-bit register. A 32-bit read has an undefined upper word. CR66 bit0
  and MM850C bit0 enable the drawing engine; a transition requires screen-off
  or vertical retrace. CR66 resets with engine disabled.
* [X.Org Savage2.4.1 source](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz):
  `SavageEnableMMIO` enables register decode through CR40, a distinct step
  from `SavageWriteMode`/mode initialization setting CR66. `SavageSetGBD_PM`
  is the SuperSavage path and uses the common GBD offsets. Merely copying
  `SavageInitialize2DEngine` assumes prior mode initialization.
* [Linux v6.2 Savage framebuffer driver](https://github.com/torvalds/linux/blob/v6.2/drivers/video/fbdev/savage/savagefb_driver.c):
  its GBD command programming also occurs within a complete mode lifecycle,
  not as an isolated guarantee that a firmware graphics mode enabled drawing.

The manual is for Savage4, not SuperSavage. Applying its common-register
read-width rule to SuperSavage is an inference corroborated by the shared
upstream register layout. Neither upstream driver establishes that our exact
32-bit readback was valid. An invalid upper word alone does not prove the
cause of an all-zero read. The physical capture did not record CR66, so its
initial value on the T23 is not claimed as known.

Decision: read the 2D block through two documented 16-bit accesses, preserving
all format/stride checks and exact restoration. Explicitly inspect the engine
enable state; change only CR66 bit0 if necessary, during a bounded vertical
retrace (or an already blanked display). Keep the engine enabled until all
saved registers have been restored; restore its original state before giving
up ownership. A retrace/restore failure must retain ownership and mappings
for recovery. Do not change display clocks, timings, stream addresses, PCI
decode or shadow DMA. The hardware fixture must reject unsupported read
widths and model a firmware mode with the engine disabled, conditions the
previous tests omitted. Private VRAM fill/copy/triangle proofs remain required.

The completed host fixture now passes 102 scenarios under ASan/UBSan, including
rejected enable, absent retrace, failed restoration with retained ownership,
invalid upper-half descriptor reads, and exact recovery. Public draw operations
also refuse CPU fallback when an early failure retains engine ownership before
the rest of the state has been saved. Evidence (with source hashes and the prior
101-case run) is in `build/tests/s3-diskseq67/report.json`. This validates the
specified protocol and failure handling, not execution on the physical GPU.

X.Org's full SuperSavage mode setter also blanks the screen while programming
stream addresses/strides and other scanout state. This backend deliberately
retains the firmware's scanout and does not copy that mode-setting sequence.
The documented CR66 transition itself is synchronized to vertical retrace.
Linux's source comment calls CR40 "Enable 2D engine"; the register manual
specifically calls it engine register I/O access, distinct from CR66 operation
enable. Both bits are handled rather than treating that comment as a substitute
for the register definition.
