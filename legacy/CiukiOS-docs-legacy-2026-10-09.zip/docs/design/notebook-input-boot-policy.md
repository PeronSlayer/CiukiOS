# Notebook input and firmware memory policy

Research and disk evidence, 2026-10-09, before implementation.

The diskseq37 capture is mixed: `DRIVERS/ACTIVE.CFG` identifies the last boot
as `COMPAQ_ES1978`, PCI `125D:1978` and `1002:4C4D`; the retained DOSR records,
S3QUAL and AUDIO.LOG belong to the preceding T23 test. They cannot establish
the Armada's controller timeout or PIC state. No claim is made that a specific
input failure has been proved on that machine.

Persist bounded CIPS snapshots after input-driver startup, after VM-manager
startup and after the first painted desktop. They read PIC masks, i8042 status
(never port60), BIOS keyboard-ring metadata and current input vectors. Capture
is atomic; DOS create/write/close happens afterward in foreground with caller
IF restored. This identifies which startup transition changes ownership on a
machine without COM1, without periodic disk writes or controller commands.

Two repository policies are demonstrably unsuitable for a wider notebook
target. VMSTART currently applies the T23's forced `I=D000-DBFF` UMB window
to every physical machine. The [pinned Jemm reference](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Readme.txt)
defines `I=` as a forced inclusion and warns that including occupied firmware
space causes unexpected results. Preserve this physically exercised T23
profile only for its exact S3 SuperSavage and Intel ICH3 pair. Other physical
machines must let Jemm discover availability in that window, retaining the
existing exclusions and extended-memory ceiling. This changes firmware
ownership policy, not the measured DOS RAM limits or working game launchers.

The desktop also tries the original BIOS keyboard queue only in its safe
video mode. [IBM-compatible INT16 interfaces in SeaBIOS](https://github.com/coreboot/seabios/blob/master/src/kbd.c)
distinguish enhanced and original queue reads; graphics mode has no bearing
on availability of either interface. Always try AH=01/00 when AH=11 reports
an empty queue, without reading a key twice or using a blocking read on an
empty queue.

The native i8042 polls currently expire after a CPU-dependent iteration
count. [SeaBIOS controller waits](https://github.com/coreboot/seabios/blob/master/src/hw/ps2port.c)
allow 10,000 intervals of 50 microseconds, and [Linux i8042](https://github.com/torvalds/linux/blob/master/drivers/input/serio/i8042.c)
also spaces polls by 50 microseconds. Any future replacement must use elapsed
time and preserve keyboard/AUX ownership, IF and caller registers. Do not
lengthen spin counts and describe that as an Armada-specific repair without
an actual controller observation.

The E500's ESS Maestro-2E is not an Intel ICH AC97 DMA controller. Its missing
startup audio remains a separate driver gap; retained successful T23 audio
records cannot certify it. The [Compaq service guide](https://h10032.www1.hp.com/ctg/Manual/c01129749.pdf)
and exact last-boot PCI records identify the machine family, not a universal
audio or input implementation.

## R17: preserve the Armada firmware input backend

The diskseq38 capture confirms the installed R16 bytes. On the latest Compaq
boot all three CIPS records have IRQ1, IRQ12 and the cascade unmasked, stable
kernel IRQ1/IRQ12 vectors, and an empty BIOS keyboard ring. Status `3C` means
OBF and IBF are clear; it does **not** reveal the controller command byte.
The owner observed that the clock continued updating. These observations
exclude a stopped desktop loop and masked PIC lines, but do not prove which
controller command or firmware interaction lost input.

Replace the failing direct-controller backend on this exact observed profile
with the existing firmware backend. Match ATI `1002:4C4D` and ESS `125D:1978`
with subsystem `0E11:B112` using read-only PCI BIOS installation/find/read
services. Subsystem DWORD at offset `2C` is `B1120E11`, with vendor in its low
word. The [PCI BIOS implementation in SeaBIOS](https://github.com/coreboot/seabios/blob/master/src/pcibios.c)
confirms `B101` signature, `B102` vendor/device inputs and returned bus/devfn,
and `B10A` configuration reads. Do not assume a fixed bus/slot, write PCI
configuration, depend on a previous machine's ACTIVE.CFG, or change the T23
input backend. Missing or failed PCI services retain the existing policy.
The probe lives in the full-image loader, which has its own bounded space.
After validation it passes DH=`E5` on a match, DH=0 otherwise, through the
relocation stub. The kernel preserves that boot-only value on its stack until
input startup. Only the exact marker selects firmware; there is no new resident
driver body. The separate [kernel memory migration](modular-kernel-memory.md)
replaces the old fixed SYSVARS boundary with reservations following the actual
core extent. The original floppy profile is not built.

Choose this backend before `ps2_mouse_init` issues AD/A7 or consumes port60.
Relinquish kernel IRQ12 and INT33 ownership using the existing failed-native
handoff. Preserve the saved OEM IRQ12 and route INT15/C2 to OEM firmware.
`INPUTINI.COM` then loads the already included CuteMouse `/P /W /B` module.
Its [upstream BIOS PS/2 implementation](https://github.com/FDOS/mouse/blob/master/ctmouse.asm)
registers a callback with C207 and enables reporting with C200; its PS2 handler
is called by firmware, rather than stealing the raw IRQ12 stream. The local
source and TECHNOTE.TXT document these same services. A successful INT33 reset
after EXEC is required before the helper declares a ready mouse.

This is a deliberate backend replacement that avoids the observed machine's
native controller takeover, not an unmeasured increase in polling time or a
claim that the exact firmware defect has been identified. Validate the actual
assembled selection/handoff, including no native controller I/O on a match,
register/IF/DF preservation, wrong subsystem and BIOS failures, and retained
native behavior otherwise. A generic BIOS-driver runtime regression can check
the existing module lifecycle; it cannot certify the Armada's physical input.
