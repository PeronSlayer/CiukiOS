# Resident LFN module API — 9 October 2026

`LFN.COM` builds independently of `CIUKIDOS.SYS`. Its former generated
`lfn_kernel.inc` imported private kernel labels, the FAT buffer address and
an unrelated `RETF` instruction from the kernel listing. Moving a routine
or enlarging the core therefore invalidated the extension. Public RTSV
service `000Dh` replaces those imports; existing service IDs remain unchanged.

The DOS-facing interface remains the Windows 95 `INT21/71xxh` long-name
API, with a conventional-memory TSR and a separate copy in each DOS VM.
The [original interrupt specification](https://fd.lod.bz/rbil/interrup/dos_kernel/2171.html)
defines carry/error results, unsupported `7100h`, and search-handle closure.
[AH31h](https://fd.lod.bz/rbil/interrup/dos_kernel/2131.html) defines the retained
PSP block in paragraphs; the module continues to discard installation code
and release its environment before staying resident. This is a 16-bit DOS
extension contract, separate from the 32-bit Jemm JLM interface.

[AH34h](https://fd.lod.bz/rbil/interrup/dos_kernel/2134.html) returns the InDOS
pointer and recommends querying it once at startup. CiukiDOS's actual
`int21_get_indos_ptr` returns `ES=CS`; the module uses this segment only as
a candidate for identity/ABI validation. It neither assumes that all DOS
implementations put their kernel there nor accepts the pointer as sufficient
evidence of compatibility. The handler remains unchanged by the new memory
layout. Public balanced enter/leave bridges replace direct writes to InDOS.

## Descriptor contract

The module checks `CIUKIDOS` identity, ABI 2, declared header/image sizes,
the declared RTSV table offset and its complete extent. It accepts additive
service counts and finds ID `000Dh`; it checks that descriptor's ABI 1,
zero reserved word and handler inside the declared core, beyond RTSV metadata.
The call returns `AX=1`, `CX=table bytes`, `DS:SI=CLFN`, carry clear.

| CLFN field | Bytes | Version 1 |
| --- | ---: | --- |
| Signature | 4 | `CLFN` |
| API version | 2 | 1 |
| Total table bytes | 2 | 64 |
| Entry count | 2 | 6 |
| Entry stride | 2 | 8 |
| Flags | 2 | 1 |
| Reserved | 2 | 0 |

Each entry is four words: public ID, ABI version 1, far offset and far segment.
The getter relocates segments from its actual `CS`; no compiled kernel or
FAT-buffer segment is imported by the module. The module validates the
returned segment, complete table extent, unique required IDs, entry versions,
far segments and code offsets before publishing its six cached far targets.
An offset cannot point into CIUKIDOS/RTSV metadata, the CLFN table, or beyond
the declared image. A rejected bind clears every target. Unknown additive
IDs are ignored after validating their common ABI and bounds.

| ID | Public operation | Register/result contract |
| --- | --- | --- |
| 1 | Read one sector | `DX:AX` volume-relative LBA, `ES:BX` 512-byte buffer, CF=error |
| 2 | Write one sector | Same |
| 3 | Flush kernel FAT cache | CF=error; dirty state retained on failed write |
| 4 | Invalidate kernel FAT cache | Clears cached sector/valid/dirty state, CF=0 |
| 5 | Enter DOS operation | Increments InDOS; rejects overflow with CF=1 |
| 6 | Leave DOS operation | Decrements InDOS; rejects underflow with CF=1 |

The six operation bridges preserve input registers and return their status
through carry; flags otherwise are scratch. Read/write wrap the existing
near disk routines in real far procedures, preserving EDD/CHS recovery,
retries, volume offset and private disk-stack behavior. FAT flushing belongs
to the kernel's existing cache implementation rather than duplicate C code
addressing private globals. `LFN.COM` still owns its own VFAT parsing/cache
and uses the original chained INT21 handler for normal 8.3 operations.

## Bounded validation

`scripts/test_lfn_public_abi.py` builds the complete module with Watcom/NASM,
without any kernel listing or private-offset generation, then executes its
actual binder and C-call assembly adapters with Unicorn. Kernel fixtures
include the unchanged production far bridges and the actual kernel FAT flush
body; only disk hardware I/O is modeled. Checks cover malformed ABI/table
extents, invalid far entries, relocation, additive RTSV counts, error
propagation, registers/stack, cache state and balanced InDOS.

The 9 October run rejected 39 malformed contracts. The **same 18,949-byte
module** successfully bound both actual assembled R17 kernels: 43,553 bytes
and 51,745 bytes with the optional 8 KiB growth probe. The report records all
three hashes in `build/tests/lfn-public-abi/report.json`. These are CPU/API
checks, not physical hardware qualification or a claim of new long-name
filesystem coverage. Existing filesystem runtime validation remains relevant.

After introducing DOS-owned interrupt stacks, the same module also binds the
final 49,898-byte core and its 58,090-byte growth probe. The updated report is
`build/tests/lfn-public-abi-r17-final/report.json`; the module hash is unchanged.

Reproduce in a capped scope (this workstation's existing Unicorn environment):

```bash
systemd-run --user --scope -p MemoryMax=256M -p MemorySwapMax=64M \
  -p CPUQuota=100% -- build/tools/setup-audit-venv/bin/python \
  scripts/test_lfn_public_abi.py \
  --kernel build/tests/notebook-input-platform-r17/kernel-r17.sys \
  --kernel build/tests/kernel-layout-growth-r17/kernel-grown.sys
```
