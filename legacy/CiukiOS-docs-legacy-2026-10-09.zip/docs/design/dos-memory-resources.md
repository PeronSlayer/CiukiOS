# DOS memory resource reporting and limits

## Decision

Keep JemmEx's dynamic XMS-backed VCPI allocation enabled. The bare-metal
VMSTART profile now passes `MAX=4194303` as an upper ceiling. Jemm parses this
decimal KiB value into 16-KiB pages, so the effective ceiling is 4 GiB minus
16 KiB. It is safely within the parser's DWORD accumulator. Do not use
`MAX=0` as an automatic-size value: it sets the pool limit to zero; only an
omitted `MAX` gets Jemm's 120-MiB default.

JemmEx bounds the requested `MAX` against its XMS free-memory accounting after
subtracting its initial fixed needs. Crucially, it clips `MaxMem16k` before
computing the size-dependent EMS/VCPI bookkeeping table. That table is sized
from the clipped maximum, so the 4-GiB ceiling does not cause a 4-GiB
bookkeeping allocation on a 512-MiB machine. With no `MIN` and with `NODYN`
absent, Jemm leaves the pool demand-driven. VCPI DE03 further reports only
currently free pool pages plus pages Jemm can still get from XMS, capped by the
remaining configured maximum.

The supported client paths in scope are DOOM through DPMIRUN/HDPMI, which
prefers XMS in VCPI mode, and Wolfenstein 3D in real mode. Those paths can use
the broader physical-memory ceiling without relying on a large VCPI allocation.
Jemm still warns that other DOS extenders can fail when offered too much VCPI
memory; qualify additional extenders before treating them as supported.

After JemmEx and CVSESSION load, VMSTART writes a versioned 32-byte `CDMR`
record to `SYSTEM/DOSMEM.BIN` using the foreground DOS file API. It records
XMS3 largest and total free KiB, VCPI DE03 free 4-KiB pages, and per-query
status/error flags. The record has a separate firmware-ceiling field, left
zero and invalid in version 1; no post-Jemm E820 sum is used as free memory.
`capture_physical_logs.py` copies this file from the read-only mounted volume
and includes its decoded values in the capture manifest. The XMS and VCPI
queries themselves do not allocate pages. The record is a live
snapshot after manager initialization, not the machine's installed-RAM total
and not a promise that the same amount will remain free after a client starts.
Decode a capture with [read_dos_memory.py](../../scripts/read_dos_memory.py).

The separate HDPMI `-x` option remains unchanged. It caps the free-memory amount
reported through DPMI function 0500h; it does not constrain actual allocations.
The default report ceiling is 256 MiB. Preserve that compatibility limit until
DOS clients are qualified with a higher reported DPMI amount. HDPMI can obtain
pages through XMS when running in VCPI mode, so the XMS report is the relevant
live source of its allocatable backing memory; the BIOS map alone is not.

## T23 measurement

The R14 physical capture's E820 map contains 535,166,976 bytes (510.375 MiB)
of page-aligned, enabled type-1 memory above 1 MiB. This is a firmware ceiling,
not post-Jemm free RAM. A physical `DOSMEM.BIN` capture has not yet been
collected, so the T23's actual post-Jemm free XMS and VCPI counts remain
unknown; do not describe 510.375 MiB as free.

`NOEMS` remains as configured. JemmEx's documentation says it installs no EMS
page frame and limits the EMS pool to 8 MiB, while the INT 67h API remains
functional. It does not mean that the VCPI pool is disabled.

## Source evidence

- [Pinned JemmEx command-line options and compatibility notes](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/Readme.txt#L122-L152): `MAX` defaults to 120 MiB, `NODYN` disables dynamic XMS allocation, and large VCPI offers can break some DOS extenders.
- [Pinned JemmEx initialization and MAX clamp](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/INIT16.ASM#L1655-L1759): potential VCPI memory comes from free XMS after base `kbneeded`; a larger `MAX` is lowered to that amount. The parser at [lines 2818-2829 and 3159-3165](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/INIT16.ASM) converts the decimal value to 16-KiB pages, and only the unset sentinel receives the default. The later [bookkeeping calculation and allocation](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/INIT16.ASM#L1764-L1812) use the already-clipped maximum.
- [Pinned JemmEx VCPI DE03 implementation](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/VCPI.ASM#L176-L187) returns free pages in EDX. [The pool calculation](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/POOL.ASM#L104-L121) combines unused pool pages with free XMS pages and caps that sum at the remaining configured maximum.
- [Microsoft XMS 3.0 specification, function 88h](https://ps-2.kev009.com/basil.holloway/ALL%20PDF/Microsoft_XMS_3%5B1%5D.0_Specification.pdf): returns largest and total free extended memory in 32-bit KiB values; function 88h is a query.
- The pinned [Jemm XMS implementation](https://github.com/Baron-von-Riedesel/Jemm/blob/e96bb6bb80cbdc3e6585544db79a6b133a5566dd/src/XMS.ASM#L420-L480) documents AH=88h's `BL` as success/error status, sets `BL=0` after counting free handles, and returns `XMS_ALL_MEM_ALLOCATED` when total free XMS is zero. The query does not allocate; VMSTART can consume `BL` as returned without initializing BX first.
- [Pinned HDPMI 3.24 manual](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HDPMI.TXT): VCPI mode prefers XMS when available; `-x` controls the amount DPMI 0500h reports as free. See also the upstream [VSBHDA extended-memory notes](https://github.com/Baron-von-Riedesel/VSBHDA/blob/main/vsbhda.txt#L170-L190), which explain the 256-MiB default and the soft-report nature of `-x`.
- Local implementation: [VMSTART](../../src/com/vmstart.asm) invokes the read-only manager queries and persistent record writer in [vm_memory_report.inc](../../src/com/vm_memory_report.inc). [read_dos_memory.py](../../scripts/read_dos_memory.py) decodes the record; [capture_physical_logs.py](../../scripts/capture_physical_logs.py) copies and decodes it from a read-only mount. [dosmem_query.asm](../../scripts/fixtures/dosmem_query.asm) is the focused live query fixture, [vm_memory_report_harness.asm](../../scripts/fixtures/vm_memory_report_harness.asm) and [test_dos_memory_queries.py](../../scripts/test_dos_memory_queries.py) execute the production report module under deterministic manager hooks, and [dosmem-v1.hex](../../scripts/fixtures/dosmem-v1.hex) is the decoder fixture. The [memory-capacity probe](../../scripts/fixtures/memory_capacity_probe.asm) and [system monitor](../../src/apps/tasks.c) also exercise XMS3 function 88h.
- [R14 DOS memory budget assessment](../../build/research/r14-dos-memory-budget.md) records the physical map and the distinction between the E820 ceiling and memory available after Jemm/XMS ownership.

## Validation

The VMSTART source and focused query fixture are assembled with NASM. The
decoder fixture validates the signature, flags, counts, and malformed-record
rejection. `test_dos_memory_queries.py` executes the production report
module itself, with only DOS/XMS/VCPI boundaries hooked: success, missing and
old XMS, XMS query error, zero available XMS, absent VCPI, VCPI query error,
open/write/short-write failures, and caller register/segment preservation all
pass. It also verifies that the module makes no XMS allocation calls. The
physical capture now includes `VM/VMSTART.COM` for binary identity checks. No
ten-case JSON report is written to `build/tests/dosmem-queries-r15/report.json`.
The current physical capture is still R14, so the live XMS/VCPI values produced
by this new module have not yet been observed on the T23. The R15 image has not
yet been written to the disk.
