# Wallpaper scheduling and readable desktop captions

## Research and decision (2026-10-08)

[Microsoft's message-loop guidance](https://learn.microsoft.com/en-us/windows/win32/winmsg/using-messages-and-message-queues#examining-a-message-queue)
describes interleaving bounded pieces of long work with input processing.
CiukiOS already implements this protocol: `app_poll` treats result 2 as work
pending without repaint, and the main loop checks input again instead of HLT.
The wallpaper worker incorrectly returned 0 between its eight-read/eight-row
batches. With no other busy application, each batch waited for a later IRQ.
At the BIOS timer rate, a 1448×1086 RGB source and 1024×707 native cache need
96 load polls plus 89 preparation polls (one shared transition), introducing about ten
seconds of waiting independently of disk/CPU speed. Input or other IRQs can
shorten this; it is not a measured physical transfer time.

Keep the existing bounded batches and report 2 while more work is immediately
available. Desktop must preserve this distinct result rather than turning it
into a full-screen repaint. Result 1 still commits visible changes and result 3
still preserves precisely queued HUD damage. Failed allocations or reads must
terminate pending work so the loop can sleep again. Cache paint stays free of
DOS I/O, allocation and resampling.

Use the low word of the read-only BIOS counter at 0040:006C for elapsed work
diagnostics. [RBIL's BIOS data-area reference](https://fd.lod.bz/rbil/memory/other/m0040006c.html)
documents approximately 55 ms updates. This gives coarse elapsed time and
poll counts, not a high-resolution performance claim. Direct reads avoid the
midnight-flag side effect of INT 1Ah/AH=00h. Load and preparation counters are
logged once when their work commits, not from paint or each batch.

The subsequent QEMU measurement reported 120 BIOS ticks across 96 load polls,
with a worst load poll of four ticks (about 220 ms). Therefore the eight-item
batch bound alone is insufficient for input responsiveness. Use one shared
live-timer budget per `EV_POLL`, stopping after a completed 6 KiB chunk or
prepared row as soon as one BIOS tick has elapsed. Preserve the eight-item
upper bound, and defer the preparation phase when loading has exhausted the
same poll's budget. [RBIL's system timer contract](https://fd.lod.bz/rbil/interrup/bios/1a00.html)
confirms the approximately 18.2 Hz granularity and the reason to avoid its
midnight-flag-consuming API. This is a soft budget with approximately 55 ms
granularity plus an indivisible chunk/row operation, not a hard latency
guarantee. Pending work continues to return 2 so the shell checks input and
resumes it without an unnecessary IRQ wait.

[Microsoft ClearType documentation](https://learn.microsoft.com/en-us/windows/win32/gdi/cleartype-antialiasing)
states that subpixel smoothing depends on LCD stripe order and applies to
outline fonts, not bitmap fonts. CiukiOS currently draws bitmap glyphs. An
offset shadow cannot ensure contrast against a detailed photograph; repeatedly
painting more glyph offsets would also multiply text work during composition.
Give each complete wrapped desktop caption a compact opaque dark backing,
with the existing title-color selection treatment. This guarantees the same
foreground/background contrast on every wallpaper, costs one background fill
and one glyph pass, and preserves the approved Tango/portrait artwork, glyphs,
full names and UTF-8 wrapping. This is contrast improvement, not ClearType.

Inline desktop rename uses the shared field input routine for drag selection,
word selection on double click, and the I-beam cursor. Its drawing and hit
rectangle remain the same, so caption backing never covers the editable field.

## Validation

`python3 scripts/test_wallp_cache.py --output build/tests/wallp-scheduling-20261008`
passes all 383 existing production cache/paint cases and 17 header cases. The
new complete 1448×1086-to-1024×707 work case finishes in 184 bounded polls,
advertises pending work between every batch, and requests exactly one commit
repaint. This removes 183 otherwise-idle waits from that simulated path. It
also checks the 48 KiB read limit, at most eight preparation-row writes per
batch, BIOS low-word wrap, maximum-per-poll diagnostics, retained old pixels on
a later read failure, the source-ready repaint without a native compositor
format, and a return to idle after completion/failure. This is
a scheduler-contract measurement, not a T23 elapsed-time result.

After the elapsed-budget refinement,
`python3 scripts/test_wallp_cache.py --output build/tests/wallp-budget-20261008`
retains all 383 pixel/band cases and 17 header cases. With a static simulated
tick it still completes in 184 polls. With one tick charged per completed
chunk/row, it completes in 1475 polls with at most one operation and one tick
per poll, including timer wrap; loading's final poll does no preparation.
Both schedules produce byte-identical native caches. Every intervening poll
reports pending work, completion returns to idle, and the failure/fallback
paths still complete. The production module also compiles under Open Watcom's
normal warnings-as-errors flags. Physical chunk and row time remains subject
to CPU/disk/XMS speed and must be read from the runtime diagnostics.

`python3 scripts/test_desktop_work.py` compiles the production Desktop functions
and actual EV_POLL branch with host boundaries. All nine combinations of helper
idle/commit/pending and desktop idle/full/precise repaint preserve their proper
meaning. Accepted/rejected request generations are also exercised. Twenty-four
caption cases cover selected/unselected, short/wrapped names and bright/dark/
mid-tone starting pixels; every glyph receives a solid contrast backing and
each line uses exactly one text pass. `scripts/test_icon_labels.py` retains its
complete-name, UTF-8 and 800/1024/1280 layout checks. OpenWatcom compiles both
changed C modules with warnings as errors. Full-image compositor checks and
physical elapsed-time measurements remain integration requirements.
