# DOSVM parent launch memory audit

`DOSVM.APP` records a bounded snapshot of its parent DOS VM immediately before
it EXECs `VMFORK.COM`. The audit preserves the parent INTDA vector exactly as
stored in the IVT and records a read-only MCB summary so a later child launch
failure can be compared with the memory state it inherited. It is diagnostic
evidence only; it does not change launch policy, memory ownership, or the VM
manager ABI.

The [Microsoft MS-DOS Encyclopedia, Section II](https://msarchive.pcjs.org/mspl13/msdos/encyclopedia/section2/)
describes conventional memory as a DOS arena of paragraph-sized entries, each
preceded by a header that records size and ownership. The
[MS-DOS 3.3 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref33/)
documents the DOS memory-management calls and paragraph-based allocation
sizes. AH=52h itself is undocumented: the bundled
[FreeDOS kernel INT 21h handler](https://github.com/FDOS/kernel/blob/master/kernel/inthndlr.c)
returns ES:BX pointing at the List of Lists, while its
[List of Lists structure](https://github.com/FDOS/kernel/blob/master/hdr/lol.h)
places the first-MCB segment at offset -2 from that pointer. This matches the
Microsoft-compatible layout used by the existing CiukiDOS arena.

The audit calls only INT 21h/AH=52h. It validates the returned far pointer and
then follows at most 128 conventional MCBs from segment 0040h up to, but not
including, A000h. Each entry must have type `M` or `Z`; the computed next
segment uses 32-bit arithmetic and must advance without crossing A000h. A
complete chain must end in `Z`. Any invalid pointer, entry, extent, or missing
terminal entry produces an `INVALID` record without partial totals.

For a valid chain, the `ROOT` fields describe the first MCB's owner and data
paragraph count. `FREE`, `MAX`, and `USED` are sums of MCB data paragraphs;
they exclude each one-paragraph MCB header. `DA=SSSS:OOOO` reports the exact
segment and offset words read from IVT vector DAh, without canonicalizing the
far pointer. The chain, INTDA words, and totals are all captured before the
first disk log write, so logging does not affect the reported measurements.

A second `Parent DA` record resolves that exact far pointer to its physical
linear address and finds the containing validated MCB interval, including a
target that lies in the 16-byte MCB header. The record includes the MCB segment,
owner, payload paragraph count, and whether the target is in the header or data.
It captures at most 16 bytes, bounded by both that interval's end and A0000h.
Pointers outside conventional memory or outside the validated chain receive an
`INVALID` sample. Equivalent segment:offset aliases therefore identify the same
interval and bytes while the original IVT words remain visible in the record.
The observed vectors `8232:01F0` and `8233:01F0` are both tested against an
arena interval that contains their physical targets.

The host fixture exercises a nonzero caller DS, exact far-pointer preservation,
valid totals, equivalent far aliases, header and data targets, the two observed
DA pointers, a one-byte sample at the conventional-memory boundary, an
out-of-range target, AH=52 failure, invalid List of Lists and first-MCB
pointers, bad MCB type and oversized extent, and the 128-entry traversal bound.
It also asserts that AH=52h is the only interrupt and that no memory reads
occur after logging begins. This is a structural host check, not a DOS runtime
test.
# R12 physical launch and conventional memory (2026-10-09)

The diskseq34 R12 capture confirms successful native ATA binding and a normal
return from DPMIRUN with code 1, not a DOS EXEC error. The user observed the
DOS/4GW banner. Executable, WAD, command interpreter and HDPMI payloads match
the immutable flashed image. The measured largest free conventional block
after compaction is 6,606 paragraphs (105,696 bytes); the full topology and
the game's fatal text are not captured, so this does not prove an OOM cause.

[DOS EXEC](https://www.delorie.com/djgpp/doc/rbinter/id/51/29.html) accepts an
explicit executable and a PSP command tail directly; the caller must release
unused memory. A GUI launch already has an absolute COM/EXE path. DPMIRUN
currently reparses it through another resident COMMAND.COM while that game
runs. Remove that intermediate allocation for plain absolute COM/EXE paths,
preserving working directory, arguments, HDPMI/device lifetime and exit code.
Keep COMMAND.COM for interactive sessions, batch files, extension search,
quoting, environment expansion and shell operators. This is a measured
reduction in memory consumption, not proof of the physical DOS/4GW failure.
Do not free pinned allocations or change conventional/extended memory limits.

R13 retains the child DPMIRUN boundary in `SYSTEM/DPMIRUNn.BIN` separately
from the final VMFORK record. The parent still performs one complete write
and close before acknowledging each held checkpoint; no child disk logger is
introduced. Stages 76 and 77 distinguish DOS EXEC failure from the returned
program status; stage 78 observes the resident DPMI host status. A `DP` marker
in the unused final ten bytes keeps host EXEC AX/FLAGS, host exit AX and the
direct-command flag even after the game returns. HDPMI installation codes
0/1/2 denote its normal resident memory modes; they are not game exit codes.

The assembled CPU fixture preserves original command tails and working-directory
policy, exercises 19 routing cases, both carry branches after EXEC, and host
installation codes 0 through 4 plus EXEC failure. The exact shipped R12 binary
is an independent negative control: it still dispatches COMMAND.COM and loses
the command EXEC AX in the saved boundary. These are launcher contract checks,
not proof of physical DOS/4GW startup success. See
`build/tests/dpmirun-direct-r13/report.json` and the separate
[measured conventional-memory audit](../validation/2026-10-09-t23-r12-conventional-memory-audit.md).

## External direct MCB mutations

The pinned HDPMI 3.24 source contains an optional dynamic TLB allocator in
[`HELPERS.ASM`](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/HELPERS.ASM#L720-L781).
`_AllocDosMemory` follows the DOS List of Lists first-MCB pointer, scans the
physical `M`/`Z` chain, chooses a free block large enough for
`?DYNTLBSIZE`, writes the split MCB headers directly, and assigns the allocated
block to the current PSP (lines 735–770). This allocator is conditional on
`?DYNTLBALLOC`, whose pinned default is enabled, and defaults to
`?DYNTLBSIZE=0FE00h` (65,024 bytes, not 8 KiB) in `HDPMI.INC` lines 69 and
120. The pinned release listing also records those configuration values. The
carve is specifically HDPMI's optional dynamic TLB allocation path; it does
not establish an 8 KiB direct carve.
The repository pins this HX revision in
[`build_hdpmi_host.sh`](../../scripts/build_hdpmi_host.sh#L7-L16).

CiukiDOS's `int21_mem_refresh_owners` at
[`floppy_stage1.asm`](../../src/boot/floppy_stage1.asm#L11740-L11791)
refreshes owner and size only for MCBs whose segments are already represented
in `dos_mem_block_table`. The table rebuild is only a legacy-state sync
([lines 12164–12176](../../src/boot/floppy_stage1.asm#L12164-L12176)), and
`int21_mem_rebuild_chain` reconstructs physical MCB headers from PSP ancestry
and that table ([lines 12693–12789](../../src/boot/floppy_stage1.asm#L12693-L12789)).
The AH=31 resident commit refreshes those existing entries, marks known blocks
belonging to the EXEC owner, and upserts the PSP arena; it does not import
other MCBs owned by that PSP ([lines 11821–11873](../../src/boot/floppy_stage1.asm#L11821-L11873)).
Therefore a valid direct MCB allocation absent from the ledger can be
classified as part of a free gap and overwritten by a later chain rebuild.
This is a generic persistent-foreign-MCB compatibility risk, but no evidence
here proves that it caused the observed DOS/4GW exit code 1.

The bounded actual-kernel fixture at
[`evidence.json`](../../build/tests/external-mcb-r12-regression/evidence.json)
refines that risk. It used the exact shipped R12 kernel SHA-256
`64ab65017f16d612c3b2753ba5fea4f680173dcfd9cad8b43f9f58c2564839d8` and
exercised the actual DOS AH=3Fh/AH=40h dispatchers with 16 KiB transfers while
the 65,024-byte HDPMI buffer was live. Both transfers preserved the MCB header
and payload; neither path called the DOS memory refresh or chain rebuild.
HDPMI frees the dynamic buffer before returning from those handlers
([`INT21API.ASM`](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/INT21API.ASM#L1193-L1269),
[lines 1278–1349](https://github.com/Baron-von-Riedesel/HX/blob/f2276db9accfc57facf2588bc016a27130597bb1/Src/HDPMI/INT21API.ASM#L1278-L1349)).
The normal dynamic-TLB lifetime therefore does not cross the CiukiDOS rebuild
that would destroy it. The same fixture confirms a permanent 8 KiB AH=48h
allocation survives AH=31h, EXEC resident merge, parent restoration and a
subsequent allocation. Its synthetic case where an untracked 65,024-byte
foreign block persists through AH=31h does fail, confirming the generic
invariant risk without reproducing the normal HDPMI file-I/O lifecycle.
No kernel import fix is justified for R13 by this path.

There is no existing full live-chain-to-ledger import helper in this path:
`int21_mem_refresh_owners` is keyed by the ledger entries, while the rebuild
path is ledger-to-chain. A safe design candidate is a bounded, validated scan
of the current MCB chain before any rebuild, importing non-free foreign-owned
blocks as pinned external allocations while preserving all current ledger
entries and refusing mutation if the chain is malformed or the ledger is full.
That requires handling allocations that were freed or resized outside DOS
calls and avoiding duplicate PSP arenas, so it needs a dedicated synthetic
foreign-MCB regression fixture before implementation. It must not infer that
every unknown entry is reclaimable or alter conventional-memory limits.

The fixture's intentionally synthetic persistent-MCB case creates a valid free
MCB, applies the pinned HDPMI carve, leaves its owner nonzero through AH=31h,
then triggers the actual kernel chain rebuild. It verifies header, owner and
payload survival and checks that later CiukiDOS allocation does not overlap.
That contract fails for the direct carve and passes for the tracked AH=48h
control. An 8 KiB direct carve is not established by `_AllocDosMemory` and is
not labeled as an HDPMI reproduction.
