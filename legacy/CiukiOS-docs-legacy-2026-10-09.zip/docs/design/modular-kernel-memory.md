# Modular kernel and conventional-memory layout

Decision before implementation, 2026-10-09. This supersedes the fixed full-
profile addresses in older architecture notes; historical captures stay intact.

The owner explicitly requires room for kernel evolution and independent
modules. R16's resident image uses 43,261 of 43,264 bytes. Increasing only that
limit would overwrite SYSVARS, EXEC snapshots, FAT buffers and the resident
shell. Fresh physical firmware data reports 639 KiB conventional memory and
EBDA at 9FC0; there is no fresh physical game peak-free measurement. Reserving
the whole expanded capacity unconditionally would therefore be unjustified.

## Core extent and memory ownership

Permit a resident core up to 60 KiB (`F000` bytes), at segment `0300`. This is
a real-mode code/data segment limit, not a limit on the complete OS. DOS and
DPMI modules already load separately; future large drivers belong there.
The loader stages the image at `0900`, checks the declared file extent and
service table, and relocates the actual bytes forward from its lower temporary
stub. Even the maximum temporary extent ends at physical `18000`, below the
conventional-memory ceiling. The loader itself is boot-only and overwritten
by relocation; its PCI input-policy module is never part of resident DOS RAM.

Place SYSVARS immediately after the actual core, rounded to a 16-byte paragraph.
Derive all following full-profile reservations from that boundary: SYSVARS
`70` paragraphs; EXEC arena `100`; metadata `100`; FAT scratch `100`; I/O
scratch `30`; environment `50`; then the COM arena. The boot-only Stage2 uses
`20` paragraphs at EXEC+`80`, and is reused for EXEC snapshots only after it
returns. Eleven EXEC frames of `16` paragraphs fit in the arena. Keep the high
legacy MZ slots and heap floor at their existing addresses; the primary MZ
start follows COM by `80` paragraphs. Publish actual reservations, rather than
asking modules to copy these implementation addresses.

[FreeDOS task management](https://github.com/FDOS/kernel/blob/master/kernel/task.c)
uses paragraph allocation, PSP ownership, environment allocation and loader-
supplied process state. Retain those DOS contracts and the existing BIOS/EBDA
upper bound. Changing the core's growth ceiling does not increase guest RAM
limits or justify taking firmware memory. Emit and validate the real layout
on each full build, and test an enlarged core across the former D900 boundary.

## Stable module interfaces

Keep CIUKIDOS ABI2 service IDs 1..11 and their versions. Extend the discoverable
RTSV table with service 12 (memory-layout descriptor) and service 13 (LFN
extension interface). Consumers validate header, actual extent, service ID,
version and entry offset; new services do not move the meaning of old IDs.
The 26-byte image header already contains its table offset. A short jump reaches
a small entry trampoline at offset26, and the table follows at29, avoiding the
old short-jump reach limit as the table grows. Do not infer a handler address
from a private kernel listing.

The memory descriptor `CMLY` has version1, total size, record count and 8-byte
records: kind, segment, paragraph count and lifetime flags. It publishes the
core's actual extent and each reservation, including the explicit temporary
Stage2 overlap and the dynamic COM-arena marker. Service12 returns DS:SI,
CX=size and AX=version, with CF clear. Layout and module bounds are checked
before an image is eligible for a disk write.

Migrate the already separate LFN resident extension away from private symbol
offsets to its public versioned interface. Keep application modules in the
existing `.APP` host ABI, system audio in `SFX.DRV`, and DOS virtualization/GPU
work in the separately loaded protected-mode `CVSESS.DLL` runtime. The existing
S3, Mach64, audio and device backends remain independently testable sources.
CuteMouse remains its own GPL resident module with firmware IRQ ownership.
Splitting source into include files alone is not a separate loaded module.

This migration establishes capacity, memory ownership and a checked import
contract. It does not claim that every remaining core subsystem has already
been extracted or that the physical S3/Compaq failures have been cured.

## Executable boundaries and ownership

```mermaid
flowchart TD
    BOOT["Boot-only FAT16 loader + PCI input policy"] --> CORE["CIUKIDOS.SYS: DOS ownership + RTSV services"]
    CORE --> MAP["CMLY: actual memory reservations"]
    CORE --> LFN["LFN.COM: independent resident VFAT extension"]
    CORE --> SHELL["SHELL.COM: desktop and application host"]
    SHELL --> APPS[".APP modules: Files, Display, editors, media"]
    SHELL --> SOUND["SFX.DRV: system sound transport"]
    SHELL --> VM["Jemm + CVSESS.DLL: isolated DOS sessions"]
    VM --> DEVICES["GPU, audio, disk and timing backends"]
    SHELL --> MOUSE["CuteMouse: OEM BIOS mouse path when selected"]
```

| Boundary | Owns | Import/lifetime rule |
| --- | --- | --- |
| Full boot loader | FAT16 bootstrap and read-only platform identification | No INT20/INT21 ownership; disappears after relocation |
| Resident core | DOS interrupt services, process/MCB state, canonical disk/FAT operations | Validated ABI2 RTSV; actual paragraphs published by CMLY |
| LFN extension | VFAT parsing and its own cache | CLFN version1 far operations; releases installer/environment memory |
| Desktop/application host | Windows, focus, painting, input dispatch | Existing checked `.APP` interface; applications remain separate files |
| Protected-mode session runtime | Guest CPU/device state and virtual devices | Existing JLM/session ABI; no implication of NTVDM architecture |
| Hardware backend | Registers, mappings, private qualification storage | Resource acquisition, bounded proof, restoration and capability publication belong to the owning backend |

Source includes are implementation units, not executable module boundaries.
The core retains one 16-bit code segment. Larger extensions must load in their
own segment or the existing protected-mode runtime and import services through
a validated far interface. Raising the resident-core limit repeatedly is not
the growth mechanism for the whole OS. A service extension preserves existing
IDs/versions, checks full table bounds, and changes dependent build metadata
together; incompatible calling contracts require a new version.

## Independent build and deployment checks

The canonical full build records the exact NASM argument vector in
`build/full/obj/kernel-build-command.json` and emits `kernel-layout.json`.
`make build-kernel-module` recompiles only that component with those recorded
flags. `scripts/build_lfn.sh OUTPUT_DIR` needs no kernel binary or listing.
Both paths validate their own output; neither regenerates wallpapers or ZIPs.

Updating an existing full image is an explicit build-tool operation:

```bash
python3 scripts/build_kernel_component.py \
  --rebuild build/full/obj/kernel-build-command.json \
  --image build/full/ciukios-full.img
```

Image injection rejects mismatched private VM imports or installed module
bytes before invoking mcopy, then reads back and validates the installed core.
It does not write a physical disk. Physical deployment uses a separately
frozen image, serial/disk-sequence checks, a backup and complete readback.
Runtime compatibility checks and physical device qualification remain distinct.

The final R17 core also owns the DOS interrupt execution stacks described in
[DOS system-call stack ownership](dos-system-call-stack.md). The driver
startup reproduction showed why these belong to the kernel: a valid program's
256-byte stack cannot hold the kernel's BIOS/output work. Twelve bounded
512-byte slots support the existing nested EXEC contract; their memory is
included in the actual 49,898-byte resident extent, leaving 11,542 bytes under
the growth ceiling. A 58,090-byte probe validates another 8 KiB of growth.

## Remaining private VM imports

`CVSESSION.DLL` and `VMFORK.COM`/`VMFORK.EXE` still import ten private kernel
offsets for InDOS, FAT-cache state, MCB/PSP state, boot drive, last INT 21h
function and the default IRET stub. The kernel-only rebuild path compares those
offsets with the generated VM-session layout and checks that the image's
CVSESSION/VMFORK files match the current artifacts before replacing the kernel.
If any offset or module differs, rebuild the VM modules and image together;
independent kernel compilation alone does not make those imports public.
