# Conventional-memory resident relocation order

## Evidence and decision (2026-10-09)

The R8b software integration image stopped before DPMIRUN with F048. Its
parent-persisted CVFL identifies stage10, sequence5, INT21 at 21E5:0103, and
the expected LFN signature immediate71. The LFN resident occupies 0451
paragraphs. Its attempted conventional destination839E is above the source,
so VMFORK correctly refuses that move. The original root PSP1180 still has
0F9A paragraphs at this point; it has not yet been shrunk.

The captured `failure-16m.bin` in
`build/full/t23-next/qemu-dos-diskseq65-r8b/` shows Jemm's eight-entry UMB
arena fragmented: its largest free extent is03D4 paragraphs, smaller than
the LFN allocation. Free extents add up to enough memory, but no one extent
fits. The preceding AUXSTACK move obtained DC2C. This is an allocation/order
failure, not a rejected LFN signature or proof of a physical IDE fault.
The earlier and current parent arenas have the same initial conventional
MCB layout. DOSVM grew by93 paragraphs; that alone does not establish why
the UMB arena differed, and no such causal claim is needed for the fix.

Before implementation, the original Microsoft
[MS-DOS 4.0 Programmer's Reference](https://www.pcjs.org/documents/books/mspl13/msdos/dosref40/)
and [allocator source](https://github.com/microsoft/MS-DOS/blob/main/v4.0/src/DOS/ALLOC.ASM)
were checked for allocation and resize semantics: a shrink creates usable
free space, and an allocation needs a contiguous extent. The local
`move_vector_resident` already implements a first-fit conventional fallback,
but `prepare_compaction` called it before releasing the root tail and then
`compact_residents` called it again afterward. The early call made that
existing fallback fail before the intended low gap existed.

The first pass now only validates the two recognized, self-owned AUXSTACK
and LFN residents. It performs all existing extent, ownership and signature
checks and allocates or moves neither resident. After staging VMFORK outside
the old root, checking the whole MCB chain, and rechecking root references,
the existing root resize creates the low gap. The existing second pass then
performs each relocation once and keeps its UMB-first/first-fit fallback.
An unknown signature still stops before root mutation. Any vector into the
root tail still pins it before staging, allocation, or resize. No memory
limits, interrupt routing, global UMB policy or resident whitelist changed.

## Focused validation

`scripts/test_vmfork_low_compaction.py` assembles production VMFORK and the
full-profile DOS kernel, then executes them in a bounded16-bit CPU fixture.
The real INT21 dispatcher, AH48/50/52/58/62, F14A resize, F149 free and MCB
allocator run; only BIOS memory reporting, diagnostic writes and a VMM UMB
entry that always refuses allocation are modeled. The fixture stops before
target EXEC and does not emulate T23 peripherals.

Five cases pass in `build/tests/vmfork-low-diskseq65/report.json`:

* With both UMB requests refused, root size0F9A becomes0010 before either
  request. AUXSTACK moves2195→1191, LFN21E5→11E1, and VMFORK stages at2637
  then rebases to1633. Current and EXEC PSP agree, resident code/signatures
  and IVT offsets survive, the actual F149 frees both old residents and
  both retired VMFORK PSPs, and root/parent ownership remains intact.
  Free memory changes27608→33206 paragraphs in this deliberately fragmented
  synthetic arena; largest free extent stays11935.
* Unknown LFN word, unknown LFN immediate and unknown AUXSTACK signature
  each reject before F14A/F149, UMB claims, or IVT mutation.
* INTDA pointing into the root tail leaves the arena and vectors unchanged
  and makes no staging allocation, UMB claim, resize or free.

The thirty existing retained-allocation cases also pass against the same
production kernel (`build/tests/vmfork-pins-diskseq65-r8c/report.json`).
They cover direct and aliased root references, embedded PSPs, retained
ancestor allocations/owners and malformed arena bounds.

R8c's real full-image software integration additionally launches DOOM twice
from Files, handles gameplay/input/quit and returns exit0. The final PLOG
CVFL is generation2, sequence23, stage8 and reports34862 free paragraphs in
one extent. This is software regression evidence only. The T23 still needs
the new physical run and its resulting checkpoints; the original whole-
system freeze has not yet been localized by these software tests.
