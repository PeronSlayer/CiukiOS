# T23 diskseq 65: identify the failed setup readback

Read-only capture of the exact R7 binaries reports S3QUAL `00150302`, error
0008, after-status stage 3, no commands and no retained engine ownership.
The first twenty restored setup prefixes returned. Prefix 21 combines six
readback predicates; this log cannot identify which one failed. It does not
prove a missing driver, a failed drawing command or an unsupported GPU.

Research before implementation (2026-10-08):

- [X.Org Savage 2.4.1](https://www.x.org/releases/individual/driver/xf86-video-savage-2.4.1.tar.xz),
  `SavageInitialize2DEngine`, explicitly sets CR31=0c before calling
  `SavageSetGBD_PM`; that SuperSavage function later clears bit zero. Reading
  only the latter function would incorrectly suggest our bits 2/3 differ.
- The explicit SuperSavage path uses `BCI_ENABLE_TWISTER=0`, little endian
  zero and BD64=1, so descriptor|1 is the matching GBD encoding.
- The original [S3 Savage4 register reference](https://old.vgamuseum.info/images/stories/doc/s3/savage4_registers.pdf)
  labels the bitplane write mask and global bitmap descriptors read/write.
  Its CR53 controls the old MMIO window, not the new MMIO accesses used here.
  The manual is family documentation; exact SuperSavage setup is checked
  against the explicit upstream branch, not inferred solely from Savage4.
- [Linux Savage fbdev](https://raw.githubusercontent.com/torvalds/linux/v6.2/drivers/video/fbdev/savage/savagefb_driver.c)
  also enables enhanced access and programs plane masks. Its different
  initialization path is not evidence for dropping a predicate on this T23.

Decision: preserve every predicate and hardware write. Tag the first failed
predicate in the high 16 bits of `error_stage`, retaining stage 3 in the low
bits; store the unmasked observed register in `last_status`. Preserve that
evidence across a successful restoration, whose idle poll otherwise overwrites
`last_status`. If restoration itself fails, retain its live failure evidence
and report synchronization stage 8, so an idle-poll value is not mislabeled
as the failed register readback.
The 128-byte status and 192-byte CVGD ABI stay unchanged. The existing durable
qualification after-record carries the detail even when the UI reports 0008.

Readback IDs: 1 control enabled, 2 GBD low, 3 GBD high, 4 CR50, 5 CR31,
6 plane write mask, 7 control disabled before PIO enable (prefix 15).
The decoder reports register, mask, expected and actual values; the expected
GBD derives from recorded pitch/depth. No qualification check is weakened and
no drawing command is submitted following a mismatch. A new T23 capture is
required to select a hardware correction from these observations.
