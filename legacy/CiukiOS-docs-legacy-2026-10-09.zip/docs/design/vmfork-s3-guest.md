# S3VBEFIX in a forked DOS session

Research and decision: 2026-10-08, before implementation.

The diskseq60 physical LOADDRV.LOG records S3VBEFIX changing INT10 from
219D:0470 to 2505:0048. The installed driver matches the pinned upstream
4123-byte binary, SHA256
`4072e46a340ae7d2c0f22d556857a74734b77e46134853d089af30a798d08f3f`.
VMFORK's INT10 resident relocation accepts only the 4Fh-paragraph AUXSTACK
image and its entry signature. A topmost S3VBEFIX therefore cannot pass that
predicate. QEMU's non-S3 profile skips this TSR, so earlier ordinary game
tests did not exercise this hardware-dependent launch path.

The primary [pinned S3VBEFIX source](https://github.com/wbcbz7/S3VBEFIX/blob/5d2a891a8a80e6ef4e6c99cb2f9afe9d39477884/src/S3VBEFIX.ASM)
defines a 40h header, signature `fK`, version 0060h, handler 48h, and the previous
INT10 far pointer at handler+9. Its code installs INT10 and optionally INT6D.
The [author's TSR documentation](https://github.com/wbcbz7/S3VBEFIX/blob/master/README.TXT)
explains the chain and warns that normal unloading must restore device state.
CiukiOS must retain the physical driver for the system desktop. The child
instead uses CVSESSION's virtual video BIOS once DPMIRUN begins; its inherited
physical hardware fix is not a guest video driver.

[DPMI 1.0](https://openwatcom.org/ftp/devel/docs/dpmi10.pdf) distinguishes private
virtual DOS environments and host-managed hardware. Repository inspection
confirms that CVSESSION's VMM_CREATE copies pages 00h..9Fh into separately
committed pages and maps those private pages for the child. IVT, DOS kernel,
MCBs and conventional TSR copies are private; UMBs remain global.

Before compaction, detach only a positively identified pinned S3VBEFIX in
the child conventional-memory copy. Require its exact header/version/handler
prefix, inactive internal-call flag, self-owned valid conventional MCB and
bounded extent, and a known AUXSTACK predecessor. Refuse other IVT references
into the allocation, including the optional INT6D hook. Change the child's
INT10 to that predecessor and release only its validated private TSR block
with the existing CiukiDOS F149h service. Preserve the system VM's vector,
driver block and hardware state: do not invoke S3VBEFIX/R, INT10, VGA ports
or MMIO. An unsupported header/chain remains unavailable and is diagnosed;
do not broaden the existing unknown-resident relocation allowlist.

This is a specific repair for a reproducible rejection predicate. It does
not by itself establish that DOOM plays correctly on the physical T23.
Qualification requires a forced pinned-TSR guest fixture plus original-game
input/exit tests and a subsequent physical capture.
