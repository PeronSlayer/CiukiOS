# Engineering Logbook - CiukiOS Legacy v2

> Chronological engineering record. Older entries retain their original scope; use `../Roadmap.md` and `current-milestones.md` for current status.

## 2026-04-22
1. Decision: full architectural reset toward legacy BIOS x86.
2. Action: previous project state reset for the clean legacy BIOS x86 baseline.
3. Action: new documentation baseline created (architecture, roadmap, AI directives).
4. Action: versioning baseline reset to `pre-Alpha v0.5.0`.
5. Milestone: delivered a BIOS-bootable `floppy` stage0 baseline with a real 16-bit boot sector.
6. Milestone: upgraded floppy QEMU smoke testing to assert a concrete boot marker.
7. Action: defined `DOS Core Specification v0.1` and `DOS Core Implementation Plan v0.1` as the normative project baseline.
8. Milestone: implemented `stage0 -> stage1` chain loading with deterministic sector layout.
9. Milestone: implemented a real-mode Stage1 BIOS monitor with diagnostics for `INT 10h/13h/16h/1Ah`.
10. Milestone: added a minimal Stage1 command loop for runtime bring-up checks (`help`, `cls`, `ticks`, `drive`, `reboot`, `halt`).
11. Milestone: initialized `INT 21h` vector in Stage1 and implemented baseline DOS services (`AH=02h`, `AH=09h`, `AH=4Ch`, `AH=4Dh`) with smoke command `dos21`.
12. Milestone: added first `.COM` execution baseline with PSP-compatible setup and deterministic command `comdemo`.
13. Milestone: added deterministic Stage1 boot selftest path with serial PASS markers for DOS and COM runtime checkpoints.
14. Milestone: introduced `qemu-test-stage1` automated regression and integrated it into `qemu-test-all`.
15. Release: bumped project version to `CiukiOS pre-Alpha v0.5.5` after Stage1 milestone closure.
16. Next step: move from embedded COM payload to FAT-backed `.COM` file loading and execution.
17. Milestone: added `.EXE` MZ runtime baseline in Stage1 with relocation handling and PSP-linked execution path.
18. Milestone: added deterministic `mzdemo` command and serial regression markers integrated in `qemu-test-stage1`.
19. Milestone: added Stage1 `INT 21h` handle-based file I/O baseline (`open/read/close/seek`) with deterministic `fileio` regression marker.
20. Action: expanded Stage1 floppy slot from 6 to 14 sectors to keep Phase 2 runtime growth stable.
21. Milestone: added Stage1 DOS execute baseline (`INT 21h AH=4Bh`) for path-driven `.COM/.EXE` launch.
22. Milestone: switched Stage1 `comdemo` and `mzdemo` validation paths to use DOS `AH=4Bh` execution flow.
23. Milestone: added minimal MCB-compatible header behavior to Stage1 memory services (`INT 21h AH=48h/49h/4Ah`).
24. Milestone: added Stage1 DTA and file search baseline (`INT 21h AH=1Ah/4Eh/4Fh`) with deterministic `findtest` coverage.
25. Milestone: added Stage1 drive/CWD compatibility baseline (`INT 21h AH=19h/0Eh/3Bh/47h`).
26. Milestone: refreshed the Stage1 shell presentation with a boot splash, loading bar, top banner, clearer help surface, and explicit logical root layout.
27. Milestone: kicked off Phase 3 with a Stage1 VGA mode 13h graphics demo plus deterministic `GFX-SERIAL` regression marker coverage.
28. Milestone: extracted reusable Stage1 VGA mode 13h drawing primitives for pixels, horizontal/vertical lines, rectangles, generic line drawing, and bitmap text.
29. Milestone: upgraded the Stage1 graphics smoke path to a non-blocking timer/input-driven demo loop instead of a fixed blocking frame hold.
30. Milestone: introduced a small VDI-like video compatibility layer (`vdi_enter_graphics`, `vdi_bar`, `vdi_box`, `vdi_line`, `vdi_gtext`) as the first bridge toward the desktop runtime rendering path.
31. Action: expanded the Stage1 reserved loader budget from 18 to 20 sectors to keep the new graphics baseline stable in both floppy and full profiles.
32. Milestone: implemented FAT16 multi-sector cluster semantics in Stage1 DOS runtime core paths (`open/read/write/exec`) and fixed root-file load cluster-to-LBA conversion for Stage2 chainload.
33. Milestone: aligned full-profile FAT16 image build with 8-sector cluster geometry, including coherent FAT entries and cluster-based payload placement.
34. Milestone: expanded DOS compatibility with additional `INT 21h` services (`2Ah`, `2Ch`, `33h`, `34h`, `36h`, `52h`, `54h`, `58h`) and minimal `INT 2Fh` multiplex handler.
35. Milestone: corrected `INT 21h` register return behavior for `ES:BX`-based APIs and added serial diagnostics for unsupported DOS calls (`[INT21-UNSUP]`).
36. Milestone: integrated desktop runtime payload in both root and legacy nested layouts in the full image and hardened Stage2 launcher with deterministic trace markers.
37. Action: introduced guarded desktop runtime safe-launch mode (default) to prevent shell hard-hang while preserving an opt-in real execution path for compatibility testing.
38. Action: expanded Stage1 reserved loader budget from 21 to 22 sectors in both full and floppy profiles to absorb DOS runtime completion work.
39. Release: bumped project version to `CiukiOS pre-Alpha v0.5.7` after DOS runtime compatibility expansion and regression validation.
40. Milestone: fixed desktop runtime nested execution path (`display bootstrap -> desktop executable`) with separated MZ load segments, restored parent PSP context after child return, and corrected FAT short-name propagation for DOS find-first compatibility.
41. Milestone: extended DOS heap limit and introduced two-block allocation behavior to improve GEM runtime memory allocation during launch sequence.
42. Action: expanded Stage1 reserved loader budget from 22 to 23 sectors in both full and floppy profiles to keep runtime growth stable.
43. Release: bumped project version to `CiukiOS pre-Alpha v0.5.8` after desktop runtime stabilization work and regression validation.

## 2026-04-23 (continued)
44. Action: restored descriptive shell messages in Stage1 (banner with version, full help listing, readable prompt and error text) after text regression introduced by stage2 overflow fix.
45. Action: expanded Stage1 reserved loader budget from 23 to 24 sectors in both full and floppy profiles, bringing both in sync; floppy was silently overflowing by 330 bytes.
46. Fix: corrected `INT 21h AH=49h` (free) block2 path — `.free_done` was aliased to `.invalid`, causing all block2 free calls to return error 9 instead of success.
47. Fix: added block2 path to `INT 21h AH=4Ah` (resize) — previously only block1 was handled, leaving GEM runtime with inconsistent memory state on resize calls targeting the secondary heap block.
48. Action: created `setup/` installer skeleton — source stubs, build scripts, manifest, and full TODO list for a future DOS-Setup-style multi-floppy + CD-ROM installer project.
49. Fix: improved DOS MCB chain consistency for two-block allocations: block2 now writes a physical MCB header, block1 MCB toggles between `M` and `Z` when block2 is allocated/freed, and `INT 21h AH=52h` now returns a valid first-MCB pointer via List-of-Lists.
50. Fix: upgraded DOS keyboard input services from stubs to BIOS-backed behavior (`INT 21h AH=06h/07h/08h/0Ah` using `INT 16h`), removing forced-CR behavior that could destabilize interactive runtime workloads.
51. Fix: implemented `INT 21h AH=51h` and corrected PSP reporting for `AH=62h` to use `current_psp_seg` instead of stale MZ-only context.
52. Action: enabled full-profile real desktop runtime path by default (`CIUKIOS_STAGE2_AUTORUN=1`) and added explicit Stage2 autorun diagnostics to support deterministic runtime tracing.
53. Release: bumped project version to `CiukiOS pre-Alpha v0.5.9` after desktop runtime probe-path stabilization (carry preservation in DOS I/O tails and special find-next compatibility adjustments).

## 2026-04-24 — Desktop runtime milestone closure (v0.5.9-final)
54. Milestone: completed final gate — 20 QEMU sessions; 100% launch, 100% return-to-shell, 0 hangs → **PASS**.
55. Milestone: completed OG-P1-01 — hardened Stage2 VDI/AES primitives (coordinate clipping, stateful INT33h); added offline validation module for graphics runtime.
56. Milestone: completed OG-P1-02 — long-session soak harness for the full profile; 100 runs × 20 min → **PASS** (0 failures, 0 errors).
57. Milestone: completed hardware lane on physical x86 PC (HP w19 monitor); markers `[HW] PASS: desktop autorun completed` and `[HW] PASS: returned to CiukiDOS shell` observed; evidence committed in `docs/hardware/`.
58. Milestone: completed runtime normalization and launch-order troubleshooting guide.
59. Milestone: completed regression lock with 10 deterministic checks (carry, find-next, alias, memory free/resize, autorun markers) → **PASS** 10/10.
60. Milestone: completed performance baseline + budget framework → **PASS**.
61. Milestone: final validation bundle aggregates gate, acceptance, soak, and hardware evidence; **Verdict: PASS** (label: final-closure-ready).
62. Action: added failure-classification counters to acceptance and soak scripts (`launch_without_return`, `qemu_fail`, `infra_fail`, `unexpected_exit`) for diagnostic precision.
63. Action: added CD-ROM profile scaffolding (`scripts/build_full_cd.sh`, `src/boot/full_cd_mbr.asm`) as foundation for the next distribution milestone.
64. Action: workspace cleanup — removed intermediate QEMU debug logs (~80 files), ~14 stale test-run directories, agent session directories (`Agents/`, `setup/`), debug binary dumps, and obsolete root markdown files.
65. Release: bumped project version to `CiukiOS pre-Alpha v0.5.9-final`; all P0/P1/P2 desktop runtime validation gates closed including real hardware evidence.

## 2026-04-28
66. Milestone: stabilized Stage1 startup path for deterministic shell entry during repeated boot cycles.
67. Fix: hardened prompt, drive, and current-working-directory handling to keep interactive shell state coherent.
68. Fix: enforced cursor placement behavior on line 1 in the shell prompt return flow.
69. Action: improved QEMU stderr diagnostics to accelerate runtime regression triage.

## 2026-04-29
70. Fix: resolved Stage1 DOS command regressions on floppy (FAT12) and full (FAT16) runtime paths.
71. Fix: corrected INT 21h read/write/seek return-value stability to prevent false file-I/O failures in regression flow.
72. Fix: preserved floppy image payload integrity during build by hardening non-truncating write behavior.
73. Release: bumped project version to `CiukiOS pre-Alpha v0.5.2` after Stage1 DOS regression closure and validation.

## 2026-04-30
74. Fix: stabilized Stage1 shell `move/mv` path-command behavior across floppy (FAT12) and full (FAT16) runtime paths.
75. Fix: corrected `INT 21h AH=56h` rename/move handling for deterministic DOS file-move semantics.
76. Validation: reran shell command regression lanes on both profiles after the fix set; outcomes stable.
77. Release: bumped project version to `CiukiOS pre-Alpha v0.5.3` after move/mv + AH=56h closure and regression validation.
78. Decision: formally closed Phase 3 on 2026-04-30 based on v0.5.3 evidence and cross-profile regression stability.
79. Decision: formally closed Phase 3.5 as a FOUNDATION/PLACEHOLDER baseline; setup artifacts were accepted as closure scope by project decision.
80. Transition: activated Phase 4 and moved all remaining executable installer implementation/validation work into the Phase 4 installer execution track.

## 2026-05-01
81. Planning: introduced `docs/external-storage-automount-plan-v0.1.md` to define external storage support scope (USB sticks, additional IDE/SATA disks, floppy automount), drive-letter policy, removable-media change handling, and verification lanes; implementation remains pending.
82. Fix: improved Stage1 shell input stability for hold-key repeat, line wrap, and backspace editing behavior.
83. Fix: stabilized FAT16 shell footer telemetry (`CPU/DSK/RAM`) by correcting refresh logic to prevent stuck runtime stats.
84. Validation: reran cross-profile build/regression lanes (floppy FAT12 + full FAT16) after the stability set with high-level stable outcomes.
85. Release: bumped project version to `CiukiOS pre-Alpha v0.5.4` after shell input and footer telemetry stabilization closure.
86. Fix: resolved the loader exec regression affecting COM demo marker emission in the full stage1 selftest path.
87. Validation: FULL-only gate is green; `scripts/qemu_test_full_stage1.sh` PASS and `scripts/qemu_test_setup_full_acceptance.sh` PASS.
88. Decision: upgraded Phase 3.5 from the 2026-04-30 FOUNDATION/PLACEHOLDER closure to a FUNCTIONAL MVP closure on the FULL-only baseline.
89. Backlog note: advanced installer media targets (multi-floppy flow and extended CD workflow) remain post-MVP items for a later phase.


## 2026-05-03
90. Milestone: closed the Phase 4 installer execution backlog (sections A-F) with deterministic report-contract evidence and scenario validation.
91. Validation: required command suite green in the same cycle: ./scripts/build_full.sh, ./scripts/qemu_test_setup_full_acceptance.sh, and ./scripts/qemu_test_setup_installer_scenarios.sh.
92. Fix: normalized installer manifest media-source reporting with explicit MANIFEST_MEDIA_HEX behavior for normal parse (0001) and raw fallback (0000).
93. Action: added and stabilized installer scenario-matrix validation for success and failure paths in scripts/qemu_test_setup_installer_scenarios.sh.
94. Compatibility: introduced setup COMMAND.COM compatibility stub path (src/com/command_stub.asm) for deterministic installer lane behavior.
95. Documentation: synchronized README.md, Roadmap.md, setup stream docs, and CHANGELOG.md to reflect closed installer scope and active runtime/DOOM scope.

## 2026-05-04
96. Milestone: closed the Phase 4 DOOM gameplay lane; the full FAT16 profile now reaches DOS/4GW, loads `doom.wad`, initializes refresh/playloop/input/sound/HUD/status-bar paths, and renders playable gameplay.
97. Fix: completed the ordered MCB table transition for full-profile INT 21h AH=48h/49h/4Ah memory mutation, with legacy allocation slots retained only as compatibility mirrors.
98. Fix: preserved FAT16 INT 21h read/seek return values across handle-slot cleanup so DOS/4GW observes correct byte counts and file positions.
99. Validation: visual DOOM taxonomy lane PASS using QEMU `-display none` and monitor `screendump`, with gameplay evidence captured at `build/full/doom_post_status_after_rebuild.png`.
100. Validation: project owner manually confirmed DOOM is playable interactively on the generated full-profile image.
101. Documentation: added `docs/phase4-doom-gameplay-playable-2026-05-04.md` and synchronized README, Roadmap, CHANGELOG, and VERSION for the milestone.
102. Release: bumped project version to `CiukiOS pre-Alpha v0.6.1` after Phase 4 gameplay playable closure.

## 2026-05-05
103. Release: bumped project version to `CiukiOS pre-Alpha v0.6.3` after full/full-CD shell, setup, path-case, and drive-semantics stabilization.

## 2026-08-29
104. Release: bumped project version to `CiukiOS pre-Alpha v0.7.1` after the Phase 5 ownership closure, current DOS compatibility work, Costa/WOLF3D integration, and the configurable resident IPv4/ICMP plus FTP networking milestone.

## 2026-08-31
105. Compatibility: stabilized the shared PS/2 mouse route across Costa, DOSNavigator, and Windows 3.1; SDL over verified X11/XWayland is the canonical graphical path, BIOS PS/2 clients own cursor rendering, and Windows callback state is cleared before guest memory is released.
106. DOSNavigator: validated one-row arrow navigation, mouse input, Colors/XMS, durable `EXIT`, and restoration of the CiukiOS shell; the workload remains PARTIAL because its packaged loader hook and broad file/full-CD coverage remain open.
107. Windows: completed the first bounded Phase 9 milestone on `full`: two Windows 3.1 386 Enhanced Mode launches, exactly one moving pointer, Calculator plus task-scoped `Alt+F4`, Program Manager survival, clean shell restoration, and relaunch.
108. Runtime: increased the default VM to 256 MiB, expanded BIOS/XMS-visible memory to approximately 63 MiB, required KVM in canonical interactive runners, and retained explicit `auto`/TCG diagnostic overrides.
109. Documentation: synchronized current milestones, compatibility boundaries, Phase 9 status, and the measured Phase 5 layout (1,542-byte loader; 43,254-byte CIUKIDOS with a 43,264-byte ceiling) without promoting unresolved Doom graphics/audio, WOLF3D patch/full-CD/audio, Phase 6 corpus, or wider Windows work.

## 2026-09-01
110. Runtime validation: replaced the oversized probe-only CIUKIDOS build with a black-box `CIUKRTST.COM` check against the exact canonical 43,254-byte kernel, then derived all eight fatal ABI cases from the same hash-verified image.
111. Networking/EXEC: fixed `NETSTART` as a normal DOS COM parent by relocating its transient stack and releasing unused PSP paragraphs with `AH=4Ah` before nested `AH=4Bh`; added hexadecimal DOS error reporting and revalidated both FTP and ICMP gates.
112. Release: promoted the current milestone ledger to a stable filename, aligned the v0.7.1 documentation to the exact release checkout, and retained Phase 6, Phase 7, broader Phase 8/9, Doom graphics/audio, and WOLF3D generalization as explicit open work.
113. Process compatibility: replaced the setup-only `COMMAND.COM` stub with the functional shell compatibility mode, fixed generic termination for children that change PSP, and removed the unused private keyboard handler; the kernel is now 43,167 bytes on `full` and 43,162 bytes on the D:-default `full-cd` profile under the unchanged 43,264-byte ceiling.
114. DOSNavigator: removed the packaged loader patch, verified the image payload is byte-identical to upstream, switched automation to native `Alt+X`, and proved same-boot ownership, PS/2 callback, and graphics cleanup after navigation, mouse, and Colors/XMS.
115. Doom-vanille: traced striped wall columns to missing upstream Watcom ABI flags rather than a kernel video defect; one-byte structure packing plus the original compiler contract restores HUD and wall textures while the automatic 256 KiB allocation remains green.
116. Validation: added Doom-specific HUD/wall-integrity classification, corrected the serial prompt-return race, removed the visual-over-runtime failure override, and added an objective KVM/WAV non-silent PC-speaker gameplay gate for original Doom.
117. Release discipline: expanded the default aggregate to all locally available Costa, DOSNavigator, WOLF3D, original Doom, doom-vanille, Windows 3.1, CuteMouse, shell/runtime, ABI-negative, and full-CD workloads; installer and networking remain focused lanes.
118. Video recovery: external child return now recreates the complete BIOS mode-03 contract before the shell redraws. The hostile mode-13 exit gate verifies 720x400 text, font/page/cursor state, title bar, and prompt rather than relying on each application to clean up.
119. Audio: all canonical runners expose AdLib/OPL2, SB16, and PC speaker together. Original Doom passes OPL2 music plus PC-speaker SFX; doom-vanille passes OPL2 music plus SB16 SFX with combined DMX return 10 and objective mixed output.
120. Performance: added a measured opt-in `vga-fast` TCG JIT profile for legacy VGA. Doom-vanille improved from 1106 to 172 realtics for 350 gametics, and focused Wolf3D, Costa, DOSNavigator, and Windows 3.1 regressions passed; KVM remains the default because QEMU 11.1 TCG crashes during original Doom gameplay and `tcg-safe` is too slow.
121. Windows memory: replaced the installed 640/128 KiB conventional and 1 MiB EMS/XMS PIF limits with generated all-available profiles. DOSMGR synthetic PSPs now receive a generic conventional arena, with no executable-name or Doom-specific PIF rule.
122. Windows process cleanup: traced post-MIDI Doom “memoria insufficiente” to a leaked fifth EXEC frame. Windows now records its four-frame startup baseline and independently unwinds every later Win16 or secondary-DOS-VM frame, while preserving the system VM and task-scoped `Alt+F4` behavior.
123. Windows validation: proved generic `COMMAND.COM` enter/exit, non-silent advancing `CANYON.MID` through native AdLib, unprofiled DOS/4GW Doom launch/exit with dynamic memory, Calculator `Alt+F4`, Windows exit, DOS mouse recovery, and a second Enhanced Mode launch in one boot. DOSNavigator, Costa/Calculator, and external CuteMouse regressions remained green.

## 2026-09-26
124. Native desktop: integrated BIOS-text DOS windows, graphical file/media browsing, wallpaper catalog/import, licensed event sounds and cooperative preview keyboard fixes; original DOS graphics virtualization remains open.
125. Validation: archived eleven focused QEMU reports for image `08bc6df6510e55e3f501d49f9414e2d0f0a2006eccdda5dbf8f78bdc1e244bd6` in `validation/2026-09-26/`, including actual input, file hashes, framebuffer pixels, PCM and interrupt/device restoration. No physical hardware acceptance is inferred.
126. Publication: synchronized current documentation, retained dated investigations as historical evidence, preserved upstream licenses and excluded personal Windows wallpaper inputs and generated caches.
127. Next implementation: original-binary DOS sessions require a V86 monitor, virtual video/input, protected-mode presentation and coordinated DPMI/audio ownership; cooperative source ports do not satisfy that requirement.
