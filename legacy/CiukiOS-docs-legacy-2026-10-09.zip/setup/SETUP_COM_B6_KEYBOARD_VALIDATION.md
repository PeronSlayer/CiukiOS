# SETUP.COM Phase 4 Block B6 Keyboard Validation

## Current Status

This matrix is a normative keyboard contract with sampled runtime evidence, not a completed per-case validation bundle. None of the unchecked placeholders below should be cited as PASS. The accepted installer MVP closure remains historical and scoped; completing this matrix is post-closure hardening and a prerequisite for any later claim of exhaustive keyboard coverage.

## Validation Mode
- Baseline type: `document baseline + targeted runtime evidence`
- Runtime execution: `executed via scripts/qemu_test_setup_installer_scenarios.sh (2026-05-03)`
- Scope: keyboard navigation expectations for screens B1-B5, with sampled runtime coverage on critical paths.

## Expected Key Semantics
- `Up/Down`: move focus between selectable options where lists/actions exist.
- `Enter`: confirm focused action and execute deterministic transition.
- `Esc`: deterministic back/cancel according to current screen/state rules.
- `Retry path`: available in error/recovery prompts only.

## Expectation Matrix (Baseline + Runtime Sample Coverage)
Table rows remain the normative keyboard contract. Runtime evidence is currently sampled on critical flows; full per-row evidence remains part of post-closure hardening.

| Case ID | Screen | Key(s) | Expected behavior | Baseline status | Runtime evidence placeholder |
|---|---|---|---|---|---|
| `KB-B1-01` | `B1_WELCOME` | `Enter` | Transition Next to `B2_COMPONENT_SELECT`. | Defined (per-case evidence pending) | `[ ] Attach transition log` |
| `KB-B1-02` | `B1_WELCOME` | `Esc` | Open cancel confirmation; abort on confirm. | Defined (per-case evidence pending) | `[ ] Attach cancel prompt screenshot` |
| `KB-B2-01` | `B2_COMPONENT_SELECT` | `Up/Down` | Move selection across `Minimal/Standard/Full`. | Defined (per-case evidence pending) | `[ ] Attach selection movement log` |
| `KB-B2-02` | `B2_COMPONENT_SELECT` | `Enter` | Persist profile and transition Next to `B3_TARGET_SELECT`. | Defined (per-case evidence pending) | `[ ] Attach profile persistence log` |
| `KB-B2-03` | `B2_COMPONENT_SELECT` | `Esc` | Transition Back to `B1_WELCOME`. | Defined (per-case evidence pending) | `[ ] Attach back transition log` |
| `KB-B3-01` | `B3_TARGET_SELECT` | `Up/Down` | Move selection across eligible target drives. | Defined (per-case evidence pending) | `[ ] Attach drive cursor log` |
| `KB-B3-02` | `B3_TARGET_SELECT` | `Enter` | Open destructive confirmation for selected drive. | Defined (per-case evidence pending) | `[ ] Attach confirmation screen evidence` |
| `KB-B3-03` | `B3_TARGET_SELECT` | `Esc` | Transition Back to `B2_COMPONENT_SELECT`. | Defined (per-case evidence pending) | `[ ] Attach back transition log` |
| `KB-B3-04` | `B3_TARGET_ERROR` | `Enter` on Retry | Retry target detection and return to `B3_TARGET_SELECT` on success. | Defined (per-case evidence pending) | `[ ] Attach retry attempt log` |
| `KB-B4-01` | `B4_PROGRESS` (`B4_PREWRITE_READY`) | `Enter` on Start copy | Transition to `B4_PROGRESS` (`B4_RUNNING`). | Defined (per-case evidence pending) | `[ ] Attach start-copy transition log` |
| `KB-B4-02` | `B4_PROGRESS` (`B4_PREWRITE_READY`) | `Esc` | Transition Back to `B3_TARGET_SELECT`. | Defined (per-case evidence pending) | `[ ] Attach prewrite back transition log` |
| `KB-B4-03` | `B4_PROGRESS` (`B4_RUNNING`) | `Esc` | Open `Cancel Setup` prompt; abort setup on confirm. | Defined (per-case evidence pending) | `[ ] Attach running cancel flow log` |
| `KB-B4-04` | `B4_PROGRESS` (`B4_COMPLETE`) | `Enter` on Next | Transition Next to `B5_COMPLETE`. | Defined (per-case evidence pending) | `[ ] Attach complete-next transition log` |
| `KB-B4-05` | `B4_PROGRESS` (`B4_COMPLETE`) | `Esc` | Transition Back to `B4_PROGRESS` read-only summary (`B4_COMPLETE`). | Defined (per-case evidence pending) | `[ ] Attach complete back transition log` |
| `KB-B4-06` | `B4_PROGRESS_RETRY_PROMPT` | `Up/Down` | Move action focus across `Retry/Back/Cancel Setup`. | Defined (per-case evidence pending) | `[ ] Attach action focus log` |
| `KB-B4-07` | `B4_PROGRESS_RETRY_PROMPT` | `Enter` on Retry | Retry current failed copy step and return to `B4_PROGRESS`. | Defined (per-case evidence pending) | `[ ] Attach retry transition log` |
| `KB-B4-08` | `B4_PROGRESS_RETRY_PROMPT` | `Esc` or Back | Return to previous safe screen per rollback rule. | Defined (per-case evidence pending) | `[ ] Attach rollback decision log` |
| `KB-B5-01` | `B5_COMPLETE` | `Enter` | Transition Next to stream C handoff step. | Defined (per-case evidence pending) | `[ ] Attach handoff transition log` |
| `KB-B5-02` | `B5_COMPLETE` | `Esc` | Transition Back to `B4_PROGRESS` read-only summary. | Defined (per-case evidence pending) | `[ ] Attach completion back transition` |
| `KB-B5-03` | `B5_FAILURE` | `Up/Down` | Move action focus across `Retry/Back/Cancel Setup`. | Defined (per-case evidence pending) | `[ ] Attach failure action focus log` |
| `KB-B5-04` | `B5_FAILURE` | `Enter` on Retry | Retry failed step when class is recoverable. | Defined (per-case evidence pending) | `[ ] Attach recoverable retry log` |
| `KB-B5-05` | `B5_FAILURE` | `Esc` or Back | Return to `B4_PROGRESS` or `B3_TARGET_SELECT` per safe state. | Defined (per-case evidence pending) | `[ ] Attach safe-state back transition` |

## Remaining Runtime Verification Items
- Expand from sampled coverage to per-case evidence for every matrix row.
- Verify key capture hooks emit one event per keypress for B1-B5.
- Verify action resolution hooks map keypress to deterministic action ids.
- Verify transition hooks report correct `from/action/to` tuples for all documented cases.
- Verify retry hook increments retry count and persists status code across attempts.
- Capture dedicated evidence artifacts (screenshots/log extracts) for all placeholders in this matrix.

## Covered runtime evidence snapshot (2026-05-03)
- `success_minimal` scenario: validated `Down/Up/Enter` navigation path through component/flow progression and successful completion.
- `failure_missing_media` scenario: validated retry-path interaction and `Esc` cancellation behavior in failure handling.
- `failure_media_swap_timeout` scenario: validated timeout-safe behavior for media-swap wait states.
